const vappBaseUrl = 'https://vapp.in/api/'
const vapp_api_key = 'API_KEY'
const SESSION_KEYS = {
    EXPIRATION_TIME: 'VApp_expirationTime',
    SESSION_ID: 'VApp_sessID'
}
let vappPingInterval
let vappIsTabActive = true
let vappStartTime = performance.now()
const vappMaxRetries = 5
let vappRetryCount
let vappEngagementID
let vappCampaignID
let vappRequestID
let vappSessID
let vappPrevEventName
let vappPrevEventTime
let vappPendingEvents = []
let vappTotalTime = 0
let vappTimeLimit = 360000

document.addEventListener('visibilitychange', () => {
        vappIsTabActive = document.visibilityState === 'visible'  
})

function extractSessionID() {
    const windowURl = new URL(window.location.href)
    vappSessID = windowURl.searchParams.get('vapp_sid') ? windowURl.searchParams.get('vapp_sid').trim() : getCookie(SESSION_KEYS.SESSION_ID)
    if (!vappSessID || vappSessID === '') {
        clearCookies()
    } else { 
        setCookie(SESSION_KEYS.SESSION_ID, vappSessID, 1)
    }
}

function analytics() {
        vappRetryCount = !vappRetryCount ? 0 :  vappRetryCount++
        if (vappRetryCount > vappMaxRetries) {
            return
        }
        extractSessionID();
        if (vappSessID && vappSessID !== '') {
            getExpirationTime(vappSessID).then((expirationTime) => {
                if (!expirationTime) {
                    analytics()
                    return
                }
                if (expirationTime === -1) {
                    return
                }
                setCookie(SESSION_KEYS.EXPIRATION_TIME, expirationTime, 1)
                vappEngagementID = !vappEngagementID ? uuidv4() : vappEngagementID
                vappStartTime = performance.now()
                 sendPing(true)
                    vappPingInterval = setInterval(() => {
                        sendPing(false)
                    }, 5000)
                }).catch(() => {
                    analytics()
                })
        }
}

function getExpirationTime(sessID) {
    return new Promise((resolve, reject) => {
        const xmlhttp = new XMLHttpRequest()
        const connectUrl = `${vappBaseUrl}interaction/expiry/${sessID}`
        xmlhttp.open('GET', connectUrl)
        xmlhttp.setRequestHeader('Content-Type', 'application/json')
        xmlhttp.onreadystatechange = (e) => {
            if (xmlhttp.readyState === XMLHttpRequest.DONE) {
                if (xmlhttp.status === 200) {
                    const response = JSON.parse(xmlhttp.responseText)
                    if (!response) {
                        reject()
                    } else if (!response.data.expiration) {
                        clearCookies()
                        reject()
                    } else if (new Date() > new Date(response.data.expiration * 1000)) {
                        clearCookies()
                        resolve(-1)
                    } else {
                        vappRequestID = response.data.requestID
                        vappCampaignID = response.data.campaignID
                        if (!vappRequestID || !vappCampaignID) {
                            reject()
                        }
                        resolve(response.data.expiration)
                    }
                } else {
                    reject()
                }
            }
        }
        xmlhttp.send()
    })
}

function sendPing(isFirst) {
    const expirationTime = getCookie(SESSION_KEYS.EXPIRATION_TIME)
    if (!getCookie(SESSION_KEYS.SESSION_ID) || !getCookie(SESSION_KEYS.EXPIRATION_TIME)) {
        clearCookies()
        clearInterval(vappPingInterval)
        analytics()
    }
    if (new Date() > new Date(expirationTime * 1000)) {
        clearCookies()
    }
    if (!document.hidden && vappIsTabActive) {
        let time = performance.now() - vappStartTime
        vappTotalTime += time
        if(vappTotalTime>vappTimeLimit){
            clearCookies()
            clearInterval(vappPingInterval)
        }
        if(isFirst){
            time = 0
        }
        sendPingData(time).then(() => {}).catch((error) => {})
    }
    vappStartTime = performance.now()
}

function sendPingData(time) {
    return new Promise((resolve, reject) => {
        const xmlhttp = new XMLHttpRequest()
        const connectUrl = `${vappBaseUrl}interaction/engagement`
        xmlhttp.open('POST', connectUrl)
        xmlhttp.setRequestHeader('Content-Type', 'application/json')
        xmlhttp.onreadystatechange = (e) => {
            if (xmlhttp.readyState === XMLHttpRequest.DONE) {
                if (xmlhttp.status === 200) {
                    resolve()
                } else {
                    reject()
                }
            }
        }
        xmlhttp.send(JSON.stringify({
            requestID: `${vappSessID}`,
            engagementID: `${vappEngagementID}`,
            time
        }))
    })
}
var eventTracker = debounce(vappEventTracker, 100);

async function vappEventTracker(eventName, identification) {
    eventName = eventName.toUpperCase().split(' ').join('_')
    if (!vappSessID) {
        extractSessionID()
    }
    if ((!vappCampaignID || !vappRequestID) && vappSessID) {
        await getExpirationTime(vappSessID)
    }

    if (!vappEngagementID) {
        vappPendingEvents.push({ vappSessID, vappRequestID, vappCampaignID, vappEngagementID, eventName, identification })
    } else {
        postEvent(vappSessID, vappRequestID, vappCampaignID, vappEngagementID, eventName, identification).then(() => {
        }).catch((error) => {})
    }
}

function postEvent(shortID, requestID, campaignID, vappEngagementID, eventName, identification) {
    return new Promise((resolve, reject) => {
        const xmlhttp = new XMLHttpRequest()
        const connectUrl = `${vappBaseUrl}interaction/interaction-event`
        xmlhttp.open('POST', connectUrl)
        xmlhttp.setRequestHeader('Content-Type', 'application/json')
        xmlhttp.onreadystatechange = (e) => {
            if (xmlhttp.readyState === XMLHttpRequest.DONE) {
                if (xmlhttp.status === 200) {
                    resolve()
                } else {
                    reject()
                }
            }
        }
        xmlhttp.send(JSON.stringify({
            requestID: `${requestID}`,
            engagementID: `${vappEngagementID}`,
            shortID: `${shortID}`,
            campaignID: `${campaignID}`,
            event: `${eventName}`,
            identification: `${identification ? identification : null}`
        }))
    })
}

function clearCookies() {
    deleteCookie(SESSION_KEYS.EXPIRATION_TIME)
    deleteCookie(SESSION_KEYS.SESSION_ID)
}

function debounce(func, wait, immediate) {
    var timeout;
    return function executedFunction() {
        var context = this;
        var args = arguments;

        var later = function () {
            timeout = null;
            if (!immediate) func.apply(context, args);
        };
        var callNow = immediate && !timeout;
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
        if (callNow) func.apply(context, args);
    };
};

function uuidv4() {
    return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
      (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
    );
  }
function setCookie(cName, cValue, expDays) {
    let date = new Date();
    date.setTime(date.getTime() + (expDays * 24 * 60 * 60 * 1000));
    const expires = "expires=" + date.toUTCString();
    document.cookie = cName + "=" + cValue + "; " + expires + "; path=/";
}
function getCookie(cName){
    var cookiestring  = document.cookie;
    var cookiearray = cookiestring.split(';');
    for(var i =0 ; i < cookiearray.length ; ++i){ 
        if(cookiearray[i].trim().match('^'+cName+'=')){ 
            return cookiearray[i].replace(`${cName}=`,'').trim();
        }
    } return null;
}
function deleteCookie(name) {
    document.cookie = name + '=;expires=Thu, 01 Jan 1970 00:00:01 GMT;';
};
analytics()