#!/bin/bash

branch=$1
if [ -z "$branch" ]; then
    echo "Branch name is required as first parameter."
    exit
fi
echo "Using branch- $branch to deploy dev.vapp.in"

echo "Connecting to dev machine and firing remote command..."
ssh -i "../.keys/DevEnvironment.pem" -t ubuntu@ec2-65-2-55-210.ap-south-1.compute.amazonaws.com "cd codebase/backend && git reset --hard && git fetch && git checkout $branch && git pull  --allow-unrelated-histories && sudo bash ./deployment/start_dev.sh"
