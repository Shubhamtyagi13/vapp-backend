#!/bin/bash
CURRENT_IMAGE_ID=$(sudo docker images vapp/backend_dev -q --no-trunc)
echo "Stopping and removing the previous containers"
sudo docker ps -a | awk '{ print $1,$2 }' | sort -k2 | grep -m 1 vapp/backend_dev | awk '{print $1 }' | xargs -t -I {} sudo docker stop {}
sudo docker ps -a | awk '{ print $1,$2 }' | sort -k2 | grep -m 1 vapp/backend_dev | awk '{print $1 }' | xargs -t -I {} sudo docker rm {}
echo $(sudo docker ps -al)
echo "Previous container cleared. Building the docker image"
sudo docker build -t vapp/backend_dev -f ./Dockerfile .
echo "Image Ready. Starting the new container"
sudo docker run -d -v "$(pwd)"/uploads:/usr/src/app/uploads --restart unless-stopped --network="host" vapp/backend_dev
echo "Removing the older image"
sudo docker rmi $CURRENT_IMAGE_ID
sudo docker image prune --force --filter "until=24h"