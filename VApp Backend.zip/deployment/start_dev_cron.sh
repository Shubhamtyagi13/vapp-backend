#!/bin/bash
PROCESSOR=$1
if [ -z "$PROCESSOR" ]; then
    echo "PROCESSOR name is required as first parameter."
    exit
fi
DOCKER_FILE=DockerfileCron
if [ "$PROCESSOR" == "CREATE_WHATSAPP_CAMPAIGN" ]
then
    DOCKER_FILE=DockerfileWhatsappCron
fi
CONTAINER_NAME=$(echo "$PROCESSOR" | tr '[:upper:]' '[:lower:]')
CURRENT_IMAGE_ID=$(sudo docker images vapp/backend_dev_$CONTAINER_NAME -q --no-trunc)
echo "Stopping and removing the previous containers"
sudo docker ps -a | awk '{ print $1,$2 }' | sort -k2 | grep -m 1 vapp/backend_dev_$CONTAINER_NAME | awk '{print $1 }' | xargs -t -I {} sudo docker stop {}
sudo docker ps -a | awk '{ print $1,$2 }' | sort -k2 | grep -m 1 vapp/backend_dev_$CONTAINER_NAME | awk '{print $1 }' | xargs -t -I {} sudo docker rm {}
echo $(sudo docker ps -al)
echo "Previous container cleared. Building the docker image"
sudo docker build -t vapp/backend_dev_$CONTAINER_NAME  -f ./$DOCKER_FILE . --build-arg cron=$PROCESSOR
echo "Image Ready. Starting the new container"
sudo docker run -d -v "$(pwd)"/uploads:/usr/src/app/uploads -v "$(pwd)"/tokens:/usr/src/app/tokens --restart unless-stopped --network="host" vapp/backend_dev_$CONTAINER_NAME
echo "Removing the older image"
sudo docker rmi $CURRENT_IMAGE_ID
sudo docker image prune --force --filter "until=24h"