

#!/bin/bash
branch=$1
if [ -z "$branch" ]; then
    echo "Branch name is required as first parameter."
    exit
fi
echo "Using branch- $branch to deploy dev.vapp.in"

echo "Connecting to dev machine and firing remote command..."

options=(CREATE_SMS_CAMPAIGN CREATE_DELIVERY_REPORT UPLOAD_DELIVERY_REPORT CREATE_CAMPAIGN_REPORT CREATE_REPORT ENGAGEMENT_TRACKING PROCESS_INTEGRATIONS CREATE_WHATSAPP_CAMPAIGN CREATE_DRIP_SMS_CAMPAIGN CREATE_DRIP_WHATSAPP_CAMPAIGN UPLOAD_CLIENT_CONTACTS IVR_WEBHOOK IVR_WEBHOOK_FINALIZE CREATE_RBM_CAMPAIGN)
for PROCESSOR in "$@"
do
    if [[ "${options[@]}" =~ $PROCESSOR ]]; then
        echo "Deploying service - $PROCESSOR"
        ssh -n -i "../.keys/DevEnvironment.pem" -t ubuntu@ec2-65-2-55-210.ap-south-1.compute.amazonaws.com "cd codebase/backend && git reset --hard && git fetch && git checkout $branch && git pull  --allow-unrelated-histories && sudo bash ./deployment/start_dev_cron.sh $PROCESSOR"
    fi
done
