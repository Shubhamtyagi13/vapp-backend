const _ = require('lodash')
const ObjectId = require('mongodb').ObjectId
module.exports = {
    async up(db, client) {
        const requests = await db.collection('requests').find({ engagementLevel: 0 })
        let a = 0
        let total = await requests.count()
        console.log('total ' + total)
        await requests.forEach(async(request) => {
            a = a + 1;
            let engagementLevelObject = {}
            let requestEngagementUpdateObject = {}
            let engagementTotal = _.sumBy(request.engagementTime, 'time')
            // Decide the engagement Level as well as engagement quality (omega))
            if (_.gte(engagementTotal, 0)) {
                requestEngagementUpdateObject = {
                    engagementLevel: 1
                }
                engagementLevelObject = {
                    negativeCount: 1,
                    neutralCount: 0,
                    positiveCount: 0
                }
            }
            if (_.gte(engagementTotal, 30000)) {
                requestEngagementUpdateObject = {
                    engagementLevel: 2
                }
                engagementLevelObject = {
                    negativeCount: 0,
                    neutralCount: 1,
                    positiveCount: 0
                }
            }
            if (_.gte(engagementTotal, 60000)) {
                requestEngagementUpdateObject = {
                    engagementLevel: 3
                }
                engagementLevelObject = {
                    negativeCount: 0,
                    neutralCount: 0,
                    positiveCount: 1
                }
            }
            // update the request engagement level inside the request object
            await db.collection('requests').updateOne({ _id: request._id }, {
                $set: requestEngagementUpdateObject
            })
            const dashboardTrendingStore = await db.collection('trends').findOne({
                clientID: request.clientID,
                year: request.year,
                month: request.month
            })
            const project = await db.collection('projects').findOne({
                "_id": ObjectId(request.projectID)
            })
            const campaign = await db.collection('campaigns').findOne({
                    "_id": ObjectId(request.campaignID)
                })
                // If the dashboard trebdubg store empty then skip
            if (_.isNil(dashboardTrendingStore)) {

            } else {
                let dashboardTrendingProjects = []
                if (!_.isNil(dashboardTrendingStore.trendingProjects) && dashboardTrendingStore.trendingProjects.length > 0) {
                    dashboardTrendingProjects = dashboardTrendingStore.trendingProjects
                }
                const requestProjectIndex = _.findIndex(dashboardTrendingProjects, (_project) => _.eq(_project.projectID, request.projectID))
                if (_.eq(requestProjectIndex, -1)) {
                    const trendingProjectObject = {}
                    trendingProjectObject.projectID = request.projectID
                    trendingProjectObject.projectName = project.name
                    trendingProjectObject.engagementSum = engagementTotal
                    trendingProjectObject.negativeCount = engagementLevelObject.negativeCount
                    trendingProjectObject.neutralCount = engagementLevelObject.neutralCount
                    trendingProjectObject.positiveCount = engagementLevelObject.positiveCount
                    dashboardTrendingProjects.push(trendingProjectObject)
                } else {
                    dashboardTrendingProjects[requestProjectIndex].engagementSum += engagementTotal
                    dashboardTrendingProjects[requestProjectIndex].negativeCount += engagementLevelObject.negativeCount
                    dashboardTrendingProjects[requestProjectIndex].neutralCount += engagementLevelObject.neutralCount
                    dashboardTrendingProjects[requestProjectIndex].negativeCount += engagementLevelObject.positiveCount
                }
                let dashboardTrendingTemplates = []
                if (!_.isNil(dashboardTrendingStore.trendingTemplates) && dashboardTrendingStore.trendingTemplates.length > 0) {
                    dashboardTrendingTemplates = dashboardTrendingStore.trendingTemplates
                }
                const requestTemplateIndex = _.findIndex(dashboardTrendingTemplates, (template) => _.eq(template.templateID, campaign.templateID))
                let templateName = null
                const template = await db.collection('templates').findOne({
                    "_id": ObjectId(campaign.templateID)
                })
                if (!_.isNil(template)) {
                    templateName = template.name
                }
                if (_.eq(requestTemplateIndex, -1)) {
                    const trendingTemplateObject = {}
                    trendingTemplateObject.templateID = campaign.templateID
                    trendingTemplateObject.templateName = templateName
                    trendingTemplateObject.engagementSum = engagementTotal
                    trendingTemplateObject.negativeCount = engagementLevelObject.negativeCount
                    trendingTemplateObject.neutralCount = engagementLevelObject.neutralCount
                    trendingTemplateObject.positiveCount = engagementLevelObject.positiveCount
                    dashboardTrendingTemplates.push(trendingTemplateObject)
                } else {
                    dashboardTrendingTemplates[requestTemplateIndex].engagementSum += engagementTotal
                    dashboardTrendingTemplates[requestTemplateIndex].negativeCount += engagementLevelObject.negativeCount
                    dashboardTrendingTemplates[requestTemplateIndex].neutralCount += engagementLevelObject.neutralCount
                    dashboardTrendingTemplates[requestTemplateIndex].negativeCount += engagementLevelObject.positiveCount
                }
              
                await db.collection('trends').updateOne({
                    clientID: request.clientID,
                    year: request.year,
                    month: request.month
                }, {
                    $set: {
                        trendingProjects: dashboardTrendingProjects,
                        trendingTemplates: dashboardTrendingTemplates
                    }
                })
            }

        })
        
        if (a < total) {
            throw new Error('incomplete migration')
        }

    },

    async down(db, client) {
        requestEngagementUpdateObject = {
            engagementLevel: 0
        }
        await db.collection('requests').updateMany({}, {
            $set: requestEngagementUpdateObject
        })
        await db.collection('trends').updateMany({}, {
            $unset: {
                trendingProjects: [],
                trendingTemplates: []
            }
        })
    }
}