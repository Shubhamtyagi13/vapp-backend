## Test

```bash
# unit tests
$ npm run test

# e2e tests
$ npm run test:e2e

# test coverage
$ npm run test:cov
```

## Stress Test

```bash
# install influx
$ sudo apt install influxdb

# install grafana
$ sudo apt install grafana

```

## Modules

- campaign (vidhyanhsu) [untested] - CRO
- credits (tushar) [x] need some work for split
- requests (tushar) [x]
- dashboard (aashis) [x]
- cron p
  splitting db keys redis
  tracking
- delivery - CRO
- TRACKING - CRO TO BE MADE
- schedule - (vidhyansh) [blocked because of crons]
- websocket -
