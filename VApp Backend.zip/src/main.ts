import dotenv from 'dotenv'

dotenv.config()

import { isTourValid } from '@app/tour/helpers/tour.helper'
import { application, environments, variables } from '@config'
import { consortium } from '@messages'
import { NestFactory } from '@nestjs/core'
import { NestExpressApplication } from '@nestjs/platform-express'
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger'
import { VappLogger } from '@services/logger.service'
import { ConfigHandler } from '@utils/config.util'
import { createStaticDirectories, getAllowedOrigin, getEnvironmentVariable, getServerAPIRevision } from '@utils/platform.util'
import { json, urlencoded } from 'body-parser'
import cookieParser from 'cookie-parser'
import express from 'express'
import _ from 'lodash'
import { SocketAapter } from '@utils/socket.util'
import { certificateFor } from 'devcert'
import { HttpsOptions } from '@nestjs/common/interfaces/external/https-options.interface'
import { NestApplicationOptions } from '@nestjs/common'
import helmet from 'helmet'
import { CoreModule } from './core/core.module'

const bootstrap = () => {
  const logger = new VappLogger()
  return new Promise<boolean>(async (resolve: (value?: boolean | PromiseLike<boolean>) => void, reject: (reason?: unknown) => void) => {
    const port: number = _.toNumber(getEnvironmentVariable(variables.PORT.name))
    const address: string = getEnvironmentVariable(variables.ADDRESS.name)
    const serverOptions = <NestApplicationOptions>{}
    if (_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.local)) {
      // const { key, cert } = await certificateFor(`${environments.local}host`, { skipCertutilInstall: false, getCaPath: true, getCaBuffer: true })
      // const httpsOptions: HttpsOptions = {}
      // httpsOptions.cert = cert
      // httpsOptions.key = key
      // serverOptions.httpsOptions = httpsOptions 
    }
    NestFactory.create<NestExpressApplication>(CoreModule, serverOptions)
      .then((app: NestExpressApplication) => {
        ConfigHandler.getInstance()
        app.set('trust proxy', 1)
        app.use(cookieParser())
        app.disable('x-powered-by')
        app.use(`/api/${getServerAPIRevision()}tour`, isTourValid, express.static(`${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.WALKTHROUGH_DIRECTORY.name)}`))
        app.use(json({ limit: '1gb', strict: true }))
        app.use(urlencoded({ limit: '1gb', extended: true }))
        app.setGlobalPrefix(getEnvironmentVariable(variables.API_PREFIX.name))
        app.useLogger(logger)
        // app.enableCors({ origin: getAllowedOrigin(), credentials: true })
        app.use(helmet())
        createStaticDirectories()
        SwaggerModule.setup(
          'api/system/docs',
          app,
          SwaggerModule.createDocument(
            app,
            new DocumentBuilder().setTitle(`${application.name} API Documentation`).setVersion(getEnvironmentVariable(variables.APPLICATION_VERSION.name)).addBearerAuth({ in: 'header', type: 'http' }, 'Authorization Bearer Token').build()
          )
        )
        app.useWebSocketAdapter(new SocketAapter(app))
        app.listen(port, address).then(() => {
          app
            .getUrl()
            .then((url: string) => {
              logger.log(`${consortium.initialised(url, port)}`)
              resolve(true)
            })
            .catch((error: Error) => {
              logger.error(error.message)
              reject()
              process.exit(0)
            })
        })
      })
      .catch((error: Error) => {
        logger.error(error.message)
        reject()
        process.exit(0)
      })
  })
}

bootstrap()
