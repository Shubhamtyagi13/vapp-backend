import { DeliveryCronModule } from '@app/delivery/delivery.cron.module'
import { ExceptionsFilter } from '@filters/exceptions.filter'
import { TimingMiddleware } from '@middlewares/timing.middleware'
import { TraceMiddleware } from '@middlewares/trace.middleware'
import { ContextModule } from '@modules/context.module'
import { LoggerModule } from '@modules/logger.module'
import { MiddlewareConsumer, Module, NestModule, ValidationPipe } from '@nestjs/common'
import { APP_FILTER, APP_PIPE } from '@nestjs/core'
import { VappLogger } from '@services/logger.service'
import { getAllowedOrigin, getArgs } from '@utils/platform.util'
import cors from 'cors'
import { CreateDeliveryReportModule, UploadDeliveryReportModule } from '@app/delivery/cron/queue.module'
import { cronJobs } from '@config'
import { GenericObject } from '@interfaces/generic.interface'
import { ReportsCronModule } from '@app/reports/reports.cron.module'
import { IVRCronModule } from '@app/ivr/ivr.cron.module'
import { ContactCronModule } from '@app/contact/contact.cron.module'
import { CampaignCronModule } from '@app/campaign/campaign.cron.module'
import { MongooseHandlerModule } from '@modules/mongoose.module'
import { RateLimiterModule } from '@modules/rate-limiter.module'
import { SessionModule } from 'nestjs-session'
import { CreateDeliveryCronModule } from '@app/delivery/delivery.create.cron.module'
import { IntegrationsCronModule } from '@app/integrations/integrations.cron.module'

const cronSwitcher = () => {
  const cron_processor = (getArgs() as GenericObject).cron
  let module_array: Array<any> = []
  switch (cron_processor) {
    case cronJobs.CREATE_DELIVERY_REPORT.name:
      module_array = [CreateDeliveryReportModule, CreateDeliveryCronModule]
      break
    case cronJobs.UPLOAD_DELIVERY_REPORT.name:
      module_array = [UploadDeliveryReportModule, DeliveryCronModule]
      break
    case cronJobs.CREATE_CAMPAIGN_REPORT.name:
      module_array = [ReportsCronModule]
      break
    case cronJobs.CREATE_REPORT.name:
      module_array = [ReportsCronModule]
      break
    case cronJobs.ENGAGEMENT_TRACKING.name:
      module_array = [CampaignCronModule]
      break
    case cronJobs.CREATE_SMS_CAMPAIGN.name:
      module_array = [CampaignCronModule]
      break
    case cronJobs.CREATE_RBM_CAMPAIGN.name:
      module_array = [CampaignCronModule]
      break
    case cronJobs.CREATE_WHATSAPP_CAMPAIGN.name:
      module_array = [CampaignCronModule]
      break
    case cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name:
      module_array = [CampaignCronModule]
      break
    case cronJobs.CREATE_DRIP_WHATSAPP_CAMPAIGN.name:
      module_array = [CampaignCronModule]
      break
    case cronJobs.UPLOAD_CLIENT_CONTACTS.name:
      module_array = [ContactCronModule]
      break
    case cronJobs.IVR_WEBHOOK.name:
      module_array = [IVRCronModule]
      break
    case cronJobs.IVR_WEBHOOK_FINALIZE.name:
      module_array = [IVRCronModule]
      break
    case cronJobs.PROCESS_INTEGRATIONS.name:
      module_array = [IntegrationsCronModule]
      break
  }
  return module_array
}
@Module({
  imports: [
    ContextModule.registerAsync(),
    RateLimiterModule,
    SessionModule,
    MongooseHandlerModule,
    TimingMiddleware.forRootAsync({
      inject: [VappLogger],
      imports: [LoggerModule],
      useFactory: async (logger: VappLogger) => ({ logger })
    }),
    ...cronSwitcher()
  ],
  providers: [{ provide: APP_FILTER, useClass: ExceptionsFilter }, { provide: APP_PIPE, useClass: ValidationPipe }, VappLogger]
})
export class CoreCronModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer
      .apply(TraceMiddleware)
      .forRoutes('*')
      .apply(
        cors({
          origin: '*',
          credentials: true
        })
      )
      .forRoutes('ivr/webhook', 'requests/engagement/*', 'interaction/*', 'website/*')
      .apply(
        cors({
          origin: getAllowedOrigin(),
          credentials: true
        })
      )
      .exclude('ivr/webhook', 'requests/engagement/*', 'interaction/*', 'website/*')
      .forRoutes('*')
  }
}
