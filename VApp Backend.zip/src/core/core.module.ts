import { AnalyticsModule } from '@app/analytics/analytics.module'
import { CampaignModule } from '@app/campaign/campaign.module'
import { ContactModule } from '@app/contact/contact.module'
import { CreditsModule } from '@app/credits/credits.module'
import { DashboardModule } from '@app/dashboard/dashboard.module'
import { DeliveryModule } from '@app/delivery/delivery.module'
import { DialogflowModule } from '@app/dialogflow/dialogflow.module'
import { LinkModule } from '@app/link/link.module'
import { ProjectsModule } from '@app/projects/projects.module'
import { ReportsModule } from '@app/reports/reports.module'
import { RequestsModule } from '@app/requests/requests.module'
import { ScheduleModule } from '@app/schedule/schedule.module'
import { DripCriteriaModule } from '@app/dripcriteria/dripcriteria.module'
import { SystemModule } from '@app/system/system.module'
import { TemplateModule } from '@app/template/template.module'
import { TourModule } from '@app/tour/tour.module'
import { TrackingModule } from '@app/tracking/tracking.module'
import { UserModule } from '@app/user/user.module'
import { WebsiteModule } from '@app/website/website.module'
import { variables } from '@config'
import { ExceptionsFilter } from '@filters/exceptions.filter'
import { MaintenanceGuard } from '@guards/maintenance.guard'
import { APIInterceptor } from '@interceptors/api.interceptor'
import { ClientUserIDTransformInterceptor } from '@interceptors/client-user-id.interceptor'
import { TimingMiddleware } from '@middlewares/timing.middleware'
import { TraceMiddleware } from '@middlewares/trace.middleware'
import { ContextModule } from '@modules/context.module'
import { LoggerModule } from '@modules/logger.module'
import { MongooseHandlerModule } from '@modules/mongoose.module'
import { RateLimiterModule } from '@modules/rate-limiter.module'
import { SessionModule } from '@modules/session.module'
import { MiddlewareConsumer, Module, NestModule, ValidationPipe } from '@nestjs/common'
import { APP_FILTER, APP_GUARD, APP_INTERCEPTOR, APP_PIPE } from '@nestjs/core'
import { ServeStaticModule } from '@nestjs/serve-static'
import { VappLogger } from '@services/logger.service'
import { getAllowedOrigin, getEnvironmentVariable, getServerAPIRevision } from '@utils/platform.util'
import { RateLimiterInterceptor } from 'nestjs-fastify-rate-limiter'
import { join } from 'path'
import { MailerModule } from '@nestjs-modules/mailer'
import { PugAdapter } from '@nestjs-modules/mailer/dist/adapters/pug.adapter'
import cors from 'cors'
import { IVRModule } from '@app/ivr/ivr.module'
import { BootstrapService } from '@services/bootstrap.service'
import { CreateDeliveryReportModule, UploadDeliveryReportModule } from '@app/delivery/cron/queue.module'
import { OTPModule } from '@app/otp/otp.module'
import { TransactionalModule } from '@app/transactional/transactional.module'
import { IntegrationsModule } from '@app/integrations/integrations.module'
import { RBMClient } from '@libraries/rbm/rbm.service'

@Module({
  imports: [
    ContextModule.registerAsync(),
    ServeStaticModule.forRoot({
      rootPath: join(process.cwd(), `${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.STATIC_DIRECTORY.name)}`),
      serveRoot: `/api/${getServerAPIRevision()}static`,
      serveStaticOptions: {
        cacheControl: true,
        etag: true
      }
    }),
    ServeStaticModule.forRoot({
      rootPath: join(process.cwd(), `${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.BROCHURE_DIRECTORY.name)}`),
      serveRoot: `/api/${getServerAPIRevision()}brochure`,
      serveStaticOptions: {
        cacheControl: true,
        etag: true
      }
    }),
    // ServeStaticModule.forRoot({
    //   rootPath: join(process.cwd(), `${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.WALKTHROUGH_DIRECTORY.name)}`),
    //   serveRoot: `/api/${getServerAPIRevision()}tour`,
    //   serveStaticOptions: {
    //     cacheControl: true,
    //     etag: true
    //   }
    // }),
    RateLimiterModule,
    SessionModule,
    MongooseHandlerModule,
    TimingMiddleware.forRootAsync({
      inject: [VappLogger],
      imports: [LoggerModule],
      useFactory: async (logger: VappLogger) => ({ logger })
    }),
    OTPModule,
    TransactionalModule,
    UploadDeliveryReportModule,
    CreateDeliveryReportModule,
    SystemModule,
    UserModule,
    CreditsModule,
    CampaignModule,
    ContactModule,
    TemplateModule,
    DripCriteriaModule,
    DialogflowModule,
    LinkModule,
    ReportsModule,
    RequestsModule,
    ScheduleModule,
    TourModule,
    ProjectsModule,
    WebsiteModule,
    DashboardModule,
    TrackingModule,
    DeliveryModule,
    AnalyticsModule,
    IVRModule,
    IntegrationsModule,
    MailerModule.forRoot({
      transport: 'smtps://siddharth@vapp.in:aukreohfwsnllbsz@smtp.gmail.com',
      defaults: {
        from: '"Virtuality Innoventure" <siddharth@vapp.in>'
      },
      template: {
        dir: `${__dirname}/templates`,
        adapter: new PugAdapter(),
        options: {
          strict: true
        }
      }
    })
  ],
  providers: [
    RBMClient,
    BootstrapService,
    { provide: APP_GUARD, useClass: MaintenanceGuard },
    { provide: APP_INTERCEPTOR, useClass: APIInterceptor },
    { provide: APP_INTERCEPTOR, useClass: ClientUserIDTransformInterceptor },
    { provide: APP_PIPE, useClass: ValidationPipe },
    { provide: APP_FILTER, useClass: ExceptionsFilter },
    { provide: APP_INTERCEPTOR, useClass: RateLimiterInterceptor },
    VappLogger
  ]
})
export class CoreModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer
      .apply(TraceMiddleware)
      .forRoutes('*')
      .apply(
        cors({
          origin: '*',
          preflightContinue: true,
          optionsSuccessStatus: 204,
          credentials: true
        })
      )
      .forRoutes('ivr/webhook', 'requests/engagement/*', 'interaction/*', 'website/*')
      .apply(
        cors({
          preflightContinue: true,
          origin: getAllowedOrigin(),
          optionsSuccessStatus: 204,
          credentials: true
        })
      )
      .exclude('ivr/webhook', 'requests/engagement/*', 'interaction/*', 'website/*')
      .forRoutes('*')
  }
}
