import { CronPayload } from '@interfaces/cron.interface'
import { BulkWriteResult } from 'mongodb'
import { messages } from '@messages'
import { getEnvironmentVariable, isObjectValid } from '@utils/platform.util'
import async, { any, IterableCollection } from 'async'
import { Job } from 'bull'
import _ from 'lodash'
import { ClientSession, Document, Model } from 'mongoose'
import { UserMetadata } from '@app/website/user-metadata.schema'
import { redisKeys } from '@config'
import { RedisHandler } from './redis.util'

export const findOperations = {
  find: (model: Model<any>, query: any, projection: any = null, sort: any = {}, session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      if (!isObjectValid(query)) {
        reject(new Error(getEnvironmentVariable(messages.MON002.code)))
      }
      if (!isObjectValid(sort)) {
        reject(new Error(getEnvironmentVariable(messages.MON004.code)))
      } else {
        model
          .find(query, projection)
          .sort(sort)
          .session(session)
          .exec()
          .then((result) => {
            if (result) {
              resolve(result)
            } else {
              resolve(getEnvironmentVariable(messages.COM001.code))
            }
          })
          .catch((error: Error) => reject(error))
      }
    }),
  findWithOffset: (model: Model<any>, query: any, projection: any = null, sort: any = {}, session: ClientSession = null, limit = 0, skip = 0): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      if (!isObjectValid(query)) {
        reject(new Error(getEnvironmentVariable(messages.MON002.code)))
      }
      if (!isObjectValid(sort)) {
        reject(new Error(getEnvironmentVariable(messages.MON004.code)))
      } else {
        model
          .find(query, projection)
          .sort(sort)
          .skip(skip)
          .limit(limit)
          .session(session)
          .exec()
          .then((result) => {
            if (result) {
              resolve(result)
            } else {
              resolve(getEnvironmentVariable(messages.COM001.code))
            }
          })
          .catch((error: Error) => reject(error))
      }
    }),

  findLean: (model: Model<any>, query: any, projection: any = null, sort: any = {}, session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      if (!isObjectValid(query)) {
        reject(new Error(getEnvironmentVariable(messages.MON002.code)))
      }
      if (!isObjectValid(sort)) {
        reject(new Error(getEnvironmentVariable(messages.MON004.code)))
      } else {
        model
          .find(query, projection)
          .sort(sort)
          .lean()
          .session(session)
          .exec()
          .then((result) => {
            if (result) {
              resolve(result)
            } else {
              resolve(getEnvironmentVariable(messages.COM001.code))
            }
          })
          .catch((error: Error) => reject(error))
      }
    }),
  findOne: (model: Model<any>, query: any, projection: any = null, session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      if (!isObjectValid(query)) {
        reject(new Error(getEnvironmentVariable(messages.MON002.code)))
      } else {
        model
          .findOne(query, projection)
          .session(session)
          .then((result) => {
            if (result) {
              resolve(result)
            } else {
              resolve(undefined)
            }
          })
          .catch((error: Error) => reject(error))
      }
    }),
  findOneLean: (model: Model<any>, query: any, projection: any = null, session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      if (!isObjectValid(query)) {
        reject(new Error(getEnvironmentVariable(messages.MON002.code)))
      } else {
        model
          .findOne(query, projection)
          .lean()
          .session(session)
          .then((result) => {
            if (result) {
              resolve(result)
            } else {
              resolve(undefined)
            }
          })
          .catch((error: Error) => reject(error))
      }
    }),
  findOneLeanSort: (model: Model<any>, query: any, projection: any = null, sort: any = null, session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      if (!isObjectValid(query)) {
        reject(new Error(getEnvironmentVariable(messages.MON002.code)))
      } else {
        model
          .findOne(query, projection)
          .lean()
          .sort(sort)
          .session(session)
          .then((result) => {
            if (result) {
              resolve(result)
            } else {
              resolve(undefined)
            }
          })
          .catch((error: Error) => reject(error))
      }
    }),
  count: (model: Model<any>, query: any, projection: any = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      if (!isObjectValid(query)) {
        reject(new Error(getEnvironmentVariable(messages.MON002.code)))
      } else {
        model
          .countDocuments(query)
          .then((result) => {
            if (result) {
              resolve(result)
            } else {
              resolve(undefined)
            }
          })
          .catch((error: Error) => reject(error))
      }
    }),
  findById: (model: Model<any>, id: any | string | number, projection: any = null, session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      if (!id) {
        reject(new Error(getEnvironmentVariable(messages.MON001.code)))
      } else {
        model
          .findById(id, projection)
          .session(session)
          .then((result) => {
            if (result) {
              resolve(result)
            } else {
              resolve(getEnvironmentVariable(messages.COM001.code))
            }
          })
          .catch((error: Error) => reject(error))
      }
    }),
  findByIdAndDelete: (model: Model<any>, id: any | string | number, options: any): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      if (!id) {
        reject(new Error(getEnvironmentVariable(messages.MON001.code)))
      } else {
        model
          .findByIdAndDelete(id, options)
          .then((result) => {
            if (result) {
              resolve(result)
            } else {
              resolve(getEnvironmentVariable(messages.COM001.code))
            }
          })
          .catch((error: Error) => reject(error))
      }
    }),
  findByIdAndRemove: (model: Model<any>, id: any | string | number, options: any): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      if (!id) {
        reject(new Error(getEnvironmentVariable(messages.MON001.code)))
      } else {
        model
          .findByIdAndRemove(id, options)
          .then((result) => {
            if (result) {
              resolve(result)
            } else {
              resolve(getEnvironmentVariable(messages.COM001.code))
            }
          })
          .catch((error: Error) => reject(error))
      }
    }),
  findByIdAndUpdate: (model: Model<any>, id: any | string | number, update: any, options: any = {}): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      if (!id) {
        reject(new Error(getEnvironmentVariable(messages.MON001.code)))
      } else if (!isObjectValid(update)) {
        reject(new Error(getEnvironmentVariable(messages.MON003.code)))
      } else {
        model
          .findByIdAndUpdate(id, update, options)
          .then((result) => {
            if (result) {
              resolve(result)
            } else {
              resolve(getEnvironmentVariable(messages.COM001.code))
            }
          })
          .catch((error: Error) => reject(error))
      }
    }),
  aggregate: (model: Model<any>, aggregations: any[], session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      if (!isObjectValid(aggregations)) {
        reject(new Error(getEnvironmentVariable(messages.MON003.code)))
      } else {
        model
          .aggregate(aggregations)
          .session(session)
          .allowDiskUse(true)
          .then((result) => {
            if (result) {
              resolve(result)
            } else {
              resolve(getEnvironmentVariable(messages.COM001.code))
            }
          })
          .catch((error: Error) => reject(error))
      }
    })
}

export const createOperations = {
  processBulkInsertion: (model: Model<any>, docs: IterableCollection<any>, job?: Job<CronPayload<any>>) =>
    new Promise<BulkWriteResult>((resolve, reject): void => {
      const insertionBatch = (master_callback: (arg0: any, arg1: BulkWriteResult) => void) => {
        const bulk = model.collection.initializeOrderedBulkOp({ ordered: false, willRetryWrites: true, retryWrites: true })
        const v = Date.now()

        async.each(
          docs as any,
          (doc: any, callback) => {
            bulk.insert(doc)
            callback()
          },
          (err) => {
            if (err) throw err
            bulk.execute((err, result) => {
              if (err) throw err
              if (!_.isNil(job)) {
                job.progress(job.progress() + 10)
              }
              master_callback(null, result)
            })
          }
        )
      }
      async.series([insertionBatch], (err, result) => {
        if (err) {
          reject(err)
        } else {
          resolve(result[0])
        }
      })
    }),
  processBulkInsertionMetadata: (model: Model<UserMetadata>, docs: IterableCollection<UserMetadata>, job?: Job<CronPayload<any>>) =>
    new Promise<BulkWriteResult>((resolve, reject): void => {
      const insertionBatch = (master_callback: (arg0: any, arg1: BulkWriteResult) => void) => {
        const bulk = model.collection.initializeOrderedBulkOp({ ordered: false, willRetryWrites: true, retryWrites: true })
        async.each(
          docs,
          (doc: UserMetadata, callback) => {
            bulk
              .find({ phone: doc.phone })
              .upsert()
              .update({ $set: { name: doc.name } })
            RedisHandler.getInstance().del(redisKeys.USER_METADATA.value(`${doc.phone}`))
            callback()
          },
          (err) => {
            if (err) throw err
            bulk.execute((err, result) => {
              if (err) throw err
              if (!_.isNil(job)) {
                job.progress(job.progress() + 10)
              }
              master_callback(null, result)
            })
          }
        )
      }
      async.series([insertionBatch], (err, result) => {
        if (err) {
          reject(err)
        } else {
          resolve(result[0])
        }
      })
    }),
  save: (document: Document, saveOptions?: any): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      document
        .save(saveOptions || {})
        .then((result) => {
          if (result) {
            resolve(result)
          } else {
            resolve(getEnvironmentVariable(messages.COM001.code))
          }
        })
        .catch((error: Error) => reject(console.log(error)))
    }),
  insertMany: (model: Model<any>, data: any, session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      model
        .insertMany(data, { session, ordered: false, lean: true })
        .then((result) => {
          if (result) {
            resolve(result)
          } else {
            resolve(getEnvironmentVariable(messages.COM001.code))
          }
        })
        .catch((error: Error) => reject(error))
    }),
  create: (model: Model<any>, data: any, session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      model
        .create(data, { session })
        .then((result) => {
          if (result) {
            resolve(result)
          } else {
            resolve(getEnvironmentVariable(messages.COM001.code))
          }
        })
        .catch((error: Error) => reject(error))
    }),
  updateOne: (model: Model<any>, query: any = {}, data: any, session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      model
        .findOneAndUpdate(query, data, { new: true, session })
        .session(session)
        .then((result) => {
          if (result) {
            resolve(result)
          } else {
            resolve(getEnvironmentVariable(messages.COM001.code))
          }
        })
        .catch((error: Error) => reject(error))
    }),
  updateOneWithoutFind: (model: Model<any>, query: any = {}, data: any, session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      model
        .updateOne(query, data, { new: true, session })
        .session(session)
        .then((result) => {
          if (result) {
            resolve(result)
          } else {
            resolve(getEnvironmentVariable(messages.COM001.code))
          }
        })
        .catch((error: Error) => reject(error))
    }),
  updateMany: (model: Model<any>, query: any = {}, data: any, session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      model
        .updateMany(query, data)
        .session(session)
        .then((result) => {
          if (result) {
            resolve(result)
          } else {
            resolve(getEnvironmentVariable(messages.COM001.code))
          }
        })
        .catch((error: Error) => reject(error))
    }),
  updateOneUpsert: (model: Model<any>, query: any = {}, data: any, session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      model
        .findOneAndUpdate(query, data, { new: true, upsert: true, setDefaultsOnInsert: true })
        .session(session)
        .then((result) => {
          if (result) {
            resolve(result)
          } else {
            resolve(getEnvironmentVariable(messages.COM001.code))
          }
        })
        .catch((error: Error) => reject(error))
    })
}

export const deleteOperations = {
  deleteMany: (model: Model<any>, data: any, session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      if (!isObjectValid(data)) {
        reject(new Error(getEnvironmentVariable(messages.MON003.code)))
      } else {
        model
          .deleteMany(data)
          .session(session)
          .then((result) => {
            if (result) {
              resolve(result)
            } else {
              resolve(getEnvironmentVariable(messages.COM001.code))
            }
          })
          .catch((error: Error) => reject(error))
      }
    }),
  deleteOne: (model: Model<any>, data: any, session: ClientSession = null): Promise<any> =>
    new Promise<any>((resolve, reject): void => {
      if (!isObjectValid(data)) {
        reject(new Error(getEnvironmentVariable(messages.MON003.code)))
      } else {
        model
          .deleteOne(data)
          .session(session)
          .then((result) => {
            if (result) {
              resolve(result)
            } else {
              resolve(getEnvironmentVariable(messages.COM001.code))
            }
          })
          .catch((error: Error) => reject(error))
      }
    })
}
