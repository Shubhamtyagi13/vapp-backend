import { variables } from '@config'
import { GenericObject } from '@interfaces/generic.interface'
import { getEnvironmentVariable } from '@utils/platform.util'
import atob from 'atob'
import jwt from 'jsonwebtoken'

export default class JWTHandler {
  secretOrPrivateKey: string

  secretOrPublicKey: string

  options: GenericObject

  constructor(options: GenericObject = {}) {
    this.secretOrPrivateKey = getEnvironmentVariable(variables.JWT_PRIVATE_SECRET.name)
    this.secretOrPublicKey = getEnvironmentVariable(variables.JWT_PUBLIC_SECRET.name)
    this.options = options // algorithm + keyid + noTimestamp + expiresIn + notBefore
  }

  sign(payload: GenericObject, signOptions: GenericObject) {
    const jwtSignOptions = { ...signOptions, ...this.options }
    return jwt.sign(payload, this.secretOrPrivateKey, jwtSignOptions)
  }

  getExpirationTime = (token: string) => {
    try {
      return JSON.parse(atob(token.split('.')[1])).exp
    } catch (e) {
      return 0
    }
  }

  getDecodedToken = (token: string) => {
    try {
      return JSON.parse(atob(token.split('.')[1]))
    } catch (e) {
      return null
    }
  }

  // refreshOptions.verify = options you would use with verify function
  // refreshOptions.jwtid = contains the id for the new token
  refresh = (token: string, refreshOptions: GenericObject) => {
    try {
      const payload = jwt.verify(token, this.secretOrPublicKey, refreshOptions.verify)
      delete (payload as GenericObject).iat
      delete (payload as GenericObject).exp
      delete (payload as GenericObject).nbf
      delete (payload as GenericObject).jti // We are generating a new token, if you are using jwtid during signing, pass it in refreshOptions
      const jwtSignOptions = { ...this.options, jwtid: refreshOptions.jwtid }
      // The first signing converted all needed options into claims, they are already in the payload
      return jwt.sign(payload, this.secretOrPrivateKey, jwtSignOptions)
    } catch (e) {
      return null
    }
  }
}
