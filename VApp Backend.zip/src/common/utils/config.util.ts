import { dynamic_config } from '@config'
import { getEnvironmentVariable } from '@utils/platform.util'
import admin from 'firebase-admin'
import _ from 'lodash'
import { FireBaseHandler } from './firebase.util'

export class ConfigHandler {
  private static instance: ConfigHandler

  private static _firebase: admin.app.App

  private static _config: any = {}

  private constructor() {
    if (_.isNil(ConfigHandler._firebase)) {
      ConfigHandler._firebase = FireBaseHandler.getInstance()
      ConfigHandler._firebase
        .database()
        .ref(dynamic_config.DYNAMIC_CONFIG)
        .on('value', (snapshot) => {
          if (!_.isNil(snapshot) && !_.isNil(snapshot.val)) {
            ConfigHandler._config = snapshot.val()
          }
        })
    }
  }

  static getInstance(): ConfigHandler {
    if (_.isNil(ConfigHandler.instance)) {
      ConfigHandler.instance = new ConfigHandler()
    }
    return ConfigHandler.instance
  }

  getSMPPConfigRoute(route: number) {
    let value: any
    try {
      if (!_.isNil(ConfigHandler._config) && !_.isNil(ConfigHandler._config.SMPP)) {
        const configurations = _.keys(ConfigHandler._config.SMPP)
        configurations.forEach((configuration) => {
          if (_.eq(ConfigHandler._config.SMPP[configuration]?.ROUTE, route)) {
            value = configuration
          }
        })
      }
    } catch (e) { }
    return value
  }

  getValue(key: string, impersonation = false) {
    let value: any
    if (!impersonation) {
      if (!_.isNil(ConfigHandler._config) && !_.isNil(ConfigHandler._config[key])) {
        value = ConfigHandler._config[key]
      }
      if (_.isNil(value)) {
        value = getEnvironmentVariable(key)
      }
    } else {
      try {
        if (!_.isNil(ConfigHandler._config) && !_.isNil(ConfigHandler._config[key.split('_')[0]])) {
          const impersonation_object = ConfigHandler._config[key.split('_')[0]]
          if (_.includes(key, 'username')) {
            value = impersonation_object.username
          } else if (_.includes(key, 'password')) {
            value = impersonation_object.password
          }
        }
      } catch (e) { }
    }
    return value
  }
}
