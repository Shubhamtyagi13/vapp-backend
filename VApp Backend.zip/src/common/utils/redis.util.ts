import { cache_client, constants, redis_client, variables } from '@config'
import { caching } from '@messages'
import { VappLogger } from '@services/logger.service'
import { getEnvironmentVariable } from '@utils/platform.util'
import _ from 'lodash'
import redis, { ClientOpts, RedisClient } from 'redis'

export class RedisHandler {
  private static _redisClients: { [key: string]: { [key: string]: RedisClient } } = {}

  private static logger: VappLogger

  private constructor() {}

  private static spawnInstance = (client_config: cache_client = cache_client.DEFAULT, db_config: redis_client = redis_client.DEFAULT) => {
    if (_.isNil(RedisHandler._redisClients[client_config])) {
      RedisHandler._redisClients[client_config] = {}
    }
    if (_.isNil(RedisHandler._redisClients[client_config][db_config])) {
      const dynamic_config = RedisHandler.switchConfiguration(client_config)
      const redis_options = {
        enable_offline_queue: true,
        host: dynamic_config.host,
        port: dynamic_config.port,
        retry_strategy: (options) => {
          if (!constants.REDIS_RETRY_STRATEGY.NUMBER_OF_RETRY_ATTEMPTS) {
            return undefined
          }
          if (!options.attempt) {
            return constants.REDIS_RETRY_STRATEGY.DELAY_OF_RETRY_ATTEMPTS
          }
          if (_.eq(RedisHandler._redisClients[client_config][db_config][`${client_config}_RETRIES`], getEnvironmentVariable(variables.REDIS_MAX_RETRIES.name))) {
            RedisHandler.logger.error(caching.reconnecting(getEnvironmentVariable(variables.REDIS_PORT.name), getEnvironmentVariable(variables.REDIS_URL.name), client_config))
          }
          RedisHandler._redisClients[client_config][db_config][`${client_config}_RETRIES`] += 1
          if (_.eq(options.attempt % (constants.REDIS_RETRY_STRATEGY.NUMBER_OF_RETRY_ATTEMPTS + 1), 0)) {
            return constants.REDIS_RETRY_STRATEGY.WAIT_TIME
          }
          return constants.REDIS_RETRY_STRATEGY.DELAY_OF_RETRY_ATTEMPTS
        },
        db: RedisHandler.switchDConfiguration(db_config)
      } as ClientOpts
      if (!_.eq(dynamic_config.password, 'no_password')) {
        _.set(redis_options, 'password', dynamic_config.password)
      }
      RedisHandler._redisClients[client_config][db_config] = redis.createClient(redis_options)
      RedisHandler._redisClients[client_config][db_config][`${client_config}_RETRIES`] = 0
      RedisHandler._redisClients[client_config][db_config]
        .on('error', (error: any) => {
          RedisHandler.logger.error(caching.error(error))
          process.exit()
        })
        .on('connect', () => {
          RedisHandler.logger.log(caching.success(getEnvironmentVariable(variables.REDIS_PORT.name), getEnvironmentVariable(variables.REDIS_URL.name), client_config, db_config))
        })
    }
  }

  static getInstance(client_config: cache_client = cache_client.DEFAULT, db_config: redis_client = redis_client.DEFAULT): RedisClient {
    if (_.isNil(RedisHandler.logger)) {
      RedisHandler.logger = new VappLogger()
    }
    const current_client = RedisHandler._redisClients[client_config] ? (RedisHandler._redisClients[client_config][db_config] ? RedisHandler._redisClients[client_config][db_config] : undefined) : undefined
    if (_.isNil(current_client)) {
      RedisHandler.spawnInstance(client_config, db_config)
    }
    return RedisHandler._redisClients[client_config][db_config]
  }

  private static switchConfiguration(client_config: cache_client = cache_client.DEFAULT) {
    let host: string
    let port: number
    let password: string
    switch (client_config) {
      case cache_client.DEFAULT:
        host = getEnvironmentVariable(variables.REDIS_URL.name)
        port = parseInt(getEnvironmentVariable(variables.REDIS_PORT.name), 10)
        password = getEnvironmentVariable(variables.REDIS_PASSWORD.name)
        break
      case cache_client.PUB_SUB:
        host = getEnvironmentVariable(variables.REDIS_PUB_SUB_URL.name)
        port = parseInt(getEnvironmentVariable(variables.REDIS_PUB_SUB_PORT.name), 10)
        password = getEnvironmentVariable(variables.REDIS_PUB_SUB_PASSWORD.name)
        break
    }
    return { host, port, password }
  }

  private static switchDConfiguration(db_config: redis_client = redis_client.DEFAULT) {
    let db: number
    switch (db_config) {
      case redis_client.DEFAULT:
        db = redis_client.DEFAULT
        break
      case redis_client.TOUR:
        db = redis_client.TOUR
        break
      case redis_client.RATE_LIMIT:
        db = redis_client.RATE_LIMIT
        break
      case redis_client.SESSION:
        db = redis_client.SESSION
        break
      case redis_client.CREATE_SMS_CAMPAIGN:
        db = redis_client.CREATE_SMS_CAMPAIGN
        break
      case redis_client.UPLOAD_CLIENT_CONTACTS:
        db = redis_client.UPLOAD_CLIENT_CONTACTS
        break
      case redis_client.UPLOAD_DELIVERY_REPORT:
        db = redis_client.UPLOAD_DELIVERY_REPORT
        break
      case redis_client.ENGAGEMENT_TRACKING:
        db = redis_client.ENGAGEMENT_TRACKING
        break
      case redis_client.CREATE_WHATSAPP_CAMPAIGN:
        db = redis_client.CREATE_WHATSAPP_CAMPAIGN
        break
      case redis_client.CREATE_CAMPAIGN_REPORT:
        db = redis_client.CREATE_CAMPAIGN_REPORT
        break
      case redis_client.IVR_WEBHOOK:
        db = redis_client.IVR_WEBHOOK
        break
      case redis_client.IVR_WEBHOOK_FINALIZE:
        db = redis_client.IVR_WEBHOOK_FINALIZE
        break
      case redis_client.SMPP_ID_UPDATE:
        db = redis_client.SMPP_ID_UPDATE
        break
      case redis_client.SMPP_DELIVERY:
        db = redis_client.SMPP_DELIVERY
        break
      case redis_client.COMMON_JOB_DATA:
        db = redis_client.COMMON_JOB_DATA
        break
      case redis_client.PROCESS_INTEGRATIONS:
        db = redis_client.PROCESS_INTEGRATIONS
        break
    }
    return db
  }
}
