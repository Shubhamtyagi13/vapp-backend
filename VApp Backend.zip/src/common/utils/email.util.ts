import { canonicalMethods, variables } from '@config'
import { CampaignInitialAlert, CreditsApprovedAlert, PasswordResetAlert } from '@interfaces/alert.interface'
import { EmailPayload } from '@interfaces/email.interface'
import sgMail from '@sendgrid/mail'
import { VappLogger } from '@services/logger.service'
import { getEnvironmentVariable, getErrorLog } from '@utils/platform.util'
import _ from 'lodash'

export class EmailHandler {
  private static instance: EmailHandler

  private static logger: VappLogger

  private constructor() {
    if (_.isNil(EmailHandler.logger)) {
      EmailHandler.logger = new VappLogger()
    }
    sgMail.setApiKey(getEnvironmentVariable(variables.SENDGRID_API.name))
  }

  static getInstance(): EmailHandler {
    if (_.isNil(EmailHandler.instance)) {
      EmailHandler.instance = new EmailHandler()
    }
    return EmailHandler.instance
  }

  sendEmail(payload: EmailPayload, traceID: string) {
    sgMail
      .send({
        ...payload,
        asm: {
          groupId: 14509
        }
      })
      .then(() => {
        EmailHandler.logger.log('successfully sent email')
      })
      .catch((error) => {
        EmailHandler.logger.error(getErrorLog(canonicalMethods.SEND_EMAIL, traceID, { error }, error.message))
      })
  }

  getEmailPayloadForInitialCampaign(clientCorrespondence: string, templateData: CampaignInitialAlert): EmailPayload {
    let payload: EmailPayload
    payload = {
      to: clientCorrespondence,
      from: getEnvironmentVariable(variables.SENDGRID_EMAIL.name),
      templateId: getEnvironmentVariable(variables.SENDGRID_INITIAL_CAMPAIGN.name),
      dynamic_template_data: templateData
    }
    return payload
  }

  getEmailPayloadForPasswordReset(clientCorrespondence: string, templateData: PasswordResetAlert): EmailPayload {
    let payload: EmailPayload
    payload = {
      to: clientCorrespondence,
      from: getEnvironmentVariable(variables.SENDGRID_EMAIL.name),
      templateId: getEnvironmentVariable(variables.SENDGRID_PASSWORD_RESET.name),
      dynamic_template_data: templateData
    }
    return payload
  }

  getEmailPayloadForCreditsApproved(clientCorrespondence: string, templateData: CreditsApprovedAlert): EmailPayload {
    let payload: EmailPayload
    payload = {
      to: clientCorrespondence,
      from: getEnvironmentVariable(variables.SENDGRID_EMAIL.name),
      templateId: getEnvironmentVariable(variables.SENDGRID_CREDITS.name),
      dynamic_template_data: templateData
    }
    return payload
  }
}
