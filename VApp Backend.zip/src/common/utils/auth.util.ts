import { constants, variables } from '@config'
import Cryptr from 'cryptr'
import _ from 'lodash'
import JWTHandler from './jwt.util'
import { getEnvironmentVariable, getTokenOptions } from './platform.util'

export default class AuthHandler {
  private static instance: AuthHandler

  private static _tokenHandler: JWTHandler

  private static _campaignTokenHandler: JWTHandler

  private static _encryptionHandler: Cryptr

  private static _whatsappCampaignTokenHandler: JWTHandler

  private constructor() {
    AuthHandler._tokenHandler = new JWTHandler(getTokenOptions(constants.TOKEN.login))
    AuthHandler._campaignTokenHandler = new JWTHandler(getTokenOptions(constants.TOKEN.campaign_sms))
    AuthHandler._encryptionHandler = new Cryptr(getEnvironmentVariable(variables.PASSWORD_HASH.name))
    AuthHandler._whatsappCampaignTokenHandler = new JWTHandler(getTokenOptions(constants.TOKEN.campaign_sms))
  }

  static getInstance(): AuthHandler {
    if (_.isNil(AuthHandler.instance)) {
      AuthHandler.instance = new AuthHandler()
    }
    return AuthHandler.instance
  }

  tokenHandler = (): JWTHandler => AuthHandler._tokenHandler

  encryptionHandler = (): Cryptr => AuthHandler._encryptionHandler

  campaignTokenHandler = (): JWTHandler => AuthHandler._campaignTokenHandler

  whatsappCampaignHandler = (): JWTHandler => AuthHandler._whatsappCampaignTokenHandler
}
