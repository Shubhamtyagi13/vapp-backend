import { variables } from '@config'
import { getEnvironmentVariable } from '@utils/platform.util'
import S3 from 'aws-sdk/clients/s3'
import _ from 'lodash'

export class S3Handler {
  private static instance: S3Handler

  private static _S3: S3

  private constructor() {
    if (_.isNil(S3Handler._S3)) {
      S3Handler._S3 = new S3({
        region: getEnvironmentVariable(variables.S3_REGION.name),
        credentials: {
          accessKeyId: getEnvironmentVariable(variables.S3_ACCESS_ID.name),
          secretAccessKey: getEnvironmentVariable(variables.S3_ACCESS_KEY.name)
        }
      })
    }
  }

  static getInstance(): S3 {
    if (_.isNil(S3Handler.instance)) {
      S3Handler.instance = new S3Handler()
    }
    return S3Handler._S3
  }
}
