import { Requests } from '@app/requests/requests.schema'
import {
  audience, constants, months, otp_types, smpp_client, variables,
} from '@config'
import { WhatsappCampaign } from '@interfaces/campaign.interface'
import { DeviceInfo } from '@interfaces/demographics.interface'
import { GenericObject } from '@interfaces/generic.interface'
import { ErrorLogObject } from '@interfaces/logger.interface'
import { Message } from '@interfaces/message.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { CampaignCronPayload } from '@interfaces/sms-campaign.interface'
import { TokenOptions, TokenSignOptions } from '@interfaces/token.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import atob from 'atob'
import gsm from 'gsm'
import { TransformFnParams } from 'class-transformer'
import Cryptr from 'cryptr'
import deviceDetect from 'device-detector-js'
import Handlebars from 'handlebars'
import { Request } from 'express'
import basicAuth from 'express-basic-auth'
import fs from 'fs'
import _ from 'lodash'
import mongoose from 'mongoose'
import ms from 'ms'
import path from 'path'
import randomize from 'randomatic'
import uniqid from 'uniqid'
import { v4 as uuidv4 } from 'uuid'
import { Socket } from 'socket.io'
import { ConfigHandler } from './config.util'

// get environment variable from .env file or return default
export const getEnvironmentVariable = (variable: number | string) => (process.env[variable] ? process.env[variable] : _.get(variables, `${variable}.value`))

export const getServerAPIRevision = () => (_.isEmpty(getEnvironmentVariable(variables.SERVER_API_REVISION.name)) ? '' : `${getEnvironmentVariable(variables.SERVER_API_REVISION.name)}/`)

export const generateOTP = (length = 6, type = otp_types.NUMERIC) => (_.eq(type, otp_types.NUMERIC) ? _.random(10 ** (length - 1), 10 ** length - 1) : _.times(length, () => _.random(35).toString(36)).join(''))

// extract parameter from url by name
export const extractParameterFromURL = (name: string, url: string) => {
  name = name.replace(/[[\]]/g, '\\$&')
  const regex = new RegExp(`[?&]${name}(=([^&#]*)|&|#|$)`)
  const results = regex.exec(url)
  if (!results) return null
  if (!results[2]) return ''
  return decodeURIComponent(results[2].replace(/\+/g, ' '))
}

/*
get success or error response for request
*/
export const getAPIResponse = (value: string, traceID: string = undefined, status: number, data: unknown = {}): ServiceResponse => {
  const message_object: Message = _.get(messages, `${value}`)
  const response_object = <ServiceResponse>{
    message: !_.isNil(message_object) ? message_object.message : 'N/A',
    traceID,
    code: !_.isNil(message_object) ? message_object.code : 'N/A',
    data,
  }
  if (status) {
    response_object.status = status
  }
  return response_object
}

/*
return error in response format for better non API responses
*/
export const createError = (value: string, traceID: string = undefined, status: number, data: unknown = {}): any => {
  const apiResponse = getAPIResponse(value, traceID, status, data)
  return {
    response: apiResponse,
  }
}

/*
get success or error log
*/
export const getLog = (method: string, payload: unknown = {}, message = 'an error occurred'): string => `method: ${method}, payload: ${JSON.stringify(payload)}, error: ${message}`

// get campaign source value
export const getCampaignSource = (type: number): string => {
  const source = _.find(constants.CAMPAIGN_TYPES, { value: type })
  if (!_.isNil(source)) {
    return source.name
  }
  return 'N/A'
}

// device detect
export const deviceDetection = (request: Request): DeviceInfo => {
  let type = constants.DEVICE_TYPES.UNKNOWN
  let os = null
  let device = null
  const userAgent = <string>(request.headers['user-agent'] || request.headers['User-Agent'])
  const deviceInfo = new deviceDetect().parse(userAgent)
  if (deviceInfo.os) {
    os = deviceInfo.os.name
  }
  if (deviceInfo.device) {
    type = deviceInfo.device.type
    if (!_.isEmpty(deviceInfo.device.brand) && !_.isEmpty(deviceInfo.device.model)) {
      device = `${deviceInfo.device.brand},${deviceInfo.device.model}`
    } else if (!_.isEmpty(deviceInfo.device.brand)) {
      device = `${deviceInfo.device.brand}`
    } else if (!_.isEmpty(deviceInfo.device.model)) {
      device = `${deviceInfo.device.model}`
    }
  }
  return { type, os, device }
}

// device detect
export const wsDeviceDetection = (client: Socket): DeviceInfo => {
  let type = constants.DEVICE_TYPES.UNKNOWN
  let os = null
  let device = null
  const userAgent = <string>(client.handshake.headers['user-agent'] || client.handshake.headers['User-Agent'])
  const deviceInfo = new deviceDetect().parse(userAgent)
  if (deviceInfo.os) {
    os = deviceInfo.os.name
  }
  if (deviceInfo.device) {
    type = deviceInfo.device.type
    if (!_.isEmpty(deviceInfo.device.brand) && !_.isEmpty(deviceInfo.device.model)) {
      device = `${deviceInfo.device.brand},${deviceInfo.device.model}`
    } else if (!_.isEmpty(deviceInfo.device.brand)) {
      device = `${deviceInfo.device.brand}`
    } else if (!_.isEmpty(deviceInfo.device.model)) {
      device = `${deviceInfo.device.model}`
    }
  }
  return { type, os, device }
}
// generate random string
export const generateRandomString = (length: number, pattern = 'Aa0'): string => randomize(pattern, length)

// get error log
export const getErrorLog = (method: string, traceID: string, stack_trace: GenericObject = {}, message?: string): ErrorLogObject => <ErrorLogObject>{
  traceID: _.isNil(traceID) ? 'N/A' : traceID,
  method: _.isNil(method) ? 'N/A' : method,
  stack_trace: _.isNil(stack_trace) ? {} : stack_trace,
  message: _.isNil(message) ? `an error occured in ${method}` : message,
}

// get days in month
export const daysInMonth = (month: number, year: number) => new Date(year, month, 0).getDate()

// return basic auth handler
export const basicAuthHandler = () => {
  const credentials = {}
  credentials[`${getEnvironmentVariable(variables.SYSTEM_USERNAME.name)}`] = getEnvironmentVariable(variables.SYSTEM_PASSWORD.name)
  return basicAuth({
    challenge: true,
    users: credentials,
  })
}

/*
get ip from request
*/
export const getIP = (request: Request): string => {
  const ip = String(request.headers['x-forwarded-for'] || request.connection.remoteAddress || request.ip)
  if (!_.isNil(ip)) {
    if (ip.includes(',')) {
      const split_ip = ip.split(',')
      return split_ip[0].trim()
    }
    return ip
  }
  return ''
}

/*
get ip for WebSocket
*/
export const wsGetIP = (client: Socket): string => {
  const ip = String(client.handshake.headers['x-forwarded-for'] || '0.0.0.0')
  if (!_.isNil(ip)) {
    if (ip.includes(',')) {
      const split_ip = ip.split(',')
      return split_ip[0].trim()
    }
    return ip
  }
  return ''
}

/*
get allowed origins
*/
export const getAllowedOrigin = () => {
  const app_environment = getEnvironmentVariable(variables.VAPP_ENV.name)
  if (!_.isNil(app_environment)) {
    return constants.ALLOWED_ORIGINS.find((_originObject) => _originObject.environment.includes(app_environment)).origins
  }
  return []
}

export const getObjectID = () => new mongoose.Types.ObjectId()

// token handler initializing options
export const getTokenOptions = (epiresIn: string): TokenOptions => ({
  algorithm: 'HS256',
  noTimestamp: false,
  expiresIn: epiresIn,
  notBefore: '0s',
} as TokenOptions)

// token handler signing options
export const getTokenSignOptions = (subject: string, audience: string): TokenSignOptions => ({
  audience,
  issuer: getEnvironmentVariable(variables.JWT_ISSUER.name),
  jwtid: uuidv4(),
  subject,
} as TokenSignOptions)

// token handler refresh options
export const getTokenRefreshOptions = (subject: string, audience: string): TokenSignOptions => ({
  audience,
  issuer: getEnvironmentVariable(variables.JWT_ISSUER.name),
  jwtid: uuidv4(),
  subject,
} as TokenSignOptions)

// get cookie strig from array
export const getCookieString = (data: { [name: string]: any }) => {
  let result = ''
  for (const k in data) {
    if (data.hasOwnProperty(k)) {
      result = `${result + k}=${data[k]};`
    }
  }
  return result
}

// delete folder recursively
export const deleteFolderRecursive = (path: string) => {
  try {
    if (fs.existsSync(path)) {
      fs.readdirSync(path).forEach((file, index) => {
        const curPath = `${path}/${file}`
        if (fs.lstatSync(curPath).isDirectory()) {
          // recurse
          deleteFolderRecursive(curPath)
        } else {
          // delete file
          fs.unlinkSync(curPath)
        }
      })
      fs.rmdirSync(path)
    }
  } catch (e) {}
}

// get sms status value
export const getSMSStatus = (input: string, isFinal = false) => {
  const inputArray = isFinal ? [...constants.SMS_STATUS_CHECKS.success.values, 'submitted'] : constants.SMS_STATUS_CHECKS.success.values
  if (_.includes(inputArray, input)) {
    return constants.SMS_STATUS_CHECKS.success.value
  } if (_.includes(constants.SMS_STATUS_CHECKS.failed.values, input)) {
    return constants.SMS_STATUS_CHECKS.failed.value
  } if (_.includes(constants.SMS_STATUS_CHECKS.refund.values, input)) {
    return constants.SMS_STATUS_CHECKS.refund.value
  } if (!isFinal) {
    if (_.includes(['submitted'], input)) {
      return constants.SMS_STATUS_CHECKS.submitted.value
    }
  }
  return constants.SMS_STATUS_CHECKS.failed.value
}

// get sms delivery status value
export const getSMSDeliveryStatus = (input: string | number, isFinal = false) => {
  if (_.includes(constants.SMS_STATUS_CHECKS.success.values, input) || _.eq(constants.SMS_STATUS_CHECKS.success.value, input)) {
    return constants.SMS_STATUS_CHECKS.success.tag
  }
  if (_.includes(constants.SMS_STATUS_CHECKS.failed.values, input) || _.eq(constants.SMS_STATUS_CHECKS.failed.value, input)) {
    return constants.SMS_STATUS_CHECKS.failed.tag
  }
  if (_.includes(constants.SMS_STATUS_CHECKS.refund.values, input) || _.eq(constants.SMS_STATUS_CHECKS.refund.value, input)) {
    return constants.SMS_STATUS_CHECKS.refund.tag
  }
  if (!isFinal) {
    if (_.includes(['submitted'], input)) {
      return constants.SMS_STATUS_CHECKS.submitted.tag
    }
  }
  return constants.SMS_STATUS_CHECKS.failed.tag
}

// chunk an array
export const chunkArray = (inputArray: any[], chunkLimit: number) => {
  let index = 0
  const arrayLength = inputArray.length
  const tempArray = []
  for (index = 0; index < arrayLength; index += chunkLimit) {
    const subChunk = inputArray.slice(index, index + chunkLimit)
    tempArray.push(subChunk)
  }
  return tempArray
}

// encrypt password using Cryptr
export const encryptPassword = (value: string) => new Cryptr(getEnvironmentVariable(variables.PASSWORD_HASH.name)).encrypt(value)

// decrypt password using Cryptr
export const decryptPassword = (value: string) => new Cryptr(getEnvironmentVariable(variables.PASSWORD_HASH.name)).decrypt(value)

// sanatise full name
export const getSanatisedName = (firstName: string, middleName: string, lastName: string) => {
  const value = `${middleName}`
  if (!value || value.trim().length <= 0) {
    return `${firstName} ${middleName} ${lastName}`
  }
  return `${firstName} ${lastName}`
}

// get sanatised first Name
export const getSanatisedFirstName = (firstName: string, lastName: string) => {
  if (!_.isNil(firstName)) {
    if (_.eq(firstName.toLowerCase(), 'n/a')) {
      return constants.MESSAGE_DEFAULTS.name
    }
    return firstName
  } if (_.isNil(firstName) && !_.isNil(lastName)) {
    return lastName
  }
  return constants.MESSAGE_DEFAULTS.name
}

// positive number check
export const isNumberPositive = (value: string) => /^[+]?\d*\.?\d+$/.test(value)

// valid sms cost check
export const isValidSMSCost = (value: string) => /^[+]?[0-9]{1,9}(?:\.[0-9]{1,2})?$/.test(value)

// valid month check
export const isValidMonth = (value: number) => /^([1-9]|1[012])$/.test(String(value))

// valid year check
export const isValidYear = (value: number) => /^19[5-9]\d|20[0-4]\d|2050$/.test(String(value))

// valid url check
export const isValidURl = (value: string) => /^(?:(?:https?|ftp):\/\/)?(?:(?!(?:10|127)(?:\.\d{1,3}){3})(?!(?:169\.254|192\.168)(?:\.\d{1,3}){2})(?!172\.(?:1[6-9]|2\d|3[0-1])(?:\.\d{1,3}){2})(?:[1-9]\d?|1\d\d|2[01]\d|22[0-3])(?:\.(?:1?\d{1,2}|2[0-4]\d|25[0-5])){2}(?:\.(?:[1-9]\d?|1\d\d|2[0-4]\d|25[0-4]))|(?:(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)(?:\.(?:[a-z\u00a1-\uffff0-9]-*)*[a-z\u00a1-\uffff0-9]+)*(?:\.(?:[a-z\u00a1-\uffff]{2,})))(?::\d{2,5})?(?:\/\S*)?$/.test(value)

// valid phone check
export const isValidPhone = (value: number | string) => /^\d{10}$/.test(String(value))

// valid distance check
export const isValidDistance = (value: string) => /^[-+]?\d*\.?\d+$/.test(value)

// valid number check
export const isValidNumber = (value: string | number) => /^[0-9]*$/.test(String(value))

// valid decimal number check
export const isValidDecimalNumber = (value: string | number) => /^-?\d*(\.\d+)?$/.test(String(value))

// valid number check
export const isValidSenderID = (value: string) => /^[a-zA-Z0-9]+$/.test(String(value))

// valid object check
export const isObjectValid = (query: any): boolean => {
  try {
    JSON.parse(JSON.stringify(query))
    return true
  } catch (e) {
    return false
  }
}

// get total consumed credits
export const getTotalCredits = (payload: CampaignCronPayload | WhatsappCampaign, shortID?: string): number => {
  let composeMessage: string
  if (payload.tracking) {
    const finalURl = `${getEnvironmentVariable(variables.EMAIL_DOMAIN.name)}/${!_.isNil(shortID) ? shortID : uniqid.time()}`
    composeMessage = `${payload.message}\n${finalURl}`
  } else {
    composeMessage = `${payload.message}`
  }
  // let credit = 0
  // if (composeMessage.length <= 306) {
  //   credit = composeMessage.length / 160
  //   if (composeMessage.length % 160 !== 0) {
  //     credit += 1
  //   }
  // } else {
  //   credit = composeMessage.length / 153
  //   if (composeMessage.length % 153 !== 0) {
  //     credit += 1
  //   }
  // }
  const parts = gsm(composeMessage)
  return parts.sms_count
  // return Math.floor(credit)
}

// get request message
export const getRequestMessage = (payload: CampaignCronPayload, request: Requests, altDomain: boolean, custom = false, rcs = false): string => {
  let composeMessage: string
  const domain = altDomain ? getEnvironmentVariable(variables.ALT_DOMAIN.name) : getEnvironmentVariable(variables.EMAIL_DOMAIN.name)

  if (payload.dynamic && (!_.isNil(request) || custom)) {
    composeMessage = `${payload.message}`
    const view = {} as GenericObject
    view.clientname = payload.clientName
    if (!_.isEmpty(payload.ivr)) {
      view.ivr = payload.ivr
    }
    if (!_.isEmpty(payload.otp)) {
      view.otp = payload.otp
    }

      view.firstname = custom ? payload.firstName || '' : request.firstName || ''
      view.middlename = custom ? payload.middleName || '' : request.middleName || ''
      view.lastname = custom ? payload.lastName || '' : request.lastName || ''
      view.var1 = custom ? payload.var1 : payload.contactData[0].var1
      view.var2 = custom ? payload.var2 : payload.contactData[0].var2
      view.var3 = custom ? payload.var3 : payload.contactData[0].var3
      view.var4 = custom ? payload.var4 : payload.contactData[0].var4

    if (payload.tracking) {
      view.url = `${domain}/${!_.isNil(request) ? request.shortID : uniqid.time()}`
    }
    composeMessage = Handlebars.compile(composeMessage)(view)
  } else if (payload.tracking) {
    if (!rcs) {
      const finalURl = `${domain}/${!_.isNil(request) ? request.shortID : uniqid.time()}`
      composeMessage = `${payload.message}\n${finalURl}`
    }
  } else {
    composeMessage = `${payload.message}`
  }
  composeMessage = composeMessage.replace('  ', ' ')
  // console.log(composeMessage)
  return composeMessage
}

export const switchSMPPClientRoute = (route:number) => {
  let destination_route = ConfigHandler.getInstance().getSMPPConfigRoute(route)
  if (_.isNil(destination_route)) {
    destination_route = 'DEFAULT'
  }
  return destination_route
}

// get request message
export const getDripRequestMessage = (payload: CampaignCronPayload, request: Requests): string => {
  let composeMessage: string
  if (payload.dynamic && !_.isNil(request)) {
    composeMessage = `${payload.dripmessage}`
    const view = {} as GenericObject
    view.clientname = payload.clientName
    if (!_.isEmpty(payload.ivr)) {
      view.ivr = payload.ivr
    }
    if (_.isEmpty(request.firstName) && _.isEmpty(request.middleName) && _.isEmpty(request.lastName)) {
      view.firstname = constants.MESSAGE_DEFAULTS.name
    } else {
      view.firstname = request.firstName || ''
      view.middlename = request.middleName || ''
      view.lastname = request.lastName || ''
      view.var1 = payload.contactData[0].var1
      view.var2 = payload.contactData[0].var2
      view.var3 = payload.contactData[0].var3
      view.var4 = payload.contactData[0].var4
    }
    if (payload.tracking) {
      view.url = `${getEnvironmentVariable(variables.EMAIL_DOMAIN.name)}/${!_.isNil(request) ? request.shortID : uniqid.time()}`
    }
    composeMessage = Handlebars.compile(composeMessage)(view)
  } else if (payload.tracking) {
    const finalURl = `${getEnvironmentVariable(variables.EMAIL_DOMAIN.name)}/${!_.isNil(request) ? request.shortID : uniqid.time()}`
    composeMessage = `${payload.message}\n${finalURl}`
  } else {
    composeMessage = `${payload.message}`
  }
  composeMessage = composeMessage.replace('  ', ' ')
  return composeMessage
}

// get credits based on string
export const getCreditsFromMessage = (composeMessage: string): number => {
  // let credit = 0
  // if (composeMessage.length <= 306) {
  //   credit = composeMessage.length / 160
  //   if (composeMessage.length % 160 !== 0) {
  //     credit += 1
  //   }
  // } else {
  //   credit = composeMessage.length / 153
  //   if (composeMessage.length % 153 !== 0) {
  //     credit += 1
  //   }
  // }
  // return Math.floor(credit)
  const parts = gsm(composeMessage)
  return parts.sms_count
}

// generate unique uid
export const generateUID = (): string => uuidv4()

// generate short unique uid
export const generateShortUID = (): string => uniqid.time()

// get milliseconds from string
export const getMilliseconds = (time: string) => {
  if (_.eq(typeof time, 'string')) {
    const milliseconds = ms(time)
    if (_.eq(typeof milliseconds, 'undefined')) {
      return undefined
    }
    return milliseconds
  }
}

export const getSecondsFromHours = (hours: number) => getSeconds(`${hours}hr`)

// get seconds from string
export const getSeconds = (time: string) => {
  if (_.eq(typeof time, 'string')) {
    const milliseconds = ms(time)
    if (_.eq(typeof milliseconds, 'undefined')) {
      return undefined
    }
    return milliseconds / 1000
  }
}

// get token expiration timestamp
export const getExpirationTimestamp = (token: string) => {
  try {
    const jwtTokenObject = JSON.parse(atob(token.split('.')[1]))
    return jwtTokenObject.exp
  } catch (error) {
    return 0
  }
}

// token handler initializing options
export const switchUserAudience = (userType: number): audience => {
  let audience_val: audience = audience.PUBLIC
  switch (userType) {
    case constants.USER_TYPES.client:
      audience_val = audience.CLIENT
      break
    case constants.USER_TYPES.admin:
      audience_val = audience.ADMIN
      break
    default:
  }
  return audience_val
}

// delete a file using file path

export const deleteFile = (filePath: string) => {
  try {
    fs.unlinkSync(filePath)
  } catch (error) {
    console.log(error)
  }
}

export const createCSV = (data: Array<any>) => {
  let field_name = ''
  const fields = Object.keys(data[0])
  const replacer = (key: string, value: any) => {
    if (_.isNil(value)) {
      return ''
    }
    if (_.eq(field_name, 'delivered')) {
      return getSMSDeliveryStatus(value)
    } if (_.eq(field_name, 'time')) {
      const time_ref = getDateTimeString(new Date(value))
      return `${time_ref.word_date} ${time_ref.time}`
    }
    return value
  }
  const csv = data.map((row) => fields
    .map((fieldName) => {
      field_name = fieldName
      return JSON.stringify(row[fieldName], replacer)
    })
    .join(','))
  csv.unshift(fields.join(','))
  return csv.join('\r\n')
}

// create server static directories
export const createStaticDirectories = () => {
  if (!fs.existsSync(path.join(process.cwd(), `${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/`))) {
    fs.mkdirSync(path.join(process.cwd(), `${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/`))
  }
  if (
    !fs.existsSync(path.join(process.cwd(), `${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.WALKTHROUGH_DIRECTORY.name)}`))
  ) {
    fs.mkdirSync(path.join(process.cwd(), `${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.WALKTHROUGH_DIRECTORY.name)}`))
  }
  if (!fs.existsSync(path.join(process.cwd(), `${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.STATIC_DIRECTORY.name)}`))) {
    fs.mkdirSync(path.join(process.cwd(), `${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.STATIC_DIRECTORY.name)}`))
  }
  if (
    !fs.existsSync(path.join(process.cwd(), `${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.BROCHURE_DIRECTORY.name)}`))
  ) {
    fs.mkdirSync(path.join(process.cwd(), `${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.BROCHURE_DIRECTORY.name)}`))
  }
}

/*
get brower name & version
*/
export const getBrowserAndVersion = (userAgent: string): RegExpMatchArray => {
  const deviceInfo = new deviceDetect().parse(userAgent)
  return [deviceInfo.client?.name || 'unknown', deviceInfo.client?.version || '0']
}

export const getArgs = () => {
  const args = {}
  process.argv
    .slice(2, process.argv.length)
    .forEach((arg) => {
      // long arg
      if (arg.slice(0, 2) === '--') {
        const longArg = arg.split('=')
        const longArgFlag = longArg[0].slice(2, longArg[0].length)
        const longArgValue = longArg.length > 1 ? longArg[1] : true
        args[longArgFlag] = longArgValue
      }
      // flags
      else if (arg[0] === '-') {
        const flags = arg.slice(1, arg.length).split('')
        flags.forEach((flag) => {
          args[flag] = true
        })
      }
    })
  return args
}

export const createVappContext = (request: Request) => {
  const userAgent = <string>(request.headers['user-agent'] || request.headers['User-Agent'])
  const { ip, originalUrl, method } = request
  const userAgentSpecs = getBrowserAndVersion(userAgent)
  return <VappContext>{
    traceID: generateUID(),
    userAgent,
    specs: {
      browser: userAgentSpecs[0],
      version: parseInt(userAgentSpecs[1], 10),
    },
    ip,
    url: originalUrl.replace(/\?.*$/, ''),
    method,
  }
}

export const getDateTimeString = (date: Date): { time: string; date: string; word_date: string } => {
  let hours = date.getHours()
  const ampm = hours >= 12 ? 'pm' : 'am'
  hours %= 12
  hours = hours || 12
  const minutes = date.getMinutes()
  const minutesString = (`0${minutes}`).slice(-2)
  return {
    time: `${hours}:${minutesString} ${ampm}`,
    date: `${date.getDate()}-${date.getMonth()}-${date.getFullYear()}`,
    word_date: `${months[date.getMonth()].short} ${date.getDate()}, ${date.getFullYear()}`,
  }
}

export const get12MonthFilter = ():any => {
  const currentMonth = new Date().getMonth()
  let startMonth = currentMonth - 11
  const condtions = []
  while (startMonth <= currentMonth) {
    let year = new Date().getFullYear()
    let month = startMonth
    if (startMonth < 0) {
      year -= 1
      month = 12 + month
    }
    condtions.push({
      year,
      month: month + 1,
    })
    startMonth++
  }
  const filter = {
    $or: condtions,
  }
  return filter
}

export const dateFromObjectId = (objectId: string) => new Date(parseInt(objectId.substring(0, 8), 16) * 1000)

export const epochTimeFromDate = (date: Date) => Math.floor(date.getTime() / 1000.0)

export const sleepThread = (waitTimeInMs) => new Promise((resolve) => setTimeout(resolve, waitTimeInMs))

export const getScrapingFormattedDate = (date: Date) => {
  const year = String(date.getFullYear()).substring(2)
  const month = (1 + date.getMonth()).toString().padStart(2, '0')
  const day = date.getDate().toString().padStart(2, '0')
  return `${day}-${month}-${year}`
}

export const toBoolean = (data: TransformFnParams) => {
  if (data.value === true || data.value === false) return data
  switch (data.value.toLowerCase().trim()) {
    case 'true':
    case 'yes':
    case '1':
      return true
    case 'false':
    case 'no':
    case '0':
    case null:
      return false
    default:
      return Boolean(data.value)
  }
}
