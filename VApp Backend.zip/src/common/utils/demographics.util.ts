import { environments, variables } from '@config'
import { DemograhicObject } from '@interfaces/demographics.interface'
import { HTTPService } from '@services/http.service'
import _ from 'lodash'
import publicIp from 'public-ip'
import { getEnvironmentVariable } from './platform.util'

export default class DemographicsHandler {
  private static instance: DemographicsHandler

  private url: string

  private key: string

  private constructor() {
    if (_.isNil(this.url)) {
      this.url = getEnvironmentVariable(variables.IPAPI_URL.name)
    }
    if (_.isNil(this.key)) {
      this.key = getEnvironmentVariable(variables.IPAPI_SECRET.name)
    }
  }

  static getInstance(): DemographicsHandler {
    if (_.isNil(DemographicsHandler.instance)) {
      DemographicsHandler.instance = new DemographicsHandler()
    }
    return DemographicsHandler.instance
  }

  getDemographics(ip: string) {
    return new Promise<DemograhicObject>(async (resolve: (value?: DemograhicObject | PromiseLike<DemograhicObject>) => void) => {
      const clientIP = !_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.local) ? ip.trim() : await publicIp.v4()
      const key = !_.isNil(this.key) && !_.isEmpty(this.key) ? `?key=${this.key}` : ''
      const url = `${this.url}${clientIP}/json${key}`
      HTTPService.getInstance()
        .get(url)
        .then((response) => {
          resolve(<DemograhicObject>response.data)
        })
        .catch((e) => {
          resolve(<DemograhicObject>{})
        })
    })
  }
}
