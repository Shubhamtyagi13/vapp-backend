import { variables } from '@config'
import { getEnvironmentVariable } from '@utils/platform.util'
import admin from 'firebase-admin'
import _ from 'lodash'

export class FireBaseHandler {
  private static instance: FireBaseHandler

  private static _firebase: admin.app.App

  private constructor() {
    if (_.isNil(FireBaseHandler._firebase)) {
      FireBaseHandler._firebase = admin.initializeApp({
        databaseURL: getEnvironmentVariable(variables.FIREBASE_DATABASE_URL.name),
        credential: admin.credential.cert({
          projectId: getEnvironmentVariable(variables.FIREBASE_PROJECT_ID.name),
          clientEmail: getEnvironmentVariable(variables.FIREBASE_CLIENT_EMAIL.name),
          privateKey: getEnvironmentVariable(variables.FIREBASE_PRIVATE_KEY.name)
        })
      })
    }
  }

  static getInstance(): admin.app.App {
    if (_.isNil(FireBaseHandler.instance)) {
      FireBaseHandler.instance = new FireBaseHandler()
    }
    return FireBaseHandler._firebase
  }
}
