import { variables } from '@config'
import { IoAdapter } from '@nestjs/platform-socket.io'
import { createAdapter } from 'socket.io-redis'
import { RedisClient } from 'redis'
import { getEnvironmentVariable } from './platform.util'

export class SocketAapter extends IoAdapter {
  createIOServer(port: number, options?: any): any {
    const server = super.createIOServer(port, options)
    const pubClient = new RedisClient({
      host: getEnvironmentVariable(variables.REDIS_URL.name),
      port: parseInt(getEnvironmentVariable(variables.REDIS_PORT.name), 10)
    })
    const subClient = pubClient.duplicate()
    const redisAdapter = createAdapter({ pubClient, subClient })
    server.adapter(redisAdapter)
    return server
  }
}
