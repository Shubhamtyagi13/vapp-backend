import { constants, variables } from '@config'
import { MaintenanceException } from '@exceptions/maintenance.exception'
import { messages } from '@messages'
import { CanActivate, ExecutionContext, Injectable } from '@nestjs/common'
import { Reflector } from '@nestjs/core'
import { ConfigHandler } from '@utils/config.util'
import { getAPIResponse } from '@utils/platform.util'
import { Request } from 'express'
import { Observable } from 'rxjs'

@Injectable()
export class MaintenanceGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
    const request = <Request>context.switchToHttp().getRequest()
    if (ConfigHandler.getInstance().getValue(variables.MAINTENANCE_MODE.name) && !this.isPresent(request.originalUrl)) {
      throw new MaintenanceException(getAPIResponse(messages.COM009.code, request.VAPP_CONTEXT.traceID, 701))
    } else {
      return true
    }
  }

  isPresent = (path: string) => {
    let isPresent = false
    constants.MAINTENANCE_FILTER_ROUTES.forEach((filterPath) => {
      if (path.includes(filterPath)) {
        isPresent = true
      }
    })
    return isPresent
  }
}
