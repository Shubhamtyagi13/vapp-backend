import { User } from '@app/user/user.schema'
import { audience, variables } from '@config'
import { JWTException } from '@exceptions/jwt.exception'
import { GenericObject } from '@interfaces/generic.interface'
import { messages } from '@messages'
import { CanActivate, ExecutionContext, HttpStatus, Injectable } from '@nestjs/common'
import { Reflector } from '@nestjs/core'
import { getAPIResponse, getEnvironmentVariable } from '@utils/platform.util'
import { Request } from 'express'
import jwt, { JsonWebTokenError, NotBeforeError, TokenExpiredError, VerifyErrors } from 'jsonwebtoken'
import _ from 'lodash'
import parse from 'parse-bearer-token'
import { Observable } from 'rxjs'

@Injectable()
export class AuthenticationGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean | Promise<boolean> | Observable<boolean> {
    const request = <Request>context.switchToHttp().getRequest()
    const jwt_token = parse(request)
    const app_audience = this.reflector.get<audience[]>('audience', context.getHandler())
    if (!_.isNil(app_audience) && !_.isEmpty(app_audience)) {
      if (!request.session.verified || !request.session.expTime || request.session.expTime - Date.now() / 1000 < 0) {
        if (!_.isNil(jwt_token)) {
          let exp_time = 0
          jwt.verify(
            jwt_token,
            getEnvironmentVariable(variables.JWT_PRIVATE_SECRET.name),
            { audience: app_audience, issuer: getEnvironmentVariable(variables.JWT_ISSUER.name) },
            (error: VerifyErrors, user: User) => {
              if (!_.isNil(error)) {
                request.session.verified = false
                delete request.session.expTime
                delete request.session.user
                delete request.session.token
                if (_.eq(error.name, JsonWebTokenError.name)) {
                  throw new JWTException(getAPIResponse(messages.JWT001.code, request.VAPP_CONTEXT.traceID, HttpStatus.UNAUTHORIZED, { error: JsonWebTokenError.name }))
                } else if (_.eq(error.name, NotBeforeError.name)) {
                  throw new JWTException(getAPIResponse(messages.JWT002.code, request.VAPP_CONTEXT.traceID, HttpStatus.FORBIDDEN, { error: NotBeforeError.name }))
                } else if (_.eq(error.name, TokenExpiredError.name)) {
                  throw new JWTException(getAPIResponse(messages.JWT003.code, request.VAPP_CONTEXT.traceID, HttpStatus.UNAUTHORIZED, { error: TokenExpiredError.name }))
                } else {
                  throw new JWTException(getAPIResponse(messages.COM001.code, request.VAPP_CONTEXT.traceID, HttpStatus.FORBIDDEN))
                }
              }
              exp_time = (user as GenericObject).exp
              request.user = _.merge({}, user) as User
              request.session.user = _.merge({}, user)
              request.session.token = jwt_token
            }
          )
          request.session.expTime = exp_time
          request.token = jwt_token
          request.session.verified = true
          return true
        }
        throw new JWTException(getAPIResponse(messages.JWT004.code, request.VAPP_CONTEXT.traceID, HttpStatus.UNAUTHORIZED))
      }
      request.user = _.merge({}, request.session.user) as User
      request.token = request.session.token
      if (!_.includes(app_audience, request.session.user.aud)) {
        throw new JWTException(getAPIResponse(messages.JWT005.code, request.VAPP_CONTEXT.traceID, HttpStatus.UNAUTHORIZED, { error: JsonWebTokenError.name }))
      }
      return true
    }
    throw new JWTException(getAPIResponse(messages.COM001.code, request.VAPP_CONTEXT.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
  }
}
