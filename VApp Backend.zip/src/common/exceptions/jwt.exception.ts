import { ServiceResponse } from '@interfaces/response.interface'
import { HttpException } from '@nestjs/common'

export class JWTException extends HttpException {
  constructor(exception: ServiceResponse) {
    super(exception, exception.status)
  }
}
