import { ServiceResponse } from '@interfaces/response.interface'
import { HttpException } from '@nestjs/common'

export class MaintenanceException extends HttpException {
  constructor(exception: ServiceResponse) {
    super(exception, exception.status)
  }
}
