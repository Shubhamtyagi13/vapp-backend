import { audience } from '@config'
import { SetMetadata } from '@nestjs/common'

export const Audience = (app_audience: audience[]) => SetMetadata('audience', app_audience)
