import { SetMetadata } from '@nestjs/common'

export const NoClientOverride = (override = true) => SetMetadata('no_override', override)
