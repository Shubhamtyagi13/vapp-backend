import { createParamDecorator, ExecutionContext } from '@nestjs/common'
import { Request } from 'express'
import parse from 'parse-bearer-token'

export const Token = createParamDecorator((data: string, ctx: ExecutionContext) => {
  const request = <Request>ctx.switchToHttp().getRequest()
  return parse(request)
})
