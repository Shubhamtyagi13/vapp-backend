import { APIResponse } from '@interfaces/response.interface'
import { messages } from '@messages'
import { ArgumentMetadata, BadRequestException, HttpStatus, Inject, mixin, PipeTransform, Type } from '@nestjs/common'
import { REQUEST } from '@nestjs/core'
import { getAPIResponse } from '@utils/platform.util'
import { plainToClass } from 'class-transformer'
import { validate } from 'class-validator'
import { Request } from 'express'

/*
validation => valid string, boolean, array or object
*/
class MixinValidationPipe implements PipeTransform<any> {
  private traceID: string

  constructor(@Inject(REQUEST) private readonly request: Request) {
    this.traceID = this.request.VAPP_CONTEXT.traceID
  }

  async transform(value: string, metadata: ArgumentMetadata) {
    const { metatype } = metadata
    if (!metatype || !this.toValidate(metatype)) {
      return value
    }
    const object = plainToClass(metatype, value)
    const errors = await validate(object)
    if (errors.length > 0) {
      const { type, data } = metadata
      throw new BadRequestException(<APIResponse>getAPIResponse(messages.VAL003.code, this.traceID, HttpStatus.BAD_REQUEST, { type, data }))
    }
    return value
  }

  private toValidate(metatype: Type<unknown>): boolean {
    const types = [String, Boolean, Number, Array, Object]
    return !types.find((type) => metatype === type)
  }
}
export const ValidationPipe = () => mixin(MixinValidationPipe)
