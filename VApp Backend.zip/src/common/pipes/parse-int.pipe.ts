import { APIResponse } from '@interfaces/response.interface'
import { messages } from '@messages'
import { ArgumentMetadata, BadRequestException, HttpStatus, Inject, mixin, PipeTransform } from '@nestjs/common'
import { REQUEST } from '@nestjs/core'
import { getAPIResponse } from '@utils/platform.util'
import { Request } from 'express'

/*
validation => valid number (decimal)
*/
class MixinParseIntPipe implements PipeTransform {
  private traceID: string

  constructor(@Inject(REQUEST) private readonly request: Request) {
    this.traceID = this.request.VAPP_CONTEXT.traceID
  }

  async transform(value: string, metadata: ArgumentMetadata) {
    const val = parseInt(value, 10)
    if (Number.isNaN(val)) {
      const { type, data } = metadata
      throw new BadRequestException(<APIResponse>getAPIResponse(messages.VAL001.code, this.traceID, HttpStatus.BAD_REQUEST, { type, data }))
    }
    return val
  }
}
export const ParseIntPipe = () => mixin(MixinParseIntPipe)
