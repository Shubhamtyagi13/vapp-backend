import { APIResponse } from '@interfaces/response.interface'
import { messages } from '@messages'
import { ArgumentMetadata, BadRequestException, HttpStatus, Inject, mixin, PipeTransform } from '@nestjs/common'
import { REQUEST } from '@nestjs/core'
import { getAPIResponse } from '@utils/platform.util'
import { Request } from 'express'
import _ from 'lodash'

/*
validation => valid number (decimal)
*/
class MixinParseBooleanPipe implements PipeTransform {
  private traceID: string

  constructor(@Inject(REQUEST) private readonly request: Request) {
    this.traceID = this.request.VAPP_CONTEXT.traceID
  }

  async transform(value: string, metadata: ArgumentMetadata) {
    if (_.eq(value, 'true')) {
      return true
    }
    if (_.eq(value, 'false')) {
      return false
    }

    const { type, data } = metadata
    throw new BadRequestException(<APIResponse>getAPIResponse(messages.VAL002.code, this.traceID, HttpStatus.BAD_REQUEST, { type, data }))
  }
}

export const ParseBooleanPipe = () => mixin(MixinParseBooleanPipe)
