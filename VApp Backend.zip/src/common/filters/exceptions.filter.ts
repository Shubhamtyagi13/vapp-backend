import { _HTTPStatus } from '@config'
import { ServiceResponse } from '@interfaces/response.interface'
import { messages } from '@messages'
import { ArgumentsHost, Catch, ExceptionFilter, HttpException, HttpStatus } from '@nestjs/common'
import { VappLogger } from '@services/logger.service'
import { createVappContext } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'

@Catch()
export class ExceptionsFilter implements ExceptionFilter {
  private logger = new VappLogger()

  catch(exception: any, host: ArgumentsHost) {
    const ctx = host.switchToHttp()
    const response = ctx.getResponse<Response>()
    const request = ctx.getRequest<Request>()
    if (_.isNil(request.VAPP_CONTEXT)) {
      request.VAPP_CONTEXT = createVappContext(request)
    }
    const status = exception instanceof HttpException ? exception.getStatus() : HttpStatus.INTERNAL_SERVER_ERROR
    const payload = this.switchResponseStatus(status)
    if (_.isNil(exception.response)) {
      exception.response = {}
    }
    response.status(status).send(<ServiceResponse>{
      traceID: request.VAPP_CONTEXT.traceID,
      code: _.isNil(exception.response.code) ? payload.code : exception.response.code,
      message: _.isNil(exception.response.message) ? payload.message : _.eq(typeof exception.response.message, 'string') ? exception.response.message : payload.message,
      data: _.isNil(exception.response.data)
        ? _.eq(typeof exception.response.message, 'object')
          ? [...exception.response.message]
          : {}
        : _.eq(typeof exception.response.message, 'object')
        ? { ...exception.response.message, ...exception.response.data }
        : exception.response.data,
      status: _.isNil(exception.response.status) ? status : exception.response.status
    })
  }

  private switchResponseStatus = (status: number) => {
    const payload = <{ message: string; code: string }>{
      message: messages.COM001.message,
      code: messages.COM001.code
    }
    switch (status) {
      case HttpStatus.FORBIDDEN:
        payload.message = messages.COM002.message
        payload.code = messages.COM002.code
        break
      case 408:
        payload.message = messages.COM005.message
        payload.code = messages.COM005.code
        break
      case HttpStatus.TOO_MANY_REQUESTS:
        payload.message = messages.COM006.message
        payload.code = messages.COM006.code
        break
      case HttpStatus.NOT_FOUND:
        payload.message = messages.COM007.message
        payload.code = messages.COM007.code
        break
      case _HTTPStatus.MAINTENANCE_MODE:
        payload.message = messages.COM009.message
        payload.code = messages.COM009.code
        break
      default:
        payload.message = messages.COM001.message
        payload.code = messages.COM001.code
    }
    return payload
  }
}
