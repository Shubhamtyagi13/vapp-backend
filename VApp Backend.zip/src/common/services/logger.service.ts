import { environments, log, variables } from '@config'
import { ErrorLogObject, TimingLogObject } from '@interfaces/logger.interface'
import { logging } from '@messages'
import { Injectable, LoggerService } from '@nestjs/common'
import { getEnvironmentVariable } from '@utils/platform.util'
import _ from 'lodash'
import winston, { format, Logger, transport } from 'winston'
import winstonCloudWatchTransport from 'winston-cloudwatch'
import winstonTimestampColorize from 'winston-timestamp-colorize'

/*
Custom logger
Dual trasports => 1: File 2: Console
Multiple logging levels
*/
@Injectable()
export class VappLogger implements LoggerService {
  private static logger: Logger

  private base_transports: transport[] = []

  private readonly options: winston.LoggerOptions = {
    levels: _.map(log.levels, (level) => ({ [level.value]: level.priority })).reduce((levels: { [key: string]: number }, level: { [key: string]: number }) => Object.assign(levels, level), {}),
    transports: this.base_transports,
  }

  constructor() {
    if (_.isNil(VappLogger.logger)) {
      winston.format.colorize().addColors(log.colors)
      if (_.includes([environments.development, environments.staging, environments.qa, environments.production], getEnvironmentVariable(variables.VAPP_ENV.name))) {
        this.base_transports.push(
          new winstonCloudWatchTransport({
            name: 'cloudwatch',
            logGroupName: 'rest-server',
            awsRegion: getEnvironmentVariable(variables.AWS_REGION.name),
            awsAccessKeyId: getEnvironmentVariable(variables.AWS_ACCESS_KEY.name),
            awsSecretKey: getEnvironmentVariable(variables.AWS_SECRET_KEY.name),
            logStreamName: `${getEnvironmentVariable(variables.VAPP_ENV.name)}_${getEnvironmentVariable(variables.NODE_APP_INSTANCE.name)}`,
            jsonMessage: true,
          }),
        )
      }
      if (_.includes([environments.development, environments.local], getEnvironmentVariable(variables.VAPP_ENV.name))) {
        this.base_transports.push(
          new winston.transports.Console({
            level: _.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production)
              ? log.levels.error.value
              : getEnvironmentVariable(variables.LOG_LEVEL.name),
            format: format.combine(format.timestamp(), format.splat(), format.colorize({ all: true }), winstonTimestampColorize({ color: 'green' }), format.printf(
              (msg) =>
                `${msg.level}: ${msg.message} - ${msg.timestamp} ${
                  !_.isNil(msg.traceID)
                    ? `${JSON.stringify(_.pick(msg, _.keys(msg).filter((key: string) => !['message', 'level', 'timestamp'].includes(key))), null, 2)}`
                    : ''
                }`,
            )),
          }),
        )
      }
      this.options.transports = this.base_transports
      VappLogger.logger = winston.createLogger(this.options)
      if (!_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production)) {
        this.log(`${logging.initialised(getEnvironmentVariable(variables.LOG_LEVEL.name))}`)
      }
    }
  }

  log(message: string | TimingLogObject | ErrorLogObject): void {
    if (!_.isNil(VappLogger.logger)) {
      VappLogger.logger.info(this.sanatizeMessage(message), this.sanatizeMetadata(message))
    }
  }

  error(message: string | TimingLogObject | ErrorLogObject): void {
    if (!_.isNil(VappLogger.logger)) {
      VappLogger.logger.error(this.sanatizeMessage(message), this.sanatizeMetadata(message))
    }
  }

  warn(message: string | TimingLogObject | ErrorLogObject): void {
    if (!_.isNil(VappLogger.logger)) {
      VappLogger.logger.warning(this.sanatizeMessage(message), this.sanatizeMetadata(message))
    }
  }

  debug(message: string | TimingLogObject | ErrorLogObject): void {
    if (!_.isNil(VappLogger.logger)) {
      VappLogger.logger.debug(this.sanatizeMessage(message), this.sanatizeMetadata(message))
    }
  }

  trace(message: string | TimingLogObject | ErrorLogObject): void {
    if (!_.isNil(VappLogger.logger)) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (VappLogger.logger as any).trace(this.sanatizeMessage(message), this.sanatizeMetadata(message))
    }
  }

  alert(message: string | TimingLogObject | ErrorLogObject): void {
    if (!_.isNil(VappLogger.logger)) {
      VappLogger.logger.alert(this.sanatizeMessage(message), this.sanatizeMetadata(message))
    }
  }

  critical(message: string | TimingLogObject | ErrorLogObject): void {
    if (!_.isNil(VappLogger.logger)) {
      VappLogger.logger.crit(this.sanatizeMessage(message), this.sanatizeMetadata(message))
    }
  }

  notice(message: string | TimingLogObject | ErrorLogObject): void {
    if (!_.isNil(VappLogger.logger)) {
      VappLogger.logger.notice(this.sanatizeMessage(message), this.sanatizeMetadata(message))
    }
  }

  private sanatizeMessage(message: string | TimingLogObject | ErrorLogObject) {
    if (_.eq(typeof message, 'object')) {
      return ''
    }
    return String(message)
  }

  private sanatizeMetadata(message: string | TimingLogObject | ErrorLogObject) {
    if (_.eq(typeof message, 'object')) {
      return message
    }
    return String({})
  }
}
