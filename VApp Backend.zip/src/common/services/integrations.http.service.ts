import { GenericObject } from '@interfaces/generic.interface'
import { HttpResponse } from '@interfaces/http.interface'
import { Injectable } from '@nestjs/common'
import axios, { AxiosInstance } from 'axios'
import _ from 'lodash'
import axiosThrottle from 'axios-request-throttle'

@Injectable()
export class IntegrationsHTTPService {
  private static instance: IntegrationsHTTPService

  private axiosInstance: AxiosInstance

  private constructor() {
    this.axiosInstance = axios.create({})
    axiosThrottle.use(this.axiosInstance, { requestsPerSecond: 1 })
  }

  static getInstance(): IntegrationsHTTPService {
    if (_.isNil(IntegrationsHTTPService.instance)) {
      IntegrationsHTTPService.instance = new IntegrationsHTTPService()
    }
    return IntegrationsHTTPService.instance
  }

  public get(url: string, params?: GenericObject, headers?: any, timeout?: number) {
    return new Promise<HttpResponse>((resolve: (value?: HttpResponse | PromiseLike<HttpResponse>) => void, reject: (reason?: Error) => void) => {
      this.axiosInstance
        .get(url, {
          headers,
          params,
          timeout: timeout || 0,
          paramsSerializer: (params) => {
            let result = ''
            Object.keys(params).forEach((key) => {
              result += `${key}=${encodeURIComponent(params[key])}&`
            })
            return result.substr(0, result.length - 1)
          }
        })
        .then((response: HttpResponse) => {
          resolve(response)
        })
        .catch((error: Error) => {
          reject(error)
        })
    })
  }

  public post(url: string, data?: any, params?: any, headers?: any, timeout?: number) {
    return new Promise<HttpResponse>((resolve: (value?: HttpResponse | PromiseLike<HttpResponse>) => void, reject: (reason?: Error) => void) => {
      this.axiosInstance
        .post(url, data, {
          headers,
          params,
          timeout: timeout || 0,
          maxContentLength: Infinity,
          maxBodyLength: Infinity
        })
        .then((response: HttpResponse) => {
          resolve(response)
        })
        .catch((error: Error) => {
          reject(error)
        })
    })
  }
}
