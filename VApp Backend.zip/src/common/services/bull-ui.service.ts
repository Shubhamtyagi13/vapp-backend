import { Injectable } from '@nestjs/common'
import _ from 'lodash'
import { ExpressAdapter } from '@bull-board/express'
import { BullAdapter } from '@bull-board/api/bullAdapter'
import { createBullBoard } from '@bull-board/api'
import { BaseAdapter } from '@bull-board/api/dist/src/queueAdapters/base'

@Injectable()
export class BullInterfaceService {
  private static instance: BullInterfaceService

  private board: {
    setQueues: (newBullQueues: readonly BaseAdapter[]) => void
    replaceQueues: (newBullQueues: readonly BaseAdapter[]) => void
    addQueue: (queue: BaseAdapter) => void
    removeQueue: (queueOrName: string | BaseAdapter) => void
  }

  private serverAdapter: ExpressAdapter

  private adapters: Array<BullAdapter>

  private constructor() {
    this.serverAdapter = new ExpressAdapter()
    this.serverAdapter.setBasePath('/api/system/jobs')
    this.adapters = []
    this.board = createBullBoard({
      queues: this.adapters,
      serverAdapter: this.serverAdapter
    })
  }

  static getInstance(): BullInterfaceService {
    if (_.isNil(BullInterfaceService.instance)) {
      BullInterfaceService.instance = new BullInterfaceService()
    }
    return BullInterfaceService.instance
  }

  public getAdapter = () => this.serverAdapter

  public registerQueues = (adapters: Array<BullAdapter>) => {
    adapters.forEach((adapter) => {
      this.adapters.push(adapter)
    })
    this.board.replaceQueues(this.adapters)
  }
}
