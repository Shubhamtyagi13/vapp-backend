import { User } from '@app/user/user.schema'
import {
  canonicalMethods, constants, environments, variables, cronJobs,
} from '@config'
import { CampaignInitialAlert, CreditsApprovedAlert, PasswordResetAlert } from '@interfaces/alert.interface'
import { EmailPayload } from '@interfaces/email.interface'
import { campaignProviderObject } from '@interfaces/sms.interface'
import { Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { createOperations, findOperations } from '@utils/crud.util'
import { EmailHandler } from '@utils/email.util'
import { getEnvironmentVariable, getErrorLog } from '@utils/platform.util'
import _ from 'lodash'
import { Model } from 'mongoose'
import AuthHandler from '@utils/auth.util'
import { Job, Queue } from 'bull'
import { InjectQueue } from '@nestjs/bull'
import { logger } from 'handlebars'

@Injectable()
export class BootstrapService {
  constructor(@InjectModel(User.name) private userModel: Model<User>) {
    this.resetDefaultPassword()
    this.createUsers()
  }

  /*
  Set default password for all users in lower environments
  */
  resetDefaultPassword() {
    if (_.includes([environments.local, environments.development], getEnvironmentVariable(variables.VAPP_ENV.name))) {
      const password = AuthHandler.getInstance().encryptionHandler().encrypt(getEnvironmentVariable(variables.BOOTSTRAP_DEFAULT_USER_PASSWORD.name))
      createOperations.updateMany(this.userModel, {}, { $set: { password } }).catch((e) => {})
    }
  }

  createUsers = () => {
    if (_.includes([environments.local, environments.development], getEnvironmentVariable(variables.VAPP_ENV.name))) {
      const adminObject: User = {
        firstName: getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_FIRST_NAME.name),
        lastName: getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_LAST_NAME.name),
        companyName: getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_COMPANY_NAME.name),
        email: `${getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_EMAIL.name)}${getEnvironmentVariable(variables.EMAIL_DOMAIN.name)}`,
        password: AuthHandler.getInstance().encryptionHandler().encrypt(getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_PASSWORD.name)),
        smsSenderID: getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_SMS_SENDER_ID.name),
        activeStatus: true,
        correspondence: `${getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_EMAIL.name)}${getEnvironmentVariable(variables.EMAIL_DOMAIN.name)}`,
        userType: constants.USER_TYPES.admin,
        manager: {
          phone: parseInt(getEnvironmentVariable(variables.BOOTSTRAP_DEFAULT_USER_CONTACT.name)),
          name: getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_FIRST_NAME.name),
          email: `${getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_EMAIL.name)}${getEnvironmentVariable(variables.EMAIL_DOMAIN.name)}`,
        },
        contact: parseInt(getEnvironmentVariable(variables.BOOTSTRAP_DEFAULT_USER_CONTACT.name)),
      } as User

      const clientObject: User = {
        firstName: getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_FIRST_NAME.name),
        lastName: getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_LAST_NAME.name),
        companyName: getEnvironmentVariable(variables.BOOTSTRAP_DEFAULT_USER_COMPANY_NAME.name),
        email: `${getEnvironmentVariable(variables.BOOTSTRAP_DEFAULT_USER_EMAIL.name)}${getEnvironmentVariable(variables.EMAIL_DOMAIN.name)}`,
        password: AuthHandler.getInstance().encryptionHandler().encrypt(getEnvironmentVariable(variables.BOOTSTRAP_DEFAULT_USER_PASSWORD.name)),
        smsSenderID: getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_SMS_SENDER_ID.name),
        activeStatus: true,
        correspondence: `${getEnvironmentVariable(variables.BOOTSTRAP_DEFAULT_USER_EMAIL.name)}${getEnvironmentVariable(variables.EMAIL_DOMAIN.name)}`,
        userType: constants.USER_TYPES.client,
        manager: {
          phone: parseInt(getEnvironmentVariable(variables.BOOTSTRAP_DEFAULT_USER_CONTACT.name)),
          name: getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_FIRST_NAME.name),
          email: `${getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_EMAIL.name)}${getEnvironmentVariable(variables.EMAIL_DOMAIN.name)}`,
        },
        contact: parseInt(getEnvironmentVariable(variables.BOOTSTRAP_DEFAULT_USER_CONTACT.name)),
      } as User
      findOperations
        .findOne(this.userModel, { email: adminObject.email.toLowerCase() })
        .then((checkExistingUser: User) => {
          if (_.isNil(checkExistingUser)) {
            createOperations
              .save(new this.userModel(adminObject))
              .then((userSaveResult: User) => {})
              .catch((error: Error) => {
              })
          }
        })
        .catch((error: Error) => {})
      findOperations
        .findOne(this.userModel, { email: clientObject.email.toLowerCase() })
        .then((checkExistingUser: User) => {
          if (_.isNil(checkExistingUser)) {
            createOperations
              .save(new this.userModel(clientObject))
              .then((userSaveResult: User) => {})
              .catch((error: Error) => {
              })
          }
        })
        .catch((error: Error) => {})
    }
  }
}
