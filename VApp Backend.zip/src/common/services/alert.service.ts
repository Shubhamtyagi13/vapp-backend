import {
  canonicalMethods, report_types, variables,
} from '@config'
import { CampaignInitialAlert, CreditsApprovedAlert, PasswordResetAlert } from '@interfaces/alert.interface'
import { EmailPayload } from '@interfaces/email.interface'
import { campaignProviderObject } from '@interfaces/sms.interface'
import { Injectable } from '@nestjs/common'
import { EmailHandler } from '@utils/email.util'
import { getEnvironmentVariable, getErrorLog } from '@utils/platform.util'
import { getSMSPayloadForInitialCampaign } from '@templates/campaign.sms.template'
import { getSMSPayloadForPasswordReset } from '@templates/password.sms.template'
import { getSMSPayloadForTransactionApproved } from '@templates/transaction.sms.template'
import _ from 'lodash'
import { VappLogger } from './logger.service'

@Injectable()
export class AlertService {
  private static instance: AlertService

  private static logger: VappLogger

  private constructor() {
    if (_.isNil(AlertService.logger)) {
      AlertService.logger = new VappLogger()
    }
  }

  static getInstance(): AlertService {
    if (_.isNil(AlertService.instance)) {
      AlertService.instance = new AlertService()
    }
    return AlertService.instance
  }

  sendCampaignInitialAlert(templateData: CampaignInitialAlert, clientContact: number, clientCorrespondence: string, traceID: string) {
    if (!_.isNil(clientContact) && !_.eq(clientContact, -1)) {
      const defaultSenderID = getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_SMS_SENDER_ID.name)
      const smsPayload: campaignProviderObject[] = []
      smsPayload.push({
        phone: clientContact,
        message: getSMSPayloadForInitialCampaign(templateData),
      })
      try {
        // SmsHandler.getInstance(sms_client.MY_INBOX_MEDIA)
        //   .sendBulkSMS(defaultSenderID, smsPayload, null, null, null, getEnvironmentVariable(variables.SMPP_DEFAULT_PE_ID.name), null, null, report_types.CAMPAIGN)
        //   .then(() => {})
        //   .catch((error) => {
        //     AlertService.logger.error(getErrorLog(canonicalMethods.SEND_SMS, traceID, { error }, error.message))
        //   })
      } catch (error) {}
    }
    if (!_.isNil(clientCorrespondence)) {
      const payload: EmailPayload = EmailHandler.getInstance().getEmailPayloadForInitialCampaign(clientCorrespondence, templateData)
      EmailHandler.getInstance().sendEmail(payload, traceID)
    }
  }

  sendPasswordResetAlert(templateData: PasswordResetAlert, clientContact: number, clientCorrespondence: string, traceID: string) {
    if (!_.isNil(clientContact) && !_.eq(clientContact, -1)) {
      const defaultSenderID = getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_SMS_SENDER_ID.name)
      const smsPayload: campaignProviderObject[] = []
      smsPayload.push({
        phone: clientContact,
        message: getSMSPayloadForPasswordReset(templateData),
      })
      try {
        // SmsHandler.getInstance(sms_client.MY_INBOX_MEDIA)
        //   .sendBulkSMS(defaultSenderID, smsPayload, null, null, null, getEnvironmentVariable(variables.SMPP_DEFAULT_PE_ID.name), null, null, report_types.CAMPAIGN)
        //   .then(() => {})
        //   .catch((error) => {
        //     AlertService.logger.error(getErrorLog(canonicalMethods.SEND_SMS, traceID, { error }, error.message))
        //   })
      } catch (error) {}
    }
    if (!_.isNil(clientCorrespondence)) {
      const payload: EmailPayload = EmailHandler.getInstance().getEmailPayloadForPasswordReset(clientCorrespondence, templateData)
      EmailHandler.getInstance().sendEmail(payload, traceID)
    }
  }

  sendCreditsApprovedAlert(templateData: CreditsApprovedAlert, clientContact: number, clientCorrespondence: string, traceID: string) {
    if (!_.isNil(clientContact) && !_.eq(clientContact, -1)) {
      const defaultSenderID = getEnvironmentVariable(variables.BOOTSTRAP_ADMIN_SMS_SENDER_ID.name)
      const smsPayload: campaignProviderObject[] = []
      smsPayload.push({
        phone: clientContact,
        message: getSMSPayloadForTransactionApproved(templateData),
      })
      try {
        // SmsHandler.getInstance(sms_client.MY_INBOX_MEDIA)
        //   .sendBulkSMS(defaultSenderID, smsPayload, null, null, null, getEnvironmentVariable(variables.SMPP_DEFAULT_PE_ID.name), null, null, report_types.CAMPAIGN)
        //   .then(() => {})
        //   .catch((error) => {
        //     AlertService.logger.error(getErrorLog(canonicalMethods.SEND_SMS, traceID, { error }, error.message))
        //   })
      } catch (error) {}
    }
    if (!_.isNil(clientCorrespondence)) {
      const payload: EmailPayload = EmailHandler.getInstance().getEmailPayloadForCreditsApproved(clientCorrespondence, templateData)
      EmailHandler.getInstance().sendEmail(payload, traceID)
    }
  }
}
