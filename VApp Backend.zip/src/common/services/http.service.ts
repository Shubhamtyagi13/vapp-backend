import { GenericObject } from '@interfaces/generic.interface'
import { HttpResponse } from '@interfaces/http.interface'
import { Injectable } from '@nestjs/common'
import axios from 'axios'
import _ from 'lodash'

@Injectable()
export class HTTPService {
  private static instance: HTTPService

  private constructor() {}

  static getInstance(): HTTPService {
    if (_.isNil(HTTPService.instance)) {
      HTTPService.instance = new HTTPService()
    }
    return HTTPService.instance
  }

  public get(url: string, params?: GenericObject, headers?: any, timeout?: number) {
    return new Promise<HttpResponse>((resolve: (value?: HttpResponse | PromiseLike<HttpResponse>) => void, reject: (reason?: Error) => void) => {
      axios
        .get(url, {
          headers,
          params,
          timeout: timeout || 0,
          paramsSerializer: (params) => {
            let result = ''
            Object.keys(params).forEach((key) => {
              result += `${key}=${encodeURIComponent(params[key])}&`
            })
            return result.substr(0, result.length - 1)
          }
        })
        .then((response: HttpResponse) => {
          resolve(response)
        })
        .catch((error: Error) => {
          reject(error)
        })
    })
  }

  public getStream(url: string, params?: GenericObject, headers?: any, timeout?: number) {
    return new Promise<HttpResponse>((resolve: (value?: HttpResponse | PromiseLike<HttpResponse>) => void, reject: (reason?: Error) => void) => {
      axios
        .get(url, {
          responseType: 'stream',
          headers,
          params,
          timeout: timeout || 0,
          paramsSerializer: (params) => {
            let result = ''
            Object.keys(params).forEach((key) => {
              result += `${key}=${encodeURIComponent(params[key])}&`
            })
            return result.substr(0, result.length - 1)
          }
        })
        .then((response: HttpResponse) => {
          resolve(response)
        })
        .catch((error: Error) => {
          reject(error)
        })
    })
  }

  public post(url: string, data?: any, params?: any, headers?: any, timeout?: number) {
    return new Promise<HttpResponse>((resolve: (value?: HttpResponse | PromiseLike<HttpResponse>) => void, reject: (reason?: Error) => void) => {
      axios
        .post(url, data, {
          headers,
          params,
          timeout: timeout || 0,
          maxContentLength: Infinity,
          maxBodyLength: Infinity
        })
        .then((response: HttpResponse) => {
          resolve(response)
        })
        .catch((error: Error) => {
          reject(error)
        })
    })
  }
}
