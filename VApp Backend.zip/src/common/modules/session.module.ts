import { cache_client, environments, redis_client, variables } from '@config'
import { getEnvironmentVariable } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import ConnectRedis from 'connect-redis'
import session from 'express-session'
import _ from 'lodash'
import { NestSessionOptions, SessionModule as SessionHandlerModule } from 'nestjs-session'

const RedisStore = ConnectRedis(session)

export const SessionModule = SessionHandlerModule.forRootAsync({
  useFactory: (): NestSessionOptions => ({
      retries: 0,
      session: {
        store: new RedisStore({
          client: RedisHandler.getInstance(cache_client.DEFAULT, redis_client.SESSION),
          prefix: `sess-${getEnvironmentVariable(variables.VAPP_ENV.name)}:`
        }),
        secret: getEnvironmentVariable(variables.SESSION_SECRET.name),
        resave: false,
        saveUninitialized: false,
        cookie: {
          sameSite: 'none',
          secure: !_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.local),
          maxAge: 86400000
        }
      }
    })
})
