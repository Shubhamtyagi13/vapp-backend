import { variables } from '@config'
import { MongooseModule } from '@nestjs/mongoose'
import { getEnvironmentVariable } from '@utils/platform.util'

export const MongooseHandlerModule = MongooseModule.forRoot(getEnvironmentVariable(variables.DB_URL.name), {
  useNewUrlParser: true,
  keepAlive: true,
  autoIndex: true,
})
