import { cache_client, redis_client } from '@config'
import { RedisHandler } from '@utils/redis.util'
import { RateLimiterModule as RateLimitHandlerModule, RateLimiterOptions } from 'nestjs-rate-limiter'

export const RateLimiterModule = RateLimitHandlerModule.registerAsync({
  useFactory: async (): Promise<RateLimiterOptions> => {
    const redisClient = RedisHandler.getInstance(cache_client.DEFAULT, redis_client.RATE_LIMIT)
    return {
      points: 100,
      type: 'Redis',
      storeClient: redisClient
    }
  }
})
