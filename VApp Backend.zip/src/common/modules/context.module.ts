import { constants } from '@config'
import { DynamicModule, Global, Module } from '@nestjs/common'
import { ContextService } from '@services/context.service'

@Global()
@Module({})
export class ContextModule {
  public static registerAsync(): DynamicModule {
    return {
      module: ContextModule,
      providers: [
        {
          provide: constants.PROVIDERS.VAPP_CONTEXT,
          useFactory: (contextService: ContextService) => contextService.getContext(),
          inject: [ContextService]
        },
        {
          provide: ContextService,
          useClass: ContextService
        }
      ],
      exports: [ContextService, constants.PROVIDERS.VAPP_CONTEXT]
    }
  }
}
