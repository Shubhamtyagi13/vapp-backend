import { Module } from '@nestjs/common'
import { VappLogger } from '@services/logger.service'

@Module({
  providers: [VappLogger],
  exports: [VappLogger]
})
export class LoggerModule {}
