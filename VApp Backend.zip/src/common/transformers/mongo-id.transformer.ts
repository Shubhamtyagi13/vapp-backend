import { buildMessage, isMongoId, ValidateBy, ValidationOptions } from 'class-validator'

export function isValidMongoIDs(array: string[]) {
  if (!(array instanceof Array)) return false
  return array.every((value) => isMongoId(value))
}

export const IsValidMongoIDs = (options = [], validationOptions?: ValidationOptions) => ValidateBy(
    {
      name: 'IsValidMongoIDs',
      constraints: [options],
      validator: {
        validate: (value, args) => isValidMongoIDs(value),
        defaultMessage: buildMessage((eachPrefix) => `${eachPrefix  }$property must containt valid mongo ids`, validationOptions)
      }
    },
    validationOptions
  )
