import { buildMessage, ValidateBy, ValidationOptions } from 'class-validator'
import _ from 'lodash'

export function isValidIVR(value: number, min: number, max: number) {
  if (_.isNil(value)) {
    return true
  }
  if (_.eq(value, 0)) {
    return true
  }
  if (typeof value !== 'number') {
    return false
  }
  return _.gte(String(value).length, min) && _.lte(String(value).length, max)
}

export const IsValidIVR = (options = {}, validationOptions?: ValidationOptions) => ValidateBy(
    {
      name: 'IsValidIVR',
      constraints: [options],
      validator: {
        validate: (value, args) => isValidIVR(value, (args.constraints[0] = 10), (args.constraints[1] = 15)),
        defaultMessage: buildMessage((eachPrefix) => `${eachPrefix  }$property must be a valid number with $constraint1 - $constraint2 digits`, validationOptions)
      }
    },
    validationOptions
  )
