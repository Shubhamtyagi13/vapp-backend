import { buildMessage, ValidateBy, ValidationOptions } from 'class-validator'
import _ from 'lodash'

export function isValidPhone(value: number, length: number) {
  if (typeof value !== 'number') {
    return false
  }
  return _.eq(String(value).length, length)
}

export const IsValidPhone = (options = {}, validationOptions?: ValidationOptions) => ValidateBy(
    {
      name: 'IsValidPhone',
      constraints: [options],
      validator: {
        validate: (value, args) => isValidPhone(value, (args.constraints[0] = 10)),
        defaultMessage: buildMessage((eachPrefix) => `${eachPrefix  }$property must ba valid number with $constraint1 digits`, validationOptions)
      }
    },
    validationOptions
  )
