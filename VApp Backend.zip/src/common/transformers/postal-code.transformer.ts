import { buildMessage, ValidateBy, ValidationOptions } from 'class-validator'
import _ from 'lodash'

export function isValidPostalCode(value: number, length: number) {
  if (typeof value !== 'number') {
    return false
  }
  return _.eq(String(value).length, length)
}

export const IsValidPostalCode = (options = {}, validationOptions?: ValidationOptions) => ValidateBy(
    {
      name: 'IsValidPostalCode',
      constraints: [options],
      validator: {
        validate: (value, args) => isValidPostalCode(value, (args.constraints[0] = 6)),
        defaultMessage: buildMessage((eachPrefix) => `${eachPrefix  }$property must ba valid number with $constraint1 digits`, validationOptions)
      }
    },
    validationOptions
  )
