import { buildMessage, ValidateBy, ValidationOptions } from 'class-validator'
import _ from 'lodash'
import { template_variables } from '@config'

export function isValidTemplateVariable(key: string, value: string) {
  const arrVars = Object.keys(template_variables)
  return _.includes(arrVars, key) && !_.isNil(value) && !_.isEmpty(value)
}

export const IsValidTemplateVariable = () => ValidateBy({
    name: 'IsValidTemplateVariable',
    validator: {
      validate: (arrVar) => {
        const arrReturns = []
        for (let i = 0; i < arrVar.length; i++) {
          arrReturns.push(isValidTemplateVariable(arrVar[i].key, arrVar[i].value))
        }
        return arrReturns.reduce((accu, currentval) => accu && currentval)
      },
      defaultMessage: buildMessage((eachPrefix) => `${eachPrefix  }$property must be valid template variables`)
    }
  })
