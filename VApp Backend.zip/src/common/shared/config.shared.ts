import _ from 'lodash'
import ms from 'ms'
import { TransactionOptions } from 'mongodb'

/*
logs configuration
priority => 0: highest 7: lowest
*/
export const log = {
  colors: {
    trace: 'brightMagenta',
    alert: 'brightRed',
    crit: 'brightRed',
    error: 'brightRed',
    warning: 'brightYellow',
    notice: 'brightBlue',
    info: 'brightCyan',
    debug: 'brightWhite'
  },
  filename: 'debug.log',
  levels: {
    trace: {
      value: 'trace',
      priority: 0
    },
    alert: {
      value: 'alert',
      priority: 1
    },
    critical: {
      value: 'crit',
      priority: 2
    },
    error: {
      value: 'error',
      priority: 3
    },
    warning: {
      value: 'warning',
      priority: 4
    },
    notice: {
      value: 'notice',
      priority: 5
    },
    info: {
      value: 'info',
      priority: 6
    },
    debug: {
      value: 'debug',
      priority: 7
    }
  }
}

/*
  smpp client configuration
*/
export enum smpp_client {
  DEFAULT = 'DEFAULT',
  OTP = 'OTP',
  VIDEOCON = 'VIDEOCON',
  MIM = 'MIM',
  PROMOTIONAL = 'PROMOTIONAL',
  KARIX = 'KARIX',
  MIMP = 'MIMP'
}

export enum otp_aggregation {
  TODAY = 'HOUR',
  MONTH = 'DAY',
  YEAR = 'MONTH'
}

export enum transactional_aggregation {
  TODAY = 'HOUR',
  MONTH = 'DAY',
  YEAR = 'MONTH'
}

/*
 environment names
 */
export const environments = {
  local: 'local',
  qa: 'qa',
  staging: 'staging',
  development: 'dev',
  production: 'production'
}

export const dynamic_config = {
  DYNAMIC_CONFIG: 'DYNAMIC_CONFIG'
}

export const virtuality_config = {
  VIRTUALITY_WEBSITE: 'VIRTUALITY_WEBSITE'
}

// environment variables file path
export const env = '../../.env'

export const _HTTPStatus = {
  MAINTENANCE_MODE: 701
}
// environment variables mapping
export const variables = {
  PORT: { name: 'PORT', value: 3000 },
  MAINTENANCE_MODE: { name: 'MAINTENANCE_MODE', value: false },
  ADDRESS: { name: 'ADDRESS', value: '0.0.0.0' },
  APPLICATION_VERSION: { name: 'APPLICATION_VERSION', value: '1.0.0' },
  LOG_LEVEL: { name: 'LOG_LEVEL', value: 'debug' },
  NODE_ENV: { name: 'NODE_ENV', value: 'development' },
  REPORT_EXPIRY_DAYS: { name: 'REPORT_EXPIRY_DAYS', value: 2 },
  NODE_APP_INSTANCE: { name: 'NODE_APP_INSTANCE', value: 0 },
  VAPP_ENV: { name: 'VAPP_ENV', value: 'local' },
  DB_NAME: { name: 'DB_NAME', value: 'vapp' },
  SMPP_SERVICE_BASE_URL: { name: 'SMPP_SERVICE_BASE_URL', value: 'http://localhost:3009/sapi/' },
  DB_URL: { name: 'DB_URL', value: 'mongodb+srv://admin:123asdF1@vapp.3khgj.mongodb.net/vapp?retryWrites=true&w=majority' },
  DB_PORT: { name: 'DB_PORT', value: '27017' },
  DB_USERNAME: { name: 'DB_USERNAME', value: '' },
  DB_PASSWORD: { name: 'DB_PASSWORD', value: '' },
  DB_REPLICA_SET: { name: 'DB_REPLICA_SET', value: '' },
  CAMPAIGN_LIMIT: { name: 'CAMPAIGN_LIMIT', value: 100000 },
  API_PREFIX: { name: 'API_PREFIX', value: 'api' },
  AWS_REGION: { name: 'AWS_REGION', value: 'ap-south-1' },
  AWS_ACCESS_KEY: { name: 'AWS_ACCESS_KEY', value: 'AKIAJFTAZN3PBSLNI45Q' },
  AWS_SECRET_KEY: { name: 'AWS_SECRET_KEY', value: '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' },
  IPAPI_SECRET: { name: 'IPAPI_SECRET', value: '' },
  IPAPI_URL: { name: 'IPAPI_URL', value: 'https://ipapi.co/' },
  JWT_PUBLIC_SECRET: { name: 'JWT_PUBLIC_SECRET', value: '0383726f4e24438bf9dd869c173357c1c89fa66a8f94a88bf51270e10c340a97' },
  JWT_PRIVATE_SECRET: { name: 'JWT_PRIVATE_SECRET', value: '0383726f4e24438bf9dd869c173357c1c89fa66a8f94a88bf51270e10c340a97' },
  JWT_ISSUER: { name: 'JWT_ISSUER', value: 'localhost' },
  PASSWORD_HASH: { name: 'PASSWORD_HASH', value: '052794d1b84f0d8db24c31834d4d5fd148dd14f324968814324f1178d2f081eb' },
  SERVER_API_REVISION: { name: 'SERVER_API_REVISION', value: '' },
  JOB_TYPES: { name: 'JOB_TYPES', value: '' },
  ALT_DOMAIN: { name: 'ALT_DOMAIN', value: 'vp2.in' },
  EMAIL_DOMAIN: { name: 'EMAIL_DOMAIN', value: 'vapp.in' },
  UPLOAD_DIRECTORY: { name: 'UPLOAD_DIRECTORY', value: 'uploads' },
  TEMP_WORK_DIRECTORY: { name: 'TEMP_WORK_DIRECTORY', value: 'temp_work' },
  WHATSAPP_DIRECTORY: { name: 'WHATSAPP_DIRECTORY', value: 'whatsapp' },
  STATIC_DIRECTORY: { name: 'STATIC_DIRECTORY', value: 'static' },
  REPORTS_DIRECTORY: { name: 'REPORTS_DIRECTORY', value: 'reports' },
  BROCHURE_DIRECTORY: { name: 'BROCHURE_DIRECTORY', value: 'brochure' },
  TESTIMONIAL_DIRECTORY: { name: 'TESTIMONIAL_DIRECTORY', value: 'testimonials' },
  CLIENT_DIRECTORY: { name: 'CLIENT_DIRECTORY', value: 'clients' },
  WALKTHROUGH_DIRECTORY: { name: 'WALKTHROUGH_DIRECTORY', value: 'walkthroughs' },
  CONTACT_DIRECTORY: { name: 'CONTACT_DIRECTORY', value: 'contacts' },

  /* S3 */
  S3_REGION: { name: 'S3_REGION', value: 'ap-south-1' },
  S3_ACCESS_ID: { name: 'S3_ACCESS_ID', value: 'AKIARUPGGPCXRT2CA2PY' },
  S3_ACCESS_KEY: { name: 'S3_ACCESS_KEY', value: 'uGuiNu7AeTbPpI6mHOuIoEyCYmU2rGfmU/ZNteFB' },
  S3_OTP_BUCKET: { name: 'S3_OTP_BUCKET', value: 'vapp-dev' },
  S3_TRANSACTIONAL_BUCKET: { name: 'S3_TRANSACTIONAL_BUCKET', value: 'vapp-dev' },
  /* Session */
  SESSION_SECRET: { name: 'SESSION_SECRET', value: 'AfXOPQ0RymqJxrbeOpDi0Y4JJB7CBq7GZRcUME' },
  /* IVR */
  IVR_SECRET: { name: 'IVR_SECRET', value: '9ng94T1rhNr6UrHEg7xU' },
  IVR_CALL_THRESHOLD: { name: 'IVR_CALL_THRESHOLD', value: 90 },
  /* Redis */
  REDIS_PORT: { name: 'REDIS_PORT', value: 6379 },
  REDIS_MAX_RETRIES: { name: 'REDIS_MAX_RETRIES', value: 10 },
  REDIS_URL: { name: 'REDIS_URL', value: 'localhost' },
  REDIS_PASSWORD: { name: 'REDIS_PASSWORD', value: 'no_password' },
  REDIS_PUB_SUB_PORT: { name: 'REDIS_PUB_SUB_PORT', value: 6379 },
  REDIS_PUB_SUB_URL: { name: 'REDIS_PUB_SUB_URL', value: 'localhost' },
  REDIS_PUB_SUB_PASSWORD: { name: 'REDIS_PUB_SUB_PASSWORD', value: 'no_password' },
  WHATSAPP_CAMPAIGN_LIMIT: { name: 'WHATSAPP_CAMPAIGN_LIMIT', value: 1000 },
  /* Firebase */
  FIREBASE_DATABASE_URL: { name: 'FIREBASE_DATABASE_URL', value: 'https://vapp-dev-62234.firebaseio.com' },
  FIREBASE_PROJECT_ID: { name: 'FIREBASE_PROJECT_ID', value: 'vapp-dev-62234' },
  FIREBASE_CLIENT_EMAIL: { name: 'FIREBASE_CLIENT_EMAIL', value: 'firebase-adminsdk-8fmpz@vapp-dev-62234.iam.gserviceaccount.com' },
  FIREBASE_PRIVATE_KEY: {
    name: 'FIREBASE_PRIVATE_KEY',
    value:
      '-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCSrCHyTXkS0DlW\nQ99sga9IqNYnAj8yN/75jiCCKZz1iIwynvv0U1YIq39lOcshAZgKQ4inzlPxKG+f\n+o6Rwf6EGzANNS7ogkJSOS+KffjHw01wLBVMZ9FEuRm8G2brWXeYAW1k0oyljiab\n0CoUacK96F5xvb/FSdR1FYU1Tbwq600LTSJtQQ/oPC+DrAZR5C7o7/EWzfmCMdD7\nFE1dmJimqqT0ODeOeYfWPx0TQOHv0B5FxeDH7iTGtz0ezKqXGcW4kN3iiF7Hewhh\nci4Q6iZpQYJULljQ8Y/55GuODFFbamkejYI+3GTQ76T/hcZNq1EXL29koVfaQnvd\nni/GXcljAgMBAAECggEAFG+2hSflTElGC+6GFXzWWwXnXOUTwCAMP2JdxjUdIRsH\nCdCcI5VvAeM/a2/LjUxHDnsNcfAuQwZS01QahFWm7GpLXjPAVvY7XnCIXsAhp1ff\nlNcXmp9GidBOtSaORxGet8fPIcKyhSjS2Vf+XPzFfSeA7VE2hLs+RpgaiOxNYR9U\n/XAuU+SwphYc/RfqKftVPunaPdFmqeRRmKcTVPVo0cCC5RQAiNIO1mLS8GQdWXV8\nFHVzreID9zc/fc1Uq7wyPNwpA3XFfNq9yOnLEnow/vL739yThcQZBcIMKqLlLBI8\n/hXo/zYYVSh3pCAja7O9Uy0KfSlJBm/KngbIJ7wDmQKBgQDKu6g0YN5//i5+ywKZ\n6s1NL+7o1j5FwrapyWcRFZ4c1fwYVuSV7MZbpFZSnzmBWPU6/+VbowY2taZ8ga1H\nulzr4moBjyR31lg3zqKJ3xkMzSvorU4sry8x2V9J645EOKm+4AevfUmn1+XLf6hB\nNx/GUp13Et6IzIvxLey1pOK+CQKBgQC5NbF3zzZn+I3dCeGj28U5Uxg9oC8i/vdn\nXdc7aT+/+jEv/ChJUBoZGtUH+9BhWBqNxLEROYxUlWJCAdCNkkuBw3gt4CxTFS6u\n/1iB/6CHy/C9RkFJzBFDe+XIl0puOKZ6jEQbeZ6GjNRkkEkvss6EOV319XLZJ2Xp\nfbzwL1pnCwKBgQCMvB61VbW/1n0Caf2BSd2BQtAv9GJAXT4euYCB/KbJT8b0QoXm\nifrdLUT7kCsEXvPGJFRc+9vZaNqNPhxDWd0dpwx9zpe7VSHig+CTozsphth/aqeF\nH4u8qDCdCRe2xjsYFT9glLHoAVk1noX318OIElvbiE7RWmWfZIkZQ8BfuQKBgFIM\nWE9US6zprqcSXpSBorCPgDikwt0FCMMRDm1yZdx9UNcKJSq9QqKGgYNk6d6F8lWF\nok+YJ/O8refB+AsPmUWmO5JPMjOoOaMq2aHVhd9C2KZw/jFcJvW3aIdhhoansBCw\nHOfzC+hdcSYPyWxJETYAWADDOJq82mgC3PWmdK0bAoGBALQ3Qbz6tLdFuACzVj2Q\n8YPDoeeSxfrDDna/VzN9qpoGch5U81IF0y0QfLIcgh95yf9ALHH1sr4xbaC3e20L\nerefzfJQh3QDdZXBB/rDCr4R7OCA6RjhgRgQWob7R+cw4Ko404spQiO324iCIcVG\n+nuLirXOgpk5qqG6Gedcnh/8\n-----END PRIVATE KEY-----\n'
  },
  GETWAY_USERNAME: { name: 'GETWAY_USERNAME', value: '' },
  GETWAY_PASSWORD: { name: 'GETWAY_PASSWORD', value: '' },
  SYSTEM_USERNAME: { name: 'SYSTEM_USERNAME', value: 'siddharthjaidka' },
  SYSTEM_PASSWORD: { name: 'SYSTEM_PASSWORD', value: '123456' },
  GETWAY_LOGIN_URL: { name: 'GETWAY_LOGIN_URL', value: 'https://getwaysms.com/Login.aspx' },
  GETWAY_DOWNLOAD_REPORT_URL: { name: 'GETWAY_DOWNLOAD_REPORT_URL', value: 'https://getwaysms.com/apps/Downlaod.aspx?q=y&for=newcampaignview&cid=' },
  GETWAY_URL: { name: 'GETWAY_URL', value: 'https://getwaysms.com/api/SendMesssgeAPI' },
  DIALOGFLOW_EMAIL: { name: 'DIALOGFLOW_EMAIL', value: '' },
  DIALOGFLOW_PRIVATE_KEY: { name: 'DIALOGFLOW_PRIVATE_KEY', value: '' },
  SERVER_PRIVATE_KEY: { name: 'SERVER_PRIVATE_KEY', value: '' },
  SERVER_FULLCHAIN_KEY: { name: 'SERVER_FULLCHAIN_KEY', value: '' },
  ENGAGEMENT_CAP: { name: 'ENGAGEMENT_CAP', value: 360000 },
  BOOTSTRAP_ADMIN_EMAIL: { name: 'BOOTSTRAP_ADMIN_EMAIL', value: 'admin@' },
  BOOTSTRAP_ADMIN_PASSWORD: { name: 'BOOTSTRAP_ADMIN_PASSWORD', value: 'user123' },
  BOOTSTRAP_ADMIN_FIRST_NAME: { name: 'BOOTSTRAP_ADMIN_FIRST_NAME', value: 'Vapp' },
  BOOTSTRAP_ADMIN_LAST_NAME: { name: 'BOOTSTRAP_ADMIN_LAST_NAME', value: 'Admin' },
  BOOTSTRAP_ADMIN_COMPANY_NAME: { name: 'BOOTSTRAP_ADMIN_COMPANY_NAME', value: 'Virtuality Innoventure' },
  BOOTSTRAP_ADMIN_SMS_SENDER_ID: { name: 'BOOTSTRAP_ADMIN_SMS_SENDER_ID', value: 'VTREND' },
  BOOTSTRAP_DEFAULT_USER_PASSWORD: { name: 'BOOTSTRAP_DEFAULT_USER_PASSWORD', value: 'user123' },
  BOOTSTRAP_DEFAULT_USER_EMAIL: { name: 'BOOTSTRAP_DEFAULT_USER_EMAIL', value: 'user@' },
  BOOTSTRAP_DEFAULT_USER_CONTACT: { name: 'BOOTSTRAP_DEFAULT_USER_CONTACT', value: 1111111111 },
  BOOTSTRAP_DEFAULT_USER_COMPANY_NAME: { name: 'BOOTSTRAP_DEFAULT_USER_COMPANY_NAME', value: 'Virtuality Innoventure' },
  MYINBOX_API_KEY: { name: 'MYINBOX_API_KEY', value: '' },
  MYINBOX_URL: { name: 'MYINBOX_URL', value: '' },
  VAPP_BACKEND_URL: { name: 'VAPP_BACKEND_URL', value: 'http://localhost:3000' },
  SENDGRID_API: { name: 'SENDGRID_API', value: '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' },
  SENDGRID_EMAIL: { name: 'SENDGRID_EMAIL', value: 'virtualityinnoventure@gmail.com' },
  SENDGRID_INITIAL_CAMPAIGN: { name: 'SENDGRID_INITIAL_CAMPAIGN', value: 'd-7ae7be47f7c64a56b5fd6ca1f5eaf6ef' },
  SENDGRID_PASSWORD_RESET: { name: 'SENDGRID_PASSWORD_RESET', value: 'd-63d2bf1f288f4778942efb2a86255f8d' },
  SENDGRID_PERIODIC_REPORT: { name: 'SENDGRID_PERIODIC_REPORT', value: 'd-c96e7cc1b27a4cc39a142e918192c1b7' },
  SENDGRID_CREDITS: { name: 'SENDGRID_CREDITS', value: 'd-46b7fc4e05fc4b42b085e5d5026ff1e2' }
}

/*
  cache client configuration
*/
export enum cache_client {
  DEFAULT = 'DEFAULT',
  PUB_SUB = 'PUB_SUB'
}

export enum campaign_client_route {
  WHATSAPP = -1
}

export enum report_types {
  OTP = 0,
  CAMPAIGN = 1,
  TRANSACTIONAL = 2,
  DRIP_CAMPAIGN = 3,
  RBM_CAMPAIGN = 4
}

export enum report_status {
  UNDER_PROCESS = 0,
  FINSIHED = 1,
  FAILED = 2
}

export enum otp_types {
  NUMERIC = 'numeric',
  ALPHA_NUMERIC = 'alpha_numeric'
}

/*
  images interceptor enumeration
*/
export enum image_intercept {
  DEFAULT = 'DEFAULT',
  PROJECT = 'PROJECT',
  TESTIMONIAL = 'TESTIMONIAL',
  CLIENT = 'CLIENT'
}

export const template_variables = {
  clientname: {
    value: 'clientname',
    otp: false,
    campaign: true,
    transactional: true
  },
  url: {
    value: 'url',
    otp: false,
    campaign: true,
    transactional: false
  },
  firstname: {
    value: 'firstname',
    otp: true,
    campaign: true,
    transactional: true
  },
  middlename: {
    value: 'middlename',
    otp: false,
    campaign: true,
    transactional: true
  },
  lastname: {
    value: 'lastname',
    otp: false,
    campaign: true,
    transactional: true
  },
  ivr: {
    value: 'ivr',
    otp: false,
    campaign: true,
    transactional: false
  },
  otp: {
    value: 'otp',
    otp: true,
    campaign: false,
    transactional: false
  },
  otpValidity: {
    value: 'validity',
    otp: true,
    campaign: false,
    transactional: false
  },
  var1: {
    value: 'var1',
    otp: false,
    campaign: true,
    transactional: true
  },
  var2: {
    value: 'var2',
    otp: false,
    campaign: true,
    transactional: true
  },
  var3: {
    value: 'var3',
    otp: false,
    campaign: true,
    transactional: true
  },
  var4: {
    value: 'var4',
    otp: false,
    campaign: true,
    transactional: true
  }
}

// application default values
export const application: { [key: string]: unknown } = {
  name: 'V-App'
}

// campaign State
export enum campaignStates {
  SCHEDULED = 1,
  RUNNING = 2,
  PROCESSED = 3,
  CANCELLED = 4
}

export const months = [
  {
    short: 'Jan',
    long: 'January',
    index: 1
  },
  {
    short: 'Feb',
    long: 'February',
    index: 2
  },
  {
    short: 'Mar',
    long: 'March',
    index: 3
  },
  {
    short: 'Apr',
    long: 'April',
    index: 4
  },
  {
    short: 'May',
    long: 'May',
    index: 5
  },
  {
    short: 'Jun',
    long: 'June',
    index: 6
  },
  {
    short: 'Jul',
    long: 'July',
    index: 7
  },
  {
    short: 'Aug',
    long: 'August',
    index: 8
  },
  {
    short: 'Sep',
    long: 'September',
    index: 9
  },
  {
    short: 'Oct',
    long: 'October',
    index: 10
  },
  {
    short: 'Nov',
    long: 'November',
    index: 11
  },
  {
    short: 'Dec',
    long: 'December',
    index: 12
  }
]

export enum integration_type {
  RBM = 0,
  LEADSQUARED = 1,
  KNOWLARITY = 3,
  WEBHOOKS = 4
}

export enum integration_category {
  CRM = 0,
  IVR = 1,
  SYSTEM = 2,
  SMS = 3
}

export enum integration_operation {
  CREATE = 0,
  UPDATE = 1
}

export const integrations = {
  LEAQSQAURED: {
    BASE_API_URL: 'https://api-in21.leadsquared.com/v2/',
    GET_USERS: 'UserManagement.svc/Users.Get',
    CREATE_LEAD: 'LeadManagement.svc/Lead.Create',
    UPDATE_LEAD: 'LeadManagement.svc/Lead.Update?leadId=',
    CREATE_FIELD: 'LeadManagement.svc/CreateLeadField'
  }
}

// database tables
export const tables = {
  USER: { name: 'users', collection: 'users' },
  USER_METADATA: { name: 'user_metadata', collection: 'user_metadata' },
  CRM_INTEGRATION: { name: 'crm_integration', collection: 'crm_integration' },
  CAMPAIGN: { name: 'campaigns', collection: 'campaigns' },
  DRIP_CAMPAIGN: { name: 'drip_campaigns', collection: 'drip_campaigns' },
  TEMPLATES: { name: 'templates', collection: 'templates' },
  DRIP_CRITERIA: { name: 'drip_criteria', collection: 'drip_criteria' },
  CONTACTS: { name: 'contacts', collection: 'contacts' },
  LINKS: { name: 'links', collection: 'links' },
  CONTACTS_DATABASE: { name: 'database', collection: 'database' },
  CREDIT_REQUESTS: { name: 'transactions', collection: 'transactions' },
  SMS: { name: 'sms', collection: 'sms' },
  CREDITS: { name: 'credits', collection: 'credits' },
  DASHBOARD: { name: 'dashboard', collection: 'dashboard' },
  CRONS: { name: 'crons', collection: 'crons' },
  REQUESTS: { name: 'requests', collection: 'requests' },
  DRIP_REQUESTS: { name: 'drip_requests', collection: 'drip_requests' },
  DEMOGRAPHICS: { name: 'demographics', collection: 'demographics' },
  IVR: { name: 'ivr', collection: 'ivr' },
  ENGAGEMENTS: { name: 'engagements', collection: 'engagements' },
  LOCATION: { name: 'location', collection: 'location' },
  LOCATION_SUB: { name: 'location_sub', collection: 'location_sub' },
  PROJECTS: { name: 'projects', collection: 'projects' },
  PROJECTS_SUB: { name: 'projects_sub', collection: 'projects_sub' },
  DASHBOARD_TRENDING_PERSON: { name: 'dashboard_trending_person', collection: 'dashboard_trending_person' },
  DASHBOARD_TRENDING_PROJECT: { name: 'dashboard_trending_project', collection: 'dashboard_trending_project' },
  DASHBOARD_TRENDING_TEMPLATE: { name: 'dashboard_trending_template', collection: 'dashboard_trending_template' },
  DASHBOARD_TRENDING_DATABASE: { name: 'dashboard_trending_database', collection: 'dashboard_trending_database' },
  DASHBOARD_TRENDING_LINK: { name: 'dashboard_trending_link', collection: 'dashboard_trending_link' },
  DASHBOARD_TRENDS: { name: 'trends', collection: 'trends' },
  PROJECT_TRENDING_ENGAGEMENTS: { name: 'project_trending_engagements', collection: 'project_trending_engagements' },
  PROJECT_TRENDS: { name: 'interactions', collection: 'interactions' },
  CLIENTS: { name: 'clients', collection: 'clients' },
  NOTICES: { name: 'notices', collection: 'notices' },
  TESTIMONIAL: { name: 'testimonials', collection: 'testimonials' },
  FEEDBACK: { name: 'feedbacks', collection: 'feedbacks' },
  TRACKING: { name: 'tracking', collection: 'tracking' },
  EVENTS: { name: 'events', collection: 'events' },
  TRACKING_UNIQUE_EVENTS: { name: 'tracking_events', collection: 'tracking_events' },
  OTP: { name: 'otp', collection: 'otp' },
  TRANSACTIONAL: { name: 'transactional', collection: 'transactional' },
  REPORTS: { name: 'reports', collection: 'reports' },
  INTEGRATIONS: { name: 'integrations', collection: 'integrations' }
}

export enum audience {
  CLIENT = 'client',
  ADMIN = 'admin',
  PUBLIC = 'public',
  MAINTAINER = 'maintainer'
}
// defined constants
export const constants = {
  ALERTS: {
    status: {
      initiated: 'initiated',
      scheduled: 'scheduled'
    }
  },
  REPORTS: {
    events: {
      report_processed: 'report_processed'
    }
  },
  TEMPLATE_TYPE: {
    campaign: 0,
    whatsapp: 1,
    transactional: 2,
    otp: 3
  },
  DEMOGRAPHICS: {
    CONTINENTS: [
      { code: 'AU', name: 'Australia' },
      { code: 'AF', name: 'Africa' },
      { code: 'NA', name: 'North America' },
      { code: 'OC', name: 'Oceania' },
      { code: 'AN', name: 'Antarctica' },
      { code: 'AS', name: 'Asia' },
      { code: 'EU', name: 'Europe' },
      { code: 'SA', name: 'South America' }
    ],
    COUNTRIES: [
      {
        name: 'Afghanistan',
        alpha2: 'AF',
        alpha3: 'AFG',
        continent: 'AS',
        numeric_code: 4
      },
      {
        name: 'Åland Islands',
        alpha2: 'AX',
        alpha3: 'ALA',
        continent: 'EU',
        numeric_code: 248
      },
      {
        name: 'Albania',
        alpha2: 'AL',
        alpha3: 'ALB',
        continent: 'EU',
        numeric_code: 8
      },
      {
        name: 'Algeria',
        alpha2: 'DZ',
        alpha3: 'DZA',
        continent: 'AF',
        numeric_code: 12
      },
      {
        name: 'American Samoa',
        alpha2: 'AS',
        alpha3: 'ASM',
        continent: 'OC',
        numeric_code: 16
      },
      {
        name: 'Andorra',
        alpha2: 'AD',
        alpha3: 'AND',
        continent: 'EU',
        numeric_code: 20
      },
      {
        name: 'Angola',
        alpha2: 'AO',
        alpha3: 'AGO',
        continent: 'AF',
        numeric_code: 24
      },
      {
        name: 'Anguilla',
        alpha2: 'AI',
        alpha3: 'AIA',
        continent: 'NA',
        numeric_code: 660
      },
      {
        name: 'Antarctica',
        alpha2: 'AQ',
        alpha3: 'ATA',
        continent: 'AN',
        numeric_code: 10
      },
      {
        name: 'Antigua and Barbuda',
        alpha2: 'AG',
        alpha3: 'ATG',
        continent: 'NA',
        numeric_code: 28
      },
      {
        name: 'Argentina',
        alpha2: 'AR',
        alpha3: 'ARG',
        continent: 'SA',
        numeric_code: 32
      },
      {
        name: 'Armenia',
        alpha2: 'AM',
        alpha3: 'ARM',
        continent: 'AS',
        numeric_code: 51
      },
      {
        name: 'Aruba',
        alpha2: 'AW',
        alpha3: 'ABW',
        continent: 'NA',
        numeric_code: 533
      },
      {
        name: 'Australia',
        alpha2: 'AU',
        alpha3: 'AUS',
        continent: 'OC',
        numeric_code: 36
      },
      {
        name: 'Austria',
        alpha2: 'AT',
        alpha3: 'AUT',
        continent: 'EU',
        numeric_code: 40
      },
      {
        name: 'Azerbaijan',
        alpha2: 'AZ',
        alpha3: 'AZE',
        continent: 'AS',
        numeric_code: 31
      },
      {
        name: 'Bahamas',
        alpha2: 'BS',
        alpha3: 'BHS',
        continent: 'NA',
        numeric_code: 44
      },
      {
        name: 'Bahrain',
        alpha2: 'BH',
        alpha3: 'BHR',
        continent: 'AS',
        numeric_code: 48
      },
      {
        name: 'Bangladesh',
        alpha2: 'BD',
        alpha3: 'BGD',
        continent: 'AS',
        numeric_code: 50
      },
      {
        name: 'Barbados',
        alpha2: 'BB',
        alpha3: 'BRB',
        continent: 'NA',
        numeric_code: 52
      },
      {
        name: 'Belarus',
        alpha2: 'BY',
        alpha3: 'BLR',
        continent: 'EU',
        numeric_code: 112
      },
      {
        name: 'Belgium',
        alpha2: 'BE',
        alpha3: 'BEL',
        continent: 'EU',
        numeric_code: 56
      },
      {
        name: 'Belize',
        alpha2: 'BZ',
        alpha3: 'BLZ',
        continent: 'NA',
        numeric_code: 84
      },
      {
        name: 'Benin',
        alpha2: 'BJ',
        alpha3: 'BEN',
        continent: 'AF',
        numeric_code: 204
      },
      {
        name: 'Bermuda',
        alpha2: 'BM',
        alpha3: 'BMU',
        continent: 'NA',
        numeric_code: 60
      },
      {
        name: 'Bhutan',
        alpha2: 'BT',
        alpha3: 'BTN',
        continent: 'AS',
        numeric_code: 64
      },
      {
        name: 'Bolivia (Plurinational State of)',
        alpha2: 'BO',
        alpha3: 'BOL',
        continent: 'SA',
        numeric_code: 68
      },
      {
        name: 'Bonaire, Sint Eustatius and Saba',
        alpha2: 'BQ',
        alpha3: 'BES',
        continent: 'NA',
        numeric_code: 535
      },
      {
        name: 'Bosnia and Herzegovina',
        alpha2: 'BA',
        alpha3: 'BIH',
        continent: 'EU',
        numeric_code: 70
      },
      {
        name: 'Botswana',
        alpha2: 'BW',
        alpha3: 'BWA',
        continent: 'AF',
        numeric_code: 72
      },
      {
        name: 'Bouvet Island',
        alpha2: 'BV',
        alpha3: 'BVT',
        continent: 'NA',
        numeric_code: 74
      },
      {
        name: 'Brazil',
        alpha2: 'BR',
        alpha3: 'BRA',
        continent: 'SA',
        numeric_code: 76
      },
      {
        name: 'British Indian Ocean Territory',
        alpha2: 'IO',
        alpha3: 'IOT',
        continent: 'AF',
        numeric_code: 86
      },
      {
        name: 'Brunei Darussalam',
        alpha2: 'BN',
        alpha3: 'BRN',
        continent: 'AS',
        numeric_code: 96
      },
      {
        name: 'Bulgaria',
        alpha2: 'BG',
        alpha3: 'BGR',
        continent: 'EU',
        numeric_code: 100
      },
      {
        name: 'Burkina Faso',
        alpha2: 'BF',
        alpha3: 'BFA',
        continent: 'AF',
        numeric_code: 854
      },
      {
        name: 'Burundi',
        alpha2: 'BI',
        alpha3: 'BDI',
        continent: 'AF',
        numeric_code: 108
      },
      {
        name: 'Cabo Verde',
        alpha2: 'CV',
        alpha3: 'CPV',
        continent: 'AF',
        numeric_code: 132
      },
      {
        name: 'Cambodia',
        alpha2: 'KH',
        alpha3: 'KHM',
        continent: 'AS',
        numeric_code: 116
      },
      {
        name: 'Cameroon',
        alpha2: 'CM',
        alpha3: 'CMR',
        continent: 'AF',
        numeric_code: 120
      },
      {
        name: 'Canada',
        alpha2: 'CA',
        alpha3: 'CAN',
        continent: 'NA',
        numeric_code: 124
      },
      {
        name: 'Cayman Islands',
        alpha2: 'KY',
        alpha3: 'CYM',
        continent: 'NA',
        numeric_code: 136
      },
      {
        name: 'Central African Republic',
        alpha2: 'CF',
        alpha3: 'CAF',
        continent: 'AF',
        numeric_code: 140
      },
      {
        name: 'Chad',
        alpha2: 'TD',
        alpha3: 'TCD',
        continent: 'AF',
        numeric_code: 148
      },
      {
        name: 'Chile',
        alpha2: 'CL',
        alpha3: 'CHL',
        continent: 'SA',
        numeric_code: 152
      },
      {
        name: 'China',
        alpha2: 'CN',
        alpha3: 'CHN',
        continent: 'AS',
        numeric_code: 156
      },
      {
        name: 'Christmas Island',
        alpha2: 'CX',
        alpha3: 'CXR',
        continent: 'OC',
        numeric_code: 162
      },
      {
        name: 'Cocos (Keeling) Islands',
        alpha2: 'CC',
        alpha3: 'CCK',
        continent: 'OC',
        numeric_code: 166
      },
      {
        name: 'Colombia',
        alpha2: 'CO',
        alpha3: 'COL',
        continent: 'SA',
        numeric_code: 170
      },
      {
        name: 'Comoros',
        alpha2: 'KM',
        alpha3: 'COM',
        continent: 'AF',
        numeric_code: 174
      },
      {
        name: 'Congo',
        alpha2: 'CG',
        alpha3: 'COG',
        continent: 'AF',
        numeric_code: 178
      },
      {
        name: 'Democratic Republic of Congo',
        alpha2: 'CD',
        alpha3: 'COD',
        continent: 'AF',
        numeric_code: 180
      },
      {
        name: 'Cook Islands',
        alpha2: 'CK',
        alpha3: 'COK',
        continent: 'OC',
        numeric_code: 184
      },
      {
        name: 'Costa Rica',
        alpha2: 'CR',
        alpha3: 'CRI',
        continent: 'NA',
        numeric_code: 188
      },
      {
        name: "Côte d'Ivoire",
        alpha2: 'CI',
        alpha3: 'CIV',
        continent: 'AF',
        numeric_code: 384
      },
      {
        name: 'Croatia',
        alpha2: 'HR',
        alpha3: 'HRV',
        continent: 'EU',
        numeric_code: 191
      },
      {
        name: 'Cuba',
        alpha2: 'CU',
        alpha3: 'CUB',
        continent: 'NA',
        numeric_code: 192
      },
      {
        name: 'Curaçao',
        alpha2: 'CW',
        alpha3: 'CUW',
        continent: 'NA',
        numeric_code: 531
      },
      {
        name: 'Cyprus',
        alpha2: 'CY',
        alpha3: 'CYP',
        continent: 'AS',
        numeric_code: 196
      },
      {
        name: 'Czechia',
        alpha2: 'CZ',
        alpha3: 'CZE',
        continent: 'EU',
        numeric_code: 203
      },
      {
        name: 'Denmark',
        alpha2: 'DK',
        alpha3: 'DNK',
        continent: 'EU',
        numeric_code: 208
      },
      {
        name: 'Djibouti',
        alpha2: 'DJ',
        alpha3: 'DJI',
        continent: 'AF',
        numeric_code: 262
      },
      {
        name: 'Dominica',
        alpha2: 'DM',
        alpha3: 'DMA',
        continent: 'NA',
        numeric_code: 212
      },
      {
        name: 'Dominican Republic',
        alpha2: 'DO',
        alpha3: 'DOM',
        continent: 'NA',
        numeric_code: 214
      },
      {
        name: 'Ecuador',
        alpha2: 'EC',
        alpha3: 'ECU',
        continent: 'SA',
        numeric_code: 218
      },
      {
        name: 'Egypt',
        alpha2: 'EG',
        alpha3: 'EGY',
        continent: 'AF',
        numeric_code: 818
      },
      {
        name: 'El Salvador',
        alpha2: 'SV',
        alpha3: 'SLV',
        continent: 'NA',
        numeric_code: 222
      },
      {
        name: 'Equatorial Guinea',
        alpha2: 'GQ',
        alpha3: 'GNQ',
        continent: 'AF',
        numeric_code: 226
      },
      {
        name: 'Eritrea',
        alpha2: 'ER',
        alpha3: 'ERI',
        continent: 'AF',
        numeric_code: 232
      },
      {
        name: 'Estonia',
        alpha2: 'EE',
        alpha3: 'EST',
        continent: 'EU',
        numeric_code: 233
      },
      {
        name: 'Eswatini',
        alpha2: 'SZ',
        alpha3: 'SWZ',
        continent: 'AF',
        numeric_code: 748
      },
      {
        name: 'Ethiopia',
        alpha2: 'ET',
        alpha3: 'ETH',
        continent: 'AF',
        numeric_code: 231
      },
      {
        name: 'Falkland Islands (Malvinas)',
        alpha2: 'FK',
        alpha3: 'FLK',
        continent: 'SA',
        numeric_code: 238
      },
      {
        name: 'Faroe Islands',
        alpha2: 'FO',
        alpha3: 'FRO',
        continent: 'EU',
        numeric_code: 234
      },
      {
        name: 'Fiji',
        alpha2: 'FJ',
        alpha3: 'FJI',
        continent: 'OC',
        numeric_code: 242
      },
      {
        name: 'Finland',
        alpha2: 'FI',
        alpha3: 'FIN',
        continent: 'EU',
        numeric_code: 246
      },
      {
        name: 'France',
        alpha2: 'FR',
        alpha3: 'FRA',
        continent: 'EU',
        numeric_code: 250
      },
      {
        name: 'French Guiana',
        alpha2: 'GF',
        alpha3: 'GUF',
        continent: 'SA',
        numeric_code: 254
      },
      {
        name: 'French Polynesia',
        alpha2: 'PF',
        alpha3: 'PYF',
        continent: 'OC',
        numeric_code: 258
      },
      {
        name: 'French Southern Territories',
        alpha2: 'TF',
        alpha3: 'ATF',
        continent: 'AF',
        numeric_code: 260
      },
      {
        name: 'Gabon',
        alpha2: 'GA',
        alpha3: 'GAB',
        continent: 'AF',
        numeric_code: 266
      },
      {
        name: 'Gambia',
        alpha2: 'GM',
        alpha3: 'GMB',
        continent: 'AF',
        numeric_code: 270
      },
      {
        name: 'Georgia',
        alpha2: 'GE',
        alpha3: 'GEO',
        continent: 'AS',
        numeric_code: 268
      },
      {
        name: 'Germany',
        alpha2: 'DE',
        alpha3: 'DEU',
        continent: 'EU',
        numeric_code: 276
      },
      {
        name: 'Ghana',
        alpha2: 'GH',
        alpha3: 'GHA',
        continent: 'AF',
        numeric_code: 288
      },
      {
        name: 'Gibraltar',
        alpha2: 'GI',
        alpha3: 'GIB',
        continent: 'EU',
        numeric_code: 292
      },
      {
        name: 'Greece',
        alpha2: 'GR',
        alpha3: 'GRC',
        continent: 'EU',
        numeric_code: 300
      },
      {
        name: 'Greenland',
        alpha2: 'GL',
        alpha3: 'GRL',
        continent: 'NA',
        numeric_code: 304
      },
      {
        name: 'Grenada',
        alpha2: 'GD',
        alpha3: 'GRD',
        continent: 'NA',
        numeric_code: 308
      },
      {
        name: 'Guadeloupe',
        alpha2: 'GP',
        alpha3: 'GLP',
        continent: 'NA',
        numeric_code: 312
      },
      {
        name: 'Guam',
        alpha2: 'GU',
        alpha3: 'GUM',
        continent: 'OC',
        numeric_code: 316
      },
      {
        name: 'Guatemala',
        alpha2: 'GT',
        alpha3: 'GTM',
        continent: 'NA',
        numeric_code: 320
      },
      {
        name: 'Guernsey',
        alpha2: 'GG',
        alpha3: 'GGY',
        continent: 'EU',
        numeric_code: 831
      },
      {
        name: 'Guinea',
        alpha2: 'GN',
        alpha3: 'GIN',
        continent: 'AF',
        numeric_code: 324
      },
      {
        name: 'Guinea-Bissau',
        alpha2: 'GW',
        alpha3: 'GNB',
        continent: 'AF',
        numeric_code: 624
      },
      {
        name: 'Guyana',
        alpha2: 'GY',
        alpha3: 'GUY',
        continent: 'SA',
        numeric_code: 328
      },
      {
        name: 'Haiti',
        alpha2: 'HT',
        alpha3: 'HTI',
        continent: 'NA',
        numeric_code: 332
      },
      {
        name: 'Heard Island and McDonald Islands',
        alpha2: 'HM',
        alpha3: 'HMD',
        continent: 'OC',
        numeric_code: 334
      },
      {
        name: 'Holy See',
        alpha2: 'VA',
        alpha3: 'VAT',
        continent: 'EU',
        numeric_code: 336
      },
      {
        name: 'Honduras',
        alpha2: 'HN',
        alpha3: 'HND',
        continent: 'NA',
        numeric_code: 340
      },
      {
        name: 'Hong Kong',
        alpha2: 'HK',
        alpha3: 'HKG',
        continent: 'AS',
        numeric_code: 344
      },
      {
        name: 'Hungary',
        alpha2: 'HU',
        alpha3: 'HUN',
        continent: 'EU',
        numeric_code: 348
      },
      {
        name: 'Iceland',
        alpha2: 'IS',
        alpha3: 'ISL',
        continent: 'EU',
        numeric_code: 352
      },
      {
        name: 'India',
        alpha2: 'IN',
        alpha3: 'IND',
        continent: 'AS',
        numeric_code: 356
      },
      {
        name: 'Indonesia',
        alpha2: 'ID',
        alpha3: 'IDN',
        continent: 'AS',
        numeric_code: 360
      },
      {
        name: 'Iran',
        alpha2: 'IR',
        alpha3: 'IRN',
        continent: 'AS',
        numeric_code: 364
      },
      {
        name: 'Iraq',
        alpha2: 'IQ',
        alpha3: 'IRQ',
        continent: 'AS',
        numeric_code: 368
      },
      {
        name: 'Ireland',
        alpha2: 'IE',
        alpha3: 'IRL',
        continent: 'EU',
        numeric_code: 372
      },
      {
        name: 'Isle of Man',
        alpha2: 'IM',
        alpha3: 'IMN',
        continent: 'EU',
        numeric_code: 833
      },
      {
        name: 'Israel',
        alpha2: 'IL',
        alpha3: 'ISR',
        continent: 'AS',
        numeric_code: 376
      },
      {
        name: 'Italy',
        alpha2: 'IT',
        alpha3: 'ITA',
        continent: 'EU',
        numeric_code: 380
      },
      {
        name: 'Jamaica',
        alpha2: 'JM',
        alpha3: 'JAM',
        continent: 'NA',
        numeric_code: 388
      },
      {
        name: 'Japan',
        alpha2: 'JP',
        alpha3: 'JPN',
        continent: 'AS',
        numeric_code: 392
      },
      {
        name: 'Jersey',
        alpha2: 'JE',
        alpha3: 'JEY',
        continent: 'EU',
        numeric_code: 832
      },
      {
        name: 'Jordan',
        alpha2: 'JO',
        alpha3: 'JOR',
        continent: 'AS',
        numeric_code: 400
      },
      {
        name: 'Kazakhstan',
        alpha2: 'KZ',
        alpha3: 'KAZ',
        continent: 'AS',
        numeric_code: 398
      },
      {
        name: 'Kenya',
        alpha2: 'KE',
        alpha3: 'KEN',
        continent: 'AF',
        numeric_code: 404
      },
      {
        name: 'Kiribati',
        alpha2: 'KI',
        alpha3: 'KIR',
        continent: 'OC',
        numeric_code: 296
      },
      {
        name: "Democratic People's Republic of Korea",
        alpha2: 'KP',
        alpha3: 'PRK',
        continent: 'AS',
        numeric_code: 408
      },
      {
        name: 'Republic of Korea',
        alpha2: 'KR',
        alpha3: 'KOR',
        continent: 'AS',
        numeric_code: 410
      },
      {
        name: 'Kuwait',
        alpha2: 'KW',
        alpha3: 'KWT',
        continent: 'AS',
        numeric_code: 414
      },
      {
        name: 'Kyrgyzstan',
        alpha2: 'KG',
        alpha3: 'KGZ',
        continent: 'AS',
        numeric_code: 417
      },
      {
        name: "Lao People's Democratic Republic",
        alpha2: 'LA',
        alpha3: 'LAO',
        continent: 'AS',
        numeric_code: 418
      },
      {
        name: 'Latvia',
        alpha2: 'LV',
        alpha3: 'LVA',
        continent: 'EU',
        numeric_code: 428
      },
      {
        name: 'Lebanon',
        alpha2: 'LB',
        alpha3: 'LBN',
        continent: 'AS',
        numeric_code: 422
      },
      {
        name: 'Lesotho',
        alpha2: 'LS',
        alpha3: 'LSO',
        continent: 'AF',
        numeric_code: 426
      },
      {
        name: 'Liberia',
        alpha2: 'LR',
        alpha3: 'LBR',
        continent: 'AF',
        numeric_code: 430
      },
      {
        name: 'Libya',
        alpha2: 'LY',
        alpha3: 'LBY',
        continent: 'AF',
        numeric_code: 434
      },
      {
        name: 'Liechtenstein',
        alpha2: 'LI',
        alpha3: 'LIE',
        continent: 'EU',
        numeric_code: 438
      },
      {
        name: 'Lithuania',
        alpha2: 'LT',
        alpha3: 'LTU',
        continent: 'EU',
        numeric_code: 440
      },
      {
        name: 'Luxembourg',
        alpha2: 'LU',
        alpha3: 'LUX',
        continent: 'EU',
        numeric_code: 442
      },
      {
        name: 'Macao',
        alpha2: 'MO',
        alpha3: 'MAC',
        continent: 'AS',
        numeric_code: 446
      },
      {
        name: 'Madagascar',
        alpha2: 'MG',
        alpha3: 'MDG',
        continent: 'AF',
        numeric_code: 450
      },
      {
        name: 'Malawi',
        alpha2: 'MW',
        alpha3: 'MWI',
        continent: 'AF',
        numeric_code: 454
      },
      {
        name: 'Malaysia',
        alpha2: 'MY',
        alpha3: 'MYS',
        continent: 'AS',
        numeric_code: 458
      },
      {
        name: 'Maldives',
        alpha2: 'MV',
        alpha3: 'MDV',
        continent: 'AS',
        numeric_code: 462
      },
      {
        name: 'Mali',
        alpha2: 'ML',
        alpha3: 'MLI',
        continent: 'AF',
        numeric_code: 466
      },
      {
        name: 'Malta',
        alpha2: 'MT',
        alpha3: 'MLT',
        continent: 'EU',
        numeric_code: 470
      },
      {
        name: 'Marshall Islands',
        alpha2: 'MH',
        alpha3: 'MHL',
        continent: 'OC',
        numeric_code: 584
      },
      {
        name: 'Martinique',
        alpha2: 'MQ',
        alpha3: 'MTQ',
        continent: 'NA',
        numeric_code: 474
      },
      {
        name: 'Mauritania',
        alpha2: 'MR',
        alpha3: 'MRT',
        continent: 'AF',
        numeric_code: 478
      },
      {
        name: 'Mauritius',
        alpha2: 'MU',
        alpha3: 'MUS',
        continent: 'AF',
        numeric_code: 480
      },
      {
        name: 'Mayotte',
        alpha2: 'YT',
        alpha3: 'MYT',
        continent: 'AF',
        numeric_code: 175
      },
      {
        name: 'Mexico',
        alpha2: 'MX',
        alpha3: 'MEX',
        continent: 'NA',
        numeric_code: 484
      },
      {
        name: 'Micronesia (Federated States of)',
        alpha2: 'FM',
        alpha3: 'FSM',
        continent: 'OC',
        numeric_code: 583
      },
      {
        name: 'Republic of Moldova',
        alpha2: 'MD',
        alpha3: 'MDA',
        continent: 'EU',
        numeric_code: 498
      },
      {
        name: 'Monaco',
        alpha2: 'MC',
        alpha3: 'MCO',
        continent: 'EU',
        numeric_code: 492
      },
      {
        name: 'Mongolia',
        alpha2: 'MN',
        alpha3: 'MNG',
        continent: 'AS',
        numeric_code: 496
      },
      {
        name: 'Montenegro',
        alpha2: 'ME',
        alpha3: 'MNE',
        continent: 'EU',
        numeric_code: 499
      },
      {
        name: 'Montserrat',
        alpha2: 'MS',
        alpha3: 'MSR',
        continent: 'NA',
        numeric_code: 500
      },
      {
        name: 'Morocco',
        alpha2: 'MA',
        alpha3: 'MAR',
        continent: 'AF',
        numeric_code: 504
      },
      {
        name: 'Mozambique',
        alpha2: 'MZ',
        alpha3: 'MOZ',
        continent: 'AF',
        numeric_code: 508
      },
      {
        name: 'Myanmar',
        alpha2: 'MM',
        alpha3: 'MMR',
        continent: 'AS',
        numeric_code: 104
      },
      {
        name: 'Namibia',
        alpha2: 'NA',
        alpha3: 'NAM',
        continent: 'AF',
        numeric_code: 516
      },
      {
        name: 'Nauru',
        alpha2: 'NR',
        alpha3: 'NRU',
        continent: 'OC',
        numeric_code: 520
      },
      {
        name: 'Nepal',
        alpha2: 'NP',
        alpha3: 'NPL',
        continent: 'AS',
        numeric_code: 524
      },
      {
        name: 'Netherlands',
        alpha2: 'NL',
        alpha3: 'NLD',
        continent: 'EU',
        numeric_code: 528
      },
      {
        name: 'New Caledonia',
        alpha2: 'NC',
        alpha3: 'NCL',
        continent: 'OC',
        numeric_code: 540
      },
      {
        name: 'New Zealand',
        alpha2: 'NZ',
        alpha3: 'NZL',
        continent: 'OC',
        numeric_code: 554
      },
      {
        name: 'Nicaragua',
        alpha2: 'NI',
        alpha3: 'NIC',
        continent: 'NA',
        numeric_code: 558
      },
      {
        name: 'Niger',
        alpha2: 'NE',
        alpha3: 'NER',
        continent: 'AF',
        numeric_code: 562
      },
      {
        name: 'Nigeria',
        alpha2: 'NG',
        alpha3: 'NGA',
        continent: 'AF',
        numeric_code: 566
      },
      {
        name: 'Niue',
        alpha2: 'NU',
        alpha3: 'NIU',
        continent: 'OC',
        numeric_code: 570
      },
      {
        name: 'Norfolk Island',
        alpha2: 'NF',
        alpha3: 'NFK',
        continent: 'OC',
        numeric_code: 574
      },
      {
        name: 'North Macedonia',
        alpha2: 'MK',
        alpha3: 'MKD',
        continent: 'EU',
        numeric_code: 807
      },
      {
        name: 'Northern Mariana Islands',
        alpha2: 'MP',
        alpha3: 'MNP',
        continent: 'OC',
        numeric_code: 580
      },
      {
        name: 'Norway',
        alpha2: 'NO',
        alpha3: 'NOR',
        continent: 'EU',
        numeric_code: 578
      },
      {
        name: 'Oman',
        alpha2: 'OM',
        alpha3: 'OMN',
        continent: 'AS',
        numeric_code: 512
      },
      {
        name: 'Pakistan',
        alpha2: 'PK',
        alpha3: 'PAK',
        continent: 'AS',
        numeric_code: 586
      },
      {
        name: 'Palau',
        alpha2: 'PW',
        alpha3: 'PLW',
        continent: 'OC',
        numeric_code: 585
      },
      {
        name: 'State of Palestine',
        alpha2: 'PS',
        alpha3: 'PSE',
        continent: 'AS',
        numeric_code: 275
      },
      {
        name: 'Panama',
        alpha2: 'PA',
        alpha3: 'PAN',
        continent: 'NA',
        numeric_code: 591
      },
      {
        name: 'Papua New Guinea',
        alpha2: 'PG',
        alpha3: 'PNG',
        continent: 'OC',
        numeric_code: 598
      },
      {
        name: 'Paraguay',
        alpha2: 'PY',
        alpha3: 'PRY',
        continent: 'SA',
        numeric_code: 600
      },
      {
        name: 'Peru',
        alpha2: 'PE',
        alpha3: 'PER',
        continent: 'SA',
        numeric_code: 604
      },
      {
        name: 'Philippines',
        alpha2: 'PH',
        alpha3: 'PHL',
        continent: 'AS',
        numeric_code: 608
      },
      {
        name: 'Pitcairn',
        alpha2: 'PN',
        alpha3: 'PCN',
        continent: 'OC',
        numeric_code: 612
      },
      {
        name: 'Poland',
        alpha2: 'PL',
        alpha3: 'POL',
        continent: 'EU',
        numeric_code: 616
      },
      {
        name: 'Portugal',
        alpha2: 'PT',
        alpha3: 'PRT',
        continent: 'EU',
        numeric_code: 620
      },
      {
        name: 'Puerto Rico',
        alpha2: 'PR',
        alpha3: 'PRI',
        continent: 'NA',
        numeric_code: 630
      },
      {
        name: 'Qatar',
        alpha2: 'QA',
        alpha3: 'QAT',
        continent: 'AS',
        numeric_code: 634
      },
      {
        name: 'Réunion',
        alpha2: 'RE',
        alpha3: 'REU',
        continent: 'AF',
        numeric_code: 638
      },
      {
        name: 'Romania',
        alpha2: 'RO',
        alpha3: 'ROU',
        continent: 'EU',
        numeric_code: 642
      },
      {
        name: 'Russian Federation',
        alpha2: 'RU',
        alpha3: 'RUS',
        continent: 'EU',
        numeric_code: 643
      },
      {
        name: 'Rwanda',
        alpha2: 'RW',
        alpha3: 'RWA',
        continent: 'AF',
        numeric_code: 646
      },
      {
        name: 'Saint Barthélemy',
        alpha2: 'BL',
        alpha3: 'BLM',
        continent: 'NA',
        numeric_code: 652
      },
      {
        name: 'Saint Helena',
        alpha2: 'SH',
        alpha3: 'SHN',
        continent: 'AF',
        numeric_code: 654
      },
      {
        name: 'Saint Kitts and Nevis',
        alpha2: 'KN',
        alpha3: 'KNA',
        continent: 'NA',
        numeric_code: 659
      },
      {
        name: 'Saint Lucia',
        alpha2: 'LC',
        alpha3: 'LCA',
        continent: 'NA',
        numeric_code: 662
      },
      {
        name: 'Saint Martin',
        alpha2: 'MF',
        alpha3: 'MAF',
        continent: 'NA',
        numeric_code: 663
      },
      {
        name: 'Saint Pierre and Miquelon',
        alpha2: 'PM',
        alpha3: 'SPM',
        continent: 'NA',
        numeric_code: 666
      },
      {
        name: 'Saint Vincent and the Grenadines',
        alpha2: 'VC',
        alpha3: 'VCT',
        continent: 'NA',
        numeric_code: 670
      },
      {
        name: 'Samoa',
        alpha2: 'WS',
        alpha3: 'WSM',
        continent: 'OC',
        numeric_code: 882
      },
      {
        name: 'San Marino',
        alpha2: 'SM',
        alpha3: 'SMR',
        continent: 'EU',
        numeric_code: 674
      },
      {
        name: 'Sao Tome and Principe',
        alpha2: 'ST',
        alpha3: 'STP',
        continent: 'AF',
        numeric_code: 678
      },
      {
        name: 'Saudi Arabia',
        alpha2: 'SA',
        alpha3: 'SAU',
        continent: 'AS',
        numeric_code: 682
      },
      {
        name: 'Senegal',
        alpha2: 'SN',
        alpha3: 'SEN',
        continent: 'AF',
        numeric_code: 686
      },
      {
        name: 'Serbia',
        alpha2: 'RS',
        alpha3: 'SRB',
        continent: 'EU',
        numeric_code: 688
      },
      {
        name: 'Seychelles',
        alpha2: 'SC',
        alpha3: 'SYC',
        continent: 'AF',
        numeric_code: 690
      },
      {
        name: 'Sierra Leone',
        alpha2: 'SL',
        alpha3: 'SLE',
        continent: 'AF',
        numeric_code: 694
      },
      {
        name: 'Singapore',
        alpha2: 'SG',
        alpha3: 'SGP',
        continent: 'AS',
        numeric_code: 702
      },
      {
        name: 'Sint Maarten (Dutch part)',
        alpha2: 'SX',
        alpha3: 'SXM',
        continent: 'NA',
        numeric_code: 534
      },
      {
        name: 'Slovakia',
        alpha2: 'SK',
        alpha3: 'SVK',
        continent: 'EU',
        numeric_code: 703
      },
      {
        name: 'Slovenia',
        alpha2: 'SI',
        alpha3: 'SVN',
        continent: 'EU',
        numeric_code: 705
      },
      {
        name: 'Solomon Islands',
        alpha2: 'SB',
        alpha3: 'SLB',
        continent: 'OC',
        numeric_code: 90
      },
      {
        name: 'Somalia',
        alpha2: 'SO',
        alpha3: 'SOM',
        continent: 'AF',
        numeric_code: 706
      },
      {
        name: 'South Africa',
        alpha2: 'ZA',
        alpha3: 'ZAF',
        continent: 'AF',
        numeric_code: 710
      },
      {
        name: 'South Georgia and the South Sandwich Islands',
        alpha2: 'GS',
        alpha3: 'SGS',
        continent: 'NA',
        numeric_code: 239
      },
      {
        name: 'South Sudan',
        alpha2: 'SS',
        alpha3: 'SSD',
        continent: 'AF',
        numeric_code: 728
      },
      {
        name: 'Spain',
        alpha2: 'ES',
        alpha3: 'ESP',
        continent: 'EU',
        numeric_code: 724
      },
      {
        name: 'Sri Lanka',
        alpha2: 'LK',
        alpha3: 'LKA',
        continent: 'AS',
        numeric_code: 144
      },
      {
        name: 'Sudan',
        alpha2: 'SD',
        alpha3: 'SDN',
        continent: 'AF',
        numeric_code: 729
      },
      {
        name: 'Suriname',
        alpha2: 'SR',
        alpha3: 'SUR',
        continent: 'SA',
        numeric_code: 740
      },
      {
        name: 'Svalbard and Jan Mayen',
        alpha2: 'SJ',
        alpha3: 'SJM',
        continent: 'EU',
        numeric_code: 744
      },
      {
        name: 'Sweden',
        alpha2: 'SE',
        alpha3: 'SWE',
        continent: 'EU',
        numeric_code: 752
      },
      {
        name: 'Switzerland',
        alpha2: 'CH',
        alpha3: 'CHE',
        continent: 'EU',
        numeric_code: 756
      },
      {
        name: 'Syrian Arab Republic',
        alpha2: 'SY',
        alpha3: 'SYR',
        continent: 'AS',
        numeric_code: 760
      },
      {
        name: 'Taiwan',
        alpha2: 'TW',
        alpha3: 'TWN',
        continent: 'AS',
        numeric_code: 158
      },
      {
        name: 'Tajikistan',
        alpha2: 'TJ',
        alpha3: 'TJK',
        continent: 'AS',
        numeric_code: 762
      },
      {
        name: 'Tanzania',
        alpha2: 'TZ',
        alpha3: 'TZA',
        continent: 'AF',
        numeric_code: 834
      },
      {
        name: 'Thailand',
        alpha2: 'TH',
        alpha3: 'THA',
        continent: 'AS',
        numeric_code: 764
      },
      {
        name: 'Timor-Leste',
        alpha2: 'TL',
        alpha3: 'TLS',
        continent: 'AS',
        numeric_code: 626
      },
      {
        name: 'Togo',
        alpha2: 'TG',
        alpha3: 'TGO',
        continent: 'AF',
        numeric_code: 768
      },
      {
        name: 'Tokelau',
        alpha2: 'TK',
        alpha3: 'TKL',
        continent: 'OC',
        numeric_code: 772
      },
      {
        name: 'Tonga',
        alpha2: 'TO',
        alpha3: 'TON',
        continent: 'OC',
        numeric_code: 776
      },
      {
        name: 'Trinidad and Tobago',
        alpha2: 'TT',
        alpha3: 'TTO',
        continent: 'NA',
        numeric_code: 780
      },
      {
        name: 'Tunisia',
        alpha2: 'TN',
        alpha3: 'TUN',
        continent: 'AF',
        numeric_code: 788
      },
      {
        name: 'Turkey',
        alpha2: 'TR',
        alpha3: 'TUR',
        continent: 'AS',
        numeric_code: 792
      },
      {
        name: 'Turkmenistan',
        alpha2: 'TM',
        alpha3: 'TKM',
        continent: 'AS',
        numeric_code: 795
      },
      {
        name: 'Turks and Caicos Islands',
        alpha2: 'TC',
        alpha3: 'TCA',
        continent: 'NA',
        numeric_code: 796
      },
      {
        name: 'Tuvalu',
        alpha2: 'TV',
        alpha3: 'TUV',
        continent: 'OC',
        numeric_code: 798
      },
      {
        name: 'Uganda',
        alpha2: 'UG',
        alpha3: 'UGA',
        continent: 'AF',
        numeric_code: 800
      },
      {
        name: 'Ukraine',
        alpha2: 'UA',
        alpha3: 'UKR',
        continent: 'EU',
        numeric_code: 804
      },
      {
        name: 'United Arab Emirates',
        alpha2: 'AE',
        alpha3: 'ARE',
        continent: 'AS',
        numeric_code: 784
      },
      {
        name: 'United Kingdom of Great Britain and Northern Ireland',
        alpha2: 'GB',
        alpha3: 'GBR',
        continent: 'EU',
        numeric_code: 826
      },
      {
        name: 'United States of America',
        alpha2: 'US',
        alpha3: 'USA',
        continent: 'NA',
        numeric_code: 840
      },
      {
        name: 'United States Minor Outlying Islands',
        alpha2: 'UM',
        alpha3: 'UMI',
        continent: 'OC',
        numeric_code: 581
      },
      {
        name: 'Uruguay',
        alpha2: 'UY',
        alpha3: 'URY',
        continent: 'SA',
        numeric_code: 858
      },
      {
        name: 'Uzbekistan',
        alpha2: 'UZ',
        alpha3: 'UZB',
        continent: 'AS',
        numeric_code: 860
      },
      {
        name: 'Vanuatu',
        alpha2: 'VU',
        alpha3: 'VUT',
        continent: 'OC',
        numeric_code: 548
      },
      {
        name: 'Venezuela (Bolivarian Republic of)',
        alpha2: 'VE',
        alpha3: 'VEN',
        continent: 'SA',
        numeric_code: 862
      },
      {
        name: 'Viet Nam',
        alpha2: 'VN',
        alpha3: 'VNM',
        continent: 'AS',
        numeric_code: 704
      },
      {
        name: 'Virgin Islands (British)',
        alpha2: 'VG',
        alpha3: 'VGB',
        continent: 'NA',
        numeric_code: 92
      },
      {
        name: 'Virgin Islands (U.S.)',
        alpha2: 'VI',
        alpha3: 'VIR',
        continent: 'NA',
        numeric_code: 850
      },
      {
        name: 'Wallis and Futuna',
        alpha2: 'WF',
        alpha3: 'WLF',
        continent: 'OC',
        numeric_code: 876
      },
      {
        name: 'Western Sahara',
        alpha2: 'EH',
        alpha3: 'ESH',
        continent: 'AF',
        numeric_code: 732
      },
      {
        name: 'Yemen',
        alpha2: 'YE',
        alpha3: 'YEM',
        continent: 'AS',
        numeric_code: 887
      },
      {
        name: 'Zambia',
        alpha2: 'ZM',
        alpha3: 'ZMB',
        continent: 'AF',
        numeric_code: 894
      },
      {
        name: 'Zimbabwe',
        alpha2: 'ZW',
        alpha3: 'ZWE',
        continent: 'AF',
        numeric_code: 716
      }
    ]
  },
  TRACE_FILTER_ROUTES: ['system/jobs', '/api/static'],
  MAINTENANCE_FILTER_ROUTES: ['/api/system', '/api/website', 'api/tour', 'api/dialogflow', 'api/requests/'],
  PROVIDERS: {
    VAPP_CONTEXT: 'VAPP_CONTEXT'
  },
  IGNORE_INTEGRATIONS: [integration_type.RBM],
  HEADERS: [
    { 'Access-Control-Allow-Credentials': 'true' },
    { 'Access-Control-Allow-Methods': 'GET,PUT,POST,DELETE,OPTIONS' },
    { 'Access-Control-Allow-Headers': 'X-Requested-With, Content-Type, Authorization' },
    { 'Cache-Control': 'private, no-cache, must-revalidate' }
  ],
  ALLOWED_ORIGINS: [
    {
      environment: [environments.development, environments.local, environments.qa],
      origins: [/^((http|https):\/\/)?((dev|qa|tours)\.)?(vapp|192.168.1.74|(localhost(\/\S*)?))(:\d+(\/\S*)?)?(\.in(\/\S*)?)?\?*.*$/m],
      cookie: 'vapp.in'
    },
    {
      environment: [environments.staging],
      origins: [/^((http|https):\/\/)?((stage)\.)?vapp(\.in(\/\S*)?)?\?*.*$/m],
      cookie: 'vapp.in'
    },
    {
      environment: [environments.production],
      origins: [/^((http|https):\/\/)?((admin|dashboard)\.)?(www\.)?vapp(\.in(\/\S*)?)?\?*.*$/m],
      cookie: 'vapp.in'
    }
  ],
  DIALOGFLOW: {
    scopes: ['https://www.googleapis.com/auth/dialogflow', 'https://www.googleapis.com/auth/cloud-platform']
  },
  REDIS_RETRY_STRATEGY: {
    NUMBER_OF_RETRY_ATTEMPTS: 5,
    DELAY_OF_RETRY_ATTEMPTS: 500,
    WAIT_TIME: 5000
  },
  DRIP_WHATSAPP_CAMPAIGN: {
    browser_arguments: [
      '--incognito',
      '--disable-gpu',
      '--renderer',
      '--no-sandbox',
      '--disable-setuid-sandbox',
      '--no-service-autorun',
      '--no-experiments',
      '--no-default-browser-check',
      '--disable-webgl',
      '--disable-threaded-animation',
      '--disable-threaded-scrolling',
      '--disable-in-process-stack-traces',
      '--disable-histogram-customizer',
      '--disable-gl-extensions',
      '--disable-extensions',
      '--disable-composited-antialiasing',
      '--disable-canvas-aa',
      '--disable-3d-apis',
      '--disable-accelerated-2d-canvas',
      '--disable-accelerated-jpeg-decoding',
      '--disable-accelerated-mjpeg-decode',
      '--disable-app-list-dismiss-on-blur',
      '--disable-accelerated-video-decode',
      '--num-raster-threads=1'
    ],
    mutators: {
      qr_code_mutator: 'qr_code_mutator',
      logout_mutator: 'logout_mutator',
      login_mutator: 'login_mutator',
      connection_mutator: 'connection_mutator',
      phone_mutator: 'phone_mutator'
    },
    events: {
      qr_code_changed: 'qr_code_changed', // qr code setting on ui
      qr_code_expired: 'qr_code_expired', // end state
      qr_code_started: 'qr_code_started',
      login_successful: 'login_successful', // login success toast
      logout_successful: 'logout_successful', // end state
      phone_disconnected: 'phone_disconnected',
      phone_connected: 'phone_connected',
      campaign_started: 'campaign_started', // progressive loader
      campaign_failed: 'campaign_failed', // end state
      campaign_finished: 'campaign_finished', // end state,
      update_profile: 'update_profile', // end state,
      qr_session_invalid: 'qr_session_invalid'
    }
  },
  WHATSAPP_CAMPAIGN: {
    browser_arguments: ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage', '--disable-setuid-sandbox', '--disable-extensions'],
    mutators: {
      qr_code_mutator: 'qr_code_mutator',
      logout_mutator: 'logout_mutator',
      login_mutator: 'login_mutator',
      connection_mutator: 'connection_mutator',
      phone_mutator: 'phone_mutator'
    },
    events: {
      qr_code_changed: 'qr_code_changed', // qr code setting on ui
      qr_code_expired: 'qr_code_expired', // end state
      qr_code_started: 'qr_code_started',
      login_successful: 'login_successful', // login success toast
      logout_successful: 'logout_successful', // end state
      phone_disconnected: 'phone_disconnected',
      phone_connected: 'phone_connected',
      campaign_started: 'campaign_started', // progressive loader
      campaign_failed: 'campaign_failed', // end state
      campaign_finished: 'campaign_finished', // end state,
      update_profile: 'update_profile', // end state,
      qr_session_invalid: 'qr_session_invalid'
    }
  },
  USER_TYPES: {
    client: 2,
    admin: 3
  },
  TOKEN: {
    login: '5d',
    campaign_sms: '48h'
  },
  SMS_STATUS_CHECKS: {
    submitted: { values: ['submitted'], value: 1, tag: 'submitted' },
    success: { values: ['delivrd', 'dlvrd', 'DELIVRD', 'DELIVERED', 'delivered'], value: 2, tag: 'delivered' },
    failed: { values: ['absent_subscriber', 'undeliv', 'failed', 'dropped', 'expired', 'UNDELIV', 'REJECTD', 'EXPIRED', 'FAILED'], value: 3, tag: 'failed' },
    refund: { values: ['dnd'], value: 4, tag: 'refunded' }
  },
  SMS_STATUS: {
    submitted: 1,
    success: 2,
    failed: 3,
    dnd: 4
  },
  SMS_STATUS_STRINGS: {
    success: 'delivrd',
    failed: 'failed',
    refund: 'refund'
  },
  SMPP_STATUS: {
    NO_ERROR: 0
  },
  MESSAGE_DEFAULTS: {
    name: 'user'
  },
  TRANSACTION_OPTIONS: {
    readPreference: { mode: 'primary' },
    readConcern: { level: 'local' },
    writeConcern: { w: 'majority' }
  } as TransactionOptions,
  JWT_AUDIENCE: {
    client: 'client',
    admin: 'admin',
    public: 'public'
  },
  FEATURES_ACCESS: {
    CAMPAIGN: {
      NAME: 'CAMPAIGN',
      FEATURES: {}
    },
    OTP: {
      NAME: 'OTP',
      FEATURES: {
        VERIFY: 'OTP_VERIFY'
      }
    },
    TRANSACTIONAL: {
      NAME: 'TRANSACTIONAL',
      FEATURES: {}
    }
  },
  CAMPAIGN_TYPES: {
    SMS: { value: 1, name: 'SMS' },
    WHATSAPP: { value: 2, name: 'Whatsapp' }
  },
  DRIP_CAMPAIGN_TYPES: {
    SMS: { value: 1, name: 'SMS' },
    WHATSAPP: { value: 2, name: 'Whatsapp' }
  },
  DEVICE_TYPES: {
    UNKNOWN: 'unknown'
  },
  DASHBOARD_TRENDS_LIMIT: {
    PERSONS_LIMIT: {
      start: 0,
      end: 10
    }
  },
  MONTHS: [
    {
      short: 'Jan',
      long: 'January',
      index: 1
    },
    {
      short: 'Feb',
      long: 'February',
      index: 2
    },
    {
      short: 'Mar',
      long: 'March',
      index: 3
    },
    {
      short: 'Apr',
      long: 'April',
      index: 4
    },
    {
      short: 'May',
      long: 'May',
      index: 5
    },
    {
      short: 'Jun',
      long: 'June',
      index: 6
    },
    {
      short: 'Jul',
      long: 'July',
      index: 7
    },
    {
      short: 'Aug',
      long: 'August',
      index: 8
    },
    {
      short: 'Sep',
      long: 'September',
      index: 9
    },
    {
      short: 'Oct',
      long: 'October',
      index: 10
    },
    {
      short: 'Nov',
      long: 'November',
      index: 11
    },
    {
      short: 'Dec',
      long: 'December',
      index: 12
    }
  ],
  ENGAGEMENT_LOWER_LIMITS: {
    negative: 0,
    neutral: 30000,
    positive: 60000
  },
  LEAD_TYPE: {
    negative: 'negative',
    neutral: 'neutral',
    positive: 'positive'
  },
  ENGAGEMENT_LEVELS: {
    initial: 0,
    negative: 1,
    neutral: 2,
    positive: 3
  },
  LEADSQUARED_FIELDS: [
    { name: 'va Source', dataType: 'Text', renderType: 'Textbox' },
    { name: 'va Phone', dataType: 'Phone', renderType: 'Textbox' },
    { name: 'va Request ID', dataType: 'Text', renderType: 'Textbox' },
    { name: 'va Campaign ID', dataType: 'Text', renderType: 'Textbox' },
    { name: 'va Views', dataType: 'Number', renderType: 'Textbox' },
    { name: 'va Chatbot', dataType: 'Boolean', renderType: 'Checkbox' },
    { name: 'va Brochure', dataType: 'Boolean', renderType: 'Checkbox' },
    { name: 'va Whatsapp', dataType: 'Boolean', renderType: 'Checkbox' },
    { name: 'va Total Calls', dataType: 'Number', renderType: 'Textbox' },
    { name: 'va OS', dataType: 'Text', renderType: 'Textbox' },
    { name: 'va Device', dataType: 'Text', renderType: 'Textbox' },
    { name: 'va Device Type', dataType: 'Text', renderType: 'Textbox' },
    { name: 'va Demographics', dataType: 'Text', renderType: 'Textbox' },
    { name: 'va IP', dataType: 'Text', renderType: 'Textbox' },
    { name: 'va City', dataType: 'Text', renderType: 'Textbox' },
    { name: 'va Region', dataType: 'Text', renderType: 'Textbox' },
    { name: 'va Region Code', dataType: 'Text', renderType: 'Textbox' },
    { name: 'va Country Code', dataType: 'Text', renderType: 'Textbox' },
    { name: 'va Latitude', dataType: 'Number', renderType: 'Textbox', numScale: true },
    { name: 'va Longitude', dataType: 'Number', renderType: 'Textbox', numScale: true },
    { name: 'va Project URL', dataType: 'Website', renderType: 'URL' },
    { name: 'va Campaign URL', dataType: 'Website', renderType: 'URL' }
  ]
}

// defined websocket even types
export const websocketEvents = {
  CLIENT_BOT_INTERACTION: 'CLIENT_BOT_INTERACTION',
  CLIENT_BROCHURE_INTERACTION: 'CLIENT_BROCHURE_INTERACTION',
  CLIENT_WHATSAPP_INTERACTION: 'CLIENT_WHATSAPP_INTERACTION',
  CLIENT_TOUR_ENGAGEMENT: 'CLIENT_TOUR_ENGAGEMENT',
  CLIENT_TOUR_ENGAGEMENT_MAX_CAP_REACHED: 'CLIENT_TOUR_ENGAGEMENT_MAX_CAP_REACHED',
  CLIENT_OTP_REPORT_INTERACTION: 'CLIENT_OTP_REPORT_INTERACTION',
  CLIENT_OTP_REPORT_COMPLETE: 'CLIENT_OTP_REPORT_COMPLETE',
  CLIENT_TRANSACTIONAL_REPORT_INTERACTION: 'CLIENT_TRANSACTIONAL_REPORT_INTERACTION',
  CLIENT_TRANSACTIONAL_REPORT_COMPLETE: 'CLIENT_TRANSACTIONAL_REPORT_COMPLETE',
  DISCONNECT: 'disconnect'
}

const getSeconds = (time: string) => {
  if (_.eq(typeof time, 'string')) {
    const milliseconds = ms(time)
    if (_.eq(typeof milliseconds, 'undefined')) {
      return undefined
    }
    return milliseconds / 1000
  }
  return undefined
}

export const redisKeys = {
  USER: { timeout: () => getSeconds('1hr'), value: (userID: string) => `user_${userID}` },
  OTP: { timeout: () => getSeconds('10m'), value: (uuid: string) => `user_otp_${uuid}` },
  USER_RESET: { timeout: () => getSeconds('30m'), value: (email: string) => `reset_user_${email}` },
  USER_REPORT: { timeout: () => getSeconds('2d'), value: (client_id: string, type: number, id: string) => `report_${client_id}_${type}_${id}` },
  USER_API_KEY: { timeout: () => getSeconds('48hr'), value: (apiKey: string) => `key_${apiKey}` },
  USER_TEMPLATES: { timeout: () => getSeconds('1hr'), value: (userID: string) => `user_templates_${userID}` },
  USER_LINKS: { timeout: () => getSeconds('1hr'), value: (userID: string) => `user_links_${userID}` },
  USER_DRIPCRITERIA: { timeout: () => getSeconds('1hr'), value: (userID: string) => `user_dripcriterias_${userID}` },
  USER_CREDITS: { timeout: () => getSeconds('1hr'), value: (userID: string) => `user_credits_${userID}` },
  USER_INTEGRATIONS: { timeout: () => getSeconds('1hr'), value: (userID: string) => `user_integrations_${userID}` },
  USER_CREATE_INTEGRATION: { timeout: () => getSeconds('48hr'), value: (requestID: string) => `user_create_integration_${requestID}` },
  USER_CREDITS_REQUESTS: { timeout: () => getSeconds('1hr'), value: (userID: string) => `user_credits_requests_${userID}` },
  USER_CONTACT_DATABASES: { timeout: () => getSeconds('1hr'), value: (userID: string) => `user_contact_databases_${userID}` },
  SMPP_DELIVERY_REPORT: { timeout: () => getSeconds('365d'), value: () => 'smpp_delivery_report' },
  SMPP_DELIVERY_RESPONSE: { timeout: () => getSeconds('2hr'), value: (traceID: string) => traceID },
  SMPP_DELIVERY_ARRAY: { timeout: () => getSeconds('2hr'), value: (traceID: string) => traceID },
  PROJECT: { timeout: () => getSeconds('1hr'), value: (projectID: string) => `project_${projectID}` },
  CAMPAIGN: { timeout: () => getSeconds('48hr'), value: (campaignID: string) => `campaign_sms_${campaignID}` },
  CAMPAIGN_REQUEST: { timeout: () => getSeconds('48hr'), value: (requestID: string) => `sms_request_${requestID}` },
  DRIP_CAMPAIGN_REQUEST: { timeout: () => getSeconds('48hr'), value: (requestID: string) => `drip_sms_request_${requestID}` },
  WEBSITE_CLIENTS: { timeout: () => getSeconds('48hr'), value: () => 'website_clients' },
  WEBSITE_TESTIMONIALS: { timeout: () => getSeconds('48hr'), value: () => 'website_testimonials' },
  CAMPAIGN_DATA: { timeout: () => getSeconds('2.5hr'), value: (traceID: string) => traceID },
  USER_METADATA: { timeout: () => getSeconds('0.5hr'), value: (phone: string) => `user_metadata_${phone}` }
}

export enum redis_client {
  DEFAULT = 0,
  TOUR = 0,
  RATE_LIMIT = 1,
  SESSION = 2,
  CREATE_SMS_CAMPAIGN = 3,
  UPLOAD_CLIENT_CONTACTS = 4,
  UPLOAD_DELIVERY_REPORT = 5,
  ENGAGEMENT_TRACKING = 6,
  CREATE_WHATSAPP_CAMPAIGN = 7,
  CREATE_CAMPAIGN_REPORT = 9,
  IVR_WEBHOOK = 11,
  IVR_WEBHOOK_FINALIZE = 12,
  SMPP_ID_UPDATE = 13,
  SMPP_DELIVERY = 14,
  SMPP_DELIVERY_ARRAY = 16,
  CREATE_REPORT = 9,
  CREATE_DELIVERY_REPORT = 9,
  COMMON_JOB_DATA = 10,
  CREATE_DRIP_SMS_CAMPAIGN = 4,
  CREATE_DRIP_WHATSAPP_CAMPAIGN = 9,
  PROCESS_INTEGRATIONS = 9
}

export const CRON_SCHEDULES_TIME = {
  CREATE_CAMAPAIGN_REPORT: '47.95H',
  UPLOAD_DELIVERY_REPORT: '15m',
  DELIVERY_TIMEOUT: '3m',
  DRIP_CAMPAIGN: '6H'
}

// default canonical method names
export const canonicalMethods = {
  // User
  UPDATE_CLIENT_USER_PASSWORD: 'UPDATE_CLIENT_USER_PASSWORD',
  UPDATE_CLIENT_USER: 'UPDATE_CLIENT_USER',
  UPDATE_CLIENT_USER_AVATAR: 'UPDATE_CLIENT_USER_AVATAR',
  FIND_CLIENT_USER: 'FIND_CLIENT_USER',
  CREATE_DELIVERY_REPORT: 'CREATE_DELIVERY_REPORT',
  AUTHENTICATE_CLIENT_USER: 'AUTHENTICATE_CLIENT_USER',
  FIND_CLIENT_TEMPLATES: 'FIND_CLIENT_TEMPLATES',
  FIND_CLIENT_LINKS: 'FIND_CLIENT_LINKS',
  CREATE_CLIENT_LINK: 'CREATE_CLIENT_LINK',
  FIND_DRIPCRITERIA: 'FIND_DRIPCRITERIA',
  TOGGLE_CLIENT_LINK: 'TOGGLE_CLIENT_LINK',
  CREATE_CLIENT_TEMPLATE: 'CREATE_CLIENT_TEMPLATE',
  EDIT_CLIENT_TEMPLATE: 'EDIT_CLIENT_TEMPLATE',
  TOGGLE_CLIENT_TEMPLATE: 'TOGGLE_CLIENT_TEMPLATE',
  TOGGLE_CLIENT_DATABASE: 'TOGGLE_CLIENT_DATABASE',
  UPDATE_CLIENT_ENGAGEMENT: 'UPDATE_CLIENT_ENGAGEMENT',
  UPDATE_CLIENT_ENGAGEMENT_DEMOGRAPHICS: 'UPDATE_CLIENT_ENGAGEMENT_DEMOGRAPHICS',
  UPDATE_CLIENT_CONTACTS: 'UPDATE_CLIENT_CONTACTS',
  TOGGLE_DRIP_CRITERIA: 'TOGGLE_DRIP_CRITERIA',
  CREATE_DRIPCRITERIA: 'CREATE_DRIPCRITERIA',
  FIND_CLIENT_CREDITS: 'FIND_CLIENT_CREDITS',
  REQUEST_CLIENT_CREDITS: 'REQUEST_CLIENT_CREDITS',
  CANCEL_CLIENT_SCHEDULE: 'CANCEL_CLIENT_SCHEDULE',
  FIND_CLIENT_SCHEDULES: 'FIND_CLIENT_SCHEDULES',
  CREATE_CLIENT_USER_CREDITS: 'CREATE_CLIENT_USER_CREDITS',
  CREATE_CLIENT_CONTACTS_DATABASE: 'CREATE_CLIENT_CONTACTS_DATABASE',
  UPLOAD_CLIENT_CONTACTS: 'UPLOAD_CLIENT_CONTACTS',
  CLIENT_SINGLE_SMS_CAMPAIGN: 'CLIENT_SINGLE_SMS_CAMPAIGN',
  CLIENT_BULK_SMS_CAMPAIGN: 'CLIENT_BULK_SMS_CAMPAIGN',
  CREATE_WHATSAPP_CAMPAIGN: 'CREATE_WHATSAPP_CAMPAIGN',
  CLIENT_DAILY_ANALYSIS: 'CLIENT_DAILY_ANALYSIS',
  CLIENT_FETCH_MASTER_REPORT: 'CLIENT_FETCH_MASTER_REPORT',
  CLIENT_FETCH_CAMPAIGN_REPORT: 'CLIENT_FETCH_CAMPAIGN_REPORT',
  CLIENT_FETCH_PROJECT_REPORT: 'CLIENT_FETCH_PROJECT_REPORT',
  PROCESS_DELIVERY_REPORT: 'PROCESS_DELIVERY_REPORT',
  PROCESS_DELIVERY_RECORD: 'PROCESS_DELIVERY_RECORD',
  PROCESS_IVR_WEBHOOK: 'PROCESS_IVR_WEBHOOK',
  FETCH_TRACKING_SCRIPT: 'FETCH_TRACKING_SCRIPT',
  FETCH_TRACKING_SCRIPT_EXPIRATION: 'FETCH_TRACKING_SCRIPT_EXPIRATION',
  SEND_EMAIL: 'SEND_EMAIL',
  SEND_SMS: 'SEND_SMS',

  // crm integration
  TOGGLE_CRM_INTEGRATION: 'TOGGLE_CRM_INTEGRATION',
  SAVE_CRM_API: 'SAVE_CRM_API',
  FETCH_CRM_API: 'FETCH_CRM_API',

  // Dialogflow
  DIALOGFLOW_AUTHENTICATE: 'DIALOGFLOW_AUTHENTICATE',
  TOGGLE_DEFAULT_SENDER_ID: 'TOGGLE_DEFAULT_SENDER_ID',
  ADD_SENDER_ID: 'ADD_SENDER_ID',

  // Custodian
  CREATE_USER: 'CREATE_USER',
  FIND_USER: 'FIND_USER',
  FIND_CLIENTS_ADMINS: 'FIND_CLIENTS_ADMINS',
  GRANT_USER_ACCESS: 'GRANT_USER_ACCESS',
  AUTHENTICATE_USER: 'AUTHENTICATE_USER',
  CREATE_TESTIMONIAL: 'CREATE_TESTIMONIAL',
  CREATE_NOTICE: 'CREATE_NOTICE',
  CREATE_WEBSITE_CLIENT: 'CREATE_WEBSITE_CLIENT',
  TOGGLE_TESTIMONIAL: 'TOGGLE_TESTIMONIAL',
  TOGGLE_WEBSITE_CLIENT: 'TOGGLE_WEBSITE_CLIENT',
  TOGGLE_NOTICE: 'TOGGLE_NOTICE',
  TOGGLE_MAINTENANCE: 'TOGGLE_MAINTENANCE',
  TOGGLE_ALT_DOMAIN: 'TOGGLE_ALT_DOMAIN',

  // OTP
  FIND_CLIENT_OTP_DASHBOARD_DATA: 'FIND_CLIENT_OTP_DASHBOARD_DATA',
  DOWNLOAD_OTP_REPORT: 'DOWNLOAD_OTP_REPORT',
  REQUEST_OTP: 'REQUEST_OTP',
  OTP_REPORT_REQUST: 'OTP_REPORT_REQUEST',
  // Transactional
  FIND_CLIENT_TRANSACTIONAL_DASHBOARD_DATA: 'FIND_CLIENT_TRANSACTIONAL_DASHBOARD_DATA',
  DOWNLOAD_TRANSACTIONAL_REPORT: 'DOWNLOAD_TRANSACTIONAL_REPORT',
  TRANSACTIONAL_REPORT_REQUST: 'TRANSACTIONAL_REPORT_REQUST',
  // Projects
  FIND_CLIENT_PROJECTS: 'FIND_CLIENT_PROJECTS',
  FIND_PROJECTS: 'FIND_PROJECTS',
  CREATE_CLIENT_PROJECT: 'CREATE_CLIENT_PROJECT',
  CREATE_CLIENT_PROJECT_TYPES: 'CREATE_CLIENT_PROJECT_TYPES',
  FIND_CLIENT_CONTACTS_DATABASES: 'FIND_CLIENT_CONTACTS_DATABASES',
  FIND_CLIENT_CONTACTS: 'FIND_CLIENT_CONTACTS',
  DOWNLOAD_CLIENT_CONTACTS_FILE: 'DOWNLOAD_CLIENT_CONTACTS_FILE',
  APPROVE_CLIENT_CREDITS: 'APPROVE_CLIENT_CREDITS',
  FETCH_CLIENT_TRANSACTIONS: 'FETCH_CLIENT_TRANSACTIONS',
  FETCH_CLIENT_TRANSACTIONS_UNAPPROVED: 'FETCH_CLIENT_TRANSACTIONS_UNAPPROVED',
  UPLOAD_DELIVERY_REPORT: 'UPLOAD_DELIVERY_REPORT',
  UPLOAD_WALKTHROUGH: 'UPLOAD_WALKTHROUGH',
  UPDATE_CLIENT_PROJECT_SENDER_ID: 'UPDATE_CLIENT_PROJECT_SENDER_ID',
  FIND_CLIENT_MASTER_DASHBOARD_DATA: 'FIND_CLIENT_MASTER_DASHBOARD_DATA',
  FIND_CLIENT_PROJECT_DASHBOARD_DATA: 'FIND_CLIENT_PROJECT_DASHBOARD_DATA',
  UPDATE_PROJECT_PHONE: 'UPDATE_PROJECT_PHONE',

  // Website
  FIND_WEBSITE_CLIENTS: 'FIND_WEBSITE_CLIENTS',
  FIND_WEBSITE_TESTIMONIALS: 'FIND_WEBSITE_CLIENTS',
  FIND_WEBSITE_NOTICES: 'FIND_WEBSITE_NOTICES',
  CREATE_WEBSITE_FEEDBACKS: 'CREATE_WEBSITE_FEEDBACKS',
  SET_FEEDBACK_VIEWED: 'SET_FEEDBACK_VIEWED',
  FIND_USER_METADATA: 'FIND_USER_METADATA',

  // Bootstrap
  BOOTSTRAP_SERVER: 'BOOTSTRAP_SERVER',

  // Tracking
  TRACK_EVENT_RECORD: 'TRACK_EVENT_RECORD',
  TRACK_DATA_FETCH: 'TRACK_DATA_FETCH',
  TRACK_UNIQUE_EVENT: 'TRACK_UNIQUE_EVENT',
  TRACK_GET_UNIQUE_EVENT: 'TRACK_GET_UNIQUE_EVENT',
  PROJECT_EVENT_DATA: 'PROJECT_EVENT_DATA',
  TRACK_REPORT_DATA: 'TRACK_REPORT_DATA',
  // Requests
  REQUEST_ID_FETCH: 'REQUEST_ID_FETCH',
  // INTEGRATION
  CREATE_INTEGRATIONS: 'CREATE_INTEGRATIONS',
  UPDATE_INTEGRATIONS: 'UPDATE_INTEGRATIONS',
  TOGGLE_INTEGRATIONS: 'TOGGLE_INTEGRATIONS'
}

// default cron jobs
export const cronJobs = {
  // Campaign
  CREATE_REPORT: {
    name: 'CREATE_REPORT',
    priority: 1,
    delay: 1000,
    lockLifeTime: 1800000,
    lockRenew: 1000,
    maxStalledCount: 1,
    attempts: 4,
    retryProcessDelay: 2000
  },
  CREATE_SMS_CAMPAIGN: {
    name: 'CREATE_SMS_CAMPAIGN',
    priority: 1,
    delay: 1000,
    lockLifeTime: 1800000,
    lockRenew: 1000,
    maxStalledCount: 0,
    attempts: 1,
    retryProcessDelay: 2000
  },
  CREATE_RBM_CAMPAIGN: {
    name: 'CREATE_RBM_CAMPAIGN',
    priority: 1,
    delay: 1000,
    lockLifeTime: 1800000,
    lockRenew: 1000,
    maxStalledCount: 0,
    attempts: 1,
    retryProcessDelay: 2000
  },
  CREATE_WHATSAPP_CAMPAIGN: {
    name: 'CREATE_WHATSAPP_CAMPAIGN',
    priority: 1,
    delay: 1000,
    lockLifeTime: 1800000,
    lockRenew: 1000,
    maxStalledCount: 0,
    attempts: 1,
    retryProcessDelay: 2000
  },
  CREATE_DRIP_WHATSAPP_CAMPAIGN: {
    name: 'CREATE_DRIP_WHATSAPP_CAMPAIGN',
    priority: 1,
    delay: 1000,
    lockLifeTime: 1800000,
    lockRenew: 1000,
    maxStalledCount: 0,
    attempts: 1,
    retryProcessDelay: 2000
  },
  CREATE_DRIP_SMS_CAMPAIGN: {
    name: 'CREATE_DRIP_SMS_CAMPAIGN',
    priority: 1,
    delay: 1000,
    lockLifeTime: 1800000,
    lockRenew: 1000,
    maxStalledCount: 0,
    attempts: 1,
    retryProcessDelay: 2000
  },
  // Contacts
  UPLOAD_CLIENT_CONTACTS: {
    name: 'UPLOAD_CLIENT_CONTACTS',
    priority: 5,
    delay: 1000,
    lockLifeTime: 1800000,
    lockRenew: 1000,
    maxStalledCount: 1,
    attempts: 2,
    retryProcessDelay: 2000
  },
  // Contacts
  IVR_WEBHOOK: {
    name: 'IVR_WEBHOOK',
    priority: 5,
    delay: 1000,
    lockLifeTime: 1800000,
    lockRenew: 1000,
    maxStalledCount: 1,
    attempts: 2,
    retryProcessDelay: 2000
  },
  IVR_WEBHOOK_FINALIZE: {
    name: 'IVR_WEBHOOK_FINALIZE',
    priority: 5,
    delay: 1000,
    lockLifeTime: 1800000,
    lockRenew: 1000,
    maxStalledCount: 1,
    attempts: 2,
    retryProcessDelay: 2000
  },
  // Delivery Report
  UPLOAD_DELIVERY_REPORT: {
    name: 'UPLOAD_DELIVERY_REPORT',
    priority: 10,
    timeout: 25000,
    delay: 180000,
    lockLifeTime: 1800000,
    lockRenew: 1000,
    maxStalledCount: 0,
    attempts: 2,
    retryProcessDelay: 2000
  },
  CREATE_DELIVERY_REPORT: {
    name: 'CREATE_DELIVERY_REPORT',
    priority: 10,
    timeout: 15000,
    delay: 30000,
    lockLifeTime: 1800000,
    lockRenew: 1000,
    maxStalledCount: 0,
    attempts: 2,
    retryProcessDelay: 2000
  },
  // Engagement Tracking 3rd-Party
  ENGAGEMENT_TRACKING: {
    name: 'ENGAGEMENT_TRACKING',
    priority: 1,
    delay: 500,
    lockLifeTime: 1800000,
    lockRenew: 1000,
    maxStalledCount: 1,
    attempts: 2,
    timeout: 120000,
    retryProcessDelay: 2000
  },
  // Campaign Report
  CREATE_CAMPAIGN_REPORT: {
    name: 'CREATE_CAMPAIGN_REPORT',
    priority: 1,
    delay: 1000,
    lockLifeTime: 1800000,
    lockRenew: 1000,
    maxStalledCount: 1,
    attempts: 2,
    retryProcessDelay: 2000
  },
  PROCESS_INTEGRATIONS: {
    name: 'PROCESS_INTEGRATIONS',
    priority: 1,
    delay: 1000,
    lockLifeTime: 1800000,
    lockRenew: 1000,
    maxStalledCount: 1,
    attempts: 1,
    retryProcessDelay: 2000
  }
}

// timeouts
export const timeOuts = {
  clearDeliveryObject: 900000
}

// content types header
export const contentTypes = {
  APPLICATION: {
    JAVA_ARCHIVE: 'application/java-archive',
    EXI_X12: 'application/EDI-X12',
    EDIFACT: 'application/EDIFACT',
    JAVASCRIPT: 'application/javascript',
    OCTET_STREAM: 'application/octet-stream',
    OGG: 'application/ogg',
    PDF: 'application/pdf',
    XHTML_xml: 'application/xhtml+xml',
    SHOCKWAVE: 'application/x-shockwave-flash',
    JSON: 'application/json',
    SPREADSHEET: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    LD_JSON: 'application/ld+json',
    XML: 'application/xml',
    ZIP: 'application/zip',
    URL_ENCODED: 'application/x-www-form-urlencoded'
  },
  AUDIO: {
    MPEG: 'audio/mpeg',
    WMA: 'audio/x-ms-wma',
    REAL_AUDIO: 'audio/vnd.rn-realaudio',
    WAV: 'audio/x-wav'
  },
  IMAGE: {
    GIF: 'image/gif',
    JPEG: 'image/jpeg',
    PNG: 'image/png',
    TIFF: 'image/tiff',
    VND_ICON: 'image/vnd.microsoft.icon',
    X_ICON: 'image/x-icon',
    DJVU: 'image/vnd.djvu',
    SVG_XML: 'image/svg+xml'
  },
  MULTIPART: {
    MIXED: 'multipart/mixed',
    ALTERNATIVE: 'multipart/alternative',
    RELATED: 'multipart/related',
    FORM_DATA: 'multipart/form-data'
  },
  TEXT: {
    CSS: 'text/css',
    CSV: 'text/csv',
    HTML: 'text/html',
    JAVASCRIPT: 'text/javascript',
    PLAIN: 'text/plain',
    XML: 'text/xml'
  },
  VIDEO: {
    MPEG: 'video/mpeg',
    MP4: 'video/mp4',
    QUICKTIME: 'video/quicktime',
    WMV: 'video/x-ms-wmv',
    MSVIDEO: 'video/x-msvideo',
    FLV: 'video/x-flv',
    WEBM: 'video/webm'
  }
}
