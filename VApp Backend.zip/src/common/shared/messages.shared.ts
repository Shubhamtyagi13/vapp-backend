import { GenericObject } from '@interfaces/generic.interface'
import { cache_client, redis_client } from './config.shared'
/*
  logging initilization messages
*/
export const logging = {
  initialised: (level: string): string => `Logging initialized at ${level} level`
}

/*
  redis caching messages
*/
export const caching = {
  error: (error: unknown | string) => `Redis connection error. ${error}`,
  success: (URL: string, port: number | string, config: cache_client, db: redis_client) => `Redis Server connected succesfully. Host: ${URL} Port: ${port} Config: ${config} Database: ${db}`,
  reconnecting: (URL: string, port: number | string, config: cache_client) => `Redis Server failing to reconnect. Host: ${URL} Port: ${port} Config: ${config}`
}

/*
  application initilization messages
*/
export const consortium = {
  initialised: (url: string, port: string | number): string => `API server listening on url => ${url}, port => ${port}`,
  welcome: 'Mainframe API'
}

/*
  mongo initilization messages
*/
export const mongo = {
  error: (error: GenericObject | string) => `MongoDB connection error. ${error}`,
  success: (dbURL: string, dbName: string, port: number | string) => `MongoDB connected succesfully. Host: ${dbURL} Database: ${dbName} Port: ${port}`
}

// Websocket (Scoket.IO)
export const websocketIO = {
  error: (error: GenericObject | string) => `Socket.IO connection error. ${error}`,
  success: (URL: string, port: number | string) => `Socket.IO Server connected succesfully. Host: ${URL} Port: ${port}`,
  connect: (clientID: string) => `New client connected to socket. ClientID: ${clientID}`,
  disconnect: (clientID: string) => `Client disconnected from socket. ClientID: ${clientID}`
}

export const messages = {
  // Common
  COM001: { message: 'server error occured', code: 'COM001' },
  COM002: { message: 'operation forbidden', code: 'COM002' },
  COM003: { message: 'authentication failure', code: 'COM003' },
  COM004: { message: 'invalid content-type, accepted content types: ', code: 'COM004' },
  COM005: { message: 'unable to validate session: ', code: 'COM005' },
  COM006: { message: 'too many requests: ', code: 'COM006' },
  COM007: { message: 'route not found: ', code: 'COM007' },
  COM008: { message: 'image file missing', code: 'COM008' },
  COM009: { message: 'server under maintenance', code: 'COM009' },
  COM010: { message: 'invalid smpp route configuration', code: 'COM010' },

  // System
  SYS001: { message: 'system info fetched successfully', code: 'SYS001' },
  SYS002: { message: 'system username or password incorrect', code: 'SYS002' },
  SYS003: { message: 'system maintenance mode toggled successfully', code: 'SYS003' },
  SYS004: { message: 'system maintenance mode fetched successfully', code: 'SYS004' },

  // JWT
  JWT001: { message: 'jwt verification failed', code: 'JWT001' },
  JWT002: { message: 'jwt not active yet', code: 'JWT002' },
  JWT003: { message: 'jwt token expired', code: 'JWT003' },
  JWT004: { message: 'jwt token missing', code: 'JWT004' },
  JWT005: { message: 'access prohibited', code: 'JWT005' },

  // Mongo Common Errors
  MON001: { message: 'object id cannot be blank', code: 'MON001' },
  MON002: { message: 'query object is invalid', code: 'MON002' },
  MON003: { message: 'update object is invalid', code: 'MON003' },
  MON004: { message: 'sort object is invalid', code: 'MON004' },

  // Dialogflow
  DIAL001: { message: 'dialogflow token fetched successfully', code: 'DIAL001' },
  DIAL002: { message: 'dialogflow token fetching failed', code: 'DIAL002' },

  // tour
  TOUR001: { message: 'tour not found', code: 'TOUR001' },

  // User
  USER001: { message: 'first name cannot be empty', code: 'USER001' },
  USER002: { message: 'last name cannot be empty', code: 'USER002' },
  USER003: { message: 'email cannot be empty', code: 'USER003' },
  USER004: { message: 'company name cannot be empty', code: 'USER004' },
  USER005: { message: 'email can not be outside vapp domain', code: 'USER005' },
  USER006: { message: 'password cannot be empty', code: 'USER006' },
  USER007: { message: 'agent created successfully', code: 'USER007' },
  USER008: { message: 'no users exist in database', code: 'USER008' },
  USER009: { message: "user doesn't exist in database", code: 'USER009' },
  USER010: { message: 'user deleted successfully', code: 'USER010' },
  USER011: { message: 'user updated successfully', code: 'USER011' },
  USER012: { message: 'user already updated', code: 'USER012' },
  USER013: { message: 'client created successfully', code: 'USER013' },
  USER014: { message: 'admin created successfully', code: 'USER014' },
  USER015: { message: 'password changed successfully', code: 'USER015' },
  USER016: { message: 'password incorrect', code: 'USER016' },
  USER017: { message: 'user authenticated successfully', code: 'USER017' },
  USER018: { message: 'old and new passwords cannot be same', code: 'USER018' },
  USER019: { message: 'old password cannot be empty', code: 'USER019' },
  USER020: { message: 'new password cannot be empty', code: 'USER020' },
  USER021: { message: 'old password incorrect', code: 'USER021' },
  USER022: { message: 'user already exists', code: 'USER022' },
  USER023: { message: 'sms cost cannot be empty', code: 'USER023' },
  USER024: { message: 'sms cost can only be numbers', code: 'USER024' },
  USER025: { message: 'user profile fetched successfully', code: 'USER025' },
  USER026: { message: 'user image file missing', code: 'USER026' },
  USER027: { message: 'invalid image format', code: 'USER027' },
  USER028: { message: 'user profile updated successfully', code: 'USER028' },
  USER029: { message: 'sms sender id cannot be empty', code: 'USER029' },
  USER030: { message: 'sms sender id must be 6 characters', code: 'USER030' },
  USER031: { message: 'sms sender id must contain only alphabets', code: 'USER031' },
  USER032: { message: 'user fetched successfully', code: 'USER032' },
  USER033: { message: 'users fetched successfully', code: 'USER033' },
  USER034: { message: 'users access changed successfully', code: 'USER034' },
  USER035: { message: 'user not activated', code: 'USER035' },
  USER037: { message: 'user token refreshed successfully', code: 'USER037' },
  USER038: { message: "user doesn't have a valid correspondance or contact", code: 'USER038' },
  USER039: { message: 'user password reset initiated successfully', code: 'USER039' },
  USER040: { message: 'expiry code has expired', code: 'USER040' },
  USER041: { message: 'reset code is invalid', code: 'USER041' },
  USER042: { message: 'new password sent successfully', code: 'USER042' },
  USER043: { message: 'user logged out successfully', code: 'USER043' },
  USER044: { message: 'error logging out user', code: 'USER044' },
  USER045: { message: 'senderID not present for user', code: 'USER045' },
  USER046: { message: 'users senderID changed successfully', code: 'USER046' },
  USER047: { message: 'domain preference changed successfully', code: 'USER047' },
  USER048: { message: 'CRM Integration preference changed successfully', code: 'USER048' },
  USER049: { message: 'Api for CRM Integration saved', code: 'USER049' },
  USER050: { message: 'Crm Api fetched successfully', code: 'USER050' },
  USER051: { message: 'No Crm for the user', code: 'USER051' },
  USER052: { message: 'senderID list updated successfully', code: 'USER052' },

  // Credits
  CRE001: { message: 'no sms object found for the client', code: 'CRE001' },
  CRE002: { message: 'you can only view your own sms record', code: 'CRE002' },
  CRE003: { message: 'sms object found successfully', code: 'CRE003' },
  CRE004: { message: 'client id cannot be empty', code: 'CRE004' },
  CRE005: { message: 'sms object already present', code: 'CRE005' },
  CRE006: { message: 'client name cannot be empty', code: 'CRE006' },
  CRE007: { message: 'sms credits added successfully', code: 'CRE007' },
  CRE008: { message: 'sms count cannot be empty', code: 'CRE008' },
  CRE009: { message: 'low sms credits, please recharge', code: 'CRE009' },
  CRE010: { message: 'credits object not found for client', code: 'CRE010' },
  CRE011: { message: 'credits update failed', code: 'CRE011' },
  CRE012: { message: 'credits requested successfully', code: 'CRE012' },
  CRE013: { message: 'credit request approved successfully', code: 'CRE013' },
  CRE014: { message: 'credits can only contain digits', code: 'CRE014' },
  CRE015: { message: "credit request doesn't exist in database", code: 'CRE015' },
  CRE016: { message: 'credit request has already been approved', code: 'CRE016' },
  CRE017: { message: 'transactions fetched successfully', code: 'CRE017' },

  // Requests
  REQ001: { message: 'request update failed', code: 'REQ001' },
  REQ002: { message: "request doesn't exist in database", code: 'REQ002' },
  REQ003: { message: 'requests save failed', code: 'REQ003' },

  // Reports
  REP001: { message: 'master report fetched successfully', code: 'REP001' },
  REP002: { message: 'project report fetched successfully', code: 'REP002' },
  REP003: { message: 'no requests found', code: 'REP003' },
  REP004: { message: 'unable to update request object', code: 'REP004' },
  REP005: { message: 'campaign report fetched successfully', code: 'REP005' },
  REP006: { message: 'campaign delivery report fetched successfully', code: 'REP006' },
  REP007: { message: 'unable to create campaign delivery report', code: 'REP007' },

  // Projects
  PROJ001: { message: 'project name cannot be empty', code: 'PROJ001' },
  PROJ002: { message: 'client id cannot be empty', code: 'PROJ002' },
  PROJ003: { message: 'client name cannot be empty', code: 'PROJ003' },
  PROJ004: { message: 'possession month cannot be empty', code: 'PROJ004' },
  PROJ005: { message: 'possession year cannot be empty', code: 'PROJ005' },
  PROJ006: { message: 'project image file missing', code: 'PROJ006' },
  PROJ007: { message: 'city cannot be empty', code: 'PROJ007' },
  PROJ008: { message: 'country cannot be empty', code: 'PROJ008' },
  PROJ009: { message: 'latitude cannot be empty', code: 'PROJ009' },
  PROJ010: { message: 'longitude cannot be empty', code: 'PROJ010' },
  PROJ011: { message: 'postal code cannot be empty', code: 'PROJ011' },
  PROJ012: { message: 'state cannot be empty', code: 'PROJ012' },
  PROJ013: { message: 'flat, house, floor, building cannot be empty', code: 'PROJ013' },
  PROJ014: { message: 'colony, street, locality cannot be empty', code: 'PROJ014' },
  PROJ015: { message: 'project created successfully', code: 'PROJ015' },
  PROJ016: { message: 'latitude can only contain digits', code: 'PROJ016' },
  PROJ017: { message: 'longitude can only contain digits', code: 'PROJ017' },
  PROJ018: { message: 'postal code can only contain digits', code: 'PROJ018' },
  PROJ019: { message: "project doesn't exist in database", code: 'PROJ019' },
  PROJ020: { message: 'project sub-type payload is invalid', code: 'PROJ020' },
  PROJ021: { message: 'project updated successfully', code: 'PROJ021' },
  PROJ022: { message: 'project id cannot be empty', code: 'PROJ022' },
  PROJ023: { message: 'walkthrough uploaded successfully', code: 'PROJ023' },
  PROJ024: { message: 'project walkthrough missing', code: 'PROJ024' },
  PROJ025: { message: 'project walkthrough already added', code: 'PROJ025' },
  PROJ026: { message: 'no generic projects found', code: 'PROJ026' },
  PROJ027: { message: 'projects fetched successfully', code: 'PROJ027' },
  PROJ028: { message: 'possession month can only contain digits', code: 'PROJ028' },
  PROJ029: { message: 'possession year can only contain digits', code: 'PROJ029' },
  PROJ030: { message: 'possession month is invalid', code: 'PROJ030' },
  PROJ031: { message: 'possession year is invalid', code: 'PROJ031' },
  PROJ032: { message: 'invalid image format', code: 'PROJ032' },
  PROJ033: { message: 'no projects found', code: 'PROJ033' },
  PROJ034: { message: 'rera id cannot be empty', code: 'PROJ034' },
  PROJ035: { message: 'phone number cannot be empty', code: 'PROJ035' },
  PROJ036: { message: 'phone number can only contain digits', code: 'PROJ036' },
  PROJ037: { message: 'phone number should be 10 digits only', code: 'PROJ037' },
  PROJ038: { message: 'invalid walkthrough format', code: 'PROJ038' },
  PROJ039: { message: 'sender id cannot be empty', code: 'PROJ039' },
  PROJ040: { message: 'sms sender id must be 6 characters', code: 'PROJ040' },
  PROJ041: { message: 'sms sender id must contain only alphabets', code: 'PROJ041' },
  PROJ042: { message: 'project update failed', code: 'PROJ042' },
  PROJ043: { message: 'request and params client id is not same', code: 'PROJ043' },
  PROJ044: { message: 'project contact updated successfully', code: 'PROJ044' },
  PROJ045: { message: 'project brochure updated successfully', code: 'PROJ045' },

  // Campaign
  CAM001: { message: 'user id cannot be empty', code: 'CAM001' },
  CAM002: { message: "project doesn't exist in database", code: 'CAM002' },
  CAM003: { message: "user doesn't exist in database", code: 'CAM003' },
  CAM004: { message: "project isin't active", code: 'CAM004' },
  CAM005: { message: "project isin't visible", code: 'CAM005' },
  CAM006: { message: 'first name cannot be empty', code: 'CAM006' },
  CAM007: { message: 'last name cannot be empty', code: 'CAM007' },
  CAM008: { message: 'phone number cannot be empty', code: 'CAM008' },
  CAM009: { message: 'phone number can only contain digits', code: 'CAM009' },
  CAM010: { message: 'phone number should be 10 digits only', code: 'CAM010' },
  CAM011: { message: 'campaign created successfully', code: 'CAM011' },
  CAM012: { message: 'campaign request not found', code: 'CAM012' },
  CAM013: { message: 'campaign request id missing', code: 'CAM013' },
  CAM014: { message: 'duplicate walkhthrough request for same number', code: 'CAM014' },
  CAM015: { message: 'message cannot be empty', code: 'CAM015' },
  CAM016: { message: 'engagement time cannot be empty', code: 'CAM016' },
  CAM017: { message: "request doesn't exist in database", code: 'CAM017' },
  CAM018: { message: 'campaign engagement added successfully', code: 'CAM018' },
  CAM019: { message: 'campaign engagement adding failed', code: 'CAM019' },
  CAM021: { message: 'campaign request found successfully', code: 'CAM021' },
  CAM022: { message: 'request id cannot be empty', code: 'CAM022' },
  CAM023: { message: 'sms data cannot be empty', code: 'CAM023' },
  CAM024: { message: 'campaign engagement job created successfully', code: 'CAM024' },
  CAM025: { message: 'campaign created successfully', code: 'CAM025' },
  CAM026: { message: 'project id cannot be empty', code: 'CAM026' },
  CAM027: { message: 'sms count cannot be empty', code: 'CAM027' },
  CAM028: { message: 'sms count can only contain digits', code: 'CAM028' },
  CAM029: { message: 'error saving map request', code: 'CAM029' },
  CAM030: { message: 'whatsapp bulk request submitted successfully', code: 'CAM030' },
  CAM031: { message: 'campaign update failed', code: 'CAM031' },
  CAM032: { message: 'unable to get time to live for campaign', code: 'CAM032' },
  CAM033: { message: 'sms template id cannot be empty', code: 'CAM033' },
  CAM034: { message: 'sms database id cannot be empty', code: 'CAM034' },
  CAM035: { message: "template doesn't exist in database", code: 'CAM035' },
  CAM036: { message: "sms database doesn't exist in database", code: 'CAM036' },
  CAM037: { message: 'daily analysis fetched successfully', code: 'CAM037' },
  CAM038: { message: 'whatsapp campaign created successfully', code: 'CAM038' },
  CAM039: { message: 'whatsapp campaign failed', code: 'CAM039' },
  CAM040: { message: "website url can't be empty for re-direction", code: 'CAM040' },
  CAM041: { message: "content link doesn't exist in database", code: 'CAM041' },
  CAM042: { message: 'database contains more than 1000 contacts', code: 'CAM042' },
  CAM043: { message: 'campaign not found', code: 'CAM043' },
  CAM044: { message: 'campaign report data not found', code: 'CAM044' },
  CAM045: { message: 'unable to fetch demographics', code: 'CAM045' },
  CAM046: { message: 'campaign delivery report data not found', code: 'CAM046' },
  CAM047: { message: 'campaign data fetched successfully', code: 'CAM047' },
  CAM048: { message: 'selected template is a dynamic template', code: 'CAM048' },
  CAM049: { message: "can't send dynamic  campaign without a template", code: 'CAM049' },
  CAM050: { message: "selected template doesn't support dynamic templating", code: 'CAM050' },
  CAM051: { message: 'selected template can not be used with a non-tracking campaign', code: 'CAM051' },
  CAM052: { message: 'selected template is not a tracking template', code: 'CAM052' },
  CAM053: { message: 'problem in delivery updload cron', code: 'CAM053' },
  CAM054: { message: 'campaign contacts exceed the max limit', code: 'CAM054' },

  // Templates
  TEM001: { message: 'templates fetched successfully', code: 'TEM001' },
  TEM002: { message: 'no templates found', code: 'TEM002' },
  TEM003: { message: 'template name cannot be empty', code: 'TEM003' },
  TEM004: { message: 'template text cannot be empty', code: 'TEM004' },
  TEM005: { message: 'template created successfully', code: 'TEM005' },
  TEM006: { message: 'template updated successfully', code: 'TEM006' },
  TEM007: { message: 'template update failed', code: 'TEM007' },
  TEM008: { message: 'registered template id missing', code: 'TEM008' },

  // Links
  LINK001: { message: 'links fetched successfully', code: 'LINK001' },
  LINK002: { message: 'no links found', code: 'LINK002' },
  LINK003: { message: 'link name cannot be empty', code: 'LINK003' },
  LINK004: { message: 'link text cannot be empty', code: 'LINK004' },
  LINK005: { message: 'link created successfully', code: 'LINK005' },
  LINK006: { message: 'link updated successfully', code: 'LINK006' },
  LINK007: { message: 'link update failed', code: 'LINK007' },

  // Interactions
  INT001: { message: 'unable to increment project whatsapp clicks', code: 'INT001' },
  INT002: { message: 'unable to increment dashboard whatsapp clicks', code: 'INT002' },
  INT003: { message: 'unable to increment campaign whatsapp clicks', code: 'INT002' },
  INT004: { message: 'unable to set whatsapp interaction in request', code: 'INT004' },
  INT005: { message: 'processed whatsapp interaction for request', code: 'INT005' },
  INT006: { message: 'processed chatbot interaction for request', code: 'INT006' },
  INT007: { message: 'processed brochure interaction for request', code: 'INT007' },
  INT008: { message: 'unable to get time to live for campaign', code: 'INT008' },
  INT009: { message: 'request id is missing for event', code: 'INT009' },
  INT010: { message: 'engagement id is missing for event', code: 'INT010' },
  INT011: { message: "request doesn't exist in database", code: 'INT011' },
  INT012: { message: 'engagement time is missing for event', code: 'INT012' },
  INT013: { message: 'engagement time is invalid', code: 'INT013' },
  INT014: { message: 'unable to update engagement time in request', code: 'INT014' },
  INT015: { message: 'unable to update engagement time in project', code: 'INT015' },
  INT016: { message: 'unable to update engagement time in campaign', code: 'INT016' },
  INT017: { message: 'unable to update engagement time in dashboard', code: 'INT017' },
  INT018: { message: 'unable to update engagement time in dashboard trends', code: 'INT018' },
  INT019: { message: 'unable to update engagement time in project trends', code: 'INT019' },
  INT020: { message: 'unable to update engagement time in template', code: 'INT020' },
  INT021: { message: 'unable to update engagement time in contact database', code: 'INT021' },
  INT022: { message: 'processed engagement for request', code: 'INT022' },
  INT023: { message: 'engagement maximum cap reached', code: 'INT023' },

  // Dashboard
  DAS001: { message: 'dashboard update failed', code: 'DAS001' },
  DAS002: { message: 'master dashboard data fetched successfully', code: 'DAS002' },
  DAS003: { message: 'project dashboard data fetched successfully', code: 'DAS003' },
  DAS004: { message: 'could not find request for the given campaign ID', code: 'DAS004' },
  // Schedules
  SCHE001: { message: 'schedules fetched succesfully', code: 'SCHE001' },
  SCHE002: { message: 'no schedules found in database', code: 'SCHE002' },
  SCHE003: { message: 'schedule deleted successfully', code: 'SCHE003' },
  SCHE004: { message: 'schedule not found', code: 'SCHE004' },

  // Drip Criteria
  DPCRI001: { message: 'Drip Criteria data cannot be empty', code: 'DPCRI001' },
  DPCRI003: { message: 'Drip Criteria fetched succesfully', code: 'DPCRI003' },
  DPCRI004: { message: 'no Drip Criteria found in database', code: 'DPCRI004' },
  DPCRI005: { message: 'Drip Criteria created succesfully', code: 'DPCRI005' },
  DPCRI006: { message: 'Drip Criteria updated successfully', code: 'DPCRI006' },

  // Contacts
  CONT001: { message: 'contacts data cannot be empty', code: 'CONT001' },
  CONT002: { message: 'contacts upload request submitted succesfully', code: 'CONT002' },
  CONT003: { message: 'contacts fetched succesfully', code: 'CONT003' },
  CONT004: { message: 'no contacts found in database', code: 'CONT004' },
  CONT005: { message: 'regions fetched succesfully', code: 'CONT005' },
  CONT006: { message: 'contact database name cannot be empty', code: 'CONT006' },
  CONT007: { message: 'contact upload failed', code: 'CONT007' },
  CONT008: { message: 'contact databases fetched successfully', code: 'CONT008' },
  CONT009: { message: 'no contacts databases in database', code: 'CONT009' },
  CONT010: { message: 'contact database update failed', code: 'CONT010' },
  CONT011: { message: 'contact database updated successfully', code: 'CONT011' },
  CONT012: { message: 'contacts file fetched successfully', code: 'CONT012' },

  // Reports
  REPO001: { message: 'delivery report submitted successfully', code: 'REPO001' },
  REPO002: { message: 'delivery report campaign id must be digits', code: 'REPO002' },
  REPO003: { message: "campaign doesn'\t exist in database", code: 'REPO003' },
  REPO004: { message: 'report file missing', code: 'REPO004' },
  REPO005: { message: 'unable to get response from getway', code: 'REPO005' },
  REPO006: { message: 'getway cookie response in invalid', code: 'REPO006' },

  // IVR
  IVR001: { message: 'ivr secret mismatch', code: 'IVR001' },
  IVR002: { message: 'ivr processed successfully', code: 'IVR002' },
  IVR003: { message: 'no campaign found for ivr webhook', code: 'IVR003' },
  IVR004: { message: 'no requests found for ivr webhook', code: 'IVR004' },
  IVR005: { message: 'ivr report fetched succesfully', code: 'IVR005' },
  IVR006: { message: 'unable to fetch ivr report', code: 'IVR006' },
  IVR007: { message: 'ivr report submitted successfully', code: 'IVR007' },
  IVR008: { message: 'ivr data fetched successfully', code: 'IVR008' },
  IVR009: { message: 'unable to fetch ivr data', code: 'IVR009' },

  // Website
  WEB001: { message: 'website clients fetched successfully', code: 'WEB001' },
  WEB002: { message: 'no webiste clients in database', code: 'WEB002' },
  WEB003: { message: 'website testimonials fetched successfully', code: 'WEB003' },
  WEB004: { message: 'no webiste testimonials in database', code: 'WEB004' },
  WEB005: { message: 'name cannot be empty', code: 'WEB005' },
  WEB006: { message: 'text cannot be empty', code: 'WEB006' },
  WEB007: { message: 'image cannot be empty', code: 'WEB007' },
  WEB008: { message: 'link cannot be empty', code: 'WEB008' },
  WEB009: { message: 'testimonial created successfully', code: 'WEB009' },
  WEB010: { message: 'testimonial image is missing', code: 'WEB010' },
  WEB011: { message: 'client image is missing', code: 'WEB011' },
  WEB012: { message: 'client created successfully', code: 'WEB012' },
  WEB013: { message: 'client toggled successfully', code: 'WEB013' },
  WEB014: { message: 'testimonial toggled successfully', code: 'WEB014' },
  WEB015: { message: "client doesn't exists in database", code: 'WEB015' },
  WEB016: { message: "testimonial doesn't exists in database", code: 'WEB016' },
  WEB017: { message: 'notice created successfully', code: 'WEB017' },
  WEB018: { message: 'notice toggled successfully', code: 'WEB018' },
  WEB019: { message: "notice doesn't exists in database", code: 'WEB019' },
  WEB020: { message: 'website notices fetched successfully', code: 'WEB020' },
  WEB021: { message: 'feedback created successfully', code: 'WEB021' },
  WEB022: { message: 'feedbacks fetched successfully', code: 'WEB022' },
  WEB023: { message: 'email sent successfully', code: 'WEB023' },
  WEB024: { message: 'firebase data fetched successfully', code: 'WEB024' },
  WEB025: { message: 'feedback marked as viewed', code: 'WEB025' },
  WEB026: { message: 'metadata uploaded successfully', code: 'WEB026' },
  WEB027: { message: 'metadata fetched successfully', code: 'WEB027' },
  WEB028: { message: 'invalid api key', code: 'WEB028' },

  // Bootstrap
  BOOT001: { message: 'admin created successfully', code: 'BOOT001' },
  BOOT002: { message: 'admin already exists in database', code: 'BOOT002' },

  // Tracking
  TRACK001: { message: 'session expiration time fetched successsfully', code: 'TRACK001' },
  TRACK002: { message: 'session has expired', code: 'TRACK002' },
  TRACK003: { message: 'invalid api key', code: 'TRACK003' },
  TRACK004: { message: 'request tracking recorded successsfully', code: 'TRACK004' },
  TRACK005: { message: 'request tracking script fetched successsfully', code: 'TRACK005' },
  TRACK006: { message: 'event successfully recorded', code: 'TRACK006' },
  TRACK007: { message: 'tracking event data fetched successfully', code: 'TRACK007' },
  TRACK008: { message: 'tracking unique event data fetched successfully', code: 'TRACK008' },
  TRACK009: { message: 'tracking report data fetched successfully', code: 'TRACK009' },

  // Analytics
  ANALY001: { message: 'analytics fetched successfully', code: 'ANALY001' },

  /*
  validations
 */
  VAL001: { message: 'invalid number', code: 'VAL001' },
  VAL002: { message: 'invalid boolean', code: 'VAL002' },
  VAL003: { message: 'invalid type', code: 'VAL003' },
  VAL004: { message: 'invalid string', code: 'VAL004' },
  VAL005: { message: 'invalid mongo object id', code: 'VAL005' },
  /*
  transactional
  */
  TRANS001: { message: 'transactional sms requested successfully', code: 'TRANS001' },
  TRANS002: { message: 'transactional sms feature access is missing', code: 'TRANS002' },
  TRANS003: { message: 'invalid api key', code: 'TRANS003' },
  TRANS004: { message: 'transactional dashboard data fetched successfully', code: 'TRANS004' },
  TRANS005: { message: 'transactional report data fetched successfully', code: 'TRANS005' },
  TRANS006: { message: 'transactional report data not found', code: 'TRANS006' },
  TRANS007: { message: 'date range tenure can be a maximum of 90 days', code: 'TRANS007' },
  TRANS008: { message: 'transactional report requested successfully', code: 'TRANS008' },
  TRANS009: { message: 'transactional template not found', code: 'TRANS009' },
  TRANS010: { message: 'provided template is not a transactional template', code: 'TRANS010' },
  TRANS011: { message: 'dlt registerated template id missing from transactional remplate', code: 'TRANS011' },
  TRANS012: { message: 'transactional template has no sender id assigned', code: 'TRANS012' },
  /*
  otp
  */
  OTP001: { message: 'otp requested successsfully', code: 'OTP001' },
  OTP002: { message: 'otp not found or otp has expired', code: 'OTP002' },
  OTP003: { message: 'invalid api key', code: 'OTP003' },
  OTP004: { message: 'otp request failed', code: 'OTP004' },
  OTP005: { message: 'otp verified successsfully', code: 'OTP005' },
  OTP006: { message: 'otp verification failed', code: 'OTP006' },
  OTP007: { message: 'otp dashboard data fetched successfully', code: 'OTP007' },
  OTP008: { message: 'otp feature access missing', code: 'OTP008' },
  OTP009: { message: 'otp verification feature access missing', code: 'OTP009' },
  OTP010: { message: 'otp template not found', code: 'OTP010' },
  OTP011: { message: 'provided template is not an otp template', code: 'OTP011' },
  OTP012: { message: 'dlt registerated template id missing from otp remplate', code: 'OTP012' },
  OTP013: { message: 'date range tenure can be a maximum of 90 days', code: 'OTP013' },
  OTP014: { message: 'otp report requested successfully', code: 'OTP014' },
  OTP015: { message: 'otp report data fetched successfully', code: 'OTP015' },
  OTP016: { message: 'otp report data not found', code: 'OTP016' },
  OTP017: { message: 'otp template has no sender id assigned', code: 'OTP017' },

  /* Integrations */
  ING001: { message: 'integrations object created successfully', code: 'ING001' },
  ING002: { message: 'integrations object already present with the same key', code: 'ING002' },
  ING003: { message: 'unable to verify credentials for integration', code: 'ING003' },
  ING004: { message: 'integrations fetched successfully', code: 'ING004' },
  ING005: { message: 'integration toggled successfully', code: 'ING005' },
  ING006: { message: "integration doesn't exists in database", code: 'ING006' }
}
