import { PasswordResetAlert } from '@interfaces/alert.interface'

export const getSMSPayloadForPasswordReset = (templateData: PasswordResetAlert): string => {
  if (templateData.reset) {
    return `Hello ${templateData.client},
  V-App password reset code is ${templateData.code}
    Team V-APP`
  }
    return `Hello ${templateData.client},
    V-App password reset successfully. Your new password is ${templateData.code}
      Team V-APP`
}
