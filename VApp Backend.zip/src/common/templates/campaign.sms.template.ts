import { variables } from '@config'
import { CampaignInitialAlert } from '@interfaces/alert.interface'
import { getEnvironmentVariable } from '@utils/platform.util'

export const getSMSPayloadForInitialCampaign = (templateData: CampaignInitialAlert): string => `Hello ${templateData.client},
    A new campaign has been scheduled for project ${templateData.project}.
    Visit https://${getEnvironmentVariable(variables.EMAIL_DOMAIN.name)} for more details.
    Team V-APP`
