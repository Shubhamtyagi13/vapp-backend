import { CreditsApprovedAlert } from '@interfaces/alert.interface'

export const getSMSPayloadForTransactionApproved = (templateData: CreditsApprovedAlert): string => `Hello ${templateData.client},
    Your transaction for ${templateData.credits} credits, requested on ${templateData.date} at ${templateData.time} has been approved successfully.
    Team V-APP`
