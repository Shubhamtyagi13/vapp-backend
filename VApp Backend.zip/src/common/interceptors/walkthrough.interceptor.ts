import { variables } from '@config'
import { FileFieldsInterceptor } from '@nestjs/platform-express'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request } from 'express'
import fs from 'fs'
import { diskStorage, FileFilterCallback } from 'multer'
import path from 'path'

export const WalkthroughInterceptor = () =>
  FileFieldsInterceptor([{ name: 'walkthrough', maxCount: 1 }], {
    storage: diskStorage({
      destination: (request: Request, file: Express.Multer.File, callback: (error: Error | null, filename: string) => void) => {
        const filePath = `./${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.WALKTHROUGH_DIRECTORY.name)}/${
          request.params.projectID
        }`
        if (!fs.existsSync(filePath)) {
          fs.mkdirSync(filePath)
        }
        request.filePath = filePath
        callback(null, filePath)
      },
      filename: (request: Request, file: Express.Multer.File, callback: (error: Error | null, filename: string) => void) => {
        const fileName = `${request.params.projectID}_${Date.now()}${path.extname(file.originalname)}`
        request.fileName = fileName
        callback(null, fileName)
      }
    }),
    fileFilter: (request: Request, file: Express.Multer.File, callback: FileFilterCallback) => {
      const fileTypes = /zip/
      const mimetype = fileTypes.test(file.mimetype)
      const extname = fileTypes.test(path.extname(file.originalname).toLowerCase())
      if (mimetype && extname) {
        return callback(null, true)
      }
      return callback(new Error('invalid format'))
    }
  })
