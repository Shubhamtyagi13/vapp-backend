import { constants } from '@config'
import { CallHandler, ExecutionContext, Injectable, NestInterceptor } from '@nestjs/common'
import { VappLogger } from '@services/logger.service'
import { Request } from 'express'
import _ from 'lodash'
import { Observable } from 'rxjs'

/*
Global API Interceptor
Usage => tracking the overall time consumption for an api
*/
@Injectable()
export class APIInterceptor implements NestInterceptor {
  constructor(private logger: VappLogger) { }

  intercept(context: ExecutionContext, next: CallHandler): Observable<any> {
    const request = <Request>context.switchToHttp().getRequest()
    const response = context.switchToHttp().getResponse()
    const now = Date.now()
    constants.HEADERS.forEach((header: { [key: string]: string }) => {
      try {
        response.header(_.keys(header)[0], _.values(header)[0])
      } catch (error) { }
    })
    return next.handle()
  }
}
