import { FileInterceptor } from '@nestjs/platform-express'
import { Request } from 'express'
import { FileFilterCallback, memoryStorage } from 'multer'
import path from 'path'

export const ReportInterceptor = () =>
  FileInterceptor('report', {
    storage: memoryStorage(),
    fileFilter: (request: Request, file: Express.Multer.File, callback: FileFilterCallback) => {
      const fileTypes = /csv/
      const mimetype = fileTypes.test(file.mimetype)
      const extname = fileTypes.test(path.extname(file.originalname).toLowerCase())
      if (mimetype && extname) {
        request.fileName = path.parse(file.originalname).name
        return callback(null, true)
      }
      return callback(new Error('invalid format'))
    }
  })
