import { variables } from '@config'
import { FileFieldsInterceptor } from '@nestjs/platform-express'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request } from 'express'
import fs from 'fs'
import _ from 'lodash'
import { diskStorage, FileFilterCallback } from 'multer'
import path from 'path'

export const WhatsAppInterceptor = () =>
  FileFieldsInterceptor([{ name: 'files', maxCount: 30 }], {
    storage: diskStorage({
      destination: (request: Request, file: Express.Multer.File, callback: (error: Error | null, filename: string) => void) => {
        const filePath = `./${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.WHATSAPP_DIRECTORY.name)}/${
          request.params.projectID
        }`
        if (!fs.existsSync(filePath)) {
          fs.mkdirSync(filePath, { recursive: true })
        }
        if (_.isNil(request.whatsappFiles)) {
          request.whatsappFiles = [] as any
        }
        request.whatsappFiles.push({ filePath, fileName: '', originalFileName: '' })

        callback(null, filePath)
      },
      filename: (request: Request, file: Express.Multer.File, callback: (error: Error | null, filename: string) => void) => {
        const fileName = `${request.params.projectID}_${Date.now()}${path.extname(file.originalname)}`
        if (_.isNil(request.whatsappFiles)) {
          request.whatsappFiles = [] as any
        }
        request.whatsappFiles[request.whatsappFiles.length - 1].fileName = fileName
        request.whatsappFiles[request.whatsappFiles.length - 1].originalFileName = file.originalname
        request.whatsappFiles[request.whatsappFiles.length - 1].filePath = `${request.whatsappFiles[request.whatsappFiles.length - 1].filePath}/${fileName}`
        callback(null, fileName)
      }
    }),
    fileFilter: (request: Request, file: Express.Multer.File, callback: FileFilterCallback) => {
      const fileTypes = /jpg|jpeg|png|gif|JPG|JPEG|JFIF|BMP|SVG|jfif|bmp|svg/
      const mimetype = fileTypes.test(file.mimetype)
      const extname = fileTypes.test(path.extname(file.originalname).toLowerCase())
      if (!mimetype || !extname) {
        request.allImages = false
      }
      return callback(null, true)
    }
  })
