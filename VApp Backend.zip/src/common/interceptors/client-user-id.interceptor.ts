import { constants } from '@config'
import { APIResponse } from '@interfaces/response.interface'
import { messages } from '@messages'
import { BadRequestException, CallHandler, ExecutionContext, HttpStatus, Injectable, NestInterceptor } from '@nestjs/common'
import { Reflector } from '@nestjs/core'
import { getAPIResponse } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import mongoose from 'mongoose'
import { Observable } from 'rxjs'

@Injectable()
export class ClientUserIDTransformInterceptor<T> implements NestInterceptor<T, Response<T>> {
  constructor(private reflector: Reflector) {}

  intercept(context: ExecutionContext, next: CallHandler): Observable<Response<T>> {
    const request = <Request>context.switchToHttp().getRequest()
    const no_client_override = this.reflector.get<boolean>('no_override', context.getHandler())
    const clientUserID = request.body.clientUserID || request.params.clientUserID || request.query.clientUserID
    if (!no_client_override) {
      if (!_.isNil(clientUserID)) {
        if (!_.isNil(request.user) && _.eq(request.user.userType, constants.USER_TYPES.admin)) {
          if (!mongoose.Types.ObjectId.isValid(clientUserID)) {
            throw new BadRequestException(<APIResponse>getAPIResponse(messages.VAL005.code, request.VAPP_CONTEXT.traceID, HttpStatus.BAD_REQUEST, { clientUserID }))
          }
          request.user._id = clientUserID
        }
      }
    }
    return next.handle()
  }
}
