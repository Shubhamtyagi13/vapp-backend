import { image_intercept, variables } from '@config'
import { FileFieldsInterceptor } from '@nestjs/platform-express'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request } from 'express'
import fs from 'fs'
import { diskStorage, FileFilterCallback } from 'multer'
import path from 'path'

export const ImageInterceptor = (image_type: image_intercept = image_intercept.DEFAULT) =>
  FileFieldsInterceptor([{ name: 'image', maxCount: 1 }], {
    storage: diskStorage({
      destination: (request: Request, file: Express.Multer.File, callback: (error: Error | null, filename: string) => void) => {
        const filePath = switchFilePath(image_type, request)
        if (!fs.existsSync(filePath)) {
          fs.mkdirSync(filePath)
        }
        request.filePath = filePath
        callback(null, filePath)
      },
      filename: (request: Request, file: Express.Multer.File, callback: (error: Error | null, filename: string) => void) => {
        const fileName = switchFileName(image_type, request, file)
        request.fileName = fileName
        callback(null, fileName)
      },
    }),
    fileFilter: (request: Request, file: Express.Multer.File, callback: FileFilterCallback) => {
      const fileTypes = /jpg|jpeg|png|gif|JPG|JPEG|JFIF|BMP|SVG|jfif|bmp|svg/
      const mimetype = fileTypes.test(file.mimetype)
      const extname = fileTypes.test(path.extname(file.originalname).toLowerCase())
      if (mimetype && extname) {
        return callback(null, true)
      }
      return callback(new Error('invalid format'))
    },
  })

const switchFilePath = (image_type: image_intercept = image_intercept.DEFAULT, request: Request) => {
  let type: string
  switch (image_type) {
    case image_intercept.DEFAULT:
      type = `./${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.STATIC_DIRECTORY.name)}/${request.user._id}`
      break
    case image_intercept.PROJECT:
      type = `./${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.STATIC_DIRECTORY.name)}/${request.user._id}`
      break
    case image_intercept.TESTIMONIAL:
      type = `./${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.STATIC_DIRECTORY.name)}/${getEnvironmentVariable(
        variables.TESTIMONIAL_DIRECTORY.name,
      )}`
      break
    case image_intercept.CLIENT:
      type = `./${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.STATIC_DIRECTORY.name)}/${getEnvironmentVariable(
        variables.CLIENT_DIRECTORY.name,
      )}`
      break
    default:
      type = `./${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.STATIC_DIRECTORY.name)}/${request.user._id}`
      break
  }
  return type
}

const switchFileName = (image_type: image_intercept = image_intercept.DEFAULT, request: Request, file: Express.Multer.File) => {
  let name: string
  switch (image_type) {
    case image_intercept.DEFAULT:
      name = `${request.user._id}_${Date.now()}${path.extname(file.originalname)}`
      break
    case image_intercept.PROJECT:
      name = `${request.user._id}_${Date.now()}${path.extname(file.originalname)}`
      break
    case image_intercept.TESTIMONIAL:
      name = `${Date.now()}${path.extname(file.originalname)}`
      break
    case image_intercept.CLIENT:
      name = `${Date.now()}${path.extname(file.originalname)}`
      break
    default:
      name = `${request.user._id}_${Date.now()}${path.extname(file.originalname)}`
      break
  }
  return name
}
