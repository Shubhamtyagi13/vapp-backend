import { variables } from '@config'
import { FileFieldsInterceptor } from '@nestjs/platform-express'
import { generateRandomString, getEnvironmentVariable } from '@utils/platform.util'
import { Request } from 'express'
import fs from 'fs'
import { diskStorage, FileFilterCallback } from 'multer'
import path from 'path'

export const BrochureInterceptor = () =>
  FileFieldsInterceptor([{ name: 'brochure', maxCount: 1 }], {
    storage: diskStorage({
      destination: (request: Request, file: Express.Multer.File, callback: (error: Error | null, filename: string) => void) => {
        const filePath = `./${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.BROCHURE_DIRECTORY.name)}`
        if (!fs.existsSync(filePath)) {
          fs.mkdirSync(filePath)
        }
        request.filePath = filePath
        callback(null, filePath)
      },
      filename: (request: Request, file: Express.Multer.File, callback: (error: Error | null, filename: string) => void) => {
        const fileName = `${generateRandomString(24)}_${request.user._id}_${request.params.projectID}${path.extname(file.originalname)}`
        request.fileName = fileName
        callback(null, fileName)
      }
    }),
    fileFilter: (request: Request, file: Express.Multer.File, callback: FileFilterCallback) => {
      const fileTypes = /jpg|jpeg|png|JPG|JPEG|pdf|ppt|pptx|doc|docx/
      const mimetype = fileTypes.test(file.mimetype)
      const extname = fileTypes.test(path.extname(file.originalname).toLowerCase())
      if (mimetype && extname) {
        return callback(null, true)
      }
      return callback(new Error('invalid format'))
    }
  })
