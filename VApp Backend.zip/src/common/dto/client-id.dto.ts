import { ApiProperty } from '@nestjs/swagger'
import { IsMongoId, IsOptional } from 'class-validator'

export class ClientUserIDDTO {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsMongoId()
  clientUserID: string
}
