import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsNotEmpty } from 'class-validator'

export class SystemAuthDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsNotEmpty()
  username: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsNotEmpty()
  password: string
}
