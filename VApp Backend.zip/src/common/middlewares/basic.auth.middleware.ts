import { variables } from '@config'
import { getEnvironmentVariable } from '@utils/platform.util'
import basicAuth from 'express-basic-auth'

export const BasicAuthenticationMiddleware = () => {
  const credentials = {}
  credentials[`${getEnvironmentVariable(variables.SYSTEM_USERNAME.name)}`] = getEnvironmentVariable(variables.SYSTEM_PASSWORD.name)
  return basicAuth({
    challenge: true,
    users: credentials
  })
}
