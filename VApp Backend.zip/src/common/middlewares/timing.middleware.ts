import { constants } from '@config'
import { TimingLogObject } from '@interfaces/logger.interface'
import { VappLogger } from '@services/logger.service'
import { createModule } from 'create-nestjs-middleware-module'
import { NextFunction, Request, Response } from 'express'
import _ from 'lodash'

export const TimingMiddleware = createModule<{ logger?: VappLogger }>((options = {}) => (request: Request, response: Response, next: NextFunction) => {
    const { logger } = options
    const now = Date.now()
    response.on('finish', () => {
      if (!_.isNil(logger) && !isPresent(request.VAPP_CONTEXT.url)) {
        logger.trace({
          message: 'Request finished',
          status: response.statusCode,
          traceID: request.VAPP_CONTEXT.traceID,
          path: request.VAPP_CONTEXT.url,
          method: request.VAPP_CONTEXT.method,
          elapsedTime: Date.now() - now,
          data: { ...request.VAPP_CONTEXT.data },
          uid: !_.isNil(request.session) && !_.isNil(request.session.uid) ? request.session.uid : 'N/A',
          ip: request.VAPP_CONTEXT.ip,
          browser: {
            name: request.VAPP_CONTEXT.specs.browser,
            version: request.VAPP_CONTEXT.specs.version
          },
          sessionID: !_.isNil(request.sessionID) ? request.sessionID : 'N/A'
        } as TimingLogObject)
      }
    })
    next()
  })

const isPresent = (path: string) => {
  let isPresent = false
  constants.TRACE_FILTER_ROUTES.forEach((filterPath) => {
    if (path.includes(filterPath)) {
      isPresent = true
    }
  })
  return isPresent
}
