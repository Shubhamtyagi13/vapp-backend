import { APIResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { Injectable, NestMiddleware } from '@nestjs/common'
import { createVappContext } from '@utils/platform.util'
import { Request, Response } from 'express'

@Injectable()
export class TraceMiddleware implements NestMiddleware {
  use(request: Request, response: Response<APIResponse>, next: () => void): void {
    request.allImages = true
    request.VAPP_CONTEXT = <VappContext>createVappContext(request)
    next()
  }
}
