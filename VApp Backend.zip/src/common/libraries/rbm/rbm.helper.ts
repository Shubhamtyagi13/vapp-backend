import { v4 } from 'uuid'
import randomstring from 'randomstring'
import _ from 'lodash'

const MISSING_INITIALIZATION = 'You must first initialize this library by calling initRbmApi.'

// wrapper object for interacting with the RBM API
export const rbmApiHelper = (rbmApiClient, auth) => {
  const rbmApi = rbmApiClient
  const authClient = auth
  return {
    /**
     * Sends a synchronous capability check to the device.
     * @param {string} msisdn The phone number in E.164 format.
     * @param {function} callback Callback method for
     * after the method is complete.
     */
    checkCapability(msisdn: string, callback: any) {
      if (!authClient) {
        throw MISSING_INITIALIZATION
      } else {
        const requestId = randomstring.generate()

        // set the params
        const params = {
          name: `phones/${msisdn}`,
          requestId,
          auth: authClient
        }

        rbmApi.phones.getCapabilities(params, {}, (err, response) => {
          // prints the RBM capabilities of the phone
          console.log(response)

          if (callback !== undefined) {
            callback(response)
          }
        })
      }
    },

    /**
     * Checks the list of user devices for reachability of RBM.
     * Maximum list size is 10,000.
     * @param {array} msisdns List of phone numbers in E.164 format.
     * @param {function} callback A callback function called at
     * the completion of getUsers
     */
    getUsers(msisdns: Array<any>, callback: any) {
      if (!authClient) {
        throw MISSING_INITIALIZATION
      } else {
        // set the params
        const params = {
          auth: authClient,
          resource: {
            users: msisdns
          }
        }

        rbmApi.users.batchGet(params, {}, (err, response) => {
          if (callback !== undefined) {
            callback(response)
          }
        })
      }
    },

    /**
     * Sends an invite to the msisdn to become a tester.
     * @param {string} msisdn The phone number in E.164 format.
     * @param {function} callback Callback method for
     * after the method is complete.
     */
    sendTesterInvite(msisdn, callback) {
      if (!authClient) {
        throw MISSING_INITIALIZATION
      } else {
        const params = { parent: `phones/${msisdn}`, auth: authClient }

        // send a tester request
        rbmApi.phones.testers.create(params, {}, (err, response) => {
          if (callback !== undefined) {
            callback(response)
          }
        })
      }
    },

    /**
     * Sends an is typing event back to the msisdn.
     * @param {string} msisdn The phone number in E.164 format.
     * @param {function} callback Callback method for
     * after the method is complete.
     */
    sendIsTypingMessage(msisdn, callback) {
      if (!authClient) {
        throw MISSING_INITIALIZATION
      } else {
        // generate a random message id for this event
        const eventId = v4()

        // create the JSON message payload to send
        const options = {
          eventType: 'IS_TYPING'
        }

        // setup the parameters for the API call
        const params = {
          parent: `phones/${msisdn}`,
          eventId,
          auth: authClient,
          resource: options // POST body
        }

        // send the client the message
        rbmApi.phones.agentEvents.create(params, options, (err, response) => {
          console.log(response)

          if (callback !== undefined) {
            callback()
          }
        })
      }
    },

    /**
     * Sends a read event back to the msisdn.
     * @param {string} msisdn The phone number in E.164 format.
     * @param {string} messageId The identifier for the message that was read.
     * @param {function} callback Callback method for after
     * the method is complete.
     */
    sendReadMessage(msisdn, messageId, callback) {
      if (!authClient) {
        throw MISSING_INITIALIZATION
      } else {
        // generate a random message id for this event
        const eventId = v4()

        // create the JSON message payload to send
        const options = {
          eventType: 'READ',
          messageId
        }

        // setup the parameters for the API call
        const params = {
          parent: `phones/${msisdn}`,
          eventId,
          auth: authClient,
          resource: options // POST body
        }

        // send the client the message
        rbmApi.phones.agentEvents.create(params, options, (err, response) => {
          if (callback !== undefined) {
            callback(response)
          }
        })
      }
    },

    /**
     * Revokes the given message from being sent to the user.
     * @param {string} msisdn The phone number in E.164 format.
     * @param {string} messageId The identifier for the message that was sent.
     * @param {function} callback Function called once the message is revoked.
     */
    revokeMessage(msisdn, messageId, callback) {
      if (!authClient) {
        throw MISSING_INITIALIZATION
      } else {
        // setup the parameters for the API call
        const params = {
          name: `phones/${msisdn}/agentMessages/${messageId}`,
          auth: authClient
        }

        // remove the message from the delivery queue
        rbmApi.phones.agentMessages.delete(params, {}, (err, response) => {
          if (callback !== undefined) {
            callback(err, response)
          }
        })
      }
    },

    /**
     * Sends the device an RBM message.
     * @param {object} params The params for the api call.
     * @param {string} params.messageText The message to
     * send the user.
     * @param {string} params.msisdn The phone number
     * in E.164 format.
     * @param {array} params.suggestions The suggested chip
     * list of replies.
     * @param {function} callback Callback method for after
     * the method is complete.
     */
    sendMessage(params, callback) {
      if (!authClient) {
        throw MISSING_INITIALIZATION
      } else {
        // generate a random message id for this message
        const messageId = v4()

        // get the message text and msisdn from the parameters
        const { messageText } = params
        const { msisdn } = params

        // create the JSON message payload to send
        const options = {
          contentMessage: {}
        }

        // add text if it exists
        if (messageText !== undefined) {
          _.set(options.contentMessage, 'text', messageText)
        }

        // add suggested replies if they exist
        if (params.suggestions !== undefined && params.suggestions.length != null && params.suggestions.length > 0) {
          _.set(options.contentMessage, 'suggestions', params.suggestions)
        }

        // add an image if a media item exists
        if (params.fileUrl !== undefined) {
          _.set(options.contentMessage, 'contentInfo', {
            fileUrl: params.fileUrl
          })
        }

        // setup the parameters for the API call
        const apiParams = {
          parent: `phones/${msisdn}`,
          messageId,
          auth: authClient,
          resource: options // POST body
        }

        // send the client the message
        rbmApi.phones.agentMessages.create(apiParams, options, (err, response) => {
          if (callback !== undefined) {
            callback(response)
          }
        })
      }
    },

    /**
     * Sends the device a rich card over RCS.
     * @param {object} params An object of parameters needed for a richcard.
     * @param {string} params.messageText The message to
     * send the user.
     * @param {string} params.messageDescription The description
     * text to use in the rich card.
     * @param {string} params.msisdn The phone number
     * in E.164 format.
     * @param {string} params.imageUrl The public URL
     * of the image for the rich card.
     * @param {array} params.suggestions The suggested chip
     * list of replies.
     * @param {function} callback Callback method for after
     * the method is complete.
     */
    sendRichCard(params, callback) {
      if (!authClient) {
        throw MISSING_INITIALIZATION
      } else {
        let messageText = ''
        if (params.messageText !== undefined) {
          messageText = params.messageText
        }

        let messageDescription = ''
        if (params.messageDescription !== undefined) {
          messageDescription = params.messageDescription
        }

        // image for the card
        const { imageUrl } = params

        // msisdn to send the message to
        const { msisdn } = params

        // generate a random message id for this message
        const messageId = v4()

        // create the JSON message payload to send
        const options = {
          contentMessage: {
            richCard: {
              standaloneCard: {
                cardOrientation: 'VERTICAL',
                cardContent: {
                  media: {
                    height: 'TALL',
                    contentInfo: {
                      fileUrl: imageUrl,
                      forceRefresh: false
                    }
                  },
                  title: messageText,
                  description: messageDescription
                }
              }
            }
          }
        }

        // add suggested replies if they exist
        if (params.suggestions !== undefined && params.suggestions.length != null && params.suggestions.length > 0) {
          _.set(options.contentMessage.richCard.standaloneCard.cardContent, 'suggestions', params.suggestions)
        }

        // setup the parameters for the API call
        const apiParams = {
          parent: `phones/${msisdn}`,
          messageId,
          auth: authClient,
          resource: options // POST body
        }

        // send the client the message
        rbmApi.phones.agentMessages.create(apiParams, options, (err, response) => {
          console.dir(err)
          if (callback !== undefined) {
            callback(response)
          }
        })
      }
    },

    /**
     * Sends the device a card carousel
     * @param {object} params An object of parameters needed for a richcard.
     * @param {string} params.cardWidth The width of a card.
     * @param {string} params.cardContents An array of
     * rich card objects.
     * @param {string} params.msisdn The phone number
     * in E.164 format.
     * @param {function} callback Callback method for after
     * the method is complete.
     */
    sendCarouselCard(params, callback) {
      if (!authClient) {
        throw MISSING_INITIALIZATION
      } else {
        let cardWidth = 'MEDIUM'
        if (params.cardWidth !== undefined) {
          cardWidth = params.cardWidth
        }

        const { cardContents } = params

        // msisdn to send the message to
        const { msisdn } = params

        // generate a random message id for this message
        const messageId = v4()

        // create the JSON message payload to send
        const options = {
          contentMessage: {
            richCard: {
              carouselCard: {
                cardWidth,
                cardContents
              }
            }
          }
        }

        // setup the parameters for the API call
        const apiParams = {
          parent: `phones/${msisdn}`,
          messageId,
          auth: authClient,
          resource: options // POST body
        }

        // send the client the message
        rbmApi.phones.agentMessages.create(apiParams, options, (err, response) => {
          if (callback !== undefined) {
            callback(response)
          }
        })
      }
    }
  }
}
