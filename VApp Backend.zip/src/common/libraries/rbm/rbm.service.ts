import { Compute, GoogleAuth } from 'google-auth-library'
import { google } from 'googleapis'
import _ from 'lodash'
import { RBMCredentials } from '@app/integrations/helpers/rbm/interfaces/credentials.interface'
import { JSONClient } from 'google-auth-library/build/src/auth/googleauth'
import { JWT } from 'googleapis-common'
import { Injectable } from '@nestjs/common'
import { Rcsbusinessmessaging } from './v1'

@Injectable()
export class RBMClient {
  constructor() {}

  /**
   * Initializes the RBM API and authentication credentials to
   * communicate with the RBM platform.
   * @param {object} serviceAccountJsonObject The JSON object for the service account key file.
   * @param {function} callback Callback method for after
   * the method is complete.
   */
  initRbmApi(serviceAccountJsonObject: RBMCredentials): Promise<{ rbmApi: any; authClient: JSONClient | Compute | JWT }> {
    return new Promise(async (resolve, reject) => {
      let authClient: JSONClient | Compute | JWT
      const auth = new GoogleAuth({
        scopes: 'https://www.googleapis.com/auth/rcsbusinessmessaging'
      })
      if (serviceAccountJsonObject === undefined) {
        authClient = await auth.getClient()
      } else {
        authClient = new google.auth.JWT(serviceAccountJsonObject.client_email, null, serviceAccountJsonObject.private_key, ['https://www.googleapis.com/auth/rcsbusinessmessaging'])
      }
      resolve({ rbmApi: new Rcsbusinessmessaging({}, google), authClient })
    })
  }
}
