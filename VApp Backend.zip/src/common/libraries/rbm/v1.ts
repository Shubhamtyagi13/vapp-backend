import { createAPIRequest } from 'googleapis-common'

const rcsbusinessmessaging_v1: any = {}

  export class Rcsbusinessmessaging {
    private context: { _options: any; google: any }

    private files: Resource$Files

    private phones: Resource$Phones

    private users: Resource$Users

    constructor(options, google) {
      this.context = {
        _options: options || {},
        google
      }

      this.files = new Resource$Files(this.context)
      this.phones = new Resource$Phones(this.context)
      this.users = new Resource$Users(this.context)
    }
  }
  rcsbusinessmessaging_v1.Rcsbusinessmessaging = Rcsbusinessmessaging
  class Resource$Files {
    private context: { _options: any; google: any }

    constructor(context) {
      this.context = context
    }

    create(paramsOrCallback, optionsOrCallback, callback) {
      let params = paramsOrCallback || {}
      let options = optionsOrCallback || {}
      if (typeof paramsOrCallback === 'function') {
        callback = paramsOrCallback
        params = {}
        options = {}
      }
      if (typeof optionsOrCallback === 'function') {
        callback = optionsOrCallback
        options = {}
      }
      const rootUrl = options.rootUrl || 'https://rcsbusinessmessaging.googleapis.com/'
      const parameters = {
        options: { url: `${rootUrl}/v1/files`.replace(/([^:]\/)\/+/g, '$1'), method: 'POST', ...options },
        params,
        mediaUrl: `${rootUrl}/upload/v1/files`.replace(/([^:]\/)\/+/g, '$1'),
        requiredParams: [],
        pathParams: [],
        context: this.context
      }
      if (callback) {
        createAPIRequest(parameters, callback)
      } else {
        return createAPIRequest(parameters)
      }
    }
  }
  rcsbusinessmessaging_v1.Resource$Files = Resource$Files
  class Resource$Phones {
    private context: { _options: any; google: any }

    private agentEvents: Resource$Phones$Agentevents

    private agentMessages: Resource$Phones$Agentmessages

    private capability: Resource$Phones$Capability

    private dialogflowMessages: Resource$Phones$Dialogflowmessages

    private testers: Resource$Phones$Testers

    constructor(context) {
      this.context = context
      this.agentEvents = new Resource$Phones$Agentevents(this.context)
      this.agentMessages = new Resource$Phones$Agentmessages(this.context)
      this.capability = new Resource$Phones$Capability(this.context)
      this.dialogflowMessages = new Resource$Phones$Dialogflowmessages(this.context)
      this.testers = new Resource$Phones$Testers(this.context)
    }

    getCapabilities(paramsOrCallback, optionsOrCallback, callback) {
      let params = paramsOrCallback || {}
      let options = optionsOrCallback || {}
      if (typeof paramsOrCallback === 'function') {
        callback = paramsOrCallback
        params = {}
        options = {}
      }
      if (typeof optionsOrCallback === 'function') {
        callback = optionsOrCallback
        options = {}
      }
      const rootUrl = options.rootUrl || 'https://rcsbusinessmessaging.googleapis.com/'
      const parameters = {
        options: { url: `${rootUrl}/v1/{+name}/capabilities`.replace(/([^:]\/)\/+/g, '$1'), method: 'GET', ...options },
        params,
        requiredParams: ['name'],
        pathParams: ['name'],
        context: this.context
      }
      if (callback) {
        createAPIRequest(parameters, callback)
      } else {
        return createAPIRequest(parameters)
      }
    }
  }
  rcsbusinessmessaging_v1.Resource$Phones = Resource$Phones
  class Resource$Phones$Agentevents {
    private context: { _options: any; google: any }

    constructor(context) {
      this.context = context
    }

    create(paramsOrCallback, optionsOrCallback, callback) {
      let params = paramsOrCallback || {}
      let options = optionsOrCallback || {}
      if (typeof paramsOrCallback === 'function') {
        callback = paramsOrCallback
        params = {}
        options = {}
      }
      if (typeof optionsOrCallback === 'function') {
        callback = optionsOrCallback
        options = {}
      }
      const rootUrl = options.rootUrl || 'https://rcsbusinessmessaging.googleapis.com/'
      const parameters = {
        options: { url: `${rootUrl}/v1/{+parent}/agentEvents`.replace(/([^:]\/)\/+/g, '$1'), method: 'POST', ...options },
        params,
        requiredParams: ['parent'],
        pathParams: ['parent'],
        context: this.context
      }
      if (callback) {
        createAPIRequest(parameters, callback)
      } else {
        return createAPIRequest(parameters)
      }
    }
  }
  rcsbusinessmessaging_v1.Resource$Phones$Agentevents = Resource$Phones$Agentevents
  class Resource$Phones$Agentmessages {
    private context: { _options: any; google: any }

    constructor(context) {
      this.context = context
    }

    create(paramsOrCallback, optionsOrCallback, callback) {
      let params = paramsOrCallback || {}
      let options = optionsOrCallback || {}
      if (typeof paramsOrCallback === 'function') {
        callback = paramsOrCallback
        params = {}
        options = {}
      }
      if (typeof optionsOrCallback === 'function') {
        callback = optionsOrCallback
        options = {}
      }
      const rootUrl = options.rootUrl || 'https://rcsbusinessmessaging.googleapis.com/'
      const parameters = {
        options: { url: `${rootUrl}/v1/{+parent}/agentMessages`.replace(/([^:]\/)\/+/g, '$1'), method: 'POST', ...options },
        params,
        requiredParams: ['parent'],
        pathParams: ['parent'],
        context: this.context
      }
      if (callback) {
        createAPIRequest(parameters, callback)
      } else {
        return createAPIRequest(parameters)
      }
    }

    delete(paramsOrCallback, optionsOrCallback, callback) {
      let params = paramsOrCallback || {}
      let options = optionsOrCallback || {}
      if (typeof paramsOrCallback === 'function') {
        callback = paramsOrCallback
        params = {}
        options = {}
      }
      if (typeof optionsOrCallback === 'function') {
        callback = optionsOrCallback
        options = {}
      }
      const rootUrl = options.rootUrl || 'https://rcsbusinessmessaging.googleapis.com/'
      const parameters = {
        options: { url: `${rootUrl}/v1/{+name}`.replace(/([^:]\/)\/+/g, '$1'), method: 'DELETE', ...options },
        params,
        requiredParams: ['name'],
        pathParams: ['name'],
        context: this.context
      }
      if (callback) {
        createAPIRequest(parameters, callback)
      } else {
        return createAPIRequest(parameters)
      }
    }
  }
  rcsbusinessmessaging_v1.Resource$Phones$Agentmessages = Resource$Phones$Agentmessages
  class Resource$Phones$Capability {
    private context: { _options: any; google: any }

    constructor(context) {
      this.context = context
    }

    requestCapabilityCallback(paramsOrCallback, optionsOrCallback, callback) {
      let params = paramsOrCallback || {}
      let options = optionsOrCallback || {}
      if (typeof paramsOrCallback === 'function') {
        callback = paramsOrCallback
        params = {}
        options = {}
      }
      if (typeof optionsOrCallback === 'function') {
        callback = optionsOrCallback
        options = {}
      }
      const rootUrl = options.rootUrl || 'https://rcsbusinessmessaging.googleapis.com/'
      const parameters = {
        options: { url: `${rootUrl}/v1/{+name}/capability:requestCapabilityCallback`.replace(/([^:]\/)\/+/g, '$1'), method: 'POST', ...options },
        params,
        requiredParams: ['name'],
        pathParams: ['name'],
        context: this.context
      }
      if (callback) {
        createAPIRequest(parameters, callback)
      } else {
        return createAPIRequest(parameters)
      }
    }
  }
  rcsbusinessmessaging_v1.Resource$Phones$Capability = Resource$Phones$Capability
  class Resource$Phones$Dialogflowmessages {
    private context: { _options: any; google: any }

    constructor(context) {
      this.context = context
    }

    create(paramsOrCallback, optionsOrCallback, callback) {
      let params = paramsOrCallback || {}
      let options = optionsOrCallback || {}
      if (typeof paramsOrCallback === 'function') {
        callback = paramsOrCallback
        params = {}
        options = {}
      }
      if (typeof optionsOrCallback === 'function') {
        callback = optionsOrCallback
        options = {}
      }
      const rootUrl = options.rootUrl || 'https://rcsbusinessmessaging.googleapis.com/'
      const parameters = {
        options: { url: `${rootUrl}/v1/{+parent}/dialogflowMessages`.replace(/([^:]\/)\/+/g, '$1'), method: 'POST', ...options },
        params,
        requiredParams: ['parent'],
        pathParams: ['parent'],
        context: this.context
      }
      if (callback) {
        createAPIRequest(parameters, callback)
      } else {
        return createAPIRequest(parameters)
      }
    }
  }
  rcsbusinessmessaging_v1.Resource$Phones$Dialogflowmessages = Resource$Phones$Dialogflowmessages
  class Resource$Phones$Testers {
    private context: { _options: any; google: any }

    constructor(context) {
      this.context = context
    }

    create(paramsOrCallback, optionsOrCallback, callback) {
      let params = paramsOrCallback || {}
      let options = optionsOrCallback || {}
      if (typeof paramsOrCallback === 'function') {
        callback = paramsOrCallback
        params = {}
        options = {}
      }
      if (typeof optionsOrCallback === 'function') {
        callback = optionsOrCallback
        options = {}
      }
      const rootUrl = options.rootUrl || 'https://rcsbusinessmessaging.googleapis.com/'
      const parameters = {
        options: { url: `${rootUrl}/v1/{+parent}/testers`.replace(/([^:]\/)\/+/g, '$1'), method: 'POST', ...options },
        params,
        requiredParams: ['parent'],
        pathParams: ['parent'],
        context: this.context
      }
      if (callback) {
        createAPIRequest(parameters, callback)
      } else {
        return createAPIRequest(parameters)
      }
    }
  }
  rcsbusinessmessaging_v1.Resource$Phones$Testers = Resource$Phones$Testers
  class Resource$Users {
    private context: { _options: any; google: any }

    constructor(context) {
      this.context = context
    }

    batchGet(paramsOrCallback, optionsOrCallback, callback) {
      let params = paramsOrCallback || {}
      let options = optionsOrCallback || {}
      if (typeof paramsOrCallback === 'function') {
        callback = paramsOrCallback
        params = {}
        options = {}
      }
      if (typeof optionsOrCallback === 'function') {
        callback = optionsOrCallback
        options = {}
      }
      const rootUrl = options.rootUrl || 'https://rcsbusinessmessaging.googleapis.com/'
      const parameters = {
        options: { url: `${rootUrl}/v1/users:batchGet`.replace(/([^:]\/)\/+/g, '$1'), method: 'POST', ...options },
        params,
        requiredParams: [],
        pathParams: [],
        context: this.context
      }
      if (callback) {
        createAPIRequest(parameters, callback)
      } else {
        return createAPIRequest(parameters)
      }
    }
  }
  rcsbusinessmessaging_v1.Resource$Users = Resource$Users
