import { Document } from 'mongoose'
import { TrendsEngagement } from './engagement.interface'
import { Location } from './location.interface'

export interface ProjectType extends Document {
  name: string
  minCarpetArea: number
  maxCarpetArea: number
  minPrice: number
  maxPrice: number
  availabilityCount: number
}

export interface Project extends Document {
  negativeCount?: number
  positiveCount?: number
  neutralCount?: number
  name: string
  isVisible: { type: boolean; index: true }
  isActive: { type: boolean; index: true }
  location?: Location
  subTypes?: [ProjectType]
  possessionMonth: number
  possessionYear: number
  reraID: string
  imageURL: string
  isPossessionAvailable: boolean
  clientID: string
  clientName: string
  phone: number
  smsSenderID: string
  walkthroughExists?: boolean
  brochure: string
  engagementTotal: number
  engagementSum: number
  smsEngagementTotal: number
  smsEngagementSum: number
  whatsappEngagementTotal: number
  whatsappEngagementSum: number
  smsSentCount: number
  smsDeliveredCount: number
  smsFailedCount: number
  whatsappClicks: number
  linksCount: number
  linksClickCount: number
  viewsCount: number
  description:string
}

export interface ProjectTrendingEngagementsStore extends Document {
  clientID: string
  projectID: string
  year: number
  month: number
  trendingEngagements: TrendsEngagement[]
}
