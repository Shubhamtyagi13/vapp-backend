import { Document } from 'mongoose'
import { ReportRequest } from './reports.interface'

export interface TransactionalMetricObject {
  sentTotal: number
  sent: Array<number> | Array<{ hour: number; value: number }>
  deliveredTotal: number
  delivered: Array<number> | Array<{ key: number; value: number }>
}

export interface TransactionalDailyStatsObject {
  day: number
  sent: number
  delivered: number
}

export interface TransactionalDashboard extends Document {
  metrics: {
    today: TransactionalMetricObject
    month: TransactionalMetricObject
    year: TransactionalMetricObject
  }
  calendar: Array<{
    month: number
    dailyStats: Array<TransactionalDailyStatsObject>
  }>
  reportRequest: Array<ReportRequest>
}
