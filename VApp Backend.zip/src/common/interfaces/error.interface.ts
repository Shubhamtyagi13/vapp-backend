export function CronError(message: string) {
  this.name = 'CronError'
  this.message = message || ''
}
CronError.prototype = Error.prototype
