export interface campaignProviderObject {
  phone: number
  message: string
}
