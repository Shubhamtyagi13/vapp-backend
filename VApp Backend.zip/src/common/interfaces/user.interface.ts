import { Manager } from '@interfaces/manager.interface'
import { Document } from 'mongoose'

export interface User extends Document {
    firstName: string
    middleName: string
    lastName: string
    email: string
    companyName: string
    profileImage: string
    userType: number
    smsSenderID: string
    isFirstTime: boolean
    password: string
    activeStatus: boolean
    greeting: string
    apiKey: string
    correspondence: string
    contact: number
    manager: Manager
}
