export interface CampaignInitialAlert {
  project: string
  client: string
  time: string
  sent: string
  tracking: string
  credits: string
  message: string
  status: string
  date: string
  year: string
  type: string
}

export interface CreditsApprovedAlert {
  client: string
  date: string
  time: string
  credits: string
  year: string
}

export interface PasswordResetAlert {
  client: string
  reset: boolean
  code: string
  year: string
}

export interface CampaignReportAlert {
  client: string
  periodic: boolean
  title: string
  type: string
  date: string
  time: string
  project: string
  link: string
  year: string
}
