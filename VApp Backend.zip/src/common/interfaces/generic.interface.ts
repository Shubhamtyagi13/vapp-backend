export interface GenericObject {
  [key: string]: any
}
