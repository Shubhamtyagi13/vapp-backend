import { Document } from 'mongoose'

export interface Engagement extends Document {
  time: number
}

export interface TrendsEngagement extends Document {
  date: string
  hour: number
  minutes: number
  seconds: number
  time: number
}

export interface EngagementLevel extends Document {
  initial: number
  negativeCount: number
  neutralCount: number
  positiveCount: number
}
