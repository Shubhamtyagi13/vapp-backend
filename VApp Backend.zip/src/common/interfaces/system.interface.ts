export interface SystemInfo {
  appVersion: string
}
