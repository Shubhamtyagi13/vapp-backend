import { Document } from 'mongoose'
import { ReportRequest } from './reports.interface'

export interface OTPMetricObject {
  sentTotal: number
  sent: Array<number> | Array<{ hour: number; value: number }>
  deliveredTotal: number
  delivered: Array<number> | Array<{ key: number; value: number }>
  verifiedTotal: number
  verified: Array<number> | Array<{ key: number; value: number }>
  attemptsTotal: number
  attempts: Array<number> | Array<{ key: number; value: number }>
}

export interface OTPDailyStatsObject {
  day: number
  sent: number
  delivered: number
  verified: number
  attempts: number
}

export interface OTPDashboard extends Document {
  metrics: {
    today: OTPMetricObject
    month: OTPMetricObject
    year: OTPMetricObject
  }
  calendar: Array<{
    month: number
    dailyStats: Array<OTPDailyStatsObject>
  }>
  reportRequest: Array<ReportRequest>
}
