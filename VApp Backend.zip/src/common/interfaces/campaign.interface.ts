import { Contact } from '@app/contact/contact.schema'
import { Document } from 'mongoose'

export interface Campaign extends Document {
  campaignID?: string
  templateID?: string
  templateName?: string
  databaseID?: string
  databaseName?: string
  projectName?: string
  type?: number
  cloud?: boolean
  value?: string
  tracking?: boolean
  dynamic: boolean
  url?: string
  projectID?: string
  clientID?: string
  phone?: number
  year?: number
  month?: number
  day?: number
  multiple?: boolean
  redirection?: boolean
  sms?: string
  token?: string
  engagementTotal: number
  engagementSum: number
  smsEngagementTotal: number
  smsEngagementSum: number
  whatsappClicks: number
  source: string
  smsSentCount: number
  whatsappSentCount: number
  smsDeliveredCount: number
  smsFailedCount: number
  linksCount: number
  linksClickCount: number
  viewsCount: number
  whatsappViewsCount: number
  smsViewsCount: number
  brochure?: string
  success?: boolean
  error?: string
  whatsappEngagementTotal: number
  whatsappEngagementSum: number
  isDripCampaign: boolean
  dripTemplateID: string
  dripCriteriaID: string
  dripSmsSenderId: string
  dripCampaignName: string
}

export interface SingleCampaign extends Document {
  firstName: string
  lastName: string
  middleName: string
  message: string
  phone: number
  cloud: string | boolean
  redirection: string | boolean
  url: string
  tracking: string | boolean
  sendTemplate: string | boolean
  templateID: string
  isDripCampaign: boolean
  dripTemplateID: string
  dripCriteriaID: string
  dripSmsSenderId: string
  dripCampaignName: string
}

export interface BulkCampaign extends Document {
  contacts: Contact[]
  cloud: string | boolean
  url: string
  message: string
  tracking: string | boolean
  redirection: string | boolean
  sendDB: string | boolean
  sendTemplate: string | boolean
  templateID: string
  databaseID: string
  isDripCampaign: boolean
  dripTemplateID: string
  dripCriteriaID: string
  dripSmsSenderId: string
  dripCampaignName: string
}

export interface WhatsappCampaign extends Document {
  contacts: Contact[]
  cloud: string | boolean
  url: string
  message: string
  tracking: string | boolean
  redirection: string | boolean
  sendTemplate: string | boolean
  dynamic: boolean
  templateID: string
  channel: string
}

export interface FileObject {
  filePath: string
  fileName: string
  originalFileName: string
}

export interface WhatsappMessageRequest {
  phone: number
  message: string
}

export interface CampaignAnalysis<Number, CampaignAnalysisObject> {
  [name: number]: CampaignAnalysisObject
}

export interface DripCampaignAnalysis<Number, DripCampaignAnalysisObject> {
  [name: number]: DripCampaignAnalysisObject
}

export interface CampaignAnalysisQuery {
  clientID: string
  year: number
  month: number
  projectID: string
}

export interface WhatsappCampaignResult {
  success: boolean
  reason?: string
  results: {
    success: number
    failed: number
  }
  usertoken?: string
}

export interface CampaignEvent {
  campaignID?: string
  databaseID?: string
  events: number
  eventsThreshold: number
}
