export interface ReportRequest {
  _id: string
  start_date: Date
  end_date: Date
  created: Date
  status: number
  type: number
  url: string
}
