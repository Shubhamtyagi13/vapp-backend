import { Document } from 'mongoose'

export interface Client extends Document {
  name: string
  image: string
  active: boolean
  link: string
}

export interface Testimonial extends Document {
  clientName: string
  text: string
  image: string
  active: boolean
  link: string
}
