import { User } from '@app/user/user.schema'
import { audience } from '@config'
import { VappContext } from '@interfaces/trace.interface'
import { FileObject } from './campaign.interface'

declare global {
  namespace Express {
   export interface Request {
      VAPP_CONTEXT: VappContext
      user: User
      filePath: string
      token: string
      fileName: string
      whatsappFiles: [FileObject]
      allImages: boolean
      ip: string
      originalUrl: string
    }
  }
}

declare module 'express-session' {
  export interface SessionData {
    verified:boolean
    expTime: number
    uid:string
    user: User & {aud?: audience}
    token: string
  }
}
