export interface Message {
  message: string
  code: string
}
