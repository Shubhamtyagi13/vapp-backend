import { Session } from 'my_smpp'

export interface SMPPCredentials {
  system_id: string
  password: string
  system_type: string
  address_range: string
  addr_ton: number
  addr_npi: number
}

export interface SMPPSessionStore {
  session: Session
  isConnected: boolean
  chunkSize: number
  source_addr: string
  campaignID: string
}

export interface SMPPSmsPayload {
  source_addr: string
  destination_addr: string
  short_message: string
  message_payload: string
  data_coding: number
  registered_delivery: number
  pe_id: string
  header_id: string
  template_id: string
}

export interface SMPPMessageDeliveryErrors {
  contact: number
  message: string
}

export interface DeliverSmPDU {
  command_length: number
  command_id: number
  command_status: number
  sequence_number: number
  command: string
  service_type: string
  source_addr_ton: number
  source_addr_npi: number
  source_addr: string
  dest_addr_ton: number
  dest_addr_npi: number
  destination_addr: string
  esm_class: number
  protocol_id: number
  priority_flag: number
  schedule_delivery_time: string
  validity_period: string
  registered_delivery: number
  replace_if_present_flag: number
  data_coding: number
  sm_default_msg_id: number
  short_message: {
    message: string
  }
  receipted_message_id: string
  campaignID?: string
  parsed_message_id?: string
  phone?: number
}
