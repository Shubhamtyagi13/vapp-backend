import { report_types } from '@config'

export interface RbmMessageWithImage extends RbmMessageBase {
  fileUrl: string
}

export interface RbmRichCard extends RbmSimpleMessage {
  messageDescription: string
  suggestions: [RbmDialAction | RbmViewLocationAction | RbmViewLocationAction | RbmOpenUrlAction]
  imageUrl: string
  height: string
}

export interface RbmRichCardCarosuel extends RbmMessageBase {
  cardContenst: [RbmRichCardCarosuelCardContents]
}

export interface RbmRichCardCarosuelCardContents {
  title: string
  description: string
  suggestions: [RbmDialAction | RbmViewLocationAction | RbmViewLocationAction | RbmOpenUrlAction]
  media: [RbmCardMedia]
}

export interface RbmCardMedia {
  height: string
  contentInfo: RbmCardMediaContentInfo
}

export interface RbmCardMediaContentInfo {
  fileUrl: string
  forceRefresh: boolean
}

export interface RbmMessageWithActions extends RbmSimpleMessage {
  suggestions: Array<{ action: RbmDialAction | RbmOpenUrlAction | RbmDialAction }>
}
export interface RbmAction {
  text: string
  postbackData: string
}

export interface RbmDialAction extends RbmAction {
  dialAction: RbmDialActionObject
}

export interface RbmDialActionObject {
  phoneNumber: string
}

export interface RbmViewLocationAction extends RbmAction {
  viewLoaction: RbmViewLocationObject
}

export interface RbmViewLocationObject {
  latLong: RbmLatLongObject
  label: string
}

export interface RbmLatLongObject {
  latitude: number
  Longitude: number
}

export interface RbmOpenUrlAction extends RbmAction {
  openUrlAction: RbmOpenUrlObject
}

export interface RbmOpenUrlObject {
  url: string
}

export interface RbmReport {
  phone: number
  rbmMessageID: string
  reportType: report_types
  campaignID: string
}

export interface RbmMessageBase {
  msisdn: string
}

export interface RbmSimpleMessage extends RbmMessageBase {
  messageText: string
}
