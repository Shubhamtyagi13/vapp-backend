import { GenericObject } from "./generic.interface"

export interface EmailPayload {
  to: string
  from: string
  templateId: string
  dynamic_template_data: GenericObject
}
