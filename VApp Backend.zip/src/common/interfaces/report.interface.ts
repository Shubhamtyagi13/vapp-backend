import { ContactDatabase } from '@app/contact/contact.database.schema'
import { Credits } from '@app/credits/credits.schema'
import { report_types } from '@config'
import { Projects } from 'aws-sdk/clients/codebuild'
import { Link } from 'aws-sdk/clients/networkmanager'
import { Template } from 'handlebars'
import { Campaign } from './campaign.interface'

export interface DeliveryObject {
  phone: number
  status: string
  smppMessageID?: string
  campaignID?: string,
  reportType:report_types
}
export interface DeliveryReport {
  data: DeliveryObject
  isFinal: boolean
  isSmpp: boolean
}

export interface CreateDeliveryReport {
  campaignID: string
  isDrip: boolean
  clientID: string
  month: number
  year: number
  projectID: string
}
export interface GetwayDeliveryReportScraper {
  campaignID: string
  campaignTime: string
  campaignObjectID: string
  impersonation: string
  isFinal: boolean
}

export interface DeliveryReportObject {
  phone: number
  status: string
  smppMessageID?: string
}

export interface ReportCronSubDeliveryObject {
  smsDeliveredCount: number
  smsFailedCount: number
  smsRefundCount: number
}

export interface ProjectReport {
  eventName: string
  phones: number[]
}

export interface SmppReportUpdateObject {
  smsDeliveredCount: number
  smsFailedCount: number
  smsRefundCount: number
}

export interface CommonEngagement{
  templates: Template[]
  contactsDatabases: ContactDatabase[]
  links: Link[]
}

export interface RedisUpdateObjects {
  campaignUpdateResult : Campaign
  commonEngagement: CommonEngagement
  creditsUpdateResult : Credits
  projectUpdateResult: Projects
}
