import { Campaign } from '@app/campaign/campaign.schema'
import { DripCampaign } from '@app/campaign/drip_campaign.schema'
import { ContactDatabase } from '@app/contact/contact.database.schema'
import { Credits } from '@app/credits/credits.schema'
import { Link } from '@app/link/link.schema'
import { Projects } from '@app/projects/projects.schema'
import { Template } from '@app/template/template.schema'
import { Document } from 'mongoose'
import { TrendsEngagement } from './engagement.interface'
import { GenericObject } from './generic.interface'
import { Project } from './project.interface'

export interface Dashboard extends Document {
  clientID?: string
  year?: number
  month?: number
  value?: string
  engagementTotal: number
  engagementSum: number
  smsEngagementTotal: number
  smsEngagementSum: number
  whatsappEngagementTotal: number
  whatsappEngagementSum: number
  whatsappClicks: number
  smsSentCount: number
  smsDeliveredCount: number
  smsFailedCount: number
  linksCount: number
  linksClickCount: number
  viewsCount: number
  whatsappViewsCount: number
  smsViewsCount: number
  whatsappDeliveredCount: number
  whatsappSentCount: number
  whatsappFailedCount: number
  negativeCount?: number
  neutralCount?: number
  positiveCount?: number
  smsLinksClickCount: number
  whatsappLinksClickCount: number
}

export interface DashboardTrendingPerson extends Document {
  firstName: string
  lastName: string
  middleName: string
  projectID: string
  requestID: string
  phone: number
  engagementSum: number
  month?: number
  projectName: string
}

export interface DashboardTrendingProject extends Document {
  projectID: string
  projectName: string
  month?: number
  engagementSum: number
  negativeCount: number
  neutralCount: number
  positiveCount: number
}

export interface DashboardTrendingTemplate extends Document {
  templateID: string
  templateName: string
  engagementSum: number
  month?: number
  negativeCount: number
  neutralCount: number
  positiveCount: number
}
export interface DashboardTrendingLink extends Document {
  linkID: string
  linkName: string
  url: string
  engagementSum: number
  negativeCount: number
  month?: number
  neutralCount: number
  positiveCount: number
}
export interface DashboardTrendingDatabase extends Document {
  month?: number
  databaseID: string
  databaseName: string
  engagementSum: number
  negativeCount: number
  neutralCount: number
  positiveCount: number
}
export interface DashboardTrendingStore extends Document {
  clientID: string
  year: number
  month: number
  trendingPersons: DashboardTrendingPerson[]
  trendingProjects: DashboardTrendingProject[]
  trendingTemplates: DashboardTrendingTemplate[]
  trendingDatabases: DashboardTrendingDatabase[]
  trendingLinks: DashboardTrendingLink[]
}

export interface MasterDashboard extends Document {
  graph: Dashboard[]
  calendar: GenericObject[]
  credits: Credits
  trends: {
    persons: DashboardTrendingPerson[]
    projects: DashboardTrendingProject[]
    templates: DashboardTrendingTemplate[]
    databases: DashboardTrendingDatabase[]
    links: DashboardTrendingLink[]
    spendingTrends: SpendingTrend[]
  }
  performance: PerformanceStats
  projectCount: number
  stats: Dashboard
  demographics: GenericObject
}

export interface PerformanceStats extends Document {
  project: Projects
  template: Template
  database: ContactDatabase
  link: Link
}

export interface ProjectDashboard extends Document {
  stats: Campaign
  graph: Campaign[]
  project: Project
  campaigns: Campaign[]
  dripcampaigns:DripCampaign[]
  engagements: TrendsEngagement[]
  smsCost: number
  whatsappCost: number
  performance: PerformanceStats
  demographics: GenericObject
  calendar: GenericObject[]
  databaseCluster: DatabaseCluster[]
}

export interface DatabaseCluster {
  databaseID: string
  databaseName: string
  clicks: number
  calls: number
  callsThreshold: number
  events: number
  eventsThreshold: number
  avgClicks: number
  avgCalls: number
  avgCallsThreshold: number
  avgEvents: number
  avgEventsThreshold: number
}
export interface SpendingTrend extends Document {
  projectID: string
  projectName: string
  smsSentCount: number
  smsDeliveredCount: number
  smsFailedCount: number
  whatsappSentCount: number
  whatsappDeliveredCount: number
  whatsappFailedCount: number
  smsLinksClickCount: number
  whatsappLinksClickCount: number
}
