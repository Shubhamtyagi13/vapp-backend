import { Document } from 'mongoose'

export interface Manager extends Document {
  email: string
  name: string
  contact: number
}
