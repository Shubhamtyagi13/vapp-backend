import { GenericObject } from '@interfaces/generic.interface'

export interface BaseLogObject {
  traceID: string
  method: string
  message: string
}

export interface TimingLogObject extends BaseLogObject {
  status: number
  path: string
  sessionID: string
  ip: string
  elapsedTime: number
  browser: {
    name: string
    version: number
  }
  data?: GenericObject
}

export interface ErrorLogObject extends BaseLogObject {
  stack_trace: GenericObject
}
