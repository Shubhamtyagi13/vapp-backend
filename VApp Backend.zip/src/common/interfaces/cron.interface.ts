import { Integrations } from '@app/integrations/integrations.schema'
import { integration_category, integration_operation } from '@config'
import { Request } from './request.interface'

export interface CronPayload<T = any> {
  payload: T
  traceID: string
  instance?: string
}

export interface CampaignReportCronPayload {
  clientID: string
  campaignID: string
}

export interface IntegrationsCronPayload {
  integrationOperation: integration_operation
  integration: Integrations
  metadata: Request
}
