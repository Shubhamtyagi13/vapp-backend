import { SingleContactDTO } from '@app/campaign/dto/bulk-campaign-dto'
import { report_types } from '@config'
import { FileObject } from './campaign.interface'

export interface CampaignCronPayload {
  multiple: boolean
  type: number
  url: string
  cloud: boolean
  clientID: string
  clientName: string
  projectID: string
  message: string
  dripmessage: string
  contactData: SingleContactDTO[]
  campaignName: string
  failover?: boolean
  smsCount: number
  ivr: number
  linkID: string
  tracking: boolean
  dynamic: boolean
  redirection: boolean
  templateID: string
  registeredTemplateID: string
  registeredDripTemplateID: string
  databaseID: string
  otp?: string
  channelID?: string
  isCaptionMessage?: boolean
  files?: [FileObject]
  persistSession?: boolean
  allImages?: boolean
  whatsappButton?: boolean
  dripWhatsappButton ?: boolean
  chatbotButton?: boolean
  campaignID: string
  isDripCampaign: boolean
  dripTemplateID: string
  dripCriteriaID: string
  dripSmsSenderId: string
  dripCampaignName: string
  scheduleDripDate:Date
  // only for otp and transactional
  firstName?: string
  middleName?: string
  lastName?: string
  var1?: string
  var2?: string
  var3?: string
  var4?: string
}

export interface RequestIDUpdatePayload {
  campaignID: string
  phone: number
  deliveryID: string
}

export interface FinalizeCampaignCronPayload {
  campaignID: string,
  campaignType:report_types
}
