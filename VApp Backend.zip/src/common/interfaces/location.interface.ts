import { Document } from 'mongoose'

export interface StreetAddress extends Document {
  sequence: string
  area: string
}
export interface Location extends Document {
  city: string
  country: string
  latitude: number
  longitude: number
  postalCode: number
  state: string
  streetAddress: StreetAddress
  landMark: string
}
