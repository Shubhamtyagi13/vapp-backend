import { GenericObject } from '@interfaces/generic.interface'

export interface VappContext extends Request {
  traceID: string
  userAgent: string
  specs: {
    browser: string
    version: number
  }
  data: GenericObject
  ip: string
  method: string
  url: string
}
