import { Campaign } from '@app/campaign/campaign.schema'
import { ContactDatabase } from '@app/contact/contact.database.schema'
import { Credits } from '@app/credits/credits.schema'
import { Dashboard } from '@app/dashboard/dashboard.schema'
import { IVR } from '@app/ivr/ivr.schema'
import { Link } from '@app/link/link.schema'
import { Projects } from '@app/projects/projects.schema'
import { RequestEngagement } from '@app/requests/requests.engagement.schema'
import { Requests } from '@app/requests/requests.schema'
import { Template } from '@app/template/template.schema'
import { Document, Model } from 'mongoose'
import { Demographics } from './demographics.interface'
import { Engagement } from './engagement.interface'

export interface Request extends Document {
  projectID: string
  clientID: string
  campaignID: string
  shortID: string
  expiresOn: number
  firstName: string
  middleName: string
  lastName: string
  visited: boolean
  month: number
  year: number
  day: number
  whatsapp: boolean
  phone: number
  morphed: boolean
  credit: number
  type: number
  smsStatus: number
  engagementTime: Engagement[]
  chatbot: boolean
  brochure: boolean
  device: string
  deviceType: string
  os: string
  lead: string
  engagementLevel: number
  demographics: Demographics
  ivr: [IVR]
  deliveryID: string
}

export interface SMSRequestRedis {
  message: string
  code: string
  projectID: string
  phoneNumber: number
  url: string
  cloud: boolean
  requestID: string
  campaignID: string
  projectName: string
  companyName: string
  brochure: string
}

export interface EngagementObject {
  requestID: string
  time: number
  engagementID: string
}

export interface FirstEngagementUpdateContext {
  projectsModel: Model<Projects>
  requestModel: Model<Requests>
  campaignModel: Model<Campaign>
  templatesModel: Model<Template>
  contactsDatabaseModel: Model<ContactDatabase>
  dashboardModel: Model<Dashboard>
  creditsModel: Model<Credits>
  engagementModel: Model<RequestEngagement>
  linksModel: Model<Link>
}
