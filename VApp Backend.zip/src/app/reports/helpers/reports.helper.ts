import { variables } from '@config'
import { getEnvironmentVariable } from '@utils/platform.util'
import fs from 'fs'
import path from 'path'

export const createCampaignReportDirectory = (clientID: string, year: number, month: number, projectID: string) => {
  const campaignDirectory = `/${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(
    variables.REPORTS_DIRECTORY.name
  )}/${clientID}/${projectID}/${year}/${month}`
  const directoryExists = fs.existsSync(path.join(process.cwd(), campaignDirectory))
  if (!directoryExists) {
    fs.mkdirSync(path.join(process.cwd(), campaignDirectory), { recursive: true })
  }
  return campaignDirectory
}
