import { report_status, tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.REPORTS.collection, autoCreate: true })
export class Reports extends Document {
  @Prop({ type: String, required: true, default: null, index: true })
  clientID: string

  @Prop({ type: Date, index: true, required: true })
  start_date: Date

  @Prop({ type: Date, index: true, required: true })
  end_date: Date

  @Prop({ type: Number, required: true, default: report_status.UNDER_PROCESS })
  status: number

  @Prop({ type: Number, required: true, index: true }) // 0 : otp, 1,2,3 etc for else
  type: number

  @Prop({ type: String, default: null })
  url: string

  @Prop({ type: Date, index: true, required: true, default: Date.now() })
  created: Date

  @Prop({ type: Date, required: true })
  expiry_timestamp: Date

  @Prop({ type: Number, required: true, default: 2 })
  expiry_days: number
}

export const ReportsSchema = SchemaFactory.createForClass(Reports)
