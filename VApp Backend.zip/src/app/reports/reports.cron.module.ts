import { Campaign, CampaignSchema } from '@app/campaign/campaign.schema'
import { DripCampaign, DripCampaignSchema } from '@app/campaign/drip_campaign.schema'
import { OTP, OTPSchema } from '@app/otp/otp.schema'
import { DripRequests, DripRequestsSchema } from '@app/requests/drip_requests.schema'
import { Requests, RequestsSchema } from '@app/requests/requests.schema'
import { Transactional, TransactionalSchema } from '@app/transactional/transactional.schema'
import { User, UserSchema } from '@app/user/user.schema'
import { cronJobs } from '@config'
import { GenericObject } from '@interfaces/generic.interface'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { getArgs } from '@utils/platform.util'
import { CreateCampaignReportQueueModule, ReportsQueueModule } from './cron/queue.module'
import { CreateCampaignReportProcessor, CreateReportProcessor } from './cron/queue.processor'
import { QueueUIProvider } from './cron/queue.ui'
import { ReportsController } from './reports.controller'
import { Reports, ReportsSchema } from './reports.schema'
import { ReportsService } from './reports.service'
import { ReportsWebSocketGateway } from './reports.socket'

const cronSwitcher = () => {
  const cron_processor = (getArgs() as GenericObject).cron
  let processor_array: Array<any> = []
  switch (cron_processor) {
    case cronJobs.CREATE_CAMPAIGN_REPORT.name:
      processor_array = [CreateCampaignReportProcessor]
      break
    case cronJobs.CREATE_REPORT.name:
      processor_array = [CreateReportProcessor]
      break
  }
  return processor_array
}
@Module({
  imports: [
    MongooseModule.forFeature([
      { name: OTP.name, schema: OTPSchema },
      { name: Transactional.name, schema: TransactionalSchema },
      { name: DripRequests.name, schema: DripRequestsSchema },
      { name: Reports.name, schema: ReportsSchema },
      { name: User.name, schema: UserSchema },
      { name: Requests.name, schema: RequestsSchema },
      { name: Campaign.name, schema: CampaignSchema },
      { name: DripCampaign.name, schema: DripCampaignSchema },
    ]),
    CreateCampaignReportQueueModule,
    ReportsQueueModule,
  ],
  controllers: [ReportsController],
  providers: [ReportsService, VappLogger, ...cronSwitcher(), QueueUIProvider, ReportsWebSocketGateway],
})
export class ReportsCronModule {}
