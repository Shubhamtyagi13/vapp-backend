import { Campaign, CampaignSchema } from '@app/campaign/campaign.schema'
import { DripCampaign, DripCampaignSchema } from '@app/campaign/drip_campaign.schema'
import { Requests, RequestsSchema } from '@app/requests/requests.schema'
import { User, UserSchema } from '@app/user/user.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { CreateCampaignReportQueueModule, ReportsQueueModule } from './cron/queue.module'
import { QueueUIProvider } from './cron/queue.ui'
import { ReportsController } from './reports.controller'
import { ReportsService } from './reports.service'

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Requests.name, schema: RequestsSchema },
      { name: Campaign.name, schema: CampaignSchema },
      { name: DripCampaign.name, schema: DripCampaignSchema }
    ]),
    CreateCampaignReportQueueModule,
    ReportsQueueModule
  ],
  controllers: [ReportsController],
  providers: [ReportsService, VappLogger, QueueUIProvider]
})
export class ReportsModule {}
