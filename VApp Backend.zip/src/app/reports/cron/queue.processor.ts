import { Campaign } from '@app/campaign/campaign.schema'
import { OTP } from '@app/otp/otp.schema'
import { DripRequests } from '@app/requests/drip_requests.schema'
import { Requests } from '@app/requests/requests.schema'
import { Transactional } from '@app/transactional/transactional.schema'
import { User } from '@app/user/user.schema'
import {
  cache_client, constants, contentTypes, cronJobs, redisKeys, redis_client, report_status, report_types, variables,
} from '@config'
import { CampaignReportCronPayload, CronPayload } from '@interfaces/cron.interface'
import { CronError } from '@interfaces/error.interface'
import { messages } from '@messages'
import {
  OnQueueActive, OnQueueCompleted, OnQueueFailed, Process, Processor,
} from '@nestjs/bull'
import { Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import { deleteFile, getEnvironmentVariable, getErrorLog } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import { S3Handler } from '@utils/s3.util'
import { Job } from 'bull'
import fs from 'fs'
import _ from 'lodash'
import { TransactionOptions } from 'mongodb'
import { Model } from 'mongoose'
import path from 'path'
import { createCampaignReportDirectory } from '../helpers/reports.helper'
import { Reports } from '../reports.schema'
import { ReportsWebSocketGateway } from '../reports.socket'

@Injectable()
@Processor(cronJobs.CREATE_CAMPAIGN_REPORT.name)
export class CreateCampaignReportProcessor {
  constructor(
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(Campaign.name) private campaignModel: Model<Campaign>,
    @InjectModel(Requests.name) private requestsModel: Model<Requests>,
    private logger: VappLogger,
  ) {}

  @Process({ concurrency: 1 })
  async createCampaignReport(job: Job<CronPayload<CampaignReportCronPayload>>) {
    const { payload } = job.data
    try {
      const campaign: Campaign = await findOperations.findOne(this.campaignModel, { _id: payload.campaignID, clientID: payload.clientID }, {})
      const data = await findOperations.aggregate(this.requestsModel, [
        {
          $match: {
            campaignID: payload.campaignID,
            visited: true,
            clientID: payload.clientID,
            engagementLevel: { $in: [constants.ENGAGEMENT_LEVELS.negative, constants.ENGAGEMENT_LEVELS.neutral, constants.ENGAGEMENT_LEVELS.positive] },
            year: new Date().getFullYear(),
          },
        },
        {
          $project: {
            _id: '$_id',
            phone: 1,
            whatsapp: 1,
            type: 1,
            brochure: 1,
            chatbot: 1,
            engagementLevel: 1,
            campaignID: 1,
            device: 1,
            deviceType: 1,
            os: 1,
            demographics: 1,
            fullName: {
              $concat: ['$firstName', ' ', { $cond: [{ $in: ['$middleName', [null, '']] }, '', { $concat: ['$middleName', ' '] }] }, '$lastName'],
            },
            totalEngagements: '$engagementTime',
          },
        },
        {
          $addFields: {
            data: {
              $map: {
                input: '$totalEngagements',
                as: 'row',
                in: {
                  duration: '$$row.time',
                  date: { $toDate: { $toObjectId: '$$row._id' } },
                  hour: { $hour: { $toDate: { $toObjectId: '$$row._id' } } },
                  minutes: { $minute: { $toDate: { $toObjectId: '$$row._id' } } },
                  year: { $year: { $toDate: { $toObjectId: '$$row._id' } } },
                  month: { $month: { $toDate: { $toObjectId: '$$row._id' } } },
                  day: { $dayOfMonth: { $toDate: { $toObjectId: '$$row._id' } } },
                },
              },
            },
          },
        },
        {
          $project: {
            _id: 0,
            phone: 1,
            fullName: 1,
            whatsapp: 1,
            brochure: 1,
            demographics: 1,
            campaignID: 1,
            engagementLevel: 1,
            type: 1,
            chatbot: 1,
            device: 1,
            deviceType: 1,
            os: 1,
            source: { $cond: [{ $eq: ['$type', constants.CAMPAIGN_TYPES.SMS.value] }, 'SMS', 'Whatsapp'] },
            engagements: { $filter: { input: '$data', as: 'item', cond: { $ne: ['$$item.duration', 0] } } },
            sum: { $sum: 'this.engagements' },
          },
        },
        {
          $project: {
            _id: 0,
            phone: 1,
            whatsapp: 1,
            brochure: 1,
            chatbot: 1,
            demographics: 1,
            source: 1,
            engagementLevel: 1,
            device: 1,
            deviceType: 1,
            os: 1,
            campaignID: 1,
            fullName: 1,
            engagements: 1,
            clicks: { $size: '$engagements' },
          },
        },
      ])
      const campaignReportDirectory = createCampaignReportDirectory(payload.clientID, campaign.year, campaign.month, campaign.projectID)
      const reportPath = path.join(process.cwd(), campaignReportDirectory, `${payload.campaignID}.json`)
      const reportExists = fs.existsSync(reportPath)
      const jsonData = !_.isNil(data) ? JSON.stringify(data, null, 2) : JSON.stringify([], null, 2)
      if (reportExists) {
        deleteFile(reportPath)
      }
      fs.writeFileSync(reportPath, jsonData)
    } catch (error) {
      if (!_.isNil(error.name) && error.name.includes(CronError.name)) {
        error.stack = 'CronError'
      }
      throw error
    }
    job.progress(100)
    return true
  }

  @OnQueueActive()
  onActive(job: Job<CronPayload<CampaignReportCronPayload>>) {
    this.logger.log(`Processing: Job name: ${cronJobs.CREATE_CAMPAIGN_REPORT.name} Job ID: ${job.id}`)
  }

  @OnQueueCompleted()
  onCompleted(job: Job<CronPayload<CampaignReportCronPayload>>) {
    this.logger.log(`Completed: Job name: ${cronJobs.CREATE_CAMPAIGN_REPORT.name} Job ID: ${job.id}`)
  }

  @OnQueueFailed()
  async onFailed(job: Job<CronPayload<CampaignReportCronPayload>>) {
    const error = job.stacktrace.includes(CronError.name) ? job.failedReason : messages.COM001.message
    this.logger.error(getErrorLog(cronJobs.CREATE_CAMPAIGN_REPORT.name, job.data.traceID, {
      id: job.id, reason: job.failedReason, stack: job.stacktrace, error,
    }))
  }
}

@Injectable()
@Processor(cronJobs.CREATE_REPORT.name)
export class CreateReportProcessor {
  constructor(
    private readonly _socketGateway: ReportsWebSocketGateway,
    @InjectModel(Reports.name) private reportsModel: Model<Reports>,
    @InjectModel(OTP.name) private otpModel: Model<OTP>,
    @InjectModel(Transactional.name) private transactionalModel: Model<Transactional>,
    @InjectModel(DripRequests.name) private dripRequestsModel: Model<DripRequests>,
    private logger: VappLogger,
  ) {}

  @Process({ concurrency: 1 })
  async createReport(job: Job<CronPayload<Reports>>) {
    const { payload } = job.data
    try {
      const start_date = new Date(new Date(payload.start_date).toISOString())
      const end_date = new Date(new Date(payload.end_date).toISOString())
      start_date.setHours(0, 0, 0, 0)
      end_date.setHours(23, 59, 59, 999)
      let report_model: Model<OTP> | Model<Transactional>
      let report_object: { phone: string; short_id: string; credits: string; time: string; delivered: string; attempts?: string; verified?: string }
      let bucket_name: string
      switch (payload.type) {
        case report_types.OTP:
          report_model = this.otpModel
          bucket_name = getEnvironmentVariable(variables.S3_OTP_BUCKET.name)
          report_object = {
            phone: '$phone',
            short_id: '$shortID',
            credits: '$credits',
            time: '$date',
            delivered: '$smsStatus',
            attempts: '$attempts',
            verified: '$verified',
          }
          break
        case report_types.TRANSACTIONAL:
          report_model = this.transactionalModel
          bucket_name = getEnvironmentVariable(variables.S3_TRANSACTIONAL_BUCKET.name)
          report_object = {
            phone: '$phone',
            short_id: '$shortID',
            credits: '$credits',
            time: '$date',
            delivered: '$smsStatus',
          }
          break
      }
      const reports: Array<{ date: string; data: Array<{ short_id: string; attempts: number; verified: boolean; time: Date }> }> = await findOperations.aggregate(report_model, [
        {
          $match: {
            clientID: payload.clientID,
            date: {
              $gte: start_date,
              $lte: end_date,
            },
          },
        },
        {
          $sort: {
            date: 1,
          },
        },
        {
          $group: {
            _id: { $dateToString: { format: '%Y-%m-%d', date: '$date' } },
            date: { $first: { $dateToString: { format: '%Y-%m-%d', date: '$date' } } },
            data: {
              $push: report_object,
            },
          },
        },
        { $project: { _id: 0 } },
      ])

      if (!_.isNil(reports)) {
        S3Handler.getInstance().putObject({
          Bucket: bucket_name,
          Key: `${payload._id}.json`,
          Body: JSON.stringify(reports),
          Expires: new Date(new Date().getTime() + parseInt(getEnvironmentVariable(variables.REPORT_EXPIRY_DAYS.name), 10) * 24 * 60 * 60 * 1000),
          ContentType: contentTypes.APPLICATION.JSON,
        }, async (error, data) => {
          if (_.isNil(error) && !_.isNil(data)) {
            this._socketGateway.server.emit(payload.clientID, {
              event: constants.REPORTS.events.report_processed,
              status: report_status.FINSIHED,
              success: true,
              report_id: payload._id,
              type: payload.type,
            })
            await createOperations.updateOne(this.reportsModel, { _id: payload._id }, { $set: { status: report_status.FINSIHED, url: `${payload._id}.json` } })
            RedisHandler.getInstance(cache_client.DEFAULT, redis_client.CREATE_REPORT).set(redisKeys.USER_REPORT.value(payload.clientID, payload.type, payload._id), 'valid')
            RedisHandler.getInstance(cache_client.DEFAULT, redis_client.CREATE_REPORT).expire(redisKeys.USER_REPORT.value(payload.clientID, payload.type, payload._id), redisKeys.USER_REPORT.timeout())
          } else {
            throw new CronError(error.message)
          }
        })
      } else {
        throw new CronError('report creation failed')
      }
    } catch (error) {
      if (!_.isNil(error.name) && error.name.includes(CronError.name)) {
        error.stack = 'CronError'
      }
      await createOperations.updateOne(this.reportsModel, { _id: payload._id }, { $set: { status: report_status.FAILED } })
      this._socketGateway.server.emit(payload.clientID, {
        status: report_status.FAILED,
        event: constants.REPORTS.events.report_processed,
        success: false,
        report_id: payload._id,
        type: payload.type,
      })
      throw error
    }
    job.progress(100)
    return true
  }

  @OnQueueActive()
  onActive(job: Job<CronPayload<Reports>>) {
    this.logger.log(`Processing: Job name: ${cronJobs.CREATE_REPORT.name} Job ID: ${job.id}`)
  }

  @OnQueueCompleted()
  onCompleted(job: Job<CronPayload<Reports>>) {
    this.logger.log(`Completed: Job name: ${cronJobs.CREATE_REPORT.name} Job ID: ${job.id}`)
  }

  @OnQueueFailed()
  async onFailed(job: Job<CronPayload<Reports>>) {
    const error = job.stacktrace.includes(CronError.name) ? job.failedReason : messages.COM001.message
    this.logger.error(getErrorLog(cronJobs.CREATE_REPORT.name, job.data.traceID, {
      id: job.id, reason: job.failedReason, stack: job.stacktrace, error,
    }))
  }
}
