import { cronJobs, redis_client, variables } from '@config'
import { BullModule } from '@nestjs/bull'
import { getEnvironmentVariable } from '@utils/platform.util'

const redis = {
  host: getEnvironmentVariable(variables.REDIS_URL.name),
  port: getEnvironmentVariable(variables.REDIS_PORT.name)
}

export const CreateCampaignReportQueueModule = BullModule.registerQueueAsync({
  name: cronJobs.CREATE_CAMPAIGN_REPORT.name,
  useFactory: () => ({
    redis: { ...redis, db: redis_client.CREATE_CAMPAIGN_REPORT },
    defaultJobOptions: {
      priority: cronJobs.CREATE_CAMPAIGN_REPORT.priority,
      removeOnComplete: true,
      removeOnFail: false,
      attempts: cronJobs.CREATE_CAMPAIGN_REPORT.attempts
    },
    prefix: cronJobs.CREATE_CAMPAIGN_REPORT.name,
    settings: {
      lockRenewTime: cronJobs.CREATE_CAMPAIGN_REPORT.lockRenew,
      maxStalledCount: cronJobs.CREATE_CAMPAIGN_REPORT.maxStalledCount,
      lockDuration: cronJobs.CREATE_CAMPAIGN_REPORT.lockLifeTime
    }
  })
})

export const ReportsQueueModule = BullModule.registerQueueAsync({
  name: cronJobs.CREATE_REPORT.name,
  useFactory: () => ({
    redis: { ...redis, db: redis_client.CREATE_REPORT },
    defaultJobOptions: {
      priority: cronJobs.CREATE_REPORT.priority,
      removeOnComplete: true,
      removeOnFail: false,
      attempts: cronJobs.CREATE_REPORT.attempts
    },
    prefix: cronJobs.CREATE_REPORT.name,
    settings: {
      retryProcessDelay: cronJobs.CREATE_REPORT.retryProcessDelay,
      lockRenewTime: cronJobs.CREATE_REPORT.lockRenew,
      maxStalledCount: cronJobs.CREATE_REPORT.maxStalledCount,
      lockDuration: cronJobs.CREATE_REPORT.lockLifeTime
    }
  })
})
