import { Campaign } from '@app/campaign/campaign.schema'
import { DripCampaign } from '@app/campaign/drip_campaign.schema'
import { Requests } from '@app/requests/requests.schema'
import { canonicalMethods, constants } from '@config'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { HttpStatus, Inject, Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { findOperations } from '@utils/crud.util'
import { getAPIResponse, getErrorLog, getExpirationTimestamp } from '@utils/platform.util'
import fs from 'fs'
import _ from 'lodash'
import { TransactionOptions } from 'mongodb'
import { Model } from 'mongoose'
import path from 'path'
import { createCampaignReportDirectory } from './helpers/reports.helper'

@Injectable()
export class ReportsService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    private logger: VappLogger,
    @InjectModel(Requests.name) private requestsModel: Model<Requests>,
    @InjectModel(Campaign.name) private campaignModel: Model<Campaign>,
    @InjectModel(DripCampaign.name) private dripcampaignModel : Model<DripCampaign>,
  ) {
    this.traceID = vapp_context.traceID
  }

  fetchMaster = (clientID: string, projectIDs: string[], engagementLevels: number[], month: number) => new Promise<ServiceResponse>(async (resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
    try {
      const campaigns: Campaign[] = await findOperations.findLean(this.campaignModel, {
        clientID,
        year: new Date().getFullYear(),
        month,
      }, { _id: 1, campaignName: 1 }, {})
      const data = await findOperations.aggregate(this.requestsModel, [
        {
          $match: {
            projectID: { $in: projectIDs },
            engagementLevel: { $in: [0, ...engagementLevels] },
            clientID,
            year: new Date().getFullYear(),
            month,
            $or: [{ visited: true }, { ivr: { $exists: true, $not: { $size: 0 } } }],
          },
        },
        {
          $project: {
            _id: '$_id',
            projectID: 1,
            campaignID: 1,
            phone: 1,
            whatsapp: 1,
            brochure: 1,
            type: 1,
            engagementLevel: 1,
            device: 1,
            deviceType: 1,
            os: 1,
            demographics: 1,
            chatbot: 1,
            ivr: {
              $cond: [{ $gte: [{ $size: { $ifNull: ['$ivr', []] } }, 1] }, true, false],
            },
            fullName: {
              $concat: ['$firstName', ' ', { $cond: [{ $in: ['$middleName', [null, '']] }, '', { $concat: ['$middleName', ' '] }] }, '$lastName'],
            },
            totalEngagements: '$engagementTime',
          },
        },
        {
          $addFields: {
            data: {
              $map: {
                input: '$totalEngagements',
                as: 'row',
                in: {
                  duration: '$$row.time',
                  date: { $toDate: { $toObjectId: '$$row._id' } },
                  hour: { $hour: { $toDate: { $toObjectId: '$$row._id' } } },
                  minutes: { $minute: { $toDate: { $toObjectId: '$$row._id' } } },
                  year: { $year: { $toDate: { $toObjectId: '$$row._id' } } },
                  month: { $month: { $toDate: { $toObjectId: '$$row._id' } } },
                  day: { $dayOfMonth: { $toDate: { $toObjectId: '$$row._id' } } },
                },
              },
            },
          },
        },
        {
          $project: {
            _id: 0,
            phone: 1,
            whatsapp: 1,
            brochure: 1,
            campaignID: 1,
            type: 1,
            chatbot: 1,
            projectID: 1,
            fullName: 1,
            engagementLevel: 1,
            device: 1,
            deviceType: 1,
            os: 1,
            demographics: 1,
            engagements: { $filter: { input: '$data', as: 'item', cond: { $ne: ['$$item.duration', 0] } } },
            sum: { $sum: 'this.engagements' },
            ivr: 1,
          },
        },
        {
          $project: {
            _id: 0,
            phone: 1,
            projectID: 1,
            brochure: 1,
            campaignID: 1,
            chatbot: 1,
            type: 1,
            whatsapp: 1,
            engagementLevel: 1,
            device: 1,
            deviceType: 1,
            os: 1,
            demographics: 1,
            fullName: 1,
            engagements: 1,
            clicks: { $size: '$engagements' },
            ivr: 1,
          },
        },
        {
          $lookup: {
            from: 'tracking',
            let: { cID: '$campaignID', ph: '$phone' },
            pipeline: [
              {
                $match: {
                  $expr: { $and: [{ $eq: ['$campaignID', '$$cID'] }, { $eq: ['$phone', '$$ph'] }] },
                  events: { $exists: true, $not: { $size: 0 } },
                },
              },
              // {$group: {event: {$first: '$events'}} },
              { $project: { _id: 0, event: '$events' } },
            ],
            as: 'event',
          },
        },
        {
          $project: {
            _id: 0,
            phone: 1,
            projectID: 1,
            brochure: 1,
            campaignID: 1,
            chatbot: 1,
            type: 1,
            whatsapp: 1,
            engagementLevel: 1,
            device: 1,
            deviceType: 1,
            os: 1,
            demographics: 1,
            fullName: 1,
            engagements: 1,
            ivr: 1,
            event: { $cond: [{ $gte: [{ $size: '$event' }, 1] }, true, false] },
          },
        },
        // till here event is array for some reason
        {
          $group: {
            _id: '$projectID',
            projectID: { $first: '$projectID' },
            phones: { $push: '$phone' },
            whatsapp: { $push: '$whatsapp' },
            brochure: { $push: '$brochure' },
            campaignID: { $push: '$campaignID' },
            chatbot: { $push: '$chatbot' },
            names: { $push: '$fullName' },
            sources: { $push: { $cond: [{ $eq: ['$type', constants.CAMPAIGN_TYPES.SMS.value] }, 'SMS', 'Whatsapp'] } },
            engagements: { $push: '$engagements' },
            clicks: { $push: { $size: '$engagements' } },
            engagementLevel: { $push: '$engagementLevel' },
            device: { $push: '$device' },
            deviceType: { $push: '$deviceType' },
            os: { $push: '$os' },
            demographics: { $push: '$demographics' },
            ivr: { $push: '$ivr' },
            events: { $push: '$event' },
          },
        },
        {
          $project: {
            _id: 0,
            whatsapp: 1,
            projectID: { $toObjectId: '$projectID' },
            names: 1,
            phones: 1,
            chatbot: 1,
            campaignID: 1,
            engagementLevel: 1,
            device: 1,
            deviceType: 1,
            os: 1,
            demographics: 1,
            brochure: 1,
            clicks: 1,
            sources: 1,
            engagements: 1,
            ivr: 1,
            events: 1,
          },
        },
        {
          $lookup: {
            from: 'projects',
            let: { pID: '$projectID' },
            pipeline: [
              {
                $match: {
                  $expr: { $eq: ['$_id', '$$pID'] },
                },
              },
              { $project: { name: 1, _id: 0, project: { name: '$name', projectID: '$_id' } } },
              { $replaceRoot: { newRoot: '$project' } },
            ],
            as: 'project',
          },
        },
        {
          $project: {
            _id: 0,
            phone: 1,
            project: 1,
            names: 1,
            phones: 1,
            sources: 1,
            chatbot: 1,
            brochure: 1,
            campaignID: 1,
            whatsapp: 1,
            clicks: 1,
            engagementLevel: 1,
            device: 1,
            deviceType: 1,
            os: 1,
            demographics: 1,
            engagements: 1,
            call: '$ivr',
            events: 1,
          },
        },
        {
          $unwind: {
            path: '$project',
            preserveNullAndEmptyArrays: true,
          },
        },
      ])
      if (!_.isNil(data)) {
        _.map(data, (project) => {
          const campaignNames = []
          _.each(project.campaignID, (campaignID) => {
            campaignNames.push(this.sanatiseCampaignName(campaigns.find((campaign) => _.eq(String(campaign._id), String(campaignID)))?.campaignName))
          })
          _.set(project, 'campaignNames', campaignNames)
          return project
        })

        resolve(getAPIResponse(messages.REP001.code, this.traceID, HttpStatus.OK, data))
      } else {
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      }
    } catch (error) {
      this.logger.error(getErrorLog(canonicalMethods.CLIENT_FETCH_MASTER_REPORT, this.traceID, { clientID, error }, error.message))
      resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
    }
  })

  fetchProject = (clientID: string, projectID: string, engagementLevels: number[], month: number) => new Promise<ServiceResponse>(async (resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
    try {
      const campaigns: Campaign[] = await findOperations.findLean(this.campaignModel, {
        clientID,
        year: new Date().getFullYear(),
        month,
        projectID,
      }, { _id: 1, campaignName: 1 }, {})
      let data = await findOperations.aggregate(this.requestsModel, [
        {
          $match: {
            projectID,
            year: new Date().getFullYear(),
            month,
            clientID,
            engagementLevel: { $in: [0, ...engagementLevels] },
            $or: [{ visited: true }, { ivr: { $exists: true, $not: { $size: 0 } } }],
          },
        },
        {
          $project: {
            _id: '$_id',
            phone: 1,
            whatsapp: 1,
            type: 1,
            brochure: 1,
            chatbot: 1,
            engagementLevel: 1,
            device: 1,
            deviceType: 1,
            os: 1,
            demographics: 1,
            campaignID: 1,
            fullName: {
              $concat: ['$firstName', ' ', { $cond: [{ $in: ['$middleName', [null, '']] }, '', { $concat: ['$middleName', ' '] }] }, '$lastName'],
            },
            totalEngagements: '$engagementTime',
            ivr: {
              $cond: [{ $gte: [{ $size: { $ifNull: ['$ivr', []] } }, 1] }, true, false],
            },
          },
        },
        {
          $addFields: {
            data: {
              $map: {
                input: '$totalEngagements',
                as: 'row',
                in: {
                  duration: '$$row.time',
                  date: { $toDate: { $toObjectId: '$$row._id' } },
                  hour: { $hour: { $toDate: { $toObjectId: '$$row._id' } } },
                  minutes: { $minute: { $toDate: { $toObjectId: '$$row._id' } } },
                  year: { $year: { $toDate: { $toObjectId: '$$row._id' } } },
                  month: { $month: { $toDate: { $toObjectId: '$$row._id' } } },
                  day: { $dayOfMonth: { $toDate: { $toObjectId: '$$row._id' } } },
                },
              },
            },
          },
        },
        {
          $project: {
            _id: 0,
            phone: 1,
            fullName: 1,
            whatsapp: 1,
            brochure: 1,
            engagementLevel: 1,
            device: 1,
            deviceType: 1,
            os: 1,
            demographics: 1,
            campaignID: 1,
            type: 1,
            chatbot: 1,
            source: { $cond: [{ $eq: ['$type', constants.CAMPAIGN_TYPES.SMS.value] }, 'SMS', 'Whatsapp'] },
            engagements: { $filter: { input: '$data', as: 'item', cond: { $ne: ['$$item.duration', 0] } } },
            sum: { $sum: 'this.engagements' },
            ivr: 1,
          },
        },
        {
          $project: {
            _id: 0,
            phone: 1,
            whatsapp: 1,
            brochure: 1,
            chatbot: 1,
            source: 1,
            engagementLevel: 1,
            device: 1,
            deviceType: 1,
            os: 1,
            demographics: 1,
            campaignID: 1,
            fullName: 1,
            engagements: 1,
            clicks: { $size: '$engagements' },
            ivr: 1,
          },
        },
        {
          $lookup: {
            from: 'tracking',
            let: { cID: '$campaignID', ph: '$phone' },
            pipeline: [
              {
                $match: {
                  $expr: { $and: [{ $eq: ['$campaignID', '$$cID'] }, { $eq: ['$phone', '$$ph'] }] },
                  events: { $exists: true, $not: { $size: 0 } },
                },
              },
              // {$group: {event: {$first: '$events'}} },
              { $project: { _id: 0, event: '$events' } },
            ],
            as: 'event',
          },
        },
        {
          $project: {
            _id: 0,
            phone: 1,
            projectID: 1,
            brochure: 1,
            campaignID: 1,
            chatbot: 1,
            type: 1,
            whatsapp: 1,
            engagementLevel: 1,
            device: 1,
            deviceType: 1,
            os: 1,
            demographics: 1,
            fullName: 1,
            engagements: 1,
            clicks: 1,
            call: '$ivr',
            event: { $cond: [{ $gte: [{ $size: '$event' }, 1] }, true, false] },
          },
        },
      ])
      if (!_.isNil(data)) {
        data = _.map(data, (element) => ({
          campaignName: this.sanatiseCampaignName(campaigns.find((campaign) => _.eq(String(campaign._id), String(element.campaignID)))?.campaignName),
          ...element,
        }))
        resolve(getAPIResponse(messages.REP002.code, this.traceID, HttpStatus.OK, data))
      } else {
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      }
    } catch (error) {
      this.logger.error(getErrorLog(canonicalMethods.CLIENT_FETCH_MASTER_REPORT, this.traceID, { clientID, error }, error.message))
      resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
    }
  })

  fetchCampaignReport = (clientID: string, campaignID: string, engagementLevels: number[]) => new Promise<ServiceResponse>(async (resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
    try {
      const campaign: Campaign = await findOperations.findOne(this.campaignModel, { _id: campaignID, clientID }, {})
      if (!_.isNil(campaign)) {
        const isExpired = getExpirationTimestamp(campaign.token) - Date.now() / 1000 < 0
        if (!isExpired || true) {
          const data = await findOperations.aggregate(this.requestsModel, [
            {
              $match: {
                campaignID,
                clientID,
                engagementLevel: { $in: [0, ...engagementLevels] },
                year: new Date().getFullYear(),
                $or: [{ visited: true }, { ivr: { $exists: true, $not: { $size: 0 } } }],
              },
            },
            {
              $project: {
                _id: '$_id',
                phone: 1,
                whatsapp: 1,
                type: 1,
                brochure: 1,
                chatbot: 1,
                engagementLevel: 1,
                campaignID: 1,
                device: 1,
                deviceType: 1,
                os: 1,
                demographics: 1,
                fullName: {
                  $concat: ['$firstName', ' ', { $cond: [{ $in: ['$middleName', [null, '']] }, '', { $concat: ['$middleName', ' '] }] }, '$lastName'],
                },
                totalEngagements: '$engagementTime',
                ivr: {
                  $cond: [{ $gte: [{ $size: { $ifNull: ['$ivr', []] } }, 1] }, true, false],
                },
              },
            },
            {
              $addFields: {
                data: {
                  $map: {
                    input: '$totalEngagements',
                    as: 'row',
                    in: {
                      duration: '$$row.time',
                      date: { $toDate: { $toObjectId: '$$row._id' } },
                      hour: { $hour: { $toDate: { $toObjectId: '$$row._id' } } },
                      minutes: { $minute: { $toDate: { $toObjectId: '$$row._id' } } },
                      year: { $year: { $toDate: { $toObjectId: '$$row._id' } } },
                      month: { $month: { $toDate: { $toObjectId: '$$row._id' } } },
                      day: { $dayOfMonth: { $toDate: { $toObjectId: '$$row._id' } } },
                    },
                  },
                },
              },
            },
            {
              $project: {
                _id: 0,
                phone: 1,
                fullName: 1,
                whatsapp: 1,
                brochure: 1,
                demographics: 1,
                campaignID: 1,
                engagementLevel: 1,
                type: 1,
                chatbot: 1,
                device: 1,
                deviceType: 1,
                os: 1,
                source: { $cond: [{ $eq: ['$type', constants.CAMPAIGN_TYPES.SMS.value] }, 'SMS', 'Whatsapp'] },
                engagements: { $filter: { input: '$data', as: 'item', cond: { $ne: ['$$item.duration', 0] } } },
                sum: { $sum: 'this.engagements' },
                ivr: 1,
              },
            },
            {
              $project: {
                _id: 0,
                phone: 1,
                whatsapp: 1,
                brochure: 1,
                chatbot: 1,
                demographics: 1,
                source: 1,
                engagementLevel: 1,
                device: 1,
                deviceType: 1,
                os: 1,
                campaignID: 1,
                fullName: 1,
                engagements: 1,
                clicks: { $size: '$engagements' },
                ivr: 1,
              },
            },
            {
              $lookup: {
                from: 'tracking',
                let: { cID: '$campaignID', ph: '$phone' },
                pipeline: [
                  {
                    $match: {
                      $expr: { $and: [{ $eq: ['$campaignID', '$$cID'] }, { $eq: ['$phone', '$$ph'] }] },
                      events: { $exists: true, $not: { $size: 0 } },
                    },
                  },
                  // {$group: {event: {$first: '$events'}} },
                  { $project: { _id: 0, event: '$events' } },
                ],
                as: 'event',
              },
            },
            {
              $project: {
                _id: 0,
                phone: 1,
                projectID: 1,
                brochure: 1,
                campaignID: 1,
                chatbot: 1,
                type: 1,
                whatsapp: 1,
                engagementLevel: 1,
                device: 1,
                deviceType: 1,
                os: 1,
                demographics: 1,
                fullName: 1,
                engagements: 1,
                clicks: 1,
                call: '$ivr',
                event: { $cond: [{ $gte: [{ $size: '$event' }, 1] }, true, false] },
              },
            },
          ])
          if (!_.isNil(data)) {
            resolve(getAPIResponse(messages.REP005.code, this.traceID, HttpStatus.OK, data))
          } else {
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          }
        } else {
        }
      } else {
        resolve(getAPIResponse(messages.CAM043.code, this.traceID, HttpStatus.NOT_FOUND))
      }
    } catch (error) {
      this.logger.error(getErrorLog(canonicalMethods.CLIENT_FETCH_MASTER_REPORT, this.traceID, { clientID, error }, error.message))
      resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
    }
  })

  fetchCampaignDeliveryReport = (clientID: string, campaignID: string, campaignType:string) => new Promise<ServiceResponse>(async (resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
    try {
      let campaign = null
      if (campaignType === 'campaign') {
        campaign = await findOperations.findOne(this.campaignModel, { _id: campaignID, clientID }, {})
      } else {
        campaign = await findOperations.findOne(this.dripcampaignModel, { _id: campaignID }, {})
      }
      if (!_.isNil(campaign)) {
        const campaignReportDirectory = createCampaignReportDirectory(clientID, campaign.year, campaign.month, campaign.projectID)

        const fileExists = fs.existsSync(path.join(process.cwd(), campaignReportDirectory, `delivery_${campaignID}.json`))

        if (fileExists) {
          const data = fs.readFileSync(path.join(process.cwd(), campaignReportDirectory, `delivery_${campaignID}.json`), 'utf8')
          resolve(getAPIResponse(messages.REP006.code, this.traceID, HttpStatus.OK, JSON.parse(data)))
        } else {
          resolve(getAPIResponse(messages.CAM046.code, this.traceID, HttpStatus.NOT_FOUND))
        }
      } else {
        resolve(getAPIResponse(messages.CAM043.code, this.traceID, HttpStatus.NOT_FOUND))
      }
    } catch (error) {
      this.logger.error(getErrorLog(canonicalMethods.CLIENT_FETCH_MASTER_REPORT, this.traceID, { clientID, error }, error.message))
      resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
    }
  })

  sanatiseCampaignName = (campaignName: string) => {
    let result = 'N/A'
    if (!_.isNil(campaignName) && !_.isEmpty(campaignName.trim())) {
      result = campaignName.trim()
    }
    return result
  }
}
