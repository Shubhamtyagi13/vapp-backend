import { Requests } from '@app/requests/requests.schema'
import { audience, environments, variables } from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Body, Controller, Get, Param, Post, Req, Res, UseGuards,
} from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { ApiBearerAuth, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import { Model } from 'mongoose'
import { CampaignReportsDTO, MasterReportsDTO, ProjectReportsDTO } from './dto/reports.dto'
import { ReportsService } from './reports.service'

@ApiTags(ReportsController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('reports')
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class ReportsController {
  constructor(@InjectModel(Requests.name) private creditsModel: Model<Requests>, private requestsService: ReportsService) {}

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post('master')
  fetchMaster(@Res() response: Response, @Req() request: Request, @Body() payload: MasterReportsDTO) {
    this.requestsService.fetchMaster(request.user._id, payload.projects, payload.engagementLevels, payload.month).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post('project/:projectID')
  fetchProject(@Param('projectID') projectID: string, @Req() request: Request, @Res() response: Response, @Body() payload: ProjectReportsDTO) {
    this.requestsService.fetchProject(request.user._id, projectID, payload.engagementLevels, payload.month).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post('campaign/:campaignID')
  fetchCampaignReport(@Param('campaignID') campaignID: string, @Req() request: Request, @Res() response: Response, @Body() payload: CampaignReportsDTO) {
    this.requestsService.fetchCampaignReport(request.user._id, campaignID, payload.engagementLevels).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get('campaign/delivery/:campaignID/:campaignType')
  fetchCampaignDeliveryReport(@Param('campaignID') campaignID: string, @Param('campaignType') campaignType: string, @Req() request: Request, @Res() response: Response) {
    console.log('fetchCampaignDeliveryReport', campaignType)
    this.requestsService.fetchCampaignDeliveryReport(request.user._id, campaignID, campaignType).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }
}
