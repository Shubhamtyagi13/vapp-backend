import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsValidMongoIDs } from '@transformers/mongo-id.transformer'
import { Type } from 'class-transformer'
import { ArrayMaxSize, ArrayMinSize, IsArray, IsIn, IsNumber, Max, Min } from 'class-validator'

export class CampaignReportsDTO extends ClientUserIDDTO {
  @ApiProperty({ required: true })
  @ArrayMinSize(1)
  @ArrayMaxSize(3)
  @IsArray()
  @IsIn([1, 2, 3], { each: true })
  @Type(() => Number)
  readonly engagementLevels: number[]
}

export class ProjectReportsDTO extends ClientUserIDDTO {
  @ApiProperty({ required: true })
  @ArrayMinSize(1)
  @ArrayMaxSize(3)
  @IsArray()
  @IsIn([1, 2, 3], { each: true })
  @Type(() => Number)
  readonly engagementLevels: number[]

  @ApiProperty({ required: true })
  @Min(1)
  @Max(12)
  @IsNumber()
  readonly month: number
}

export class MasterReportsDTO extends ClientUserIDDTO {
  @ApiProperty({ required: true })
  @ArrayMinSize(1)
  @ArrayMaxSize(3)
  @IsArray()
  @IsIn([1, 2, 3], { each: true })
  @Type(() => Number)
  readonly engagementLevels: number[]

  @ApiProperty({ required: true })
  @Min(1)
  @Max(12)
  @IsNumber()
  readonly month: number

  @ApiProperty({ required: true })
  @ArrayMinSize(1)
  @IsArray()
  @IsValidMongoIDs()
  @Type(() => String)
  readonly projects: string[]
}
