import { audience, contentTypes, environments, variables } from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import { Controller, Post, Res, Headers, Body, Get, Param, Req, UseGuards, Query, HttpStatus } from '@nestjs/common'
import { ApiBearerAuth, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { HTTPService } from '@services/http.service'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Response, Request } from 'express'
import _ from 'lodash'
import { AxiosResponse } from 'axios'
import { IVRFinalizeDTO } from './dto/finalize'
import { IVRWebhookDTO } from './dto/webhook'
import { IVRService } from './ivr.service'

/*
  ivr webhook controller
*/
@ApiTags(IVRController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('ivr')
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class IVRController {
  constructor(private ivrService: IVRService) {}

  @Post('webhook')
  ivrWebhook(@Req() request: Request, @Res() response: Response, @Headers('vapp_header') ivrSecret: string, @Body() ivrData: IVRWebhookDTO) {
    this.ivrService.processWebhook(ivrSecret, ivrData).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Post('knowlarity')
  ivrWebhookStallion(@Req() request: Request, @Res() response: Response, @Headers('vapp_header') ivrSecret: string, @Body() ivrData: any) {
    const data = {} as IVRWebhookDTO
    let status = ''
    if (!_.isNil(ivrData) && !_.isEmpty(ivrData) && !_.isNil(ivrData[0].Data.Note)) {
      try {
        const dummyObj = { SourceData: '' }
        ivrData[0].Data.Note.split('{next}').forEach((e) => {
          const sub_split = e.split('{=}')
          _.set(dummyObj, sub_split[0], sub_split[1])
        })
        const dummyJson = JSON.parse(dummyObj.SourceData.replace(/'/g, '"'))
        data.call_to_number = dummyJson.DisplayNumber?.trim()
        data.caller_id_number = dummyJson.SourceNumber?.trim()
        data.uuid = dummyJson.CallSessionId
        data.duration = `${dummyJson.CallDuration}`
        data.recording_url = `${dummyJson.ResourceURL}`
        data.start_stamp = dummyJson.StartTime
        status = dummyJson.Status
      } catch (e) {}
    }
    this.ivrService.processWebhookStallion(data, status).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Get('knowlarity_call')
  downloadURL(@Req() request: Request, @Res() response: Response, @Query('url') url: string) {
    HTTPService.getInstance()
      .getStream(url)
      .then((res: AxiosResponse<any>) => {
        response.writeHead(200, {
          'Content-Type': 'audio/mpeg'
        })
        res.data.pipe(response)
      })
      .catch((e) => {
        response.status(HttpStatus.INTERNAL_SERVER_ERROR).send()
      })
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get('report/:campaignID')
  ivrReport(@Req() request: Request, @Param('campaignID') campaignID: string, @Res() response: Response) {
    this.ivrService.ivrReport(campaignID, request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post('finalize/:campaignID')
  ivrReportFinalize(@Req() request: Request, @Param('campaignID') campaignID: string, @Body() payload: IVRFinalizeDTO, @Res() response: Response) {
    this.ivrService.ivrFinalizeReport(campaignID, request.user._id, payload).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get('data/:campaignID')
  getIvrData(@Req() request: Request, @Param('campaignID') campaignID: string, @Res() response: Response) {
    this.ivrService.getIvrData(campaignID, request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }
}
