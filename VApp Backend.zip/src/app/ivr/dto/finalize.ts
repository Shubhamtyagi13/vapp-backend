import { constants } from '@config'
import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import { Type } from 'class-transformer'
import { ArrayMinSize, IsArray, IsDefined, IsEnum, IsNumber, IsString, ValidateNested } from 'class-validator'

export class IVRFinalizeObjectDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  @IsValidPhone()
  phone: number

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  @IsEnum([constants.LEAD_TYPE.positive, constants.LEAD_TYPE.negative, constants.LEAD_TYPE.neutral])
  status: string
}
export class IVRFinalizeDTO {
  @ApiProperty({ required: true })
  @IsArray()
  @ArrayMinSize(1)
  @IsDefined()
  @ValidateNested({ each: true })
  @Type(() => IVRFinalizeObjectDTO)
  data: IVRFinalizeObjectDTO[]
}
