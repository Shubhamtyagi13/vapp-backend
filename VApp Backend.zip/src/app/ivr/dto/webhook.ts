import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsDateString, IsDefined, IsMongoId, IsNumber, IsOptional, IsString, IsUrl } from 'class-validator'

export class IVRWebhookDTO {
  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  uuid: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  call_to_number: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  caller_id_number: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  start_stamp: string

  @ApiProperty({ required: true })
  @IsString()
  @IsOptional()
  duration: string

  @ApiProperty({ required: true })
  @IsString()
  @IsOptional()
  recording_url: string
}
