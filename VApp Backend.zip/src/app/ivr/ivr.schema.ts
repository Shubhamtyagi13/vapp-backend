import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.IVR.collection, autoCreate: false, _id: false })
export class IVR extends Document {
  @Prop({ type: Number, required: true, index: true })
  duration: number

  @Prop({ type: String, default: null })
  recording_url: string

  @Prop({ type: Date, index: true, required: true })
  start_stamp: Date

  @Prop({ type: String, required: true, index: true })
  uuid: string
}

export interface IVRQueryResult{
  phone: number
  ivr: IVR
}

export const IVRSchema = SchemaFactory.createForClass(IVR)
