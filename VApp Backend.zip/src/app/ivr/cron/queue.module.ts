import { cronJobs, redis_client, variables } from '@config'
import { BullModule } from '@nestjs/bull'
import { getEnvironmentVariable } from '@utils/platform.util'

const redis = {
  host: getEnvironmentVariable(variables.REDIS_URL.name),
  port: getEnvironmentVariable(variables.REDIS_PORT.name)
}

export const IVRQueueModule = BullModule.registerQueueAsync({
  name: cronJobs.IVR_WEBHOOK.name,
  useFactory: () => ({
    redis: { ...redis, db: redis_client.IVR_WEBHOOK },
    defaultJobOptions: {
      priority: cronJobs.IVR_WEBHOOK.priority,
      removeOnComplete: true,
      removeOnFail: false,
      attempts: cronJobs.IVR_WEBHOOK.attempts
    },
    prefix: cronJobs.IVR_WEBHOOK.name,
    settings: {
      lockRenewTime: cronJobs.IVR_WEBHOOK.lockRenew,
      maxStalledCount: cronJobs.IVR_WEBHOOK.maxStalledCount,
      lockDuration: cronJobs.IVR_WEBHOOK.lockLifeTime
    }
  })
})

export const IVRFinalizeQueueModule = BullModule.registerQueueAsync({
  name: cronJobs.IVR_WEBHOOK_FINALIZE.name,
  useFactory: () => ({
    redis: { ...redis, db: redis_client.IVR_WEBHOOK_FINALIZE },
    defaultJobOptions: {
      priority: cronJobs.IVR_WEBHOOK_FINALIZE.priority,
      removeOnComplete: true,
      removeOnFail: false,
      attempts: cronJobs.IVR_WEBHOOK_FINALIZE.attempts
    },
    prefix: cronJobs.IVR_WEBHOOK_FINALIZE.name,
    settings: {
      lockRenewTime: cronJobs.IVR_WEBHOOK_FINALIZE.lockRenew,
      maxStalledCount: cronJobs.IVR_WEBHOOK_FINALIZE.maxStalledCount,
      lockDuration: cronJobs.IVR_WEBHOOK_FINALIZE.lockLifeTime
    }
  })
})
