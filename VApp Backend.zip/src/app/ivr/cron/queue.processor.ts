import { Campaign } from '@app/campaign/campaign.schema'
import { ContactDatabase } from '@app/contact/contact.database.schema'
import { Contact } from '@app/contact/contact.schema'
import { UploadContactDTO } from '@app/contact/dto/upload-contacts.dto'
import { Requests } from '@app/requests/requests.schema'
import { canonicalMethods, constants, cronJobs, redisKeys, variables } from '@config'
import { CronPayload } from '@interfaces/cron.interface'
import { CronError } from '@interfaces/error.interface'
import { messages } from '@messages'
import { OnQueueActive, OnQueueCompleted, OnQueueFailed, Process, Processor } from '@nestjs/bull'
import { Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { ConfigHandler } from '@utils/config.util'
import { createOperations, findOperations } from '@utils/crud.util'
import { getErrorLog } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import async from 'async'
import { Job } from 'bull'
import _ from 'lodash'
import { TransactionOptions } from 'mongodb'
import mongoose, { Model } from 'mongoose'
import { IVRFinalizeObjectDTO } from '../dto/finalize'
import { IVRWebhookDTO } from '../dto/webhook'

@Injectable()
@Processor(cronJobs.IVR_WEBHOOK.name)
export class IVRWebhookProcessor {
  constructor(
    @InjectModel(Campaign.name) private campaignsModel: Model<Campaign>,
    @InjectModel(Contact.name) private contactsModel: Model<Contact>,
    @InjectModel(ContactDatabase.name) private contactDatabaseModel: Model<ContactDatabase>,
    @InjectModel(Requests.name) private requestModel: Model<Requests>,
    private logger: VappLogger
  ) {}

  @Process({ concurrency: 1 })
  async processIVRWebhook(job: Job<CronPayload<IVRWebhookDTO>>) {
    const { payload, traceID } = job.data
    const original_calling_date = new Date(payload.start_stamp)
    const search_date = new Date(payload.start_stamp)
    // set 48 hours prior date for searching
    search_date.setDate(search_date.getDate() - 2)
    if (_.eq(payload.call_to_number.length, 12)) {
      payload.call_to_number = payload.call_to_number.slice(2)
    }
    if (_.eq(payload.caller_id_number.length, 12)) {
      payload.caller_id_number = payload.caller_id_number.slice(2)
    }
    const ivr_number = Number(payload.call_to_number)
    const user_number = Number(payload.caller_id_number)
    const call_duration = Number(payload.duration)
    const crossed_threshold = _.gte(call_duration, Number(ConfigHandler.getInstance().getValue(variables.IVR_CALL_THRESHOLD.name)))
    const search_timestamp = Math.floor(search_date.getTime() / 1000)
    const search_object_id = mongoose.Types.ObjectId.createFromTime(search_timestamp)
    try {
      let contactsDatabases: ContactDatabase[]
      const requests: Requests[] = await findOperations.find(this.requestModel, { phone: user_number, _id: { $gt: search_object_id } }, {}, {})
      if (!_.isEmpty(requests)) {
        const campaignIDS: string[] = requests.map((e) => e.campaignID)
        const campaign: Campaign = await findOperations.findOneLeanSort(this.campaignsModel, { _id: { $in: campaignIDS }, ivr: ivr_number }, {}, { _id: -1 })
        const call_object = <IVRWebhookDTO>(<unknown>{
          duration: call_duration,
          recording_url: payload.recording_url,
          start_stamp: original_calling_date,
          uuid: payload.uuid
        })
        if (!_.isNil(campaign)) {
          const requestUpdateResult = await createOperations.updateOneWithoutFind(this.requestModel, { phone: user_number, campaignID: _.toString(campaign._id) }, { $addToSet: { ivr: call_object } })
          const updateCount = requestUpdateResult?.nModified || requestUpdateResult?.modifiedCount || 0
          const campaignUpdateResult = await createOperations.updateOne(this.campaignsModel, { _id: _.toString(campaign._id) }, { $inc: { calls: updateCount, callsThreshold: !_.eq(updateCount, 0) ? (crossed_threshold ? 1 : 0) : 0 } })
          if (!_.isNil(campaign.databaseID)) {
            await createOperations.updateOne(this.contactDatabaseModel, { _id: campaign.databaseID }, { $inc: { calls: updateCount, callsThreshold: !_.eq(updateCount, 0) ? (crossed_threshold ? 1 : 0) : 0 } })
            contactsDatabases = await findOperations.find(this.contactDatabaseModel, { clientID: campaignUpdateResult.clientID }, { __v: 0, password: 0 }, {})
          }
          if (!_.isNil(contactsDatabases)) {
            RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(campaign.clientID), JSON.stringify(contactsDatabases))
            RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(campaign.clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
          }
          if (!_.isNil(campaignUpdateResult)) {
            RedisHandler.getInstance().set(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), JSON.stringify(campaignUpdateResult))
            RedisHandler.getInstance().ttl(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), (error: Error, time: number) => {
              if (_.isNil(error) && _.isNumber(time)) {
                RedisHandler.getInstance().expire(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), time)
              } else {
                this.logger.error(getErrorLog(canonicalMethods.PROCESS_IVR_WEBHOOK, traceID, { payload }, messages.CAM032.message))
              }
            })
          }
        } else {
          throw new CronError(messages.IVR003.message)
        }
      } else {
        throw new CronError(messages.IVR004.message)
      }
    } catch (error) {
      this.logger.error(getErrorLog(cronJobs.IVR_WEBHOOK.name, traceID, { error, payload }, error.message))
      if (!_.isNil(error.name) && error.name.includes(CronError.name)) {
        error.stack = 'CronError'
      }
      throw error
    }
    job.progress(100)
    return true
  }

  @OnQueueActive()
  onActive(job: Job<CronPayload<UploadContactDTO>>) {
    this.logger.log(`Processing: Job name: ${cronJobs.IVR_WEBHOOK.name} Job ID: ${job.id}`)
  }

  @OnQueueCompleted()
  onCompleted(job: Job<CronPayload<UploadContactDTO>>) {
    this.logger.log(`Completed: Job name: ${cronJobs.IVR_WEBHOOK.name} Job ID: ${job.id}`)
  }

  @OnQueueFailed()
  onFailed(job: Job<CronPayload<UploadContactDTO>>) {
    this.logger.error(getErrorLog(cronJobs.IVR_WEBHOOK.name, job.data.traceID, { id: job.id, reason: job.failedReason, stack: job.stacktrace }))
  }
}

@Injectable()
@Processor(cronJobs.IVR_WEBHOOK_FINALIZE.name)
export class IVRWebhookFinalizeProcessor {
  constructor(
    @InjectModel(Campaign.name) private campaignsModel: Model<Campaign>,
    @InjectModel(Contact.name) private contactsModel: Model<Contact>,
    @InjectModel(ContactDatabase.name) private contactDatabaseModel: Model<ContactDatabase>,
    @InjectModel(Requests.name) private requestModel: Model<Requests>,
    private logger: VappLogger
  ) {}

  @Process({ concurrency: 1 })
  async processIVRWebhook(job: Job<CronPayload<{ data: [IVRFinalizeObjectDTO]; clientID: string; campaignID: string }>>) {
    const { payload, traceID } = job.data
    const { clientID, campaignID, data } = payload
    try {
      let contactsDatabases: ContactDatabase[]
      let leadPositive = 0
      let leadNegative = 0
      let leadNeutral = 0
      const updatePromises = []
      data.forEach((updateObject) => {
        updatePromises.push((callback: any) => {
          createOperations
            .updateOne(
              this.requestModel,
              {
                lead: { $eq: null },
                phone: updateObject.phone,
                campaignID,
                clientID
              },
              { $set: { lead: updateObject.status } }
            )
            .then((updatedRequest: Requests) => {
              if (!_.isNil(updatedRequest)) {
                callback(null, updatedRequest.lead)
              } else {
                callback(null, null)
              }
            })
        })
      })

      const results = await this.processUpdates(updatePromises)
      leadPositive = results.filter((e) => _.eq(e, constants.LEAD_TYPE.positive)).length
      leadNegative = results.filter((e) => _.eq(e, constants.LEAD_TYPE.negative)).length
      leadNeutral = results.filter((e) => _.eq(e, constants.LEAD_TYPE.neutral)).length
      const campaignUpdateResult = await createOperations.updateOne(this.campaignsModel, { _id: campaignID }, { $inc: { leadPositive, leadNegative, leadNeutral }, $set: { ivrFinalized: true } })
      if (!_.isNil(campaignUpdateResult?.databaseID)) {
        await createOperations.updateOne(this.contactDatabaseModel, { _id: campaignUpdateResult?.databaseID }, { $inc: { leadPositive, leadNegative, leadNeutral } })
        contactsDatabases = await findOperations.find(this.contactDatabaseModel, { clientID: campaignUpdateResult.clientID }, { __v: 0, password: 0 }, {})
      }
      if (!_.isNil(contactsDatabases)) {
        RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(clientID), JSON.stringify(contactsDatabases))
        RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
      }
      if (!_.isNil(campaignUpdateResult)) {
        RedisHandler.getInstance().set(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), JSON.stringify(campaignUpdateResult))
        RedisHandler.getInstance().ttl(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), (error: Error, time: number) => {
          if (_.isNil(error) && _.isNumber(time)) {
            RedisHandler.getInstance().expire(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), time)
          } else {
            this.logger.error(getErrorLog(canonicalMethods.PROCESS_IVR_WEBHOOK, traceID, { payload }, messages.CAM032.message))
          }
        })
      }
    } catch (error) {
      this.logger.error(getErrorLog(cronJobs.IVR_WEBHOOK_FINALIZE.name, traceID, { error, payload }, error.message))
      if (!_.isNil(error.name) && error.name.includes(CronError.name)) {
        error.stack = 'CronError'
      }
      throw error
    }
    job.progress(100)
    return true
  }

  private processUpdates = (updatePromises) =>
    new Promise<Array<any>>((resolve, reject) => {
      async.series(updatePromises, async (error, results) => {
        if (!_.isNil(results) && !_.isEmpty(results)) {
          resolve(results)
        } else {
          resolve([])
        }
      })
    })

  @OnQueueActive()
  onActive(job: Job<CronPayload<UploadContactDTO>>) {
    this.logger.log(`Processing: Job name: ${cronJobs.IVR_WEBHOOK_FINALIZE.name} Job ID: ${job.id}`)
  }

  @OnQueueCompleted()
  onCompleted(job: Job<CronPayload<UploadContactDTO>>) {
    this.logger.log(`Completed: Job name: ${cronJobs.IVR_WEBHOOK_FINALIZE.name} Job ID: ${job.id}`)
  }

  @OnQueueFailed()
  onFailed(job: Job<CronPayload<UploadContactDTO>>) {
    this.logger.error(getErrorLog(cronJobs.IVR_WEBHOOK_FINALIZE.name, job.data.traceID, { id: job.id, reason: job.failedReason, stack: job.stacktrace }))
  }
}
