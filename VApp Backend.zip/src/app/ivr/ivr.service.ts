import { Requests } from '@app/requests/requests.schema'
import { constants, cronJobs, variables } from '@config'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { InjectQueue } from '@nestjs/bull'
import { HttpStatus, Inject } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { findOperations } from '@utils/crud.util'
import { getAPIResponse, getEnvironmentVariable } from '@utils/platform.util'
import { Queue } from 'bull'
import _ from 'lodash'
import { Model } from 'mongoose'
import { IVRFinalizeDTO } from './dto/finalize'
import { IVRWebhookDTO } from './dto/webhook'
import { IVRQueryResult } from './ivr.schema'

export class IVRService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    private logger: VappLogger,
    @InjectModel(Requests.name) private requestsModel: Model<Requests>,
    @InjectQueue(cronJobs.IVR_WEBHOOK.name) private ivrWebhookQueue: Queue,
    @InjectQueue(cronJobs.IVR_WEBHOOK_FINALIZE.name) private ivrWebhookFinalizeQueue: Queue
  ) {
    this.traceID = vapp_context.traceID
  }

  processWebhook = (ivrSecret: string, ivrData: IVRWebhookDTO) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      if (!_.eq(getEnvironmentVariable(variables.IVR_SECRET.name), ivrSecret)) {
        resolve(getAPIResponse(messages.IVR001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      } else {
        this.ivrWebhookQueue.add({ payload: ivrData, traceID: this.traceID })
        resolve(getAPIResponse(messages.IVR002.code, this.traceID, HttpStatus.OK))
      }
    })

  processWebhookStallion = (ivrData: IVRWebhookDTO, status: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      if (_.isEqual(status, 'Answered') || _.isEqual(status, 'Missed')) {
        this.ivrWebhookQueue.add({ payload: ivrData, traceID: this.traceID })
      }
      resolve(getAPIResponse(messages.IVR002.code, this.traceID, HttpStatus.OK))
    })

  ivrFinalizeReport = (campaignID: string, clientID: string, payload: IVRFinalizeDTO) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      this.ivrWebhookFinalizeQueue.add({ payload: { data: payload.data, clientID, campaignID }, traceID: this.traceID })
      resolve(getAPIResponse(messages.IVR007.code, this.traceID, HttpStatus.OK))
    })

  ivrReport = (campaignID: string, clientID: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      findOperations
        .findLean(this.requestsModel, { campaignID, clientID, $expr: { $gte: [{ $size: { $ifNull: ['$ivr', []] } }, 1] } }, { phone: 1, ivr: 1, lead: 1 })
        .then((requests: [Requests]) => {
          requests.forEach((e, index) => {
            if (_.isNil(e.lead)) {
              _.set(requests[index], 'lead', null)
            }
          })
          resolve(getAPIResponse(messages.IVR005.code, this.traceID, HttpStatus.OK, requests))
        })
        .catch((e) => {
          resolve(getAPIResponse(messages.IVR006.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  getIvrData = (campaignID: string, clientID: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      const result: IVRQueryResult[] = []
      findOperations
        .findLean(this.requestsModel, { campaignID, clientID, $expr: { $gte: [{ $size: { $ifNull: ['$ivr', []] } }, 1] } }, { phone: 1, ivr: 1 })
        .then((requests: [Requests]) => {
          requests.forEach((request) => {
            request.ivr.forEach((ivr) => {
              result.push({
                phone: request.phone,
                ivr
              } as IVRQueryResult)
            })
          })
          resolve(getAPIResponse(messages.IVR008.code, this.traceID, HttpStatus.OK, result))
        })
        .catch((e) => {
          resolve(getAPIResponse(messages.IVR009.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })
}
