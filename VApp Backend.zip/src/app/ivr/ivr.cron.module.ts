import { Campaign, CampaignSchema } from '@app/campaign/campaign.schema'
import { ContactDatabase, ContactDatabaseSchema } from '@app/contact/contact.database.schema'
import { Contact, ContactSchema } from '@app/contact/contact.schema'
import { Requests, RequestsSchema } from '@app/requests/requests.schema'
import { cronJobs } from '@config'
import { GenericObject } from '@interfaces/generic.interface'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { getArgs } from '@utils/platform.util'
import { IVRQueueModule, IVRFinalizeQueueModule } from './cron/queue.module'
import { IVRWebhookProcessor, IVRWebhookFinalizeProcessor } from './cron/queue.processor'
import { QueueUIProvider } from './cron/queue.ui'
import { IVRController } from './ivr.controller'
import { IVRService } from './ivr.service'

const cronSwitcher = () => {
  const cron_processor = (getArgs() as GenericObject).cron
  let processor_array: Array<any> = []
  switch (cron_processor) {
    case cronJobs.IVR_WEBHOOK.name:
      processor_array = [IVRWebhookProcessor]
      break
    case cronJobs.IVR_WEBHOOK_FINALIZE.name:
      processor_array = [IVRWebhookFinalizeProcessor]
      break
  }
  return processor_array
}
@Module({
  imports: [
    IVRQueueModule,
    IVRFinalizeQueueModule,
    MongooseModule.forFeature([
      { name: Contact.name, schema: ContactSchema },
      { name: ContactDatabase.name, schema: ContactDatabaseSchema },
      { name: Requests.name, schema: RequestsSchema },
      { name: Campaign.name, schema: CampaignSchema },
    ]),
  ],
  controllers: [IVRController],
  providers: [IVRService, VappLogger, ...cronSwitcher(), QueueUIProvider],
})
export class IVRCronModule {}
