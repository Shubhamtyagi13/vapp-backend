import { Campaign, CampaignSchema } from '@app/campaign/campaign.schema'
import { ContactDatabase, ContactDatabaseSchema } from '@app/contact/contact.database.schema'
import { Contact, ContactSchema } from '@app/contact/contact.schema'
import { Requests, RequestsSchema } from '@app/requests/requests.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { IVRQueueModule, IVRFinalizeQueueModule } from './cron/queue.module'
import { QueueUIProvider } from './cron/queue.ui'
import { IVRController } from './ivr.controller'
import { IVRService } from './ivr.service'

@Module({
  imports: [
    IVRQueueModule,
    IVRFinalizeQueueModule,
    MongooseModule.forFeature([
      { name: Contact.name, schema: ContactSchema },
      { name: ContactDatabase.name, schema: ContactDatabaseSchema },
      { name: Requests.name, schema: RequestsSchema },
      { name: Campaign.name, schema: CampaignSchema }
    ])
  ],
  controllers: [IVRController],
  providers: [IVRService, VappLogger, QueueUIProvider]
})
export class IVRModule {}
