import { Campaign, CampaignSchema } from '@app/campaign/campaign.schema'
import { Template, TemplateSchema } from '@app/template/template.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { TemplateController } from './template.controller'
import { TemplateService } from './template.service'

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Template.name, schema: TemplateSchema },
      { name: Campaign.name, schema: CampaignSchema }
    ])
  ],
  controllers: [TemplateController],
  providers: [TemplateService, VappLogger],
  exports: [MongooseModule]
})
export class TemplateModule {}
