import { Campaign } from '@app/campaign/campaign.schema'
import { Template } from '@app/template/template.schema'
import { canonicalMethods, constants, redisKeys } from '@config'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { HttpStatus, Inject, Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import { getAPIResponse, getErrorLog } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import _ from 'lodash'
import { Model } from 'mongoose'
import { CreateTemplateDTO } from './dto/create-template.dto'
import { EditTemplateDTO } from './dto/edit-template.dto'
import { FilterDripTemplate, FilterTemplate } from './helper/template.helper'

@Injectable()
export class TemplateService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    @InjectModel(Template.name) private templatesModel: Model<Template>,
    @InjectModel(Campaign.name) private campaignsModel: Model<Campaign>,
    private logger: VappLogger
  ) {
    this.traceID = vapp_context.traceID
  }

  createTemplate = (userID: string, templateObject: CreateTemplateDTO) =>
    new Promise<ServiceResponse>((resolve) => {
      ; ((templateObject as unknown) as Template).clientID = userID
      createOperations
        .save(new this.templatesModel(templateObject))
        .then((template: Template) => {
          if (!_.isNil(template)) {
            findOperations
              .find(this.templatesModel, <Template>{ clientID: userID }, { __v: 0, password: 0 })
              .then((templates: Template[]) => {
                if (!_.isNil(templates)) {
                  RedisHandler.getInstance().set(redisKeys.USER_TEMPLATES.value(userID), JSON.stringify(templates))
                  RedisHandler.getInstance().expire(redisKeys.USER_TEMPLATES.value(userID), redisKeys.USER_TEMPLATES.timeout())
                }
              })
              .catch((error: Error) => {
                this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_TEMPLATES, this.traceID, { templateObject, userID, error }, error.message))
              })
            resolve(getAPIResponse(messages.TEM005.code, this.traceID, HttpStatus.OK))
          }
          this.logger.error(getErrorLog(canonicalMethods.CREATE_CLIENT_TEMPLATE, this.traceID, { templateObject, userID }))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.CREATE_CLIENT_TEMPLATE, this.traceID, { templateObject, userID, error }))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  editTemplate = (userID: string, templateObject: EditTemplateDTO) =>
    new Promise<ServiceResponse>((resolve) => {
      ; ((templateObject as unknown) as Template).clientID = userID

      const updateTemplate = _.pick(templateObject, ['text', 'name', 'dynamic', 'templateID', 'senderIDList', 'dripcampaign'])
      createOperations
        .updateOne(this.templatesModel, { _id: templateObject._id }, updateTemplate)
        .then((template: Template) => {
          if (!_.isNil(template)) {
            findOperations
              .find(this.templatesModel, <Template>{ clientID: userID }, { __v: 0, password: 0 })
              .then((templates: Template[]) => {
                if (!_.isNil(templates)) {
                  RedisHandler.getInstance().set(redisKeys.USER_TEMPLATES.value(userID), JSON.stringify(templates))
                  RedisHandler.getInstance().expire(redisKeys.USER_TEMPLATES.value(userID), redisKeys.USER_TEMPLATES.timeout())
                }
              })
              .catch((error: Error) => {
                this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_TEMPLATES, this.traceID, { templateObject, userID, error }, error.message))
              })
            resolve(getAPIResponse(messages.TEM006.code, this.traceID, HttpStatus.OK))
          }
          this.logger.error(getErrorLog(canonicalMethods.CREATE_CLIENT_TEMPLATE, this.traceID, { templateObject, userID }))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.CREATE_CLIENT_TEMPLATE, this.traceID, { templateObject, userID, error }))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  findAll = (userID: string, url: string, senderID: string) =>
    new Promise<ServiceResponse>(async (resolve) => {
      const requestUrl = url.replace('/', '')
      let fetchActive = false
      if (_.includes(requestUrl, 'active')) {
        fetchActive = true
      }
      const campaigns = await findOperations.findLean(
        this.campaignsModel,
        { clientID: userID, year: new Date().getFullYear(), templateID: { $ne: null } },
        {
          month: 1,
          projectID: 1,
          templateID: 1,
          negativeCount: 1,
          positiveCount: 1,
          neutralCount: 1,
          campaignName: 1
        }
      )
      RedisHandler.getInstance().get(redisKeys.USER_TEMPLATES.value(userID), (error: Error, data: string) => {
        if (_.isNil(error) && !_.isNil(data)) {
          const output = this.processUsageStats(campaigns, JSON.parse(data) as [Template])
          resolve(<ServiceResponse>getAPIResponse(messages.TEM001.code, this.traceID, HttpStatus.OK, FilterTemplate(output, fetchActive, senderID)))
        } else {
          findOperations
            .findLean(this.templatesModel, { clientID: userID }, { __v: 0, password: 0 })
            .then((templates: [Template]) => {
              if (!_.isNil(templates)) {
                if (templates.length > 0) {
                  RedisHandler.getInstance().set(redisKeys.USER_TEMPLATES.value(userID), JSON.stringify(templates))
                  RedisHandler.getInstance().expire(redisKeys.USER_TEMPLATES.value(userID), redisKeys.USER_TEMPLATES.timeout())
                  const output = this.processUsageStats(campaigns, templates)
                  resolve(getAPIResponse(messages.TEM001.code, this.traceID, HttpStatus.OK, FilterTemplate(output, fetchActive, senderID)))
                }
                resolve(getAPIResponse(messages.TEM002.code, this.traceID, HttpStatus.OK, []))
              }
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            })
            .catch((error: Error) => {
              this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_TEMPLATES, this.traceID, { userID }, error.message))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            })
        }
      })
    })

  processUsageStats = (campaigns: [Campaign], input: [Template]) => {
    const currentMonth = new Date().getMonth() + 1
    const usageStatsMap = {}
    campaigns.map((campaign) => {
      if (_.isNil(usageStatsMap[`${campaign.templateID}`])) {
        _.set(
          usageStatsMap,
          `${campaign.templateID}`,
          _.assign(
            {},
            {
              year: { useCount: 0, acrossProjectsCount: 0, projects: {}, campaigns: {} },
              month: { useCount: 0, acrossProjectsCount: 0, projects: {}, campaigns: {} }
            }
          )
        )
      }
      // check year wise
      if (_.isNil(usageStatsMap[`${campaign.templateID}`].year.projects[`${campaign.projectID}`])) {
        usageStatsMap[`${campaign.templateID}`].year.acrossProjectsCount += 1
        usageStatsMap[`${campaign.templateID}`].year.projects[`${campaign.projectID}`] = true
      }
      usageStatsMap[`${campaign.templateID}`].year.useCount += 1
      if (_.isNil(usageStatsMap[`${campaign.templateID}`].year.campaigns[`${campaign._id}`])) {
        usageStatsMap[`${campaign.templateID}`].year.campaigns[`${campaign._id}`] = {
          projectID: campaign.projectID,
          negativeCount: campaign.negativeCount,
          positiveCount: campaign.positiveCount,
          neutralCount: campaign.neutralCount,
          campaignName: campaign.campaignName
        }
      }
      // check month wise
      if (_.eq(currentMonth, campaign.month)) {
        if (_.isNil(usageStatsMap[`${campaign.templateID}`].month.projects[`${campaign.projectID}`])) {
          usageStatsMap[`${campaign.templateID}`].month.acrossProjectsCount += 1
          usageStatsMap[`${campaign.templateID}`].month.projects[`${campaign.projectID}`] = true
        }
        usageStatsMap[`${campaign.templateID}`].month.useCount += 1
        if (_.isNil(usageStatsMap[`${campaign.templateID}`].month.campaigns[`${campaign._id}`])) {
          usageStatsMap[`${campaign.templateID}`].month.campaigns[`${campaign._id}`] = {
            projectID: campaign.projectID,
            negativeCount: campaign.negativeCount,
            positiveCount: campaign.positiveCount,
            neutralCount: campaign.neutralCount,
            campaignName: campaign.campaignName
          }
        }
      }
    })
    input.forEach((ele, index) => {
      if (!_.isNil(usageStatsMap[`${ele._id}`])) {
        const data = usageStatsMap[`${ele._id}`]
        if (!_.isArray(data.year.projects)) data.year.projects = _.map(_.keys(data.year.projects), (key) => key)
        if (!_.isArray(data.year.campaigns))
          data.year.campaigns = _.map(_.keys(data.year.campaigns), (key) => {
            const { projectID, negativeCount, positiveCount, neutralCount, campaignName } = data.year.campaigns[`${key}`]
            return {
              _id: key,
              projectID,
              negativeCount: !_.isNil(negativeCount) ? negativeCount : 0,
              positiveCount: !_.isNil(positiveCount) ? positiveCount : 0,
              neutralCount: !_.isNil(neutralCount) ? neutralCount : 0,
              campaignName: !_.isNil(campaignName) ? campaignName : 'N/A'
            }
          })
        if (!_.isArray(data.month.projects)) data.month.projects = _.map(_.keys(data.month.projects), (key) => key)
        if (!_.isArray(data.month.campaigns))
          data.month.campaigns = _.map(_.keys(data.month.campaigns), (key) => {
            const { projectID, negativeCount, positiveCount, neutralCount, campaignName } = data.month.campaigns[`${key}`]
            return {
              _id: key,
              projectID,
              negativeCount: !_.isNil(negativeCount) ? negativeCount : 0,
              positiveCount: !_.isNil(positiveCount) ? positiveCount : 0,
              neutralCount: !_.isNil(neutralCount) ? neutralCount : 0,
              campaignName: !_.isNil(campaignName) ? campaignName : 'N/A'
            }
          })
        input[index] = ({ ...ele, usage: { ...data } }) as any
      } else {
        input[index] = ({

          ...ele,
          usage: {
            year: { useCount: 0, acrossProjectsCount: 0, projects: [], campaigns: [] },
            month: { useCount: 0, acrossProjectsCount: 0, projects: [], campaigns: [] }
          }
        }) as any
      }
    })
    return input
  }

  toggle = (userID: string, templateID: string, flag: string) =>
    new Promise<ServiceResponse>((resolve) => {
      if (!_.isEmpty(userID)) {
        createOperations
          .updateOne(this.templatesModel, { clientID: userID, _id: templateID }, { $set: { active: flag === 'true' } })
          .then(async (template: Template) => {
            if (!_.isNil(template)) {
              findOperations.find(this.templatesModel, { clientID: userID }, { __v: 0, password: 0 }).then(async (templates: Template[]) => {
                if (!_.isNil(templates)) {
                  RedisHandler.getInstance().set(redisKeys.USER_TEMPLATES.value(userID), JSON.stringify(templates))
                  RedisHandler.getInstance().expire(redisKeys.USER_TEMPLATES.value(userID), redisKeys.USER_TEMPLATES.timeout())
                }
              })
              const campaigns = await findOperations.findLean(
                this.campaignsModel,
                { clientID: userID, year: new Date().getFullYear(), templateID },
                {
                  month: 1,
                  projectID: 1,
                  templateID: 1,
                  negativeCount: 1,
                  positiveCount: 1,
                  neutralCount: 1,
                  campaignName: 1
                }
              )
              const output = this.processUsageStats(campaigns, [template.toObject() as any])
              resolve(getAPIResponse(messages.TEM006.code, this.traceID, HttpStatus.OK, output[0]))
            }
            this.logger.error(getErrorLog(canonicalMethods.TOGGLE_CLIENT_TEMPLATE, this.traceID, { templateID, userID, flag }))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
          .catch((error: Error) => {
            this.logger.error(getErrorLog(canonicalMethods.TOGGLE_CLIENT_TEMPLATE, this.traceID, { templateID, userID, flag }))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
      } else {
        resolve(getAPIResponse(messages.COM002.code, this.traceID, HttpStatus.FORBIDDEN))
      }
    })

  findDripTemplate = (userID: string, isdrip: boolean) =>
    new Promise<ServiceResponse>(async (resolve) => {
      const fetchActive = true
      const campaigns = await findOperations.findLean(
        this.campaignsModel,
        { clientID: userID, year: new Date().getFullYear(), templateID: { $ne: null } },
        {
          month: 1,
          projectID: 1,
          templateID: 1,
          negativeCount: 1,
          positiveCount: 1,
          neutralCount: 1,
          campaignName: 1
        }
      )

      RedisHandler.getInstance().get(redisKeys.USER_TEMPLATES.value(userID), (error: Error, data: string) => {
        if (_.isNil(error) && !_.isNil(data)) {
          const output = this.processUsageStats(campaigns, JSON.parse(data) as [Template])
          resolve(<ServiceResponse>getAPIResponse(messages.TEM001.code, this.traceID, HttpStatus.OK, FilterDripTemplate(output, fetchActive, isdrip)))
        } else {
          findOperations
            .findLean(this.templatesModel, { clientID: userID }, { __v: 0, password: 0 })
            .then((templates: [Template]) => {
              if (!_.isNil(templates)) {
                if (templates.length > 0) {
                  RedisHandler.getInstance().set(redisKeys.USER_TEMPLATES.value(userID), JSON.stringify(templates))
                  RedisHandler.getInstance().expire(redisKeys.USER_TEMPLATES.value(userID), redisKeys.USER_TEMPLATES.timeout())
                  const output = this.processUsageStats(campaigns, templates)
                  resolve(getAPIResponse(messages.TEM001.code, this.traceID, HttpStatus.OK, FilterDripTemplate(output, fetchActive, isdrip)))
                }
                resolve(getAPIResponse(messages.TEM002.code, this.traceID, HttpStatus.OK, []))
              }
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            })
            .catch((error: Error) => {
              this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_TEMPLATES, this.traceID, { userID }, error.message))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            })
        }
      })
    })
}
