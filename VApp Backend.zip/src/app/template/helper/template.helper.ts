import _ from 'lodash'
import { Template } from '../template.schema'

export const FilterTemplate = (templates: [Template], fetchActive: boolean, senderID: string) => {
  let filteredArray = fetchActive ? templates.filter((template) => template.active) : templates
  if (!_.isNil(senderID)) {
    filteredArray = filteredArray.filter((template) => template.senderIDList?.includes(senderID) && template.active)
  }
  return filteredArray
}

export const FilterDripTemplate = (templates: [Template], fetchActive: boolean, isdrip: boolean) => {
  let filteredArray = fetchActive ? templates.filter((template) => template.active) : templates

  if (!_.isNil(isdrip)) {
    filteredArray = isdrip ? templates.filter((template) => template.dripcampaign) : templates
  }

  return filteredArray
}
