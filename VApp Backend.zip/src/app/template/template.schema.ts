import { constants, tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.TEMPLATES.collection, autoCreate: true })
export class Template extends Document {
  @Prop({ type: String, index: true, required: true })
  clientID: string

  @Prop({ type: String, required: true })
  text: string

  @Prop({ type: String, required: true })
  name: string

  @Prop({ type: Boolean, index: true, default: true })
  active: boolean

  @Prop({ type: Boolean, index: true, default: false })
  dynamic: boolean

  @Prop({ type: Number, index: true, default: 0 })
  linksCount: number

  @Prop({ type: Number, index: true, default: 0 })
  linksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsSentCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsDeliveredCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsFailedCount: number

  @Prop({ type: Number, index: true, default: 0 })
  viewsCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappViewsCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsViewsCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappLinksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsLinksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappSentCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappFailedCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappDeliveredCount: number

  @Prop({ type: Number, index: true, default: 0 })
  negativeCount: number

  @Prop({ type: Number, index: true, default: 0 })
  neutralCount: number

  @Prop({ type: Number, index: true, default: 0 })
  positiveCount: number

  @Prop({ type: Number, index: true, default: constants.TEMPLATE_TYPE.campaign })
  type: number

  @Prop({ type: String, required: false, default: null })
  templateID: string

  @Prop({ type: Boolean, required: false, default: false })
  isApproved: string

  @Prop({ type: [String], default: []})
  senderIDList: [string ]

  @Prop({ type: Boolean, index: true, default: false })
  dripcampaign: boolean
}

export const TemplateSchema = SchemaFactory.createForClass(Template)
