import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsBoolean, IsDefined, IsOptional, IsString, IsArray } from 'class-validator'
import { Type } from 'class-transformer'

export class CreateTemplateDTO extends ClientUserIDDTO {
  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  text: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  name: string

  @ApiProperty({ required: false })
  @IsBoolean()
  @IsOptional()
  active: boolean

  @ApiProperty({ required: true })
  @IsBoolean()
  @IsDefined()
  dynamic: boolean

  @ApiProperty({})
  @IsString()
  @IsOptional()
  templateID: string

  @ApiProperty()
  @IsArray()
  @Type(()=> String)
  @IsDefined()
  senderIDList: [string]

  @ApiProperty({})
  @IsBoolean()
  @IsDefined()
  dripcampaign: boolean
}
