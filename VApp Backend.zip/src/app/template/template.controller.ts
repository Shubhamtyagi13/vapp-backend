import { audience, environments, variables } from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Body, Controller, Get, Param, Post, Req, Res, UseGuards,
} from '@nestjs/common'
import { ApiBearerAuth, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import { CreateTemplateDTO } from './dto/create-template.dto'
import { EditTemplateDTO } from './dto/edit-template.dto'
import { TemplateService } from './template.service'

@ApiTags(TemplateController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('template')
@UseGuards(AuthenticationGuard)
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class TemplateController {
  constructor(private templateService: TemplateService) { }

  /*
   create a new template for current user
  */
  @Audience([audience.CLIENT, audience.ADMIN])
  @Post('create')
  create(@Res() response: Response, @Body() templateObject: CreateTemplateDTO, @Req() request: Request) {
    this.templateService.createTemplate(request.user._id, templateObject).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
 Edit a template for current user
*/
  @Audience([audience.CLIENT, audience.ADMIN])
  @Post('edit')
  edit(@Res() response: Response, @Body() templateObject: EditTemplateDTO, @Req() request: Request) {
    this.templateService.editTemplate(request.user._id, templateObject).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }



  /*
   all - retrieve all the templates for a client
   active - retrieve all active temp;ates for a client
  */
  @Audience([audience.CLIENT, audience.ADMIN])
  @Get(['all', 'active', 'senderid/:senderID'])
  findAll(@Res() response: Response, @Req() request: Request, @Param('senderID') senderID: string) {
    this.templateService.findAll(request.user._id, request.url, senderID).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   toggle template for a client
  */
  @Audience([audience.CLIENT, audience.ADMIN])
  @Get('toggle/:templateID/:flag')
  toggle(@Res() response: Response, @Req() request: Request, @Param('templateID') templateID: string, @Param('flag') flag: string) {
    this.templateService.toggle(request.user._id, templateID, flag).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
  all - retrieve all the templates for a client
  active - retrieve all active templates for a client
 */
  @Audience([audience.CLIENT, audience.ADMIN])
  @Get('dripTemplate/:isdrip')
  findDripTemplate(@Res() response: Response, @Req() request: Request, @Param('isdrip') isdrip: boolean) {
    this.templateService.findDripTemplate(request.user._id, isdrip).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }
}
