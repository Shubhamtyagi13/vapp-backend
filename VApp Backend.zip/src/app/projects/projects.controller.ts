import {
  audience, contentTypes, environments, image_intercept, variables,
} from '@config'
import { ApiFile } from '@decorators/api-file.decorator'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { BrochureInterceptor } from '@interceptors/brochure.interceptor'
import { ImageInterceptor } from '@interceptors/image.interceptor'
import { WalkthroughInterceptor } from '@interceptors/walkthrough.interceptor'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Body, Controller, Get, Param, Post, Req, Res, UploadedFile, UseGuards, UseInterceptors,
} from '@nestjs/common'
import {
  ApiBearerAuth, ApiConsumes, ApiExcludeController, ApiTags,
} from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import { CreateProjectDTO } from './dto/create-project.dto'
import { CreateSubTypeDTO } from './dto/create-sub-type.dto'
import { SenderIDDTO } from './dto/sender-id.dto'
import { UpdateProjectPhoneDTO } from './dto/update-project-phone.dto'
import { ProjectsService } from './projects.service'

@ApiTags(ProjectsController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('projects')
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class ProjectsController {
  constructor(private projectsService: ProjectsService) {}

  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Post('sender/:projectID')
  updateSMSSenderID(@Param('projectID') projectID: string, @Req() request: Request, @Res() response: Response, @Body() senderID: SenderIDDTO) {
    this.projectsService.updateSenderID(projectID, senderID).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get('specific')
  findAll(@Req() request: Request, @Res() response: Response) {
    this.projectsService.findAll(request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Post('create')
  @ApiConsumes(contentTypes.MULTIPART.FORM_DATA)
  @UseInterceptors(ImageInterceptor(image_intercept.PROJECT))
  createProject(@Req() request: Request, @Res() response: Response, @Body() projectObject: CreateProjectDTO) {
    this.projectsService.createProject(request.filePath, request.fileName, projectObject, request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Post('type/:projectID')
  createSubType(@Param('projectID') projectID: string, @Req() request: Request, @Res() response: Response, @Body() subTypeObject: CreateSubTypeDTO[]) {
    this.projectsService.createSubType(projectID, subTypeObject, request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Post('update/phone/:projectID')
  updatePhone(@Param('projectID') projectID: string, @Req() request: Request, @Res() response: Response, @Body() updatePhoneObject: UpdateProjectPhoneDTO) {
    this.projectsService.updatePhone(projectID, updatePhoneObject, request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @ApiFile('walkthrough')
  @ApiConsumes(contentTypes.MULTIPART.FORM_DATA)
  @UseInterceptors(WalkthroughInterceptor())
  @Post('walkthrough/:projectID')
  uploadWalkthrough(@Param('projectID') projectID: string, @Req() request: Request, @Res() response: Response, @UploadedFile() file: any) {
    this.projectsService.uploadWalkthrough(request.filePath, request.fileName).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @ApiFile('brochure')
  @ApiConsumes(contentTypes.MULTIPART.FORM_DATA)
  @UseInterceptors(BrochureInterceptor())
  @Post('brochure/:projectID')
  uploadBrouchere(@Param('projectID') projectID: string, @Req() request: Request, @Res() response: Response, @UploadedFile() file: any) {
    this.projectsService.uploadBrochure(projectID, request.user._id, request.filePath, request.fileName).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }
}
