import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import { IsValidPostalCode } from '@transformers/postal-code.transformer'
import { Type } from 'class-transformer'
import { IsDefined, IsNumber, IsOptional, IsString, Max, Min } from 'class-validator'

export class CreateProjectDTO extends ClientUserIDDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  readonly name: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  readonly reraID: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  @Type(() => Number)
  @Min(1)
  @Max(12)
  readonly possessionMonth: number

  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  @Type(() => Number)
  @Min(1950)
  @Max(2050)
  readonly possessionYear: number

  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  readonly city: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  readonly country: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  readonly state: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  readonly sequence: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  readonly area: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  readonly landMark: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  @Type(() => Number)
  readonly latitude: number

  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  @Type(() => Number)
  readonly longitude: number

  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  @Type(() => Number)
  readonly postalCode: number

  @ApiProperty({ required: true })
  @IsDefined()
  @IsValidPhone()
  @IsNumber()
  @Type(() => Number)
  readonly phone: number

  @ApiProperty({ type: 'file' })
  @IsOptional()
  image: any

  @ApiProperty({required : true})
  @IsDefined()
  @IsString()
  readonly description : string
}
