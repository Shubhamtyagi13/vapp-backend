import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import { Type } from 'class-transformer'
import { IsDefined } from 'class-validator'

export class UpdateProjectPhoneDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsValidPhone()
  @Type(() => Number)
  readonly phone: number
}
