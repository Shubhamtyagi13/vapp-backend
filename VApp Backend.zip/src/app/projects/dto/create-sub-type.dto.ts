import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsNumber, IsString } from 'class-validator'

export class CreateSubTypeDTO extends ClientUserIDDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  readonly name: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  readonly minCarpetArea: number

  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  readonly maxCarpetArea: number

  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  readonly minPrice: number

  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  readonly maxPrice: number

  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  readonly availabilityCount: number
}
