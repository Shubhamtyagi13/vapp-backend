import { ApiProperty } from '@nestjs/swagger'
import {
  IsAlpha, IsAlphanumeric, IsDefined, IsString, Length,
} from 'class-validator'

export class SenderIDDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  @Length(6, 6)
  @IsAlphanumeric()
  readonly senderID: string
}
