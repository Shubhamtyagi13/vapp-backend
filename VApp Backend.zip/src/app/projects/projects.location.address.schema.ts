import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

// @Schema({ collection: tables.LOCATION_SUB.collection, autoCreate: true })
@Schema()
export class StreetAddress extends Document {
  @Prop({ type: String })
  sequence: string // flat, house, floor, building

  @Prop({ type: String })
  area: string
}

export const StreetAddressSchema = SchemaFactory.createForClass(StreetAddress)
