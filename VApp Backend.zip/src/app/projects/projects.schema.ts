import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'
import { Location, LocationSchema } from './projects.location.schema'
import { ProjectType, ProjectTypeSchema } from './projects.type.schema'

@Schema({ collection: tables.PROJECTS.collection, autoCreate: true })
export class Projects extends Document {
  @Prop({ type: String, index: true })
    name: string

  @Prop({ type: Boolean, index: true })
    isVisible: boolean

  @Prop({ type: Boolean, index: true })
    isActive: boolean

  @Prop({ type: LocationSchema })
    location: Location

  @Prop({ type: [ProjectTypeSchema], default: [] })
    subTypes: [ProjectType]

  @Prop({ type: Number, index: true })
    possessionMonth: number

  @Prop({ type: Number, index: true })
    possessionYear: number

  @Prop({ type: String, index: true })
    reraID: string

  @Prop({ type: String, index: true })
    imageURL: string

  @Prop({ type: Boolean, index: true })
    isPossessionAvailable: boolean

  @Prop({ type: String, index: true })
    clientID: string

  @Prop({ type: String, index: true })
    clientName: string

  @Prop({ type: Number, index: true })
    phone: number

  @Prop({ default: null, type: String, index: true })
    smsSenderID: string

  @Prop({ type: String, index: true, default: null })
    brochure: string

  @Prop({ type: Number, index: true, default: 0 })
    engagementTotal: number

  @Prop({ type: Number, index: true, default: 0 })
    engagementSum: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappEngagementTotal: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappEngagementSum: number

  @Prop({ type: Number, index: true, default: 0 })
    smsEngagementTotal: number

  @Prop({ type: Number, index: true, default: 0 })
    smsEngagementSum: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappClicks: number

  @Prop({ type: Number, index: true, default: 0 })
    linksCount: number

  @Prop({ type: Number, index: true, default: 0 })
    linksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappLinksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
    smsLinksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
    smsSentCount: number

  @Prop({ type: Number, index: true, default: 0 })
    smsDeliveredCount: number

  @Prop({ type: Number, index: true, default: 0 })
    smsFailedCount: number

  @Prop({ type: Number, index: true, default: 0 })
    viewsCount: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappViewsCount: number

  @Prop({ type: Number, index: true, default: 0 })
    smsViewsCount: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappSentCount: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappFailedCount: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappDeliveredCount: number

  @Prop({ type: Number, index: true, default: 0 })
    negativeCount: number

  @Prop({ type: Number, index: true, default: 0 })
    neutralCount: number

  @Prop({ type: Number, index: true, default: 0 })
    positiveCount: number

  @Prop({ type: String, index: true })
    description: string
}

export const ProjectsSchema = SchemaFactory.createForClass(Projects)
