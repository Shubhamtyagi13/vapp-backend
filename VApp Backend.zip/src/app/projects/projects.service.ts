import { canonicalMethods, constants, redisKeys, variables } from '@config'
import { Project, ProjectType } from '@interfaces/project.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { HttpStatus, Inject } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import { deleteFile, getAPIResponse, getEnvironmentVariable, getErrorLog } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import extract from 'extract-zip'
import fs from 'fs'
import _ from 'lodash'
import { Model } from 'mongoose'
import { join } from 'path'
import { CreateProjectDTO } from './dto/create-project.dto'
import { CreateSubTypeDTO } from './dto/create-sub-type.dto'
import { SenderIDDTO } from './dto/sender-id.dto'
import { UpdateProjectPhoneDTO } from './dto/update-project-phone.dto'
import { StreetAddress } from './projects.location.address.schema'
import { Location } from './projects.location.schema'
import { Projects } from './projects.schema'

export class ProjectsService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    @InjectModel(Projects.name) private projectsModel: Model<Projects>,
    private logger: VappLogger
  ) {
    this.traceID = vapp_context.traceID
  }

  findAll = (userID: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      findOperations
        .find(this.projectsModel, { clientID: userID }, { __v: 0, password: 0 })
        .then((projects: [Project]) => {
          if (!_.isNil(projects)) {
            if (projects.length > 0) {
              projects.map((project, index) => {
                projects[index] = projects[index].toObject() as any
                projects[index].walkthroughExists = fs.existsSync(
                  `./${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.WALKTHROUGH_DIRECTORY.name)}/${project._id}`
                )
              })
              resolve(getAPIResponse(messages.PROJ027.code, this.traceID, HttpStatus.OK, projects))
            }
            resolve(getAPIResponse(messages.PROJ033.code, this.traceID, HttpStatus.OK, []))
          }
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_PROJECTS, this.traceID, { userID, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  updateSenderID = (projectID: string, senderIDObject: SenderIDDTO) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      let smsSenderID = senderIDObject.senderID
      smsSenderID = smsSenderID.toUpperCase()
      createOperations
        .updateOne(this.projectsModel, { _id: projectID }, { $set: { smsSenderID } })
        .then((project: Project) => {
          if (!_.isNil(project)) {
            RedisHandler.getInstance().set(redisKeys.PROJECT.value(projectID), JSON.stringify(project))
            RedisHandler.getInstance().expire(redisKeys.PROJECT.value(projectID), redisKeys.USER.timeout())
            resolve(getAPIResponse(messages.PROJ021.code, this.traceID, HttpStatus.OK, project))
          } else {
            resolve(getAPIResponse(messages.PROJ019.code, this.traceID, HttpStatus.NOT_FOUND))
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_PROJECT_SENDER_ID, this.traceID, { projectID, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  createProject = (filePath: string, fileName: string, createObject: CreateProjectDTO, userID: string) =>
    new Promise<ServiceResponse>((resolve) => {
     // if (_.isNil(fileName)) {
       // resolve(getAPIResponse(messages.PROJ006.code, this.traceID, HttpStatus.BAD_REQUEST))
      // } else {
        const projectObject: Project = <Project>(<unknown>createObject)
        projectObject.clientID = userID
        projectObject.location = {} as Location
        projectObject.location.streetAddress = {} as StreetAddress
        projectObject.location.city = createObject.city
        projectObject.location.country = createObject.country
        projectObject.location.latitude = createObject.latitude
        projectObject.location.longitude = createObject.longitude
        projectObject.location.postalCode = createObject.postalCode
        projectObject.location.state = createObject.state
        projectObject.location.streetAddress.sequence = createObject.sequence
        projectObject.location.streetAddress.area = createObject.area
        projectObject.location.landMark = createObject.landMark
        projectObject.description=createObject.description
        projectObject.imageURL = fileName
        createOperations
          .save(new this.projectsModel(projectObject))
          .then((projectSaveResult: Project) => {
            if (!_.isNil(projectSaveResult._id)) {
              RedisHandler.getInstance().set(redisKeys.PROJECT.value(projectSaveResult._id), JSON.stringify(projectSaveResult))
              RedisHandler.getInstance().expire(redisKeys.PROJECT.value(projectSaveResult._id), redisKeys.PROJECT.timeout())
              resolve(getAPIResponse(messages.PROJ015.code, this.traceID, HttpStatus.OK, projectSaveResult))
            } else {
              deleteFile(`${filePath}/${fileName}`)
              this.logger.error(getErrorLog(canonicalMethods.CREATE_CLIENT_PROJECT, this.traceID, { projectObject }))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            }
          })
          .catch((error: Error) => {
            deleteFile(`${filePath}/${fileName}`)
            this.logger.error(getErrorLog(canonicalMethods.CREATE_CLIENT_PROJECT, this.traceID, { projectObject, error }, error.message))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
      // }
    })

  createSubType = (projectID: string, createSubType: CreateSubTypeDTO[], userID: string) =>
    new Promise<ServiceResponse>((resolve) => {
      const projectTypes: [ProjectType] = (createSubType as unknown) as [ProjectType]
      const finalProjectTypes = []
      projectTypes.forEach((projectType: ProjectType) => {
        finalProjectTypes.push(projectType)
      })
      if (!_.isNil(finalProjectTypes) && finalProjectTypes.length > 0) {
        createOperations
          .updateOne(this.projectsModel, <Project>{ _id: projectID, clientID: userID }, { $addToSet: { subTypes: { $each: finalProjectTypes } } })
          .then((project: Project) => {
            if (!_.isNil(project)) {
              RedisHandler.getInstance().set(redisKeys.PROJECT.value(projectID), JSON.stringify(project))
              RedisHandler.getInstance().expire(redisKeys.PROJECT.value(projectID), redisKeys.PROJECT.timeout())
              resolve(getAPIResponse(messages.PROJ021.code, this.traceID, HttpStatus.OK, project))
            } else {
              this.logger.error(getErrorLog(canonicalMethods.CREATE_CLIENT_PROJECT_TYPES, this.traceID, { finalProjectTypes, projectID }))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            }
          })
          .catch((error: Error) => {
            this.logger.error(getErrorLog(canonicalMethods.CREATE_CLIENT_PROJECT_TYPES, this.traceID, { finalProjectTypes, projectID, error }, error.message))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
      } else {
        resolve(getAPIResponse(messages.PROJ020.code, this.traceID, HttpStatus.FORBIDDEN))
      }
    })

  uploadWalkthrough = (filePath: string, fileName: string) =>
    new Promise<ServiceResponse>((resolve) => {
      if (_.isNil(fileName)) {
        resolve(getAPIResponse(messages.PROJ024.code, this.traceID, HttpStatus.BAD_REQUEST))
      } else {
        extract(join(join(process.cwd(), filePath), fileName), { dir: join(process.cwd(), filePath) })
          .then(() => {
            deleteFile(`${filePath}/${fileName}`)
            resolve(getAPIResponse(messages.PROJ023.code, this.traceID, HttpStatus.OK))
          })
          .catch((error: Error) => {
            deleteFile(`${filePath}/${fileName}`)
            this.logger.error(getErrorLog(canonicalMethods.UPLOAD_WALKTHROUGH, this.traceID, { error }, error.message))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
      }
    })

  updatePhone = (projectID: string, updatePhoneObject: UpdateProjectPhoneDTO, userID: string) =>
    new Promise<ServiceResponse>(async (resolve) => {
      try {
        let project = await findOperations.findOne(this.projectsModel, { _id: projectID, clientID: userID })
        if (_.isNil(project)) {
          this.logger.error(getErrorLog(canonicalMethods.UPDATE_PROJECT_PHONE, this.traceID, { updatePhoneObject, projectID }))
          resolve(getAPIResponse(messages.PROJ019.code, this.traceID, HttpStatus.BAD_REQUEST))
        }
        project = await createOperations.updateOne(this.projectsModel, { _id: projectID, clientID: userID }, { phone: updatePhoneObject.phone })
        RedisHandler.getInstance().set(redisKeys.PROJECT.value(projectID), JSON.stringify(project))
        RedisHandler.getInstance().expire(redisKeys.PROJECT.value(projectID), redisKeys.PROJECT.timeout())
        resolve(getAPIResponse(messages.PROJ044.code, this.traceID, HttpStatus.OK, { project }))
      } catch (error) {
        this.logger.error(getErrorLog(canonicalMethods.UPDATE_PROJECT_PHONE, this.traceID, { updatePhoneObject, error }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      }
    })

  uploadBrochure = (projectID: string, clientID: string, filePath: string, fileName: string) =>
    new Promise<ServiceResponse>(async (resolve) => {
      if (_.isNil(fileName)) {
        resolve(getAPIResponse(messages.PROJ024.code, this.traceID, HttpStatus.BAD_REQUEST))
      } else {
        try {
          const project = await createOperations.updateOne(this.projectsModel, { _id: projectID, clientID }, { brochure: fileName })
          if (_.isNil(project)) {
            this.logger.error(getErrorLog(canonicalMethods.UPDATE_PROJECT_PHONE, this.traceID, { projectID }))
            resolve(getAPIResponse(messages.PROJ019.code, this.traceID, HttpStatus.BAD_REQUEST))
          }
          RedisHandler.getInstance().set(redisKeys.PROJECT.value(projectID), JSON.stringify(project))
          RedisHandler.getInstance().expire(redisKeys.PROJECT.value(projectID), redisKeys.PROJECT.timeout())
          resolve(getAPIResponse(messages.PROJ045.code, this.traceID, HttpStatus.OK, { project }))
        } catch (error) {
          deleteFile(`${filePath}/${fileName}`)
          this.logger.error(getErrorLog(canonicalMethods.UPDATE_PROJECT_PHONE, this.traceID, { projectID, clientID, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        }
      }
    })
}
