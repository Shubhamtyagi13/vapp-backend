import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema()
export class ProjectType extends Document {
  @Prop({ type: String, index: true })
  name: string

  @Prop({ type: Number, index: true })
  minCarpetArea: number

  @Prop({ type: Number, index: true })
  maxCarpetArea: number

  @Prop({ type: Number, index: true })
  minPrice: number

  @Prop({ type: Number, index: true })
  maxPrice: number

  @Prop({ type: Number, index: true })
  availabilityCount: number
}

export const ProjectTypeSchema = SchemaFactory.createForClass(ProjectType)
