import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ _id: false })
export class TrendingEngagements extends Document {
  @Prop({ type: String, required: true })
  date: string

  @Prop({ type: Number, required: true })
  minutes: number

  @Prop({ type: Number, required: true })
  seconds: number

  @Prop({ type: Number, required: true })
  hour: number

  @Prop({ type: Number, required: true })
  time: number
}

const TrendingEngagementsSchema = SchemaFactory.createForClass(TrendingEngagements)

@Schema({ collection: tables.PROJECT_TRENDS.collection, autoCreate: true })
export class ProjectTrendingEngagementsSchemaStore extends Document {
  @Prop({ type: String, index: true, required: true })
  clientID: string

  @Prop({ type: String, index: true, required: true })
  projectID: string

  @Prop({ type: Number, index: true, required: true })
  year: number

  @Prop({ type: Number, index: true, required: true })
  month: number

  @Prop({ type: [TrendingEngagementsSchema] })
  trendingEngagements: [TrendingEngagements]
}

export const ProjectTrendingEngagementsSchema = SchemaFactory.createForClass(ProjectTrendingEngagementsSchemaStore)
