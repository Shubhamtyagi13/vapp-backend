import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { ProjectsController } from './projects.controller'
import { Projects, ProjectsSchema } from './projects.schema'
import { ProjectsService } from './projects.service'
import { ProjectTrendingEngagementsSchema, ProjectTrendingEngagementsSchemaStore } from './projects.trending.engagement.schema'

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Projects.name, schema: ProjectsSchema },
      {
        name: ProjectTrendingEngagementsSchemaStore.name,
        schema: ProjectTrendingEngagementsSchema
      }
    ])
  ],
  controllers: [ProjectsController],
  providers: [ProjectsService, VappLogger],
  exports: [MongooseModule]
})
export class ProjectsModule {}
