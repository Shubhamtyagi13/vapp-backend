import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'
import { StreetAddress, StreetAddressSchema } from './projects.location.address.schema'

@Schema()
export class Location extends Document {
  @Prop({ type: String, index: true })
  city: string

  @Prop({ type: String, index: true })
  country: string

  @Prop({ type: Number, index: true })
  latitude: number

  @Prop({ type: Number, index: true })
  longitude: number

  @Prop({ type: Number, index: true })
  postalCode: number

  @Prop({ type: String, index: true })
  state: string

  @Prop({ type: StreetAddressSchema, default: null })
  streetAddress: StreetAddress

  @Prop({ type: String, index: true, default: null })
  landMark: string
}

export const LocationSchema = SchemaFactory.createForClass(Location)
