import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'
import { DripCondition, DripConditionSchema } from './dripcondition.schema'

@Schema({ collection: tables.DRIP_CRITERIA.collection, autoCreate: true })
export class DripCriteria extends Document {
  @Prop({ type: String, index: true, required: true })
    clientID: string

  @Prop({ type: String, required: true })
    name: string

  @Prop({ type: Boolean, index: true, default: true })
    active: boolean

  @Prop({ type: [DripConditionSchema], default: [] })
    orConditions: [DripCondition]

  @Prop({ type: [DripConditionSchema], default: [] })
    andConditions: [DripCondition]

  @Prop({ type: [DripConditionSchema], default: [] })
    eventCondition: [DripCondition]
}

export const DripCriteriaSchema = SchemaFactory.createForClass(DripCriteria)
