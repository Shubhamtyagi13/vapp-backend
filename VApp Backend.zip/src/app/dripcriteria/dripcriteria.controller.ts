import { audience, environments, variables } from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Body, Controller, Get, Param, Post, Req, Res, UseGuards,
} from '@nestjs/common'
import { ApiBearerAuth, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { Request, Response } from 'express'
import { getEnvironmentVariable } from '@utils/platform.util'
import _ from 'lodash'
import { DripCriteriaDTO } from './dto/dripcriteria.dto'
import { DripCriteriaService } from './dripcriteria.service'

@ApiTags(DripCriteriaController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('dripcriteria')
@UseGuards(AuthenticationGuard)
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class DripCriteriaController {
  constructor(private dripCriteriaService: DripCriteriaService) {}

  /*
   create a new template for current user
  */
  @Audience([audience.CLIENT, audience.ADMIN])
  @Post('create')
  create(@Res() response: Response, @Body() dripcriteriaObject: DripCriteriaDTO, @Req() request: Request) {
    this.dripCriteriaService.createDripCriteria(request.user._id, dripcriteriaObject).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @Post('modify')
  modify(@Res() response: Response, @Body() dripcriteriaObject: DripCriteriaDTO, @Req() request: Request) {
    this.dripCriteriaService.modifyDripCriteria(request.user._id, dripcriteriaObject).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   all - retrieve all the templates for a client
   active - retrieve all active temp;ates for a client
  */
   @Audience([audience.CLIENT, audience.ADMIN])
   @Get(['all', 'active'])
  findAll(@Res() response: Response, @Req() request: Request) {
    this.dripCriteriaService.findAll(request.user._id, request.url).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   toggle DripCriteria for a client
  */
  @Audience([audience.CLIENT, audience.ADMIN])
  @Get('toggle/:dripcriteriaID/:flag')
   toggle(@Res() response: Response, @Req() request: Request, @Param('dripcriteriaID') dripcriteriaID: string, @Param('flag') flag: string) {
     this.dripCriteriaService.toggle(request.user._id, dripcriteriaID, flag).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
   }
}
