import { canonicalMethods, constants, redisKeys } from '@config'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { HttpStatus, Inject, Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import { getAPIResponse, getErrorLog } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import _ from 'lodash'
import { Model } from 'mongoose'
import { DripCriteriaDTO } from './dto/dripcriteria.dto'
import { DripCriteria, DripCriteriaSchema } from './dripcriteria.schema'

@Injectable()
export class DripCriteriaService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    @InjectModel(DripCriteria.name) private dripCriteriaModel: Model<DripCriteria>,
    private logger: VappLogger,
  ) {
    this.traceID = vapp_context.traceID
  }

  createDripCriteria = (userID: string, dripCriteriaObject: DripCriteriaDTO) => new Promise<ServiceResponse>((resolve) => {
    ((dripCriteriaObject as unknown) as DripCriteria).clientID = userID
    createOperations
      .save(new this.dripCriteriaModel(dripCriteriaObject))
      .then((dripcriteria: DripCriteria) => {
        if (!_.isNil(dripcriteria)) {
          findOperations
            .find(this.dripCriteriaModel, <DripCriteria>{ clientID: userID }, { __v: 0, password: 0 })
            .then((dripcriterias: DripCriteria[]) => {
              if (!_.isNil(dripcriterias)) {
                RedisHandler.getInstance().set(redisKeys.USER_DRIPCRITERIA.value(userID), JSON.stringify(dripcriterias))
                RedisHandler.getInstance().expire(redisKeys.USER_DRIPCRITERIA.value(userID), redisKeys.USER_DRIPCRITERIA.timeout())
              }
            })
            .catch((error: Error) => {
              this.logger.error(getErrorLog(canonicalMethods.FIND_DRIPCRITERIA, this.traceID, { dripCriteriaObject, userID, error }, error.message))
            })
          resolve(getAPIResponse(messages.DPCRI005.code, this.traceID, HttpStatus.OK))
        }
        this.logger.error(getErrorLog(canonicalMethods.CREATE_DRIPCRITERIA, this.traceID, { dripCriteriaObject, userID }))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
      .catch((error: Error) => {
        this.logger.error(getErrorLog(canonicalMethods.CREATE_DRIPCRITERIA, this.traceID, { dripCriteriaObject, userID, error }))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
  })

  modifyDripCriteria = (userID: string, dripCriteriaObject: DripCriteriaDTO) => new Promise<ServiceResponse>((resolve) => {
    const dripCriteriaModel = new this.dripCriteriaModel(dripCriteriaObject);
    ((dripCriteriaObject as unknown) as DripCriteria).clientID = userID
    findOperations.findByIdAndUpdate(this.dripCriteriaModel, dripCriteriaModel._id, dripCriteriaObject, { new: true })
      .then((dripcriteria: DripCriteria) => {
        if (!_.isNil(dripcriteria)) {
          findOperations
            .find(this.dripCriteriaModel, <DripCriteria>{ clientID: userID }, { __v: 0, password: 0 })
            .then((dripcriterias: DripCriteria[]) => {
              if (!_.isNil(dripcriterias)) {
                RedisHandler.getInstance().set(redisKeys.USER_DRIPCRITERIA.value(userID), JSON.stringify(dripcriterias))
                RedisHandler.getInstance().expire(redisKeys.USER_DRIPCRITERIA.value(userID), redisKeys.USER_DRIPCRITERIA.timeout())
              }
            })
            .catch((error: Error) => {
              this.logger.error(getErrorLog(canonicalMethods.FIND_DRIPCRITERIA, this.traceID, { dripCriteriaObject, userID, error }, error.message))
            })
          resolve(getAPIResponse(messages.DPCRI005.code, this.traceID, HttpStatus.OK))
        }
        this.logger.error(getErrorLog(canonicalMethods.CREATE_DRIPCRITERIA, this.traceID, { dripCriteriaObject, userID }))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
      .catch((error: Error) => {
        this.logger.error(getErrorLog(canonicalMethods.CREATE_DRIPCRITERIA, this.traceID, { dripCriteriaObject, userID, error }))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
  })

  findAll = (clientID: string, url: string) => new Promise<ServiceResponse>((resolve) => {
    const requestUrl = url.replace('/', '')
    let fetchActive = false
    if (_.includes(requestUrl, 'active')) {
      fetchActive = true
    }

    findOperations
      .find(this.dripCriteriaModel, { clientID })
      .then((dripcriteria: DripCriteria[]) => {
        if (!_.isNil(dripcriteria)) {
          if (dripcriteria.length > 0) {
            resolve(getAPIResponse(messages.DPCRI003.code, this.traceID, HttpStatus.OK, dripcriteria))
          }
          resolve(getAPIResponse(messages.DPCRI004.code, this.traceID, HttpStatus.OK, []))
        }
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
      .catch((error: Error) => {
        this.logger.error(getErrorLog(canonicalMethods.FIND_DRIPCRITERIA, this.traceID, { error, clientID }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
  })

  toggle = (userID: string, dripcriteriaID: string, flag: string) => new Promise<ServiceResponse>((resolve) => {
    if (!_.isEmpty(userID)) {
      createOperations
        .updateOne(this.dripCriteriaModel, { clientID: userID, _id: dripcriteriaID }, { $set: { active: flag === 'true' } })
        .then(async (dripcriteria: DripCriteria) => {
          if (!_.isNil(dripcriteria)) {
            findOperations.find(this.dripCriteriaModel, { clientID: userID }, { __v: 0, password: 0 }).then(async (dripcriterias: DripCriteria[]) => {
              if (!_.isNil(dripcriterias)) {
                RedisHandler.getInstance().set(redisKeys.USER_DRIPCRITERIA.value(userID), JSON.stringify(dripcriterias))
                RedisHandler.getInstance().expire(redisKeys.USER_DRIPCRITERIA.value(userID), redisKeys.USER_DRIPCRITERIA.timeout())
              }
            })
            resolve(getAPIResponse(messages.DPCRI006.code, this.traceID, HttpStatus.OK, dripcriteria))
          }
          this.logger.error(getErrorLog(canonicalMethods.TOGGLE_DRIP_CRITERIA, this.traceID, { dripcriteriaID, userID, flag }))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.TOGGLE_DRIP_CRITERIA, this.traceID, { dripcriteriaID, userID, flag }))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    } else {
      resolve(getAPIResponse(messages.COM002.code, this.traceID, HttpStatus.FORBIDDEN))
    }
  })
}
