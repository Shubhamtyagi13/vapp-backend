import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import { IsDefined, IsEmail, IsNotEmpty, IsNumber, IsOptional, IsString } from 'class-validator'

export class DripConditionDTO extends ClientUserIDDTO {
  @ApiProperty()
  @IsDefined()
  @IsString()
  @IsOptional()
  condition: string

  @ApiProperty()
  @IsDefined()
  @IsString()
  @IsOptional()
  name: string

  @ApiProperty()
  @IsDefined()
  @IsNumber()
  @IsOptional()
  value: number

  @ApiProperty()
  @IsDefined()
  @IsString()
  @IsOptional()
  logicalOperator: string
}