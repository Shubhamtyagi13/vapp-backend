import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsBoolean, IsDefined, IsOptional, IsString, IsArray, IsNumber, ValidateNested } from 'class-validator'
import { Type } from 'class-transformer'
import { DripConditionDTO } from './dripcondition.dto'

export class DripCriteriaDTO extends ClientUserIDDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  name : string

  @ApiProperty()
  @IsBoolean()
  @IsOptional()
  active: boolean

  @ApiProperty()
  @ValidateNested({ each: true })
  @Type(() => DripConditionDTO)
  @IsDefined()
  andConditions: [DripConditionDTO]

  @ApiProperty()
  @ValidateNested({ each: true })
  @Type(() => DripConditionDTO)
  @IsDefined()
  orConditions: [DripConditionDTO]

  @ApiProperty()
  @ValidateNested({ each: true })
  @Type(() => DripConditionDTO)
  @IsDefined()
  eventCondition: [DripConditionDTO]
}
