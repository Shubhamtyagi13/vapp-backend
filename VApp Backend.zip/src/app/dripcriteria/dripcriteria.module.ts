import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { DripCriteriaController } from './dripcriteria.controller'
import { DripCriteria, DripCriteriaSchema } from './dripcriteria.schema'
import { DripCriteriaService } from './dripcriteria.service'

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: DripCriteria.name, schema: DripCriteriaSchema }
    ])
  ],
  controllers: [DripCriteriaController],
  providers: [DripCriteriaService, VappLogger],
  exports: [MongooseModule]
})
export class DripCriteriaModule {}
