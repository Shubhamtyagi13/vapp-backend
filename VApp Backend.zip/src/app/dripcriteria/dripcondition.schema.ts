import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ _id: false })
export class DripCondition extends Document {
  @Prop({ type: String, required: true, default: null })
  name: string

  @Prop({ type: String, required: true, default: null, index: true })
  condition: string

  @Prop({ type: Number, required: true, index: true })
  value: number

  @Prop({ type: String, default: null, index: true })
  logicalOperator: string
}

export const DripConditionSchema = SchemaFactory.createForClass(DripCondition)