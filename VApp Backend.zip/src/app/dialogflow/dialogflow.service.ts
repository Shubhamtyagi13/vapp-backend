import { canonicalMethods, constants, variables } from '@config'
import { Credentials } from '@interfaces/dialogflow.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { HttpStatus, Inject } from '@nestjs/common'
import { VappLogger } from '@services/logger.service'
import { getAPIResponse, getEnvironmentVariable, getErrorLog } from '@utils/platform.util'
import { google } from 'googleapis'
import { JWT } from 'googleapis-common'
import _ from 'lodash'

export class DialogflowService {
  private traceID: string

  private _googleJWTClient: JWT

  constructor(@Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext, private logger: VappLogger) {
    this.traceID = this.vapp_context.traceID
    this._googleJWTClient = new google.auth.JWT(
      getEnvironmentVariable(variables.DIALOGFLOW_EMAIL.name),
      null,
      getEnvironmentVariable(variables.DIALOGFLOW_PRIVATE_KEY.name),
      constants.DIALOGFLOW.scopes,
      null
    )
  }

  authenticate = () =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      this._googleJWTClient.authorize((error: Error | null, token: Credentials) => {
        if (!_.isNil(error)) {
          this.logger.error(getErrorLog(canonicalMethods.DIALOGFLOW_AUTHENTICATE, this.traceID, { error }, error.message))
          resolve(getAPIResponse(messages.DIAL002.code, this.traceID, HttpStatus.BAD_REQUEST, error.message))
        } else {
          resolve(getAPIResponse(messages.DIAL001.code, this.traceID, HttpStatus.OK, { token: token.access_token }))
        }
      })
    })
}
