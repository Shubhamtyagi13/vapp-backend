import { Module } from '@nestjs/common'
import { VappLogger } from '@services/logger.service'
import { DialogflowController } from './dialogflow.controller'
import { DialogflowService } from './dialogflow.service'

@Module({
  imports: [],
  controllers: [DialogflowController],
  providers: [DialogflowService, VappLogger]
})
export class DialogflowModule {}
