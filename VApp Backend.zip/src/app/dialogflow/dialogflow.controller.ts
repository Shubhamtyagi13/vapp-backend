import { environments, variables } from '@config'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Controller, Get, Req, Res,
} from '@nestjs/common'
import { ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import { DialogflowService } from './dialogflow.service'
/*
  Dialog flow controller is used to connent and record chatbot responses
*/
@ApiTags(DialogflowController.name)
@Controller('dialogflow')
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class DialogflowController {
  constructor(private dialogflowService: DialogflowService) {}

  @Get()
  authenticate(@Res() response: Response, @Req() request: Request) {
    this.dialogflowService.authenticate().then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }
}
