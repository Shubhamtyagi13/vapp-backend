import { audience, environments, variables } from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Controller, Get, Param, Req, Res, UseGuards,
} from '@nestjs/common'
import { ApiBearerAuth, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import { ScheduleService } from './schedule.service'

@ApiTags(ScheduleController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('schedules')
@UseGuards(AuthenticationGuard)
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class ScheduleController {
  constructor(private scheduleService: ScheduleService) {}

  @Audience([audience.CLIENT, audience.ADMIN])
  @Get('all')
  findAll(@Res() response: Response, @Req() request: Request) {
    this.scheduleService.findAll(request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @Get('cancel/:cancelID')
  cancelJOb(@Res() response: Response, @Req() request: Request, @Param('cancelID') cancelID: string) {
    this.scheduleService.cancelJob(request.user._id, cancelID).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }
}
