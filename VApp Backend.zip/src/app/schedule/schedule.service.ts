import { canonicalMethods, constants, cronJobs, campaignStates } from '@config'
import { CronPayload } from '@interfaces/cron.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { CampaignCronPayload } from '@interfaces/sms-campaign.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { InjectQueue } from '@nestjs/bull'
import { HttpStatus, Inject } from '@nestjs/common'
import { VappLogger } from '@services/logger.service'
import { getAPIResponse, getErrorLog } from '@utils/platform.util'
import { Job, Queue } from 'bull'
import _ from 'lodash'
import { createOperations, findOperations } from '@utils/crud.util'
import { InjectModel } from '@nestjs/mongoose'
import { Campaign } from '@app/campaign/campaign.schema'
import { Model, Types } from 'mongoose'

export class ScheduleService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    @InjectModel(Campaign.name) private campaignModel: Model<Campaign>,
    private logger: VappLogger,
    @InjectQueue(cronJobs.CREATE_SMS_CAMPAIGN.name) private createSMSCampaignQueue: Queue,
  ) {
    this.traceID = vapp_context.traceID
  }

  findAll = (userID: string) => new Promise<ServiceResponse>(async (resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
    try {
      const jobs: Job<CronPayload<CampaignCronPayload>>[] = await this.createSMSCampaignQueue.getDelayed()
      const responseJobs = jobs
        .filter((job) => _.eq(job.data.payload.clientID, userID))
        .map((job) => ({
          id: job.id,
          data: job.data,
          scheduleDate: new Date(new Date(job.timestamp).getTime() + job.opts.delay),
        }))
      if (!_.isEmpty(jobs)) {
        resolve(getAPIResponse(messages.SCHE001.code, this.traceID, HttpStatus.OK, responseJobs))
      } else {
        resolve(getAPIResponse(messages.SCHE001.code, this.traceID, HttpStatus.OK, []))
      }
    } catch (error) {
      this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_SCHEDULES, this.traceID, { userID }, error.message))
      resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR, []))
    }
  })

  cancelJob = (userID: string, cancelID: string) => new Promise<ServiceResponse>(async (resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
    try {
      const jobs: Job<CronPayload<CampaignCronPayload>>[] = await this.createSMSCampaignQueue.getDelayed()
      const job = jobs.find((job) => _.eq(job.data.payload.clientID, userID) && _.eq(job.id, cancelID))
      if (!_.isNil(job)) {
        await job.remove()
        const campaign = await createOperations.updateOne(this.campaignModel, { _id: job.data.payload.campaignID }, {
          status: campaignStates.CANCELLED,
        })
        const jobs: Job<CronPayload<CampaignCronPayload>>[] = await this.createSMSCampaignQueue.getDelayed()
        const responseJobs = jobs
          .filter((job) => _.eq(job.data.payload.clientID, userID))
          .map((job) => ({
            id: job.id,
            data: job.data,
            scheduleDate: new Date(new Date(job.timestamp).getTime() + job.opts.delay),
          }))
        resolve(getAPIResponse(messages.SCHE003.code, this.traceID, HttpStatus.OK, { status: true, id: cancelID, jobs: responseJobs }))
      } else {
        resolve(getAPIResponse(messages.SCHE004.code, this.traceID, HttpStatus.NOT_FOUND, { id: cancelID }))
      }
    } catch (error) {
      this.logger.error(getErrorLog(canonicalMethods.CANCEL_CLIENT_SCHEDULE, this.traceID, { userID, cancelID }, error.message))
      resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
    }
  })
}
