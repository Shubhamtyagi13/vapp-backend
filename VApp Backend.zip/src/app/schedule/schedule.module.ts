import { CreateSMSCampaignQueueModule, CreateRBMCampaignQueueModule } from '@app/campaign/cron/queue.module'
import { Module } from '@nestjs/common'
import { VappLogger } from '@services/logger.service'
import { ScheduleController } from './schedule.controller'
import { ScheduleService } from './schedule.service'
import { Campaign, CampaignSchema } from '@app/campaign/campaign.schema'
import { MongooseModule } from '@nestjs/mongoose'

@Module({
  imports: [MongooseModule.forFeature([{ name: Campaign.name, schema: CampaignSchema }]), CreateSMSCampaignQueueModule, CreateRBMCampaignQueueModule],
  controllers: [ScheduleController],
  providers: [ScheduleService, VappLogger],
})
export class ScheduleModule {}
