import { Campaign } from '@app/campaign/campaign.schema'
import { canonicalMethods, constants } from '@config'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { HttpStatus, Inject } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { findOperations } from '@utils/crud.util'
import { getAPIResponse, getErrorLog } from '@utils/platform.util'
import { Model } from 'mongoose'
import { AnalyticsMasterDTO } from './dto/master-filter-dto'
import { getDBFilterFromAnalyticsDTO } from './helper/master-analytics.helper'

export class AnalyticsService {
  private traceID: string

  constructor(@InjectModel(Campaign.name) private campaignModel: Model<Campaign>, @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext, private logger: VappLogger) {
    this.traceID = this.vapp_context.traceID
  }

  fetchMasterAnalyticsData = (filterObject: AnalyticsMasterDTO) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      const filter = getDBFilterFromAnalyticsDTO(filterObject)
      findOperations
        .find(this.campaignModel, filter)
        .then((campaigns: Campaign[]) => {
          resolve(getAPIResponse(messages.ANALY001.code, this.traceID, HttpStatus.OK, campaigns))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.CLIENT_BULK_SMS_CAMPAIGN, this.traceID, { filterObject }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

    fetchAggregatedTrends = (filterObject: AnalyticsMasterDTO) =>
     new Promise<ServiceResponse>(async (resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      try {
        let filter = getDBFilterFromAnalyticsDTO(filterObject)
        console.log(":::: campaigns :::: ")
        let campaigns: Campaign[] = await findOperations.find(this.campaignModel, filter)
        console.log(" --- Fetch Aggregate trends --")
        
        let data = await findOperations.aggregate(
          this.campaignModel,
          [{
            $match: {
              year: new Date().getFullYear()
            }
          },
            {
              $project: {
                _id: '$_id',
                phone: 1,
                smsSentCount: 1,
                smsDeliveredCount : 1,
                whatsappSentCount : 1,
                whatsappDeliveredCount : 1,
                month:1,
                totalSentCount :{ '$add':['$smsSentCount','$whatsappSentCount'] },
              }
          },{
            $group:{
              _id:'$month',
              sumSmsSentCount: { $sum: '$smsSentCount' },
              sumWhatsappSentCount: { $sum: '$whatsappSentCount' },
              sumwhatsappDeliveredCount: { $sum: '$whatsappDeliveredCount' },
              sumSmsDeliveredCount :{ $sum: '$smsDeliveredCount' },
              totalSumSentCount : { $sum: '$totalSentCount' }
              
            }
          }
        ])
        console.log(data)
        resolve(getAPIResponse(messages.ANALY001.code, this.traceID, HttpStatus.OK, data))
       } catch (error) {
         console.log(error)
         this.logger.error(getErrorLog(canonicalMethods.CLIENT_BULK_SMS_CAMPAIGN, this.traceID, { filterObject }, error.message))
         return resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      }
    })
}
