import { Campaign, CampaignSchema } from '@app/campaign/campaign.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { AnalyticsController } from './analytics.controller'
import { AnalyticsService } from './analytics.service'

@Module({
  imports: [MongooseModule.forFeature([{ name: Campaign.name, schema: CampaignSchema }])],
  controllers: [AnalyticsController],
  providers: [AnalyticsService, VappLogger]
})
export class AnalyticsModule {}
