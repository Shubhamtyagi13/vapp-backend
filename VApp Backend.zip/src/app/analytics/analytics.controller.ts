import { audience, environments, variables } from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Body, Controller, Post, Res, UseGuards, Get
} from '@nestjs/common'
import { ApiBearerAuth, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Response } from 'express'
import _ from 'lodash'
import { AnalyticsService } from './analytics.service'
import { AnalyticsMasterDTO } from './dto/master-filter-dto'
/*
  Dialog flow controller is used to connent and record chatbot responses
*/
@ApiTags(AnalyticsController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('analytics')
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class AnalyticsController {
  constructor(private analyticsService: AnalyticsService) {}

  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post('master')
  fetchMasterAnalyticsData(@Res() response: Response, @Body() filterObject: AnalyticsMasterDTO) {
    this.analyticsService.fetchMasterAnalyticsData(filterObject).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get('/trends')
  fetchAggregatedTrends(@Res() response: Response, @Body() filterObject: AnalyticsMasterDTO) {
    this.analyticsService.fetchAggregatedTrends(filterObject).then((service_response: ServiceResponse) => {
      return response.status(service_response.status).send(<APIResponse>service_response)
    })
  } 
}
