import { ApiProperty } from '@nestjs/swagger'
import { Type } from 'class-transformer'
import { IsArray, IsNumber, IsOptional } from 'class-validator'

export class AnalyticsMasterDTO {
  @ApiProperty({ required: false })
  @IsNumber()
  @IsOptional()
  year?: number

  @ApiProperty({ required: false })
  @IsNumber()
  @IsOptional()
  month?: number

  @ApiProperty({ required: false })
  @IsNumber()
  @IsOptional()
  day?: number

  @ApiProperty({ required: false })
  @IsOptional()
  @IsArray()
  @Type(() => Number)
  channels?: number[]

  @ApiProperty({ required: false })
  @IsOptional()
  @IsArray()
  @Type(() => String)
  sources?: string[]

  @ApiProperty({ required: false })
  @IsOptional()
  @IsArray()
  @Type(() => String)
  clients?: string[]

  @ApiProperty({ required: false })
  @IsOptional()
  @IsArray()
  @Type(() => String)
  projects?: string[]
}
