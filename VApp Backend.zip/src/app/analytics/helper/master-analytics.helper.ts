import { GenericObject } from '@interfaces/generic.interface'
import _ from 'lodash'
import { AnalyticsMasterDTO } from '../dto/master-filter-dto'

export const getDBFilterFromAnalyticsDTO = (filterObject: AnalyticsMasterDTO): GenericObject => {
  const filter = {} as GenericObject
  filter.year = new Date().getFullYear()
  if (!_.isNil(filterObject.month)) {
    filter.month = filterObject.month
  }
  if (!_.isNil(filterObject.day)) {
    filter.day = filterObject.day
  }
  if (!_.isNil(filterObject.channels)) {
    filter.type = { $in: filterObject.channels }
  }
  if (!_.isNil(filterObject.sources)) {
    filter.route = { $in: filterObject.sources }
  }
  if (!_.isNil(filterObject.clients)) {
    filter.clientID = { $in: filterObject.clients }
  }
  if (!_.isNil(filterObject.projects)) {
    filter.projectID = { $in: filterObject.projects }
  }
  filter.success = true
  return filter
}
