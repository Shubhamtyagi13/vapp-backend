import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { cronJobs } from '@config'
import { GenericObject } from '@interfaces/generic.interface'
import { getArgs } from '@utils/platform.util'
import { RBMClient } from '@libraries/rbm/rbm.service'
import { LeadSquaredIntegrationsService } from './helpers/leadsquared/leadsqaured.integration.service'
import { IntegrationsController } from './integrations.controller'
import { Integrations, IntegrationSchema } from './integrations.schema'
import { IntegrationsService } from './integrations.service'
import { QueueUIProvider } from './cron/queue.ui'
import { ProcessIntegrationsProcessor } from './cron/queue.processor'
import { ProcessIntegrationsQueueModule } from './cron/queue.module'
import { WebhooksIntegrationsService } from './helpers/webhooks/webhooks.integration.service'
import { RBMIntegrationsService } from './helpers/rbm/rbm.integration.service'

const cronSwitcher = () => {
  const cron_processor = (getArgs() as GenericObject).cron
  let processor_array: Array<any> = []
  switch (cron_processor) {
    case cronJobs.PROCESS_INTEGRATIONS.name:
      processor_array = [ProcessIntegrationsProcessor]
      break
  }
  return processor_array
}
@Module({
  imports: [ProcessIntegrationsQueueModule, MongooseModule.forFeature([{ name: Integrations.name, schema: IntegrationSchema }])],
  controllers: [IntegrationsController],
  providers: [VappLogger, IntegrationsService, LeadSquaredIntegrationsService, RBMClient, WebhooksIntegrationsService, RBMIntegrationsService, ...cronSwitcher(), QueueUIProvider]
})
export class IntegrationsCronModule {}
