import { integration_category, integration_type } from '@config'
import { GenericObject } from '@interfaces/generic.interface'
import { ApiProperty } from '@nestjs/swagger'
import { IsBoolean, IsDefined, IsEnum, IsMongoId, IsNotEmptyObject, isNotEmptyObject, IsNumber, IsObject, IsOptional, IsString } from 'class-validator'

export class CreateIntegrationDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsObject()
  @IsNotEmptyObject()
  credentials: GenericObject

  @ApiProperty({ required: true })
  @IsDefined()
  @IsOptional()
  @IsMongoId()
  clientID: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  @IsEnum(integration_type)
  type: integration_type

  @ApiProperty({ required: true })
  @IsOptional()
  @IsBoolean()
  enabled: boolean

  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  @IsEnum(integration_category)
  category: integration_category

  @ApiProperty({ required: true })
  @IsDefined()
  @IsOptional()
  metadata: GenericObject
}
