import { canonicalMethods, constants, cronJobs, integration_operation, integration_type, redisKeys } from '@config'
import { GenericObject } from '@interfaces/generic.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { messages } from '@messages'
import { HttpStatus } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import { getAPIResponse, getErrorLog } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import _ from 'lodash'
import { Model } from 'mongoose'
import { Request } from '@interfaces/request.interface'
import { InjectQueue } from '@nestjs/bull'
import { Queue } from 'bull'
import { IntegrationsCronPayload } from '@interfaces/cron.interface'
import { CreateIntegrationDTO } from './dto/create-integration.dto'
import { LeadSquaredIntegrationsService } from './helpers/leadsquared/leadsqaured.integration.service'
import { Integrations } from './integrations.schema'
import { WebhooksIntegrationsService } from './helpers/webhooks/webhooks.integration.service'
import { RBMIntegrationsService } from './helpers/rbm/rbm.integration.service'

export class IntegrationsService {
  constructor(
    @InjectModel(Integrations.name) private integrationsModel: Model<Integrations>,
    private leadSquaredService: LeadSquaredIntegrationsService,
    private webhooksService: WebhooksIntegrationsService,
    private rbmService: RBMIntegrationsService,

    @InjectQueue(cronJobs.PROCESS_INTEGRATIONS.name) private processIntegrationsQueue: Queue,
    private logger: VappLogger
  ) {}

  createIntegration = (createIntegrationObject: CreateIntegrationDTO, traceID: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      this.switchVerifyCall(createIntegrationObject.type)
        .verifyUser(createIntegrationObject.credentials as any, traceID)
        .then((data: GenericObject) => {
          if (!_.isNil(data)) {
            createIntegrationObject.metadata = data
            createOperations
              .updateOneUpsert(
                this.integrationsModel,
                {
                  type: createIntegrationObject.type,
                  clientID: createIntegrationObject.clientID
                },
                createIntegrationObject
              )
              .then((integration: Integrations) => {
                if (!_.isNil(integration)) {
                  this.updateIntegrationsInCache(traceID, createIntegrationObject.clientID)
                  resolve(getAPIResponse(messages.ING001.code, traceID, HttpStatus.OK, _.pick(integration.toObject(), _.pull(_.keys(integration.toObject()), 'credentials', '__v', 'clientID'))))
                } else {
                  resolve(getAPIResponse(messages.COM001.code, traceID, HttpStatus.PARTIAL_CONTENT))
                }
              })
              .catch((error) => {
                this.logger.error(getErrorLog(canonicalMethods.CREATE_INTEGRATIONS, traceID, { createIntegrationObject, error }, error.message))
                resolve(getAPIResponse(messages.COM001.code, traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              })
          } else {
            this.logger.error(getErrorLog(canonicalMethods.CREATE_INTEGRATIONS, traceID, { createIntegrationObject }, messages.ING003.message))
            resolve(getAPIResponse(messages.ING003.code, traceID, HttpStatus.PARTIAL_CONTENT))
          }
        })
        .catch((error) => {
          this.logger.error(getErrorLog(canonicalMethods.CREATE_INTEGRATIONS, traceID, { createIntegrationObject, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  processIntegration = async (integrationOperation: integration_operation, metadata: Request, traceID: string) => {
    const { data } = await this.fetchIntegrations(metadata.clientID, traceID, true)
    if (!_.isNil(data)) {
      data.forEach((integration: Integrations) => {
        if (integration.enabled && !constants.IGNORE_INTEGRATIONS.includes(integration.type)) {
          this.processIntegrationsQueue.add({
            payload: {
              integration,
              integrationOperation,
              metadata
            } as IntegrationsCronPayload,
            traceID
          })
        }
      })
    }
  }

  fetchIntegrations = (clientID: string, traceID: string, internalRequire = false) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      RedisHandler.getInstance().get(redisKeys.USER_INTEGRATIONS.value(clientID), (error: Error, data: string) => {
        if (_.isNil(error) && !_.isNil(data)) {
          const output = JSON.parse(data) as Array<Integrations>
          if (!internalRequire) {
            output.forEach((integration: Integrations, index: number) => {
              delete output[index].credentials
            })
          }
          resolve(getAPIResponse(messages.ING004.code, traceID, HttpStatus.OK, output))
        } else {
          findOperations
            .findLean(
              this.integrationsModel,
              {
                clientID
              },
              { __v: 0, clientID: 0 }
            )
            .then((existingIntegrations: Array<Integrations>) => {
              if (!_.isNil(existingIntegrations)) {
                this.updateIntegrationsInCache(traceID, clientID, existingIntegrations)
                if (!internalRequire) {
                  existingIntegrations.forEach((integration: Integrations, index: number) => {
                    delete existingIntegrations[index].credentials
                  })
                }
                resolve(getAPIResponse(messages.ING004.code, traceID, HttpStatus.OK, existingIntegrations))
              } else {
                resolve(getAPIResponse(messages.COM001.code, traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              }
            })
            .catch((error) => {
              this.logger.error(getErrorLog(canonicalMethods.CREATE_INTEGRATIONS, traceID, { clientID, error }, error.message))
              resolve(getAPIResponse(messages.COM001.code, traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            })
        }
      })
    })

  toggleIntegration = (clientID: string, url: string, integrationID: string, traceID: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      const status = !!_.includes(url, 'enable')
      createOperations
        .updateOne(this.integrationsModel, { _id: integrationID, clientID }, { $set: { enabled: status } })
        .then((integration: Integrations) => {
          if (!_.isNil(integration)) {
            this.updateIntegrationsInCache(traceID, clientID)
            return resolve(getAPIResponse(messages.ING005.code, traceID, HttpStatus.OK, { enabled: status }))
          }
          return resolve(getAPIResponse(messages.ING006.code, traceID, HttpStatus.NOT_FOUND))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.TOGGLE_INTEGRATIONS, traceID, { clientID, url, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  private updateIntegrationsInCache = async (traceID: string, clientID: string, existingIntegrations: Array<Integrations> = null) => {
    let updatedIntegrations: Array<Integrations>
    try {
      if (!_.isNil(existingIntegrations)) {
        updatedIntegrations = existingIntegrations
      } else {
        updatedIntegrations = await findOperations.findLean(
          this.integrationsModel,
          {
            clientID
          },
          { __v: 0, clientID: 0 }
        )
      }
    } catch (error) {
      this.logger.error(getErrorLog(canonicalMethods.UPDATE_INTEGRATIONS, traceID, { clientID, error }, error.message))
    }
    if (!_.isNil(updatedIntegrations)) {
      RedisHandler.getInstance().set(redisKeys.USER_INTEGRATIONS.value(clientID), JSON.stringify(updatedIntegrations))
      RedisHandler.getInstance().expire(redisKeys.USER_INTEGRATIONS.value(clientID), redisKeys.USER_INTEGRATIONS.timeout())
    }
  }

  private switchVerifyCall(type: integration_type) {
    switch (type) {
      case integration_type.LEADSQUARED:
        return this.leadSquaredService
      case integration_type.WEBHOOKS:
        return this.webhooksService
      case integration_type.RBM:
        return this.rbmService
      default:
        return null
    }
  }
}
