import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { RBMClient } from '@libraries/rbm/rbm.service'
import { LeadSquaredIntegrationsService } from './helpers/leadsquared/leadsqaured.integration.service'
import { IntegrationsController } from './integrations.controller'
import { Integrations, IntegrationSchema } from './integrations.schema'
import { IntegrationsService } from './integrations.service'
import { QueueUIProvider } from './cron/queue.ui'
import { ProcessIntegrationsQueueModule } from './cron/queue.module'
import { WebhooksIntegrationsService } from './helpers/webhooks/webhooks.integration.service'
import { RBMIntegrationsService } from './helpers/rbm/rbm.integration.service'

@Module({
  imports: [MongooseModule.forFeature([{ name: Integrations.name, schema: IntegrationSchema }]), ProcessIntegrationsQueueModule],
  controllers: [IntegrationsController],
  providers: [VappLogger, IntegrationsService, LeadSquaredIntegrationsService, RBMClient, WebhooksIntegrationsService, RBMIntegrationsService, QueueUIProvider],
  exports: [IntegrationsService, LeadSquaredIntegrationsService, RBMIntegrationsService, RBMClient, WebhooksIntegrationsService, MongooseModule.forFeature([{ name: Integrations.name, schema: IntegrationSchema }]), ProcessIntegrationsQueueModule]
})
export class IntegrationsModule {}
