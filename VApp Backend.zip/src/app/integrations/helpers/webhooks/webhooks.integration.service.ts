import { canonicalMethods, constants, integrations, integration_type } from '@config'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { HttpStatus, Inject } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import { getErrorLog } from '@utils/platform.util'
import { HttpResponse } from '@interfaces/http.interface'
import _ from 'lodash'
import { Model } from 'mongoose'
import { GenericObject } from '@interfaces/generic.interface'
import async from 'async'
import { IntegrationsHTTPService } from '@services/integrations.http.service'
import { HTTPService } from '@services/http.service'
import { Integrations } from '../../integrations.schema'
import { WebhooksCredentials } from './interfaces/credentials.interface'

export class WebhooksIntegrationsService {
  constructor(@InjectModel(Integrations.name) private integrationsModel: Model<Integrations>, private logger: VappLogger) {}

  verifyUser = (credentials: WebhooksCredentials, traceID: string) =>
    new Promise<{ url: string }>((resolve: (value?: { url: string } | PromiseLike<{ url: string }>) => void) => {
      HTTPService.getInstance()
        .post(credentials.apiURL, { Source: 'VApp Webhook Verification' }, {}, {}, 5000)
        .then(async (response: HttpResponse<any>) => {
          if (_.isEqual(response.status, HttpStatus.OK)) {
            resolve({ url: credentials.apiURL })
          } else {
            resolve(null)
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.CREATE_INTEGRATIONS, traceID, { type: integration_type.WEBHOOKS, sub: 'VERIFY', credentials, error }, error.message))
          resolve(null)
        })
    })

  postLead = (credentials: WebhooksCredentials, postData: GenericObject, traceID: string) =>
    new Promise<boolean>((resolve: (value?: boolean | PromiseLike<boolean>) => void) => {
      HTTPService.getInstance()
        .post(credentials.apiURL, postData, {}, {}, 5000)
        .then((response: HttpResponse<any>) => {
          if (_.isEqual(response.status, HttpStatus.OK)) {
            resolve(true)
          } else {
            resolve(false)
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.CREATE_INTEGRATIONS, traceID, { type: integration_type.WEBHOOKS, sub: 'CREATE', credentials, error }, error.message))
          resolve(false)
        })
    })
}
