export interface WebhooksCredentials {
  apiURL: string
}
