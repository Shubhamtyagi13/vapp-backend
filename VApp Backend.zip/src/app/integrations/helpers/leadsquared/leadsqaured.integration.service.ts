import { canonicalMethods, constants, integrations, integration_type } from '@config'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { HttpStatus, Inject } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import { getErrorLog } from '@utils/platform.util'
import { HttpResponse } from '@interfaces/http.interface'
import _ from 'lodash'
import { Model } from 'mongoose'
import { GenericObject } from '@interfaces/generic.interface'
import async from 'async'
import { IntegrationsHTTPService } from '@services/integrations.http.service'
import { Integrations } from '../../integrations.schema'
import { LeadSquaredUser } from './interfaces/user.interface'
import { LeadSquaredCredentials } from './interfaces/credentials.interface'
import { LeadSquaredCustomField } from './interfaces/fields.inteface'

export class LeadSquaredIntegrationsService {
  constructor(@InjectModel(Integrations.name) private integrationsModel: Model<Integrations>, private logger: VappLogger) {}

  verifyUser = (credentials: LeadSquaredCredentials, traceID: string) =>
    new Promise<{ email: string; name: string }>((resolve: (value?: { email: string; name: string } | PromiseLike<{ email: string; name: string }>) => void) => {
      IntegrationsHTTPService.getInstance()
        .get(`${integrations.LEAQSQAURED.BASE_API_URL}${integrations.LEAQSQAURED.GET_USERS}`, {}, { 'x-LSQ-AccessKey': credentials.accessKey, 'x-LSQ-SecretKey': credentials.secretKey })
        .then(async (response: HttpResponse<Array<LeadSquaredUser>>) => {
          if (_.isEqual(response.status, HttpStatus.OK) && !_.isNil(response.data) && !_.isEmpty(response.data)) {
            const main_user = response.data.find((user: LeadSquaredUser) => _.isEqual(user.Role, 'Administrator'))
            this.createFields(credentials, traceID)
            resolve({ email: main_user.EmailAddress, name: `${(main_user.FirstName || '').trim()} ${(main_user.LastName || '').trim()}` })
          } else {
            resolve(null)
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.CREATE_INTEGRATIONS, traceID, { type: integration_type.LEADSQUARED, sub: 'VERIFY', credentials, error }, error.message))
          resolve(null)
        })
    })

  createLead = (credentials: LeadSquaredCredentials, postData: GenericObject, traceID: string) =>
    new Promise<string>((resolve: (value?: string | PromiseLike<string>) => void) => {
      IntegrationsHTTPService.getInstance()
        .post(`${integrations.LEAQSQAURED.BASE_API_URL}${integrations.LEAQSQAURED.CREATE_LEAD}`, postData, {}, { 'x-LSQ-AccessKey': credentials.accessKey, 'x-LSQ-SecretKey': credentials.secretKey })
        .then((response: HttpResponse<{ Message: { Id: string } }>) => {
          if (_.isEqual(response.status, HttpStatus.OK) && !_.isNil(response.data.Message.Id) && !_.isEmpty(response.data.Message.Id)) {
            resolve(response.data.Message.Id)
          } else {
            resolve(null)
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.CREATE_INTEGRATIONS, traceID, { type: integration_type.LEADSQUARED, sub: 'CREATE', credentials, error }, error.message))
          resolve(null)
        })
    })

  createFields = (credentials: LeadSquaredCredentials, traceID: string) =>
    new Promise<boolean>((resolve: (value?: boolean | PromiseLike<boolean>) => void) => {
      const lead_creation_promises = []
      constants.LEADSQUARED_FIELDS.forEach((field) => {
        lead_creation_promises.push((callback: (arg0: any, arg1: boolean) => void): void => {
          const postData = {
            DisplayName: field.name,
            DataType: field.dataType,
            IsMandatory: false,
            RenderTypeTextValue: field.renderType,
            ShowInImport: true,
            ShowInMailMerge: true,
            LockAfterCreate: 0,
            UseInLeadClone: false,
            MaxLength: '255',
            OptionsJson: ''
          } as LeadSquaredCustomField
          if (field.numScale) {
            postData.Num_Scale = '4'
          }
          IntegrationsHTTPService.getInstance()
            .post(`${integrations.LEAQSQAURED.BASE_API_URL}${integrations.LEAQSQAURED.CREATE_FIELD}`, postData, {}, { 'x-LSQ-AccessKey': credentials.accessKey, 'x-LSQ-SecretKey': credentials.secretKey })
            .then((response: HttpResponse<{ Message: { Id: string }; ExceptionType?: string }>) => {
              if (_.isEqual(response.status, HttpStatus.OK) && !_.isNil(response.data.Message.Id) && !_.isEmpty(response.data.Message.Id)) {
                callback(null, true)
              } else if (!_.isNil(response.data.ExceptionType) && _.isEqual(response.data.ExceptionType, 'MXDuplicateEntryException')) {
                callback(null, true)
              } else {
                callback(false, false)
              }
            })
            .catch((error: Error) => {
              if (!_.isNil((error as any).response.data.ExceptionType) && _.isEqual((error as any).response.data.ExceptionType, 'MXDuplicateEntryException')) {
                callback(null, true)
              } else {
                this.logger.error(getErrorLog(canonicalMethods.CREATE_INTEGRATIONS, traceID, { type: integration_type.LEADSQUARED, sub: 'CREATE', credentials, error }, error.message))
                callback(false, false)
              }
            })
        })
      })
      async.series(lead_creation_promises, (err: any, results: Array<boolean>) => {
        resolve(true)
      })
    })

  updateLead = (credentials: LeadSquaredCredentials, postData: GenericObject, leadID: string, traceID: string) =>
    new Promise<number>((resolve: (value?: number | PromiseLike<number>) => void) => {
      IntegrationsHTTPService.getInstance()
        .post(`${integrations.LEAQSQAURED.BASE_API_URL}${integrations.LEAQSQAURED.UPDATE_LEAD}${leadID}`, postData, {}, { 'x-LSQ-AccessKey': credentials.accessKey, 'x-LSQ-SecretKey': credentials.secretKey })
        .then((response: HttpResponse<{ Message: { AffectedRows: number } }>) => {
          if (_.isEqual(response.status, HttpStatus.OK) && !_.isNil(response.data.Message) && !_.isEmpty(response.data.Message.AffectedRows)) {
            resolve(response.data.Message.AffectedRows)
          } else {
            resolve(null)
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.CREATE_INTEGRATIONS, traceID, { type: integration_type.LEADSQUARED, sub: 'UPDATE', credentials, error }, error.message))
          resolve(null)
        })
    })
}
