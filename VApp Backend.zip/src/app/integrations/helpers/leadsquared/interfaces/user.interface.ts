export interface LeadSquaredUser {
  ID: string
  FirstName: string
  LastName: string
  EmailAddress: string
  Role: string
}
