export interface LeadSquaredCredentials {
  accessKey: string
  secretKey: string
}
