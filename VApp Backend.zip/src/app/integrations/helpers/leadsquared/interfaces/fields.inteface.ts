export interface LeadSquaredCustomField {
  DisplayName: string
  DataType: string
  IsMandatory: boolean
  RenderTypeTextValue: string
  ShowInImport: boolean
  ShowInMailMerge: boolean
  LockAfterCreate: number
  UseInLeadClone: boolean
  MaxLength: string
  Num_Scale?: string
  OptionsJson: string
}
