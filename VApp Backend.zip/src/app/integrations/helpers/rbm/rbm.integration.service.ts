import { canonicalMethods, integration_type } from '@config'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { getErrorLog } from '@utils/platform.util'
import _ from 'lodash'
import { Model } from 'mongoose'
import { RBMClient } from '@libraries/rbm/rbm.service'
import { GenericObject } from '@interfaces/generic.interface'
import { Integrations } from '../../integrations.schema'
import { RBMCredentials } from './interfaces/credentials.interface'

export class RBMIntegrationsService {
  constructor(@InjectModel(Integrations.name) private integrationsModel: Model<Integrations>, private rbmClient: RBMClient, private logger: VappLogger) {}

  verifyUser = (credentials: RBMCredentials, traceID: string) =>
    new Promise<GenericObject>(async (resolve: (value?: GenericObject | PromiseLike<GenericObject>) => void) => {
      const rbmClient = await this.rbmClient.initRbmApi(credentials)
      await rbmClient.authClient
        .getAccessToken()
        .then((res) => {
          if (!_.isNil(res.token)) {
            resolve({ email: credentials.client_email, id: credentials.client_id })
          } else {
            resolve(null)
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.CREATE_INTEGRATIONS, traceID, { type: integration_type.WEBHOOKS, sub: 'VERIFY', credentials, error }, error.message))
          resolve(null)
        })
    })
}
