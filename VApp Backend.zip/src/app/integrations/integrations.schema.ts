import { tables, integration_type, integration_category } from '@config'
import { GenericObject } from '@interfaces/generic.interface'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.INTEGRATIONS.collection, autoCreate: true })
export class Integrations extends Document {
  @Prop({ type: String, index: true, required: true })
  clientID: string

  @Prop({ type: {}, required: true })
  credentials: GenericObject

  @Prop({ type: Number, index: true, required: true })
  type: integration_type

  @Prop({ type: Number, index: true, required: true })
  category: integration_category

  @Prop({ type: Boolean, index: true, default: true })
  enabled: integration_category

  @Prop({ type: {}, required: false, default: null })
  readonly metadata: GenericObject
}

export const IntegrationSchema = SchemaFactory.createForClass(Integrations)
