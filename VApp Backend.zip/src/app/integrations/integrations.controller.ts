import { audience } from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { ServiceResponse, APIResponse } from '@interfaces/response.interface'
import { Body, Controller, Get, Param, Post, Req, Res, UseGuards } from '@nestjs/common'
import { ApiTags, ApiBearerAuth } from '@nestjs/swagger'
import _ from 'lodash'
import { Response, Request } from 'express'
import { CreateIntegrationDTO } from './dto/create-integration.dto'
import { IntegrationsService } from './integrations.service'

@ApiTags(IntegrationsController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('integrations')
export class IntegrationsController {
  constructor(private integrationsService: IntegrationsService) {}

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post('create')
  createIntegration(@Req() request: Request, @Body() createIntegrationObject: CreateIntegrationDTO, @Res() response: Response) {
    createIntegrationObject.clientID = request.user._id
    this.integrationsService.createIntegration(createIntegrationObject, request.VAPP_CONTEXT.traceID).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get('fetch')
  fetchIntegrations(@Req() request: Request, @Res() response: Response) {
    this.integrationsService.fetchIntegrations(request.user._id, request.VAPP_CONTEXT.traceID).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Get(['enable/:integrationID', 'disable/:integrationID'])
  toggleIntegration(@Res() response: Response, @Req() request: Request, @Param('integrationID') integrationID: string) {
    this.integrationsService.toggleIntegration(request.user._id, request.url, integrationID, request.VAPP_CONTEXT.traceID).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }
}
