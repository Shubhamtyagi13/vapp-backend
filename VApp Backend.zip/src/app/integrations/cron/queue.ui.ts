import { cronJobs } from '@config'
import { InjectQueue } from '@nestjs/bull'
import { Injectable } from '@nestjs/common'
import { Queue } from 'bull'
import { BullAdapter } from '@bull-board/api/bullAdapter'
import { BullInterfaceService } from '@services/bull-ui.service'

@Injectable()
export class QueueUIProvider {
  constructor(
    @InjectQueue(cronJobs.PROCESS_INTEGRATIONS.name) private processIntegrationsQueue: Queue
  ) {
    BullInterfaceService.getInstance().registerQueues([new BullAdapter(processIntegrationsQueue), new BullAdapter(processIntegrationsQueue)])
  }
}
