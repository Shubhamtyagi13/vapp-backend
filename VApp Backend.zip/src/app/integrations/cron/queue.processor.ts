import { Campaign } from '@app/campaign/campaign.schema'
import { OTP } from '@app/otp/otp.schema'
import { DripRequests } from '@app/requests/drip_requests.schema'
import { Requests } from '@app/requests/requests.schema'
import { Transactional } from '@app/transactional/transactional.schema'
import { User } from '@app/user/user.schema'
import { cache_client, constants, contentTypes, cronJobs, integration_operation, integration_type, redisKeys, redis_client, report_status, report_types, variables } from '@config'
import { CronPayload, IntegrationsCronPayload } from '@interfaces/cron.interface'
import { CronError } from '@interfaces/error.interface'
import { messages } from '@messages'
import { OnQueueActive, OnQueueCompleted, OnQueueFailed, Process, Processor } from '@nestjs/bull'
import { Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import { dateFromObjectId, deleteFile, getEnvironmentVariable, getErrorLog } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import { Job } from 'bull'
import _ from 'lodash'
import { LeadSquaredCredentials } from '../helpers/leadsquared/interfaces/credentials.interface'
import { LeadSquaredIntegrationsService } from '../helpers/leadsquared/leadsqaured.integration.service'
import { WebhooksCredentials } from '../helpers/webhooks/interfaces/credentials.interface'
import { WebhooksIntegrationsService } from '../helpers/webhooks/webhooks.integration.service'

@Injectable()
@Processor(cronJobs.PROCESS_INTEGRATIONS.name)
export class ProcessIntegrationsProcessor {
  constructor(private logger: VappLogger, private leadsquaredIntegrationServcie: LeadSquaredIntegrationsService, private webhooksIntegrationServcie: WebhooksIntegrationsService) {}

  private retreiveMessageID(requestID: string) {
    return new Promise<string>((res: (value?: string | PromiseLike<string>) => void, _rej) => {
      RedisHandler.getInstance().get(redisKeys.USER_CREATE_INTEGRATION.value(requestID), async (error: Error, leadID: string) => {
        if (_.isNil(error) && !_.isNil(leadID)) {
          res(leadID)
        } else {
          res(null)
        }
      })
    })
  }

  @Process({ concurrency: 1 })
  async processIntegration(job: Job<CronPayload<IntegrationsCronPayload>>) {
    const { payload, traceID } = job.data
    try {
      if (_.isEqual(payload.integration.type, integration_type.LEADSQUARED)) {
        const payloadData = []
        payloadData.push({ Attribute: 'mx_va_Request_ID', Value: payload.metadata._id })
        payloadData.push({ Attribute: 'GTalkId', Value: payload.metadata._id })
        payloadData.push({ Attribute: 'mx_va_Source', Value: 'VAPP' })
        payloadData.push({ Attribute: 'mx_va_Phone', Value: payload.metadata.phone })
        payloadData.push({ Attribute: 'mx_va_Campaign_ID', Value: payload.metadata.campaignID })
        payloadData.push({ Attribute: 'mx_va_Project_URL', Value: `https://dashboard.vapp.in/#/org/projects/${payload.metadata.projectID}` })
        payloadData.push({ Attribute: 'mx_va_Campaign_URL', Value: `https://dashboard.vapp.in/#/org/projects/${payload.metadata.projectID}/${payload.metadata.campaignID}/campaign` })
        payloadData.push({ Attribute: 'mx_va_Views', Value: payload.metadata.engagementTime.length })
        // payloadData.push({
        //   Attribute: 'mx_va_Device_Info',
        //   Value: '',
        //   Fields: [
        //     { Attribute: 'mx_va_OS', Value: payload.metadata.os },
        //     { Attribute: 'mx_va_Device', Value: payload.metadata.device },
        //     { Attribute: 'mx_va_Device_Type', Value: payload.metadata.deviceType }
        //   ]
        // })
        payloadData.push({ Attribute: 'mx_va_OS', Value: payload.metadata.os })
        payloadData.push({ Attribute: 'mx_va_Device', Value: payload.metadata.device })
        payloadData.push({ Attribute: 'mx_va_Device_Type', Value: payload.metadata.deviceType })
        // payloadData.push({
        //   Attribute: 'mx_va_Demographics',
        //   Value: '',
        //   Fields: [
        //     { Attribute: 'mx_va_IP', Value: payload.metadata.demographics?.ip },
        //     { Attribute: 'mx_va_City', Value: payload.metadata.demographics?.city },
        //     { Attribute: 'mx_va_Region', Value: payload.metadata.demographics?.region },
        //     { Attribute: 'mx_va_Region_Code', Value: payload.metadata.demographics?.region_code },
        //     { Attribute: 'mx_va_Country_Code', Value: payload.metadata.demographics?.country_code },
        //     { Attribute: 'mx_va_Latitude', Value: payload.metadata.demographics?.latitude },
        //     { Attribute: 'mx_va_Longitude', Value: payload.metadata.demographics?.longitude }
        //   ]
        // })
        payloadData.push({ Attribute: 'mx_va_IP', Value: payload.metadata.demographics?.ip })
        payloadData.push({ Attribute: 'mx_va_City', Value: payload.metadata.demographics?.city })
        payloadData.push({ Attribute: 'mx_va_Region', Value: payload.metadata.demographics?.region })
        payloadData.push({ Attribute: 'mx_va_Region_Code', Value: payload.metadata.demographics?.region_code })
        payloadData.push({ Attribute: 'mx_va_Country_Code', Value: payload.metadata.demographics?.country_code })
        payloadData.push({ Attribute: 'mx_va_Latitude', Value: payload.metadata.demographics?.latitude })
        payloadData.push({ Attribute: 'mx_va_Longitude', Value: payload.metadata.demographics?.longitude })
        payloadData.push({ Attribute: 'mx_va_Chatbot', Value: payload.metadata.chatbot })
        payloadData.push({ Attribute: 'mx_va_Brochure', Value: payload.metadata.brochure })
        payloadData.push({ Attribute: 'mx_va_Whatsapp', Value: payload.metadata.whatsapp })
        payloadData.push({ Attribute: 'mx_va_Total_Calls', Value: payload.metadata.ivr.length })
        const credentials = payload.integration.credentials as LeadSquaredCredentials
        const leadID = await this.retreiveMessageID(payload.metadata._id)
        if (_.isEqual(payload.integrationOperation, integration_operation.CREATE) || _.isNil(leadID)) {
          const messageID = await this.leadsquaredIntegrationServcie.createLead(credentials, payloadData, traceID)
          if (!_.isNil(messageID)) {
            RedisHandler.getInstance().set(redisKeys.USER_CREATE_INTEGRATION.value(payload.metadata._id), messageID)
            RedisHandler.getInstance().expire(redisKeys.USER_CREATE_INTEGRATION.value(payload.metadata._id), redisKeys.USER_CREATE_INTEGRATION.timeout())
          } else {
            throw new CronError(messages.COM002.message)
          }
        } else if (!_.isNil(leadID)) {
          await this.leadsquaredIntegrationServcie.updateLead(credentials, payloadData, leadID, traceID)
        } else {
          throw new CronError(messages.COM002.message)
        }
      } else if (_.isEqual(payload.integration.type, integration_type.WEBHOOKS)) {
        const payloadData = {}
        _.set(payloadData, 'requestID', payload.metadata._id)
        _.set(payloadData, 'campaignID', payload.metadata.campaignID)
        _.set(payloadData, 'projectID', payload.metadata.projectID)
        _.set(payloadData, 'projectURL', `https://dashboard.vapp.in/#/org/projects/${payload.metadata.projectID}`)
        _.set(payloadData, 'campaignURL', `https://dashboard.vapp.in/#/org/projects/${payload.metadata.projectID}/${payload.metadata.campaignID}/campaign`)
        _.set(payloadData, 'views', payload.metadata.engagementTime.length)
        _.set(payloadData, 'deviceInfo', {
          os: payload.metadata.os,
          device: payload.metadata.device,
          deviceType: payload.metadata.deviceType
        })
        _.set(payloadData, 'demographics', {
          ip: payload.metadata.demographics?.ip,
          city: payload.metadata.demographics?.city,
          region: payload.metadata.demographics?.region,
          regionCode: payload.metadata.demographics?.region_code,
          countryCode: payload.metadata.demographics?.country_code,
          latitude: payload.metadata.demographics?.latitude,
          longitude: payload.metadata.demographics?.longitude,
          continentCode: payload.metadata.demographics?.continent_code
        })
        _.set(payloadData, 'chatbot', payload.metadata.chatbot)
        _.set(payloadData, 'brochure', payload.metadata.brochure)
        _.set(payloadData, 'whatsapp', payload.metadata.whatsapp)
        _.set(payloadData, 'totalCalls', payload.metadata.ivr.length)
        _.set(
          payloadData,
          'engagements',
          payload.metadata.engagementTime.map((engagement) => ({
            time: engagement.time,
            data: dateFromObjectId(engagement._id).toISOString(),
            engagementID: engagement._id
          }))
        )
        const credentials = payload.integration.credentials as WebhooksCredentials
        const result = await this.webhooksIntegrationServcie.postLead(credentials, payloadData, traceID)
        if (!_.isNil(result)) {
        } else {
          throw new CronError(messages.COM002.message)
        }
      }
    } catch (error) {
      if (!_.isNil(error.name) && error.name.includes(CronError.name)) {
        error.stack = 'CronError'
      }
      throw error
    }
    job.progress(100)
    return true
  }

  @OnQueueActive()
  onActive(job: Job<CronPayload<IntegrationsCronPayload>>) {
    this.logger.log(`Processing: Job name: ${cronJobs.PROCESS_INTEGRATIONS.name} Job ID: ${job.id}`)
  }

  @OnQueueCompleted()
  onCompleted(job: Job<CronPayload<IntegrationsCronPayload>>) {
    this.logger.log(`Completed: Job name: ${cronJobs.PROCESS_INTEGRATIONS.name} Job ID: ${job.id}`)
  }

  @OnQueueFailed()
  async onFailed(job: Job<CronPayload<IntegrationsCronPayload>>) {
    const error = job.stacktrace.includes(CronError.name) ? job.failedReason : messages.COM001.message
    this.logger.error(
      getErrorLog(cronJobs.PROCESS_INTEGRATIONS.name, job.data.traceID, {
        id: job.id,
        reason: job.failedReason,
        stack: job.stacktrace,
        error
      })
    )
  }
}
