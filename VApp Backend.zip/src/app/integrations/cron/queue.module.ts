import { cronJobs, redis_client, variables } from '@config'
import { BullModule } from '@nestjs/bull'
import { getEnvironmentVariable } from '@utils/platform.util'

const redis = {
  host: getEnvironmentVariable(variables.REDIS_URL.name),
  port: getEnvironmentVariable(variables.REDIS_PORT.name)
}

export const ProcessIntegrationsQueueModule = BullModule.registerQueueAsync({
  name: cronJobs.PROCESS_INTEGRATIONS.name,
  useFactory: () => ({
    redis: { ...redis, db: redis_client.PROCESS_INTEGRATIONS },
    defaultJobOptions: {
      priority: cronJobs.PROCESS_INTEGRATIONS.priority,
      removeOnComplete: true,
      removeOnFail: false,
      attempts: cronJobs.PROCESS_INTEGRATIONS.attempts
    },
    prefix: cronJobs.PROCESS_INTEGRATIONS.name,
    settings: {
      lockRenewTime: cronJobs.PROCESS_INTEGRATIONS.lockRenew,
      maxStalledCount: cronJobs.PROCESS_INTEGRATIONS.maxStalledCount,
      lockDuration: cronJobs.PROCESS_INTEGRATIONS.lockLifeTime
    }
  })
})
