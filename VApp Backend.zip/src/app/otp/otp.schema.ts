import { constants, tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { getObjectID } from '@utils/platform.util'
import { Document } from 'mongoose'

@Schema({ collection: tables.OTP.collection, autoCreate: true })
export class OTP extends Document {
  @Prop({ type: String, required: true, default: null, index: true })
  clientID: string

  @Prop({ type: Date, index: true, required: true })
  date: Date

  @Prop({ type: String, required: true, default: null, index: true })
  templateID: string

  @Prop({ type: String, required: true, default: null })
  otp: string

  @Prop({ type: Number, required: true, default: 0 })
  credits: number

  @Prop({ type: String, index: true, required: true })
  shortID: string

  @Prop({ type: Number, required: true, default: 0 })
  expiry: number

  @Prop({ type: Boolean, index: true, default: false })
  morphed: boolean

  @Prop({ type: Number, index: true, default: constants.SMS_STATUS.submitted })
  smsStatus: number

  @Prop({ type: Boolean, index: true, default: false })
  verified: boolean

  @Prop({ type: Number, required: false, default: 0 })
  attempts: number

  @Prop({ type: Number, index: true, required: true })
  phone: number

  @Prop({ type: String, index: true, default: null })
  deliveryID: string
}

export const OTPSchema = SchemaFactory.createForClass(OTP)
