import { User } from '@app/user/user.schema'
import { TransactionOptions } from 'mongodb'
import { zip } from 'zip-a-folder'
import {
  cache_client,
  canonicalMethods,
  constants,
  cronJobs,
  otp_aggregation,
  otp_types,
  redisKeys,
  redis_client,
  report_status,
  report_types,
  variables,
} from '@config'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { HttpStatus, Inject, Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import {
  createCSV,
  deleteFolderRecursive,
  generateOTP,
  getAPIResponse,
  getCreditsFromMessage,
  getEnvironmentVariable,
  getErrorLog,
  getRequestMessage,
} from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import _ from 'lodash'
import { Model } from 'mongoose'
import { Reports, ReportsSchema } from '@app/reports/reports.schema'

import uniqid from 'uniqid'
import randomize from 'randomatic'
import { OTPDailyStatsObject, OTPDashboard, OTPMetricObject } from '@interfaces/otp.interface'
import async from 'async'

import { campaignProviderObject } from '@interfaces/sms.interface'
import { Template } from '@app/template/template.schema'
import { CampaignCronPayload } from '@interfaces/sms-campaign.interface'
import { InjectQueue } from '@nestjs/bull'
import { Queue } from 'bull'
import { ReportRequest } from '@interfaces/reports.interface'
import { S3Handler } from '@utils/s3.util'
import { Credits } from '@app/credits/credits.schema'
import path from 'path'
import fs from 'fs'
import { ProcessSMPPDTO } from '@app/campaign/dto/smpp-campaign'
import { HTTPService } from '@services/http.service'
import { OTPReportDTO } from './dto/otp-report.dto'
import { getOTPCalendarData, getOTPData, getReportData } from './helpers/otp.helper'
import { OTP } from './otp.schema'
import { VerifyOtpDTO } from './dto/verify-otp.dto'
import { RequestOtpDTO } from './dto/request-otp.dto'

@Injectable()
export class OTPService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    private logger: VappLogger,
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(OTP.name) private otpModel: Model<OTP>,
    @InjectModel(Reports.name) private reportsModel: Model<Reports>,
    @InjectModel(Template.name) private templateModel: Model<Template>,
    @InjectModel(Credits.name) private creditsModel: Model<Credits>,
    @InjectQueue(cronJobs.CREATE_REPORT.name) private reportQueue: Queue,
  ) {
    this.traceID = this.vapp_context.traceID
  }

  requestOTP = (otpPayload: RequestOtpDTO) => new Promise<ServiceResponse>((resolve) => {
    let { length, type } = otpPayload
    const { apiKey, phone, templateID } = otpPayload
    if (_.isNil(otpPayload.type)) {
      type = otp_types.NUMERIC
    }
    if (!_.isNumber(otpPayload.length)) {
      length = 6
    }
    RedisHandler.getInstance().get(redisKeys.USER_API_KEY.value(apiKey), async (error: Error, data: string) => {
      let user: User
      if (_.isNil(data)) {
        user = await findOperations.findOne(this.userModel, { apiKey })
        if (!_.isNil(user)) {
          RedisHandler.getInstance().set(redisKeys.USER_API_KEY.value(apiKey), JSON.stringify(user))
          RedisHandler.getInstance().expire(redisKeys.USER_API_KEY.value(apiKey), redisKeys.USER_API_KEY.timeout())
        } else {
          return resolve(getAPIResponse(messages.OTP003.code, this.traceID, HttpStatus.FORBIDDEN))
        }
      } else {
        user = JSON.parse(data)
      }
      if (_.includes(user?.access, constants.FEATURES_ACCESS.OTP.NAME)) {
        const template: Template = await findOperations.findOne(this.templateModel, { _id: templateID })
        if (_.isNil(template)) {
          return resolve(getAPIResponse(messages.OTP010.code, this.traceID, HttpStatus.FORBIDDEN))
        }
        if (!_.isNil(template.senderIDList) && !_.isEmpty(template.senderIDList)) {
          if (!_.isEqual(template.type, constants.TEMPLATE_TYPE.otp)) {
            return resolve(getAPIResponse(messages.OTP011.code, this.traceID, HttpStatus.FORBIDDEN))
          }
          if (_.isNil(template.templateID) || _.isEmpty(template.templateID)) {
            return resolve(getAPIResponse(messages.OTP012.code, this.traceID, HttpStatus.FORBIDDEN))
          }
          const smsTemplateID = template.templateID
          const otp_verfication_feature_access = _.includes(user.access, constants.FEATURES_ACCESS.OTP.FEATURES.VERIFY)
          const otp = `${generateOTP(length, type as otp_types)}`
          const shortID = `${randomize('Aa0', 4)}${uniqid.time()}`
          RedisHandler.getInstance().set(redisKeys.OTP.value(shortID), _.toString(otp))
          RedisHandler.getInstance().expire(redisKeys.OTP.value(shortID), redisKeys.OTP.timeout())
          const current_date = new Date()
          const otp_timeout_date = new Date()
          otp_timeout_date.setMinutes(0, current_date.getSeconds() + redisKeys.OTP.timeout())
          const otp_request = new this.otpModel(<OTP>{
            clientID: user._id,
            date: new Date(),
            templateID,
            otp,
            shortID,
            expiry: Math.floor(otp_timeout_date.getTime() / 1000),
            phone: otpPayload.phone,
          })
          let totalCredits = 0
          const smsSenderID = template.senderIDList[_.random(0, template.senderIDList.length - 1)]
          const { peID } = user
          let route = -1
          if (!_.isNaN(user.route)) {
            route = user.route
          }
          const smsProviderPayload: campaignProviderObject[] = []
          const payload = <CampaignCronPayload>{
            dynamic: true,
            message: template.text,
            otp,
            clientName: user.companyName,
            clientID: user._id,
          }
          const compiledMessage: string = getRequestMessage(payload, null, false, true)
          otp_request.credits = getCreditsFromMessage(compiledMessage)
          const credits: Credits = await findOperations.findOne(this.creditsModel, { clientID: payload.clientID }, {})
          if (!_.isNil(credits)) {
            if (credits.credits > 0 && credits.credits - totalCredits > 0) {
              totalCredits += otp_request.credits
              smsProviderPayload.push({
                phone: parseInt(String(Math.abs(Number(phone))), 10),
                message: compiledMessage,
              })
              const response = await HTTPService.getInstance().post(`${getEnvironmentVariable(variables.SMPP_SERVICE_BASE_URL.name)}campaign/common`, <ProcessSMPPDTO>{
                smpp_config: 'OTP',
                data: smsProviderPayload,
                smsSenderID,
                templateID: smsTemplateID,
                campaignID: otp_request._id,
                peID,
                reportType: report_types.OTP,
              })
              const smppMessageID = response.data?.data?.smppMessageID
              if (_.isNil(smppMessageID)) {
                return resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              }
              // RedisHandler.getInstance(cache_client.DEFAULT, redis_client.SMPP_DELIVERY).set(redisKeys.SMPP_DELIVERY_RESPONSE.value(`report_${report_types.OTP}_${smppMessageID}`), JSON.stringify(response.data))
              // RedisHandler.getInstance(cache_client.DEFAULT, redis_client.SMPP_DELIVERY).expire(redisKeys.SMPP_DELIVERY_RESPONSE.value(`report_${report_types.OTP}_${smppMessageID}`), redisKeys.SMPP_DELIVERY_RESPONSE.timeout())
              otp_request.deliveryID = smppMessageID
              const session = await this.userModel.db.startSession()
              await session.withTransaction(async () => {
                await otp_request.save()
                const creditsUpdateResult: Credits = await createOperations.updateOne(this.creditsModel, { clientID: payload.clientID }, { $inc: { credits: -totalCredits } }, session)
                await session.commitTransaction()
                RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), JSON.stringify(creditsUpdateResult))
                RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), redisKeys.USER_CREDITS.timeout())
              }, <TransactionOptions>constants.TRANSACTION_OPTIONS)
              session.endSession()
              try {
                return resolve(
                  getAPIResponse(messages.OTP001.code, this.traceID, HttpStatus.OK, otp_verfication_feature_access ? { uid: shortID, otp } : { otp }),
                )
              } catch (e) {
                return resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              }
            } else {
              return resolve(getAPIResponse(messages.CRE009.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            }
          } else {
            return resolve(getAPIResponse(messages.CRE010.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          }
        } else {
          return resolve(getAPIResponse(messages.OTP017.code, this.traceID, HttpStatus.FORBIDDEN))
        }
      } else {
        return resolve(getAPIResponse(messages.OTP008.code, this.traceID, HttpStatus.FORBIDDEN))
      }
    })
  })

  verifyOTP = (verificationPayload: VerifyOtpDTO) => new Promise<ServiceResponse>((resolve) => {
    const { uuid, otp, apiKey } = verificationPayload
    RedisHandler.getInstance().get(redisKeys.USER_API_KEY.value(apiKey), async (error: Error, data: string) => {
      if (_.isNil(data)) {
        const user: User = await findOperations.findOne(this.userModel, { apiKey })
        if (!_.isNil(user)) {
          RedisHandler.getInstance().set(redisKeys.USER_API_KEY.value(apiKey), JSON.stringify({ apiKey }))
          RedisHandler.getInstance().expire(redisKeys.USER_API_KEY.value(apiKey), redisKeys.USER_API_KEY.timeout())
        } else {
          return resolve(getAPIResponse(messages.OTP003.code, this.traceID, HttpStatus.FORBIDDEN))
        }
      }
      RedisHandler.getInstance().get(redisKeys.OTP.value(uuid), async (error: Error, data: string) => {
        if (_.isNil(error) && !_.isNil(data)) {
          const otp_match = _.eq(data, _.toString(otp))
          createOperations.updateOne(this.otpModel, { shortID: uuid }, otp_match ? { $set: { verified: true }, $inc: { attempts: 1 } } : { $inc: { attempts: 1 } })
          if (otp_match) {
            resolve(getAPIResponse(messages.OTP005.code, this.traceID, HttpStatus.OK, { verified: true }))
          } else {
            resolve(getAPIResponse(messages.OTP006.code, this.traceID, HttpStatus.OK, { verified: false }))
          }
        } else {
          resolve(getAPIResponse(messages.OTP002.code, this.traceID, HttpStatus.FORBIDDEN))
        }
      })
    })
  })

  getAnalytics = (clientID: string) => new Promise<ServiceResponse>((resolve) => {
    const otpDashboardData = {} as OTPDashboard
    otpDashboardData.metrics = {} as any
    const baseMetricObject = {
      sentTotal: 0,
      sent: _.times(24, _.constant(0)),
      deliveredTotal: 0,
      delivered: _.times(24, _.constant(0)),
      verifiedTotal: 0,
      verified: _.times(24, _.constant(0)),
      attemptsTotal: 0,
      attempts: _.times(24, _.constant(0)),
    } as OTPMetricObject
    otpDashboardData.metrics.today = _.assign({}, baseMetricObject) as OTPMetricObject
    const current_date = new Date()
    const total_days = new Date(current_date.getFullYear(), current_date.getMonth() + 1, 0).getDate()
    baseMetricObject.sent = _.times(total_days, _.constant(0))
    baseMetricObject.delivered = _.times(total_days, _.constant(0))
    baseMetricObject.verified = _.times(total_days, _.constant(0))
    baseMetricObject.attempts = _.times(total_days, _.constant(0))
    otpDashboardData.metrics.month = _.assign({}, baseMetricObject) as OTPMetricObject
    baseMetricObject.sent = _.times(12, _.constant(0))
    baseMetricObject.delivered = _.times(12, _.constant(0))
    baseMetricObject.verified = _.times(12, _.constant(0))
    baseMetricObject.attempts = _.times(12, _.constant(0))
    otpDashboardData.metrics.year = _.assign({}, baseMetricObject) as OTPMetricObject
    otpDashboardData.calendar = _.assign([], _.times(12, (month) => ({ month: month + 1, dailystats: [] })))
    const dashboardQueries = [
      (callback: (error: Error | null, data?: OTPMetricObject) => void) => getOTPData(clientID, this.otpModel, otp_aggregation.TODAY, callback),
      (callback: (error: Error | null, data?: OTPMetricObject) => void) => getOTPData(clientID, this.otpModel, otp_aggregation.MONTH, callback),
      (callback: (error: Error | null, data?: OTPMetricObject) => void) => getOTPData(clientID, this.otpModel, otp_aggregation.YEAR, callback),
      (
        callback: (
            error: Error | null,
            data?: Array<{
              month: number
              dailyStats: Array<OTPDailyStatsObject>
            }>
          ) => void,
      ) => getOTPCalendarData(clientID, this.otpModel, callback),
      (callback: (error: Error | null, data?: Array<ReportRequest>) => void) => getReportData(clientID, this.reportsModel, callback),
    ]
    async.parallel(dashboardQueries, (error: Error | undefined, results: any[]) => {
      if (_.isNil(error)) {
        if (!_.isNil(results)) {
          // OTP today's data
          if (!_.isNil(results[0])) {
            otpDashboardData.metrics.today = _.assign({}, results[0])
          }
          // OTP months's data
          if (!_.isNil(results[1])) {
            otpDashboardData.metrics.month = _.assign({}, results[1])
          }
          // OTP year's data
          if (!_.isNil(results[2])) {
            otpDashboardData.metrics.year = _.assign({}, results[2])
          }
          // OTP calendar stats data
          if (!_.isNil(results[3])) {
            otpDashboardData.calendar = _.assign([], results[3])
          }
          // Report Request
          if (!_.isNil(results[4])) {
            otpDashboardData.reportRequest = _.assign([], results[4])
          }
          resolve(getAPIResponse(messages.OTP007.code, this.traceID, HttpStatus.OK, otpDashboardData))
        } else {
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        }
      } else {
        this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_OTP_DASHBOARD_DATA, this.traceID, { clientID, error }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      }
    })
  })

  requestReport = (clientID: string, requestReport: OTPReportDTO) => new Promise<ServiceResponse>((resolve) => {
    Object.assign(requestReport, {
      type: report_types.OTP,
      expiry_days: parseInt(getEnvironmentVariable(variables.REPORT_EXPIRY_DAYS.name), 10),
      expiry_timestamp: new Date(new Date().getTime() + parseInt(getEnvironmentVariable(variables.REPORT_EXPIRY_DAYS.name), 10) * 24 * 60 * 60 * 1000),
      clientID,
    })
    if (_.lte(Math.abs(new Date(requestReport.end_date).getTime() - new Date(requestReport.start_date).getTime()) / (1000 * 3600 * 24), 90)) {
      createOperations
        .save(new this.reportsModel(requestReport))
        .then((reportRequest) => {
          this.reportQueue.add({ payload: reportRequest, traceID: this.traceID })
          resolve(getAPIResponse(messages.OTP014.code, this.traceID, HttpStatus.OK, reportRequest))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.OTP_REPORT_REQUST, this.traceID, { requestReport, error }))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    } else {
      resolve(getAPIResponse(messages.OTP013.code, this.traceID, HttpStatus.BAD_REQUEST))
    }
  })

  downloadReport = (clientID: string, report_id: string) => new Promise<ServiceResponse>((resolve) => {
    RedisHandler.getInstance(cache_client.DEFAULT, redis_client.CREATE_REPORT).get(redisKeys.USER_REPORT.value(clientID, report_types.OTP, report_id), async (error: Error, data: string) => {
      if (_.isNil(error) && !_.isNil(data)) {
        S3Handler.getInstance().getObject({ Bucket: getEnvironmentVariable(variables.S3_OTP_BUCKET.name), Key: `${report_id}.json` }, (error, file_data) => {
          if (_.isNil(error) && !_.isNil(file_data)) {
            try {
              const file_json = JSON.parse(file_data.Body.toString()) as Array<{
                    date: string
                    data: Array<{
                      phone: number
                      short_id: string
                      delivered: number
                      attempts: number
                      credits: number
                      verified: boolean
                      time: Date
                    }>
                  }>
              const temp_report_directory = `/${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.TEMP_WORK_DIRECTORY.name)}/${report_id}`
              const directoryExists = fs.existsSync(path.join(process.cwd(), temp_report_directory))
              if (!directoryExists) {
                fs.mkdirSync(path.join(process.cwd(), temp_report_directory), { recursive: true })
              }

              file_json.forEach((report) => {
                if (!_.isNil(report.data) && !_.isEmpty(report.data)) {
                  const reportPath = path.join(process.cwd(), temp_report_directory, `otp_report_${report.date.replace(/-/g, '_')}.csv`)
                  const csv_data = createCSV(report.data)
                  fs.writeFileSync(reportPath, csv_data)
                }
              })
              zip(path.join(process.cwd(), temp_report_directory), path.join(process.cwd(), `otp_reports_${report_id}.zip`))
                .then(() => {
                  deleteFolderRecursive(path.join(process.cwd(), temp_report_directory))
                  resolve(getAPIResponse(messages.OTP015.code, this.traceID, HttpStatus.OK))
                })
                .catch((error) => {
                  this.logger.error(getErrorLog(canonicalMethods.DOWNLOAD_OTP_REPORT, this.traceID, { clientID, error }, error.message))
                  resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                })
            } catch (error) {
              this.logger.error(getErrorLog(canonicalMethods.DOWNLOAD_OTP_REPORT, this.traceID, { clientID, error }, error.message))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            }
          } else {
            this.logger.error(getErrorLog(canonicalMethods.DOWNLOAD_OTP_REPORT, this.traceID, { clientID, error }, error.message))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          }
        })
      } else {
        resolve(getAPIResponse(messages.OTP016.code, this.traceID, HttpStatus.BAD_REQUEST))
      }
    })
  })
}
