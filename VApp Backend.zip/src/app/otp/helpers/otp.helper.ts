import { Reports } from '@app/reports/reports.schema'
import { otp_aggregation, report_types } from '@config'
import { OTPDailyStatsObject, OTPDashboard, OTPMetricObject } from '@interfaces/otp.interface'
import { ReportRequest } from '@interfaces/reports.interface'
import { findOperations } from '@utils/crud.util'
import _ from 'lodash'
import { Model } from 'mongoose'
import { OTP } from '../otp.schema'

export const getOTPData = (clientID: string, otpModel: Model<OTP>, type: otp_aggregation, callback: (error: Error | null, data?: OTPMetricObject) => void) => {
  const current_date = new Date()
  const filter_object = {
    clientID,
    'date.year': current_date.getFullYear(),
    'date.month': current_date.getMonth() + 1,
    'date.day': current_date.getDate()
  }
  if (_.eq(type, otp_aggregation.MONTH)) {
    delete filter_object['date.day']
  }
  if (_.eq(type, otp_aggregation.YEAR)) {
    delete filter_object['date.day'], delete filter_object['date.month']
  }
  findOperations
    .aggregate(otpModel, [
      [
        {
          $addFields: {
            date: {
              $dateToParts: {
                date: '$date'
              }
            }
          }
        },
        {
          $match: filter_object
        },
        {
          $group: {
            _id: `$date.${type.toLowerCase()}`,
            key: { $first: `$date.${type.toLowerCase()}` },
            sent: { $push: 1 },
            delivered: {
              $push: {
                $cond: [{ $eq: ['$smsStatus', 2] }, 1, 0]
              }
            },
            verified: {
              $push: {
                $cond: [{ $eq: ['$verified', true] }, 1, 0]
              }
            },
            attempts: { $push: '$attempts' }
          }
        },
        {
          $project: {
            sent: { $sum: '$sent' },
            delivered: { $sum: '$delivered' },
            verified: { $sum: '$verified' },
            attempts: { $sum: '$attempts' },
            key: 1
          }
        },
        {
          $group: {
            _id: null,
            sentTotal: { $sum: '$sent' },
            deliveredTotal: { $sum: '$delivered' },
            verifiedTotal: { $sum: '$verified' },
            attemptsTotal: { $sum: '$attempts' },
            sent: { $push: { key: '$key', value: '$sent' } },
            attempts: { $push: { key: '$key', value: '$attempts' } },
            verified: { $push: { key: '$key', value: '$verified' } },
            delivered: { $push: { key: '$key', value: '$delivered' } }
          }
        },
        { $project: { _id: 0 } }
      ]
    ])
    .then((otpResult: Array<OTPMetricObject>) => {
      if (!_.isNil(otpResult[0])) {
        let temp = []
        let end = 24
        let start = 0
        if (_.eq(type, otp_aggregation.MONTH)) {
          const current_date = new Date()
          start = 1
          end = new Date(current_date.getFullYear(), current_date.getMonth() + 1, 0).getDate() + 1
        }
        if (_.eq(type, otp_aggregation.YEAR)) {
          start = 1
          end = 12 + 1
        }
        const otp_keys = ['sent', 'verified', 'attempts', 'delivered']
        for (let j = 0; j < otp_keys.length; j++) {
          temp = []
          for (let i = start; i < end; i++) {
            const data = otpResult[0][`${otp_keys[j]}`]
            const value = (data as Array<{ key: number; value: number }>).find((e) => _.eq(e.key, i))?.value
            temp.push(!_.isNil(value) ? value : 0)
          }
          otpResult[0][`${otp_keys[j]}`] = _.assign([], temp)
        }
        callback(null, otpResult[0])
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      callback(null)
    })
}

export const getOTPCalendarData = (
  clientID: string,
  otpModel: Model<OTP>,
  callback: (
    error: Error | null,
    data?: Array<{
      month: number
      dailyStats: Array<OTPDailyStatsObject>
    }>
  ) => void
) => {
  const current_date = new Date()
  findOperations
    .aggregate(otpModel, [
      {
        $addFields: {
          date: {
            $dateToParts: {
              date: '$date'
            }
          }
        }
      },
      {
        $match: {
          clientID,
          'date.year': current_date.getFullYear()
        }
      },
      {
        $group: {
          _id: { month: '$date.month', day: '$date.day' },
          month: { $first: '$date.month' },
          day: { $first: '$date.day' },

          sent: { $push: 1 },
          delivered: {
            $push: {
              $cond: [{ $eq: ['$smsStatus', 2] }, 1, 0]
            }
          },
          verified: {
            $push: {
              $cond: [{ $eq: ['$verified', true] }, 1, 0]
            }
          },

          attempts: { $push: '$attempts' }
        }
      },
      {
        $project: {
          sent: { $sum: '$sent' },
          delivered: { $sum: '$delivered' },
          verified: { $sum: '$verified' },
          attempts: { $sum: '$attempts' },
          month: 1,
          day: 1
        }
      },
      {
        $group: {
          _id: '$month',
          month: { $first: '$month' },
          dailyStats: {
            $push: {
              day: '$day',
              sent: '$sent',
              delivered: '$delivered',
              verified: '$verified',
              attempts: '$attempts'
            }
          }
        }
      },
      { $project: { _id: 0 } }
    ])
    .then(
      (
        otpResult: Array<{
          month: number
          dailyStats: Array<OTPDailyStatsObject>
        }>
      ) => {
        if (!_.isNil(otpResult)) {
          otpResult = _.orderBy(
            [
              ..._.difference(
                _.times(12, (month) => ++month),
                _.map(otpResult, (e) => e.month)
              ).map((month) => ({ month, dailyStats: [] })),
              ...otpResult
            ],
            'month'
          )
          callback(null, otpResult)
        } else {
          callback(null)
        }
      }
    )
    .catch((error: Error) => {
      callback(null)
    })
}

export const getReportData = (clientID: string, reportsModel: Model<Reports>, callback: (error: Error | null, data?: Array<ReportRequest>) => void) => {
  const current_date = new Date()
  findOperations
    .aggregate(reportsModel, [
      {
        $addFields: {
          datepart: {
            $dateToParts: {
              date: '$created'
            }
          }
        }
      },
      {
        $match: {
          clientID,
          'datepart.year': current_date.getFullYear(),
          type: report_types.OTP
        }
      },
      {
        $sort: {
          created: -1
        }
      },
      {
        $project: {
          _id: 1,
          created: 1,
          start_date: 1,
          end_date: 1,
          status: 1,
          type: 1,
          url: 1
        }
      }
    ])
    .then((reportRequest: Array<ReportRequest>) => {
      if (!_.isNil(reportRequest)) {
        callback(null, reportRequest)
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      callback(null)
    })
}
