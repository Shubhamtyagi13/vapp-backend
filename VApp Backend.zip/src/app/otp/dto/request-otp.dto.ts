import { otp_types } from '@config'
import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import {
  IsDefined, IsNumber, IsOptional, IsString, IsMongoId, Min, Max, IsIn,
} from 'class-validator'

export class RequestOtpDTO {
  @ApiProperty({ required: true, description: 'API key of your VAPP Account' })
  @IsString()
  @IsDefined()
  @IsMongoId()
    apiKey: string

  @ApiProperty({ required: true, description: 'Template id of the template containing dlt infromation' })
  @IsString()
  @IsDefined()
  @IsMongoId()
    templateID: string

  @ApiProperty({ required: true, description: '10 digits phone number (india) for otp' })
  @IsDefined()
  @IsValidPhone()
    phone: number

  @ApiProperty({ required: false, description: 'Generator type => numeric or alpha_numeric' })
  @IsOptional()
  @IsIn([otp_types.NUMERIC, otp_types.ALPHA_NUMERIC])
    type: string

  @ApiProperty({ required: false, description: 'length of otp, min => 6 max => 10' })
  @Min(6)
  @Max(10)
  @IsOptional()
  @IsNumber()
    length: number

  // add custom variables
}
