import { otp_types } from '@config'
import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import {
  IsDefined, IsString, IsMongoId,
} from 'class-validator'

export class VerifyOtpDTO {
  @ApiProperty({ required: true, description: 'API key of your VAPP Account' })
  @IsString()
  @IsDefined()
  @IsMongoId()
    apiKey: string

  @ApiProperty({ required: true, description: 'Unique identifier of otp received after sending' })
  @IsString()
  @IsDefined()
    uuid: string

  @ApiProperty({ required: true, description: 'Value of otp to verify' })
  @IsDefined()
    otp: string
}
