import {
  audience, contentTypes, environments, variables,
} from '@config'
import { Audience } from '@decorators/audience.decorator'
import { SystemAuthDTO } from '@dto/system-auth.dto'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import { messages } from '@messages'
import {
  Body, Controller, Get, HttpStatus, Param, Post, Query, Req, Res, UseGuards,
} from '@nestjs/common'
import {
  ApiBearerAuth, ApiExcludeEndpoint, ApiQuery, ApiTags,
} from '@nestjs/swagger'
import { ParseStringPipe } from '@pipes/parse-string.pipe'
import { deleteFile, getEnvironmentVariable } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import path from 'path'
import { OTPReportDTO } from './dto/otp-report.dto'
import { RequestOtpDTO } from './dto/request-otp.dto'
import { VerifyOtpDTO } from './dto/verify-otp.dto'
import { OTPService } from './otp.service'

@ApiTags(OTPController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('otp')
export class OTPController {
  constructor(private readonly otpService: OTPService) {}

  @Post('request')
  requestOTP(@Res() response: Response, @Body() otpPayload: RequestOtpDTO) {
    this.otpService.requestOTP(otpPayload).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Get('verify')
  @ApiQuery({ name: 'apiKey', description: 'API key of your VAPP Account' })
  @ApiQuery({ name: 'uuid', description: 'Unique identifier of otp received after sending' })
  @ApiQuery({ name: 'otp', description: 'Value of otp to verify' })
  verifyOTP(
    @Res() response: Response,
    @Query('apiKey', ParseStringPipe()) apiKey: string,
    @Query('uuid', ParseStringPipe()) uuid: string,
    @Query('otp', ParseStringPipe()) otp: string,
  ) {
    this.otpService.verifyOTP(<VerifyOtpDTO>{ apiKey, uuid, otp }).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Post('verify')
  @ApiQuery({ name: 'apiKey', description: 'API key of your VAPP Account' })
  @ApiQuery({ name: 'uuid', description: 'Unique identifier of otp received after sending' })
  @ApiQuery({ name: 'otp', description: 'Value of otp to verify' })
  verifyOTPPost(
    @Res() response: Response,
    @Body() otpPayload: VerifyOtpDTO,
  ) {
    this.otpService.verifyOTP(otpPayload).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @UseGuards(AuthenticationGuard)
  @Audience([audience.CLIENT, audience.ADMIN])
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  @Get('analytics')
  getAnalytics(@Res() response: Response, @Req() request: Request) {
    this.otpService.getAnalytics(request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @UseGuards(AuthenticationGuard)
  @Audience([audience.CLIENT, audience.ADMIN])
  @Post('request-report')
  requestReport(@Res() response: Response, @Body() reportRequest: OTPReportDTO, @Req() request: Request) {
    this.otpService.requestReport(request.user._id, reportRequest).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @UseGuards(AuthenticationGuard)
  @Audience([audience.CLIENT, audience.ADMIN])
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  @Get('download-report/:id')
  downloadReport(@Res() response: Response<APIResponse>, @Req() request: Request, @Param('id') report_id: string) {
    this.otpService.downloadReport(request.user._id, report_id).then((service_response: ServiceResponse) => {
      if (_.eq(service_response.status, HttpStatus.OK)) {
        const report_file_path = path.join(process.cwd(), `otp_reports_${report_id}.zip`)
        response.sendFile(report_file_path, (err) => {
          if (err) {
            return response.status(service_response.status).send(<APIResponse>{
              code: messages.COM001.code,
              message: messages.COM001.message,
              traceID: service_response.traceID,
              status: HttpStatus.INTERNAL_SERVER_ERROR,
              data: {},
            })
          }
          deleteFile(report_file_path)
        })
      } else {
        return response.status(service_response.status).send(<APIResponse>service_response)
      }
    })
  }
}
