import { Credits, CreditsSchema } from '@app/credits/credits.schema'
import { ReportsQueueModule } from '@app/reports/cron/queue.module'
import { Reports, ReportsSchema } from '@app/reports/reports.schema'
import { Template, TemplateSchema } from '@app/template/template.schema'
import { User, UserSchema } from '@app/user/user.schema'
import { BasicAuthenticationMiddleware } from '@middlewares/basic.auth.middleware'
import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { UploadDeliveryReportModule } from '@app/delivery/cron/queue.module'
import { OTPController } from './otp.controller'
import { OTP, OTPSchema } from './otp.schema'
import { OTPService } from './otp.service'

@Module({
  imports: [
    UploadDeliveryReportModule,
    ReportsQueueModule,
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Credits.name, schema: CreditsSchema },
      { name: OTP.name, schema: OTPSchema },
      { name: Reports.name, schema: ReportsSchema },
      { name: Template.name, schema: TemplateSchema },
    ]),
  ],
  controllers: [OTPController],
  providers: [OTPService, VappLogger],
})
export class OTPModule {}
