import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.DEMOGRAPHICS.collection, autoCreate: false, _id: false })
export class Demographics extends Document {
  @Prop({ type: Number, required: true })
  latitude: number

  @Prop({ type: Number, required: true })
  longitude: number

  @Prop({ type: String, index: true, required: true })
  country_code: string

  @Prop({ type: String, index: true, required: true })
  region_code: string

  @Prop({ type: String, index: true, default: null })
  region: string

  @Prop({ type: String, index: true, required: true })
  continent_code: string

  @Prop({ type: String, index: true, required: true })
  city: string

  @Prop({ type: String, required: true })
  ip: string
}
export const DemographicsSchema = SchemaFactory.createForClass(Demographics)
