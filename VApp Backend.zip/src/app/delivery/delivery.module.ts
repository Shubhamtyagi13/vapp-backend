import { Campaign, CampaignSchema } from '@app/campaign/campaign.schema'
import { ContactDatabase, ContactDatabaseSchema } from '@app/contact/contact.database.schema'
import { Contact, ContactSchema } from '@app/contact/contact.schema'
import { Credits, CreditsSchema } from '@app/credits/credits.schema'
import { Dashboard, DashboardSchema } from '@app/dashboard/dashboard.schema'
import { DashboardTrendingStore, DashboardTrendingStoreSchema } from '@app/dashboard/dashboard.trending.schema'
import { Link, LinkSchema } from '@app/link/link.schema'
import { Projects, ProjectsSchema } from '@app/projects/projects.schema'
import { ProjectTrendingEngagementsSchema, ProjectTrendingEngagementsSchemaStore } from '@app/projects/projects.trending.engagement.schema'
import { Requests, RequestsSchema } from '@app/requests/requests.schema'
import { Template, TemplateSchema } from '@app/template/template.schema'
import { User, UserSchema } from '@app/user/user.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { CreateDeliveryReportModule, UploadDeliveryReportModule } from '@app/delivery/cron/queue.module'
import { QueueUIProvider } from '@app/delivery/cron/queue.ui'
import { DeliveryController } from './delivery.controller'
import { DeliveryService } from './delivery.service'

@Module({
  imports: [
    UploadDeliveryReportModule,
    CreateDeliveryReportModule,
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Contact.name, schema: ContactSchema },
      { name: Link.name, schema: LinkSchema },
      { name: Credits.name, schema: CreditsSchema },
      { name: ContactDatabase.name, schema: ContactDatabaseSchema },
      { name: Requests.name, schema: RequestsSchema },
      { name: Projects.name, schema: ProjectsSchema },
      { name: Campaign.name, schema: CampaignSchema },
      { name: Template.name, schema: TemplateSchema },
      { name: DashboardTrendingStore.name, schema: DashboardTrendingStoreSchema },
      { name: Dashboard.name, schema: DashboardSchema },
      { name: ProjectTrendingEngagementsSchemaStore.name, schema: ProjectTrendingEngagementsSchema },
    ]),
  ],
  controllers: [DeliveryController],
  providers: [DeliveryService, VappLogger, QueueUIProvider],
})
export class DeliveryModule {}
