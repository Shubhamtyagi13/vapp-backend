import { Campaign, CampaignSchema } from '@app/campaign/campaign.schema'
import { DripCampaign, DripCampaignSchema } from '@app/campaign/drip_campaign.schema'
import { ContactDatabase, ContactDatabaseSchema } from '@app/contact/contact.database.schema'
import { Contact, ContactSchema } from '@app/contact/contact.schema'
import { Credits, CreditsSchema } from '@app/credits/credits.schema'
import { Dashboard, DashboardSchema } from '@app/dashboard/dashboard.schema'
import { DashboardTrendingStore, DashboardTrendingStoreSchema } from '@app/dashboard/dashboard.trending.schema'
import { Link, LinkSchema } from '@app/link/link.schema'
import { OTP, OTPSchema } from '@app/otp/otp.schema'
import { Projects, ProjectsSchema } from '@app/projects/projects.schema'
import { ProjectTrendingEngagementsSchema, ProjectTrendingEngagementsSchemaStore } from '@app/projects/projects.trending.engagement.schema'
import { DripRequests, DripRequestsSchema } from '@app/requests/drip_requests.schema'
import { Requests, RequestsSchema } from '@app/requests/requests.schema'
import { Template, TemplateSchema } from '@app/template/template.schema'
import { Transactional, TransactionalSchema } from '@app/transactional/transactional.schema'
import { User, UserSchema } from '@app/user/user.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { CreateDeliveryReportModule, UploadDeliveryReportModule } from '@app/delivery/cron/queue.module'
import { UploadDeliveryReportProcessor } from '@app/delivery/cron/queue.processor'
import { QueueUIProvider } from '@app/delivery/cron/queue.ui'
import { DeliveryController } from './delivery.controller'
import { DeliveryService } from './delivery.service'

@Module({
  imports: [
    UploadDeliveryReportModule,
    CreateDeliveryReportModule,
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Link.name, schema: LinkSchema },
      { name: Contact.name, schema: ContactSchema },
      { name: Credits.name, schema: CreditsSchema },
      { name: ContactDatabase.name, schema: ContactDatabaseSchema },
      { name: Requests.name, schema: RequestsSchema },
      { name: Projects.name, schema: ProjectsSchema },
      { name: Campaign.name, schema: CampaignSchema },
      { name: Template.name, schema: TemplateSchema },
      { name: OTP.name, schema: OTPSchema },
      { name: DripCampaign.name, schema: DripCampaignSchema },
      { name: Transactional.name, schema: TransactionalSchema },
      { name: DripRequests.name, schema: DripRequestsSchema },
      { name: DashboardTrendingStore.name, schema: DashboardTrendingStoreSchema },
      { name: Dashboard.name, schema: DashboardSchema },
      { name: ProjectTrendingEngagementsSchemaStore.name, schema: ProjectTrendingEngagementsSchema },
    ]),
  ],
  controllers: [DeliveryController],
  providers: [DeliveryService, VappLogger, QueueUIProvider, UploadDeliveryReportProcessor],
})
export class DeliveryCronModule {}
