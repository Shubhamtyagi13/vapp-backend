import { canonicalMethods, constants, cronJobs } from '@config'
import { DeliveryReport } from '@interfaces/report.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { InjectQueue } from '@nestjs/bull'
import { HttpStatus, Inject } from '@nestjs/common'
import { VappLogger } from '@services/logger.service'
import { getAPIResponse, getErrorLog, isValidNumber } from '@utils/platform.util'
import { Queue } from 'bull'
import csv from 'csvtojson'
import _ from 'lodash'
import { Multer } from 'multer'

export class DeliveryService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    private logger: VappLogger,
    @InjectQueue(cronJobs.UPLOAD_DELIVERY_REPORT.name) private reportsUploadQueue: Queue,
  ) {
    this.traceID = vapp_context.traceID
  }

  uploadDeliveryReport = (file: Express.Multer.File, fileName: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      if (_.isNil(fileName)) {
        resolve(getAPIResponse(messages.REPO004.code, this.traceID, HttpStatus.BAD_REQUEST))
      }
      csv()
        .fromString(file.buffer.toString('utf8'))
        .then((reportObject) => {
          if (!_.isNil(reportObject)) {
            try {
              reportObject = _.map(_.map(reportObject, (e) => _.pick(e, ['Mobile Number', 'Status'])), (f) => {
                f.phone = Number(f['Mobile Number'])
                f.status = String(f.Status).toLowerCase()
                return _.pick(f, ['phone', 'status'])
              })
              const campaignID = fileName
              if (isValidNumber(campaignID)) {
                this.logger.log(`Campaign ID: ${fileName}`)
                this.logger.log(`Total Records: ${reportObject.length}`)
                reportObject = _.uniqBy(reportObject, 'phone')
                const uniqStatusValues = _.map(_.map(_.uniqBy(reportObject, 'status'), (e) => _.pick(e, ['status'])), (y) => String(y.status).toLowerCase())
                this.logger.log(`Total Unique Records: ${reportObject.length}`)
                this.logger.log(`Unique SMS Status: ${uniqStatusValues}`)
                // const payload = {
                //   campaignID,
                //   data: reportObject,
                //   isFinal: true
                // } as DeliveryReport
                // this.reportsUploadQueue.add({ payload, traceID: this.traceID })
                resolve(getAPIResponse(messages.REPO001.code, this.traceID, HttpStatus.OK))
              } else {
                this.logger.error(getErrorLog(canonicalMethods.UPLOAD_DELIVERY_REPORT, this.traceID, { fileName, r: 'res' }))
                resolve(getAPIResponse(messages.REP002.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              }
            } catch (error) {
              this.logger.error(getErrorLog(canonicalMethods.UPLOAD_DELIVERY_REPORT, this.traceID, { fileName, error }, error.message))
              resolve(getAPIResponse(messages.CAM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            }
          } else {
            this.logger.error(getErrorLog(canonicalMethods.UPLOAD_DELIVERY_REPORT, this.traceID, { fileName }))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          }
        })
    })
}
