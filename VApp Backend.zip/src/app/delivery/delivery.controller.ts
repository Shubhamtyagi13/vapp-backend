import {
  audience, contentTypes, environments, variables,
} from '@config'
import { ApiFile } from '@decorators/api-file.decorator'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { ReportInterceptor } from '@interceptors/report.interceptor'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Controller, Post, Req, Res, UploadedFile, UseGuards, UseInterceptors,
} from '@nestjs/common'
import {
  ApiBearerAuth, ApiConsumes, ApiExcludeController, ApiTags,
} from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import { DeliveryService } from './delivery.service'
/*
  Dialog flow controller is used to connent and record chatbot responses
*/
@ApiTags(DeliveryController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('delivery')
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class DeliveryController {
  constructor(private deliveryService: DeliveryService) {}

  @Post('report')
  @ApiFile('report')
  @ApiConsumes(contentTypes.MULTIPART.FORM_DATA)
  @UseInterceptors(ReportInterceptor())
  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  uploadDeliveryReport(@UploadedFile() file: any, @Res() response: Response, @Req() request: Request) {
    this.deliveryService.uploadDeliveryReport(file, request.fileName).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }
}
