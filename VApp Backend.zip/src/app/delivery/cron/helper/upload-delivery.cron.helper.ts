import { ContactDatabase } from '@app/contact/contact.database.schema'
import { Link } from '@app/link/link.schema'
import { Template } from '@app/template/template.schema'
import { variables } from '@config'
import { GenericObject } from '@interfaces/generic.interface'
import { createOperations, findOperations } from '@utils/crud.util'
import { getEnvironmentVariable } from '@utils/platform.util'
import _ from 'lodash'
import { ClientSession, Model } from 'mongoose'
import path from 'path'
import fs from 'fs'
import { SmppReportUpdateObject } from '@interfaces/report.interface'

export const updateCommonEngagement = (
  databaseModel: Model<ContactDatabase>,
  templateModel: Model<Template>,
  linkModel: Model<Link>,
  templateID: string,
  linkID: string,
  databaseID: string,
  clientID: string,
  updateObject: GenericObject,
) => new Promise<{
      templates: Template[]
      contactsDatabases: ContactDatabase[]
      links: Link[]
    }>(async (resolve, reject) => {
      let templates: Template[]
      let contactsDatabases: ContactDatabase[]
      let links: Link[]
      try {
        if (!_.isNil(databaseID)) {
          await createOperations.updateOne(databaseModel, { _id: databaseID }, { $inc: updateObject })
          contactsDatabases = await findOperations.find(databaseModel, { clientID }, { __v: 0, password: 0 }, {})
        }
      } catch (error) {
        reject(error)
      }
      try {
        if (!_.isNil(templateID)) {
          await createOperations.updateOne(templateModel, { _id: templateID }, { $inc: updateObject })
          templates = await findOperations.find(templateModel, { clientID }, { __v: 0, password: 0 }, {})
        }
      } catch (error) {
        reject(error)
      }
      try {
        if (!_.isNil(linkID)) {
          await createOperations.updateOne(linkModel, { _id: linkID }, { $inc: updateObject })
          links = await findOperations.find(linkModel, { clientID }, { __v: 0, password: 0 }, {})
        }
      } catch (error) {
        reject(error)
      }
      resolve({ templates, links, contactsDatabases })
    })

export const createCampaignReportDirectory = (clientID: string, year: number, month: number, projectID: string) => {
  const campaignDirectory = `/${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(
    variables.REPORTS_DIRECTORY.name,
  )}/${clientID}/${projectID}/${year}/${month}`
  const directoryExists = fs.existsSync(path.join(process.cwd(), campaignDirectory))
  if (!directoryExists) {
    fs.mkdirSync(path.join(process.cwd(), campaignDirectory), { recursive: true })
  }
  return campaignDirectory
}
