import { cronJobs } from '@config'
import { InjectQueue } from '@nestjs/bull'
import { Injectable } from '@nestjs/common'
import { Queue } from 'bull'
import { BullAdapter } from '@bull-board/api/bullAdapter'
import { BullInterfaceService } from '@services/bull-ui.service'

@Injectable()
export class QueueUIProvider {
  constructor(
    @InjectQueue(cronJobs.UPLOAD_DELIVERY_REPORT.name) private deliveryReportUploadQueue: Queue,
    @InjectQueue(cronJobs.CREATE_DELIVERY_REPORT.name) private createReportUploadQueue: Queue,

  ) {
    BullInterfaceService.getInstance().registerQueues([new BullAdapter(deliveryReportUploadQueue), new BullAdapter(createReportUploadQueue)])
  }
}
