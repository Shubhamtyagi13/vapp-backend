import { Campaign } from '@app/campaign/campaign.schema'
import { ContactDatabase } from '@app/contact/contact.database.schema'
import { Contact } from '@app/contact/contact.schema'
import { Credits } from '@app/credits/credits.schema'
import { Dashboard } from '@app/dashboard/dashboard.schema'
import { Link } from '@app/link/link.schema'
import { Projects } from '@app/projects/projects.schema'
import { Requests } from '@app/requests/requests.schema'
import { Template } from '@app/template/template.schema'
import {
  canonicalMethods, constants, cronJobs, redisKeys, report_types,
} from '@config'
import { CronPayload } from '@interfaces/cron.interface'
import { CronError } from '@interfaces/error.interface'
import { CreateDeliveryReport, DeliveryReport, DeliveryReportObject } from '@interfaces/report.interface'
import { messages } from '@messages'
import {
  InjectQueue, OnQueueActive, OnQueueCompleted, OnQueueFailed, Process, Processor,
} from '@nestjs/bull'
import { Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import {
  deleteFile, getErrorLog, getSMSStatus, getSMSDeliveryStatus,
} from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import { Job, Queue } from 'bull'
import _ from 'lodash'
import { Model } from 'mongoose'
import fs from 'fs'
import path from 'path'
import { OTP } from '@app/otp/otp.schema'
import { Transactional } from '@app/transactional/transactional.schema'
import { DripRequests } from '@app/requests/drip_requests.schema'
import { DripCampaign } from '@app/campaign/drip_campaign.schema'
import { createCampaignReportDirectory, updateCommonEngagement } from './helper/upload-delivery.cron.helper'

@Injectable()
@Processor(cronJobs.UPLOAD_DELIVERY_REPORT.name)
export class UploadDeliveryReportProcessor {
  constructor(
    private logger: VappLogger,
    @InjectModel(Contact.name) private contactsModel: Model<Contact>,
    @InjectModel(Credits.name) private creditsModel: Model<Credits>,
    @InjectModel(Campaign.name) private campaignModel: Model<Campaign>,
    @InjectModel(DripCampaign.name) private dripCampaignModel: Model<DripCampaign>,
    @InjectModel(Requests.name) private requestModel: Model<Requests>,
    @InjectModel(Projects.name) private projectsModel: Model<Projects>,
    @InjectModel(Template.name) private templatesModel: Model<Template>,
    @InjectModel(Dashboard.name) private dashboardModel: Model<Dashboard>,
    @InjectModel(OTP.name) private otpModel: Model<OTP>,
    @InjectModel(Transactional.name) private transactionalModel: Model<Transactional>,
    @InjectModel(DripRequests.name) private dripRequestsModel: Model<DripRequests>,
    @InjectModel(Link.name) private linksModel: Model<Link>,
    @InjectModel(ContactDatabase.name) private contactDatabaseModel: Model<ContactDatabase>,
    @InjectQueue(cronJobs.CREATE_DELIVERY_REPORT.name) private createDeliveryReportQueue: Queue,
  ) {}

  @Process({ concurrency: 1000 })
  async processUploadDelivery(job: Job<CronPayload<DeliveryReport>>) {
    const { payload, traceID } = job.data
    try {
      let smsDeliveredCount = 0
      let smsFailedCount = 0
      let smsRefundCount = 0
      let isDrip = false
      const {
        status, reportType, campaignID, smppMessageID,
      } = job.data.payload.data
      let { phone } = job.data.payload.data
      const smsStatusValue: number = getSMSStatus(status, payload.isFinal)
      const markReportAsFinal: boolean = _.eq(smsStatusValue, constants.SMS_STATUS.success) || _.eq(smsStatusValue, constants.SMS_STATUS.failed) || _.eq(smsStatusValue, constants.SMS_STATUS.dnd)
      if (_.eq(String(phone).length, 12)) {
        phone = Number(String(phone).substr(2))
      } else {
        phone = Number(String(phone))
      }
      const destinationModel = _.isEqual(reportType, report_types.OTP)
        ? this.otpModel
        : _.isEqual(reportType, report_types.TRANSACTIONAL)
          ? this.transactionalModel
          : _.isEqual(reportType, report_types.DRIP_CAMPAIGN)
            ? this.dripRequestsModel
            : this.requestModel
      const isNonCampaign = _.isEqual(reportType, report_types.OTP) || _.isEqual(reportType, report_types.TRANSACTIONAL)
      const queryObject = isNonCampaign ? { phone, deliveryID: smppMessageID, morphed: false } : { phone, campaignID, morphed: false }
      const requestUpdateResult = await createOperations.updateOne(destinationModel, queryObject, {
        $set: {
          deliveryID: smppMessageID,
          smsStatus: smsStatusValue,
          morphed: payload.isFinal ? true : !!markReportAsFinal,
        },
      })
      isDrip = _.isEqual(reportType, report_types.DRIP_CAMPAIGN)
      if (!_.isNil(requestUpdateResult)) {
        if (!isNonCampaign) {
          if (_.eq(smsStatusValue, constants.SMS_STATUS.success)) {
            smsDeliveredCount += 1
          } else if (_.eq(smsStatusValue, constants.SMS_STATUS.failed)) {
            smsFailedCount += 1
          } else if (_.eq(smsStatusValue, constants.SMS_STATUS.dnd)) {
            smsRefundCount += 1
          }
          const updateObject = { smsDeliveredCount, smsFailedCount }
          const destinationCampaignModel = isDrip ? this.dripCampaignModel : this.campaignModel
          const campaign = (await findOperations.findOneLean(destinationCampaignModel, { _id: campaignID })) as Campaign
          const campaignUpdateResult = (await createOperations.updateOne(destinationCampaignModel, { _id: campaignID }, { $inc: updateObject })) as Campaign
          const projectUpdateResult = await createOperations.updateOne(this.projectsModel, { _id: campaignUpdateResult.projectID }, { $inc: updateObject })

          // update contactsdb, links and templates
          const commonEngagement = await updateCommonEngagement(this.contactDatabaseModel, this.templatesModel, this.linksModel, campaign.templateID, campaign.linkID, campaign.databaseID, campaign.clientID, updateObject)
          // update dashboard
          await createOperations.updateOneUpsert(this.dashboardModel, {
            year: campaign.year,
            month: campaign.month,
            clientID: campaign.clientID,
          }, { $inc: updateObject })
          // update credits
          const creditsUpdateResult = await createOperations.updateOne(this.creditsModel, {
            clientID: campaign.clientID,
          }, {
            $inc: { smsDeliveredCount, smsFailedCount, smsCount: smsRefundCount },
          })
          // update campaign
          RedisHandler.getInstance().set(redisKeys.CAMPAIGN.value(campaignID), JSON.stringify(campaignUpdateResult))
          RedisHandler.getInstance().ttl(redisKeys.CAMPAIGN.value(campaignID), (error: Error, time: number) => {
            if (_.isNil(error) && _.isNumber(time)) {
              RedisHandler.getInstance().expire(redisKeys.CAMPAIGN.value(campaignID), time)
            } else {
              this.logger.error(getErrorLog(canonicalMethods.PROCESS_DELIVERY_REPORT, traceID, { campaignID }, messages.CAM032.message))
            }
          })
          // update project
          RedisHandler.getInstance().set(redisKeys.PROJECT.value(projectUpdateResult.id), JSON.stringify(projectUpdateResult))
          RedisHandler.getInstance().expire(redisKeys.PROJECT.value(projectUpdateResult.id), redisKeys.PROJECT.timeout())
          // update credits
          RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), JSON.stringify(creditsUpdateResult))
          RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), redisKeys.USER_CREDITS.timeout())
          // update common engagements
          if (!_.isNil(commonEngagement.contactsDatabases)) {
            RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(campaign.clientID), JSON.stringify(commonEngagement.contactsDatabases))
            RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(campaign.clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
          }
          if (!_.isNil(commonEngagement.templates)) {
            RedisHandler.getInstance().set(redisKeys.USER_TEMPLATES.value(campaign.clientID), JSON.stringify(commonEngagement.templates))
            RedisHandler.getInstance().expire(redisKeys.USER_TEMPLATES.value(campaign.clientID), redisKeys.USER_TEMPLATES.timeout())
          }
          if (!_.isNil(commonEngagement.links)) {
            RedisHandler.getInstance().set(redisKeys.USER_LINKS.value(campaign.clientID), JSON.stringify(commonEngagement.links))
            RedisHandler.getInstance().expire(redisKeys.USER_LINKS.value(campaign.clientID), redisKeys.USER_LINKS.timeout())
          }
          const job = await this.createDeliveryReportQueue.getJob(campaignUpdateResult.id)
          const create_delivery_job_data = {
            payload: {
              clientID: campaignUpdateResult.clientID,
              year: campaignUpdateResult.year,
              month: campaignUpdateResult.month,
              projectID: campaignUpdateResult.projectID,
              isDrip,
              campaignID: campaignUpdateResult.id,
            } as CreateDeliveryReport,
            traceID,
          }
          if (_.isNil(job)) {
            await this.createDeliveryReportQueue.add(create_delivery_job_data, { jobId: campaignUpdateResult.id })
          }
        }
      } else {
        throw Error('delivery already updated')
      }
    } catch (error) {
      if (!_.isNil(error.name) && error.name.includes(CronError.name)) {
        error.stack = 'CronError'
      }
      throw error
    }
    job.progress(100)
    return true
  }

  @OnQueueActive()
  onActive(job: Job<CronPayload<DeliveryReport>>) {
    this.logger.log(`Processing: Job name: ${cronJobs.UPLOAD_DELIVERY_REPORT.name} Job ID: ${job.id}`)
  }

  @OnQueueCompleted()
  onCompleted(job: Job<CronPayload<DeliveryReport>>) {
    this.logger.log(`Completed: Job name: ${cronJobs.UPLOAD_DELIVERY_REPORT.name} Job ID: ${job.id}`)
  }

  @OnQueueFailed()
  onFailed(job: Job<CronPayload<DeliveryReport>>) {
    const error = job.stacktrace.includes(CronError.name) ? job.failedReason : messages.COM001.message
    this.logger.error(getErrorLog(cronJobs.UPLOAD_DELIVERY_REPORT.name, job.data.traceID, { id: job.id, reason: job.failedReason, stack: job.stacktrace }, error))
  }
}

@Injectable()
@Processor(cronJobs.CREATE_DELIVERY_REPORT.name)
export class CreateDeliveryReportProcessor {
  constructor(private logger: VappLogger, @InjectModel(Requests.name) private requestModel: Model<Requests>, @InjectModel(DripRequests.name) private dripRequestsModel: Model<DripRequests>) {}

  @Process({ concurrency: 10 })
  async createUploadDelivery(job: Job<CronPayload<CreateDeliveryReport>>) {
    const { payload, traceID } = job.data
    const {
      campaignID, isDrip, clientID, month, year, projectID,
    } = payload
    try {
      const deliveryData: DeliveryReportObject[] = []
      const destinationRequestModel = isDrip ? this.dripRequestsModel : this.requestModel
      const reportFinalData: Requests[] = await findOperations.aggregate(destinationRequestModel, [{ $match: { campaignID } }, { $project: { phone: 1, smsStatus: 1, _id: 0 } }])
      if (!_.isNil(reportFinalData) && !_.isEmpty(reportFinalData)) {
        reportFinalData.forEach((element) => {
          deliveryData.push({
            phone: element.phone,
            status: getSMSDeliveryStatus(element.smsStatus),
          })
        })
      }
      const campaignReportDirectory = createCampaignReportDirectory(clientID, year, month, projectID)
      const reportPath = path.join(process.cwd(), campaignReportDirectory, `delivery_${campaignID}.json`)
      const reportExists = fs.existsSync(reportPath)
      if (reportExists) {
        deleteFile(path.join(process.cwd(), campaignReportDirectory, `delivery_${campaignID}.json`))
      }
      const jsonData = !_.isNil(deliveryData) ? JSON.stringify(deliveryData, null, 2) : JSON.stringify([], null, 2)
      try {
        fs.writeFileSync(reportPath, jsonData)
      } catch (error) {
        this.logger.error(getErrorLog(canonicalMethods.CREATE_DELIVERY_REPORT, traceID, { campaignID }, messages.REP007.message))
      }
    } catch (error) {
      if (!_.isNil(error.name) && error.name.includes(CronError.name)) {
        error.stack = 'CronError'
      }
      throw error
    }
    job.progress(100)
    return true
  }

  @OnQueueActive()
  onActive(job: Job<CronPayload<CreateDeliveryReport>>) {
    this.logger.log(`Processing: Job name: ${cronJobs.CREATE_DELIVERY_REPORT.name} Job ID: ${job.id}`)
  }

  @OnQueueCompleted()
  onCompleted(job: Job<CronPayload<CreateDeliveryReport>>) {
    this.logger.log(`Completed: Job name: ${cronJobs.CREATE_DELIVERY_REPORT.name} Job ID: ${job.id}`)
  }

  @OnQueueFailed()
  onFailed(job: Job<CronPayload<CreateDeliveryReport>>) {
    const error = job.stacktrace.includes(CronError.name) ? job.failedReason : messages.COM001.message
    this.logger.error(getErrorLog(cronJobs.CREATE_DELIVERY_REPORT.name, job.data.traceID, { id: job.id, reason: job.failedReason, stack: job.stacktrace }, error))
  }
}
