import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsBoolean, IsDefined, IsOptional, IsString, IsUrl } from 'class-validator'

export class CreateLinkDTO extends ClientUserIDDTO {
  @ApiProperty({ required: true })
  @IsUrl({ protocols: ['http', 'https'], require_protocol: true, require_host: true })
  @IsDefined()
  url: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  name: string

  @ApiProperty()
  @IsBoolean()
  @IsOptional()
  active: boolean
}
