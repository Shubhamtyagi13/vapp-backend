import { Campaign, CampaignSchema } from '@app/campaign/campaign.schema'
import { Link, LinkSchema } from '@app/link/link.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { LinkController } from './link.controller'
import { LinkService } from './link.service'

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Link.name, schema: LinkSchema },
      { name: Campaign.name, schema: CampaignSchema }
    ])
  ],
  controllers: [LinkController],
  providers: [LinkService, VappLogger],
  exports: [MongooseModule]
})
export class LinkModule {}
