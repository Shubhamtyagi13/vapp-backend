import { audience, environments, variables } from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Body, Controller, Get, Param, Post, Req, Res, UseGuards,
} from '@nestjs/common'
import { ApiBearerAuth, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import { CreateLinkDTO } from './dto/create-link.dto'
import { LinkService } from './link.service'

@ApiTags(LinkController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('link')
@UseGuards(AuthenticationGuard)
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class LinkController {
  constructor(private linkService: LinkService) {}

  /*
   create a new link for current user
  */
  @Audience([audience.CLIENT, audience.ADMIN])
  @Post('create')
  create(@Res() response: Response, @Body() linkObject: CreateLinkDTO, @Req() request: Request) {
    this.linkService.createLink(request.user._id, linkObject).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   all - retrieve all the links for a client
   active - retrieve all active links for a client
  */
  @Audience([audience.CLIENT, audience.ADMIN])
  @Get(['all', 'active'])
  findAll(@Res() response: Response, @Req() request: Request) {
    this.linkService.findAll(request.user._id, request.url).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   toggle link for a client
  */
  @Audience([audience.CLIENT, audience.ADMIN])
  @Get('toggle/:linkID/:flag')
  toggle(@Res() response: Response, @Req() request: Request, @Param('linkID') linkID: string, @Param('flag') flag: string) {
    this.linkService.toggle(request.user._id, linkID, flag).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }
}
