import { Campaign, CampaignSchema } from '@app/campaign/campaign.schema'
import { CreateSMSCampaignQueueModule, CreateRBMCampaignQueueModule, EngagementTrackingQueueModule } from '@app/campaign/cron/queue.module'
import { Contact, ContactSchema } from '@app/contact/contact.schema'
import { Credits, CreditsSchema } from '@app/credits/credits.schema'
import { Dashboard, DashboardSchema } from '@app/dashboard/dashboard.schema'
import { IntegrationsModule } from '@app/integrations/integrations.module'
import { Integrations, IntegrationSchema } from '@app/integrations/integrations.schema'
import { IntegrationsService } from '@app/integrations/integrations.service'
import { Link, LinkSchema } from '@app/link/link.schema'
import { Projects, ProjectsSchema } from '@app/projects/projects.schema'
import { ReportsService } from '@app/reports/reports.service'
import { Template, TemplateSchema } from '@app/template/template.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { RequestsController } from './requests.controller'
import { RequestEngagement, RequestsEngagementSchema } from './requests.engagement.schema'
import { Requests, RequestsSchema } from './requests.schema'
import { RequestsService } from './requests.service'
import { RequestsWebSocketGateway } from './requests.socket'

@Module({
  imports: [
    EngagementTrackingQueueModule,
    CreateSMSCampaignQueueModule,
    CreateRBMCampaignQueueModule,
    IntegrationsModule,
    MongooseModule.forFeature([
      { name: Requests.name, schema: RequestsSchema },
      { name: RequestEngagement.name, schema: RequestsEngagementSchema },
      { name: Projects.name, schema: ProjectsSchema },
      { name: Link.name, schema: LinkSchema },
      { name: Campaign.name, schema: CampaignSchema },
      { name: Template.name, schema: TemplateSchema },
      { name: Contact.name, schema: ContactSchema },
      { name: Credits.name, schema: CreditsSchema },
      { name: Dashboard.name, schema: DashboardSchema }
    ])
  ],
  controllers: [RequestsController],
  providers: [RequestsService, VappLogger, IntegrationsService, RequestsWebSocketGateway]
})
export class RequestsModule {}
