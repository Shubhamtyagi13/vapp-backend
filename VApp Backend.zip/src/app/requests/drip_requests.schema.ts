import { Demographics, DemographicsSchema } from '@app/demographics/demographics.schema'
import { IVR, IVRSchema } from '@app/ivr/ivr.schema'
import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'
import { RequestEngagement, RequestsEngagementSchema } from './requests.engagement.schema'

@Schema({ collection: tables.DRIP_REQUESTS.collection, autoCreate: true })
export class DripRequests extends Document {
  @Prop({ type: String, index: true, required: true })
  projectID: string

  @Prop({ type: String, index: true, required: true })
  clientID: string

  @Prop({ type: Boolean, index: true, default: false })
  rcs: boolean

  @Prop({ type: String, index: true, required: true })
  campaignID: string

  @Prop({ type: String, index: true, required: true })
  shortID: string

  @Prop({ type: String, index: true, default: null })
  device: string

  @Prop({ type: String, index: true, default: null })
  deviceType: string

  @Prop({ type: String, index: true, default: null })
  os: string

  @Prop({ type: Number, index: true, required: true })
  expiresOn: number

  @Prop({ type: String, index: true, default: '' })
  firstName: string

  @Prop({ type: String, index: true, default: null })
  middleName: string

  @Prop({ type: String, index: true, default: '' })
  lastName: string

  @Prop({ type: Boolean, index: true, default: false })
  visited: boolean

  @Prop({ type: Number, index: true })
  month: number

  @Prop({ type: Number, index: true })
  year: number

  @Prop({ type: Number, index: true })
  day: number

  @Prop({ type: Boolean, index: true, default: false })
  whatsapp: boolean

  @Prop({ type: Number, index: true, required: true })
  phone: number

  @Prop({ type: Number, index: true, required: true })
  credit: number

  @Prop({ type: Number, index: true, default: 0, required: true })
  type: number

  @Prop({ type: Boolean, index: true, default: false })
  morphed: boolean

  @Prop({ type: Number, index: true, default: 1 })
  smsStatus: number

  @Prop({ type: [RequestsEngagementSchema] })
  engagementTime: [RequestEngagement]

  @Prop({ type: Boolean, index: true, default: false })
  chatbot: boolean

  @Prop({ type: Boolean, index: true, default: false })
  brochure: boolean

  @Prop({ type: String, index: true, default: null })
  lead: string

  @Prop({ type: Number, default: 0, index: true })
  engagementLevel: number

  @Prop({ type: DemographicsSchema, default: null })
  demographics: Demographics

  @Prop({ type: [IVRSchema], default: [], index: true })
  ivr: [IVR]

  @Prop({ type: String, index: true, default: null })
  deliveryID: string
}

export const DripRequestsSchema = SchemaFactory.createForClass(DripRequests)
