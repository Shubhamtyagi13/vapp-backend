import { Campaign } from '@app/campaign/campaign.schema'
import { ContactDatabase } from '@app/contact/contact.database.schema'
import { Contact } from '@app/contact/contact.schema'
import { Credits } from '@app/credits/credits.schema'
import { Dashboard } from '@app/dashboard/dashboard.schema'
import { IntegrationsService } from '@app/integrations/integrations.service'
import { Link } from '@app/link/link.schema'
import { Projects } from '@app/projects/projects.schema'
import { Template } from '@app/template/template.schema'
import { canonicalMethods, constants, integration_operation, redisKeys } from '@config'
import { Demographics, DeviceInfo } from '@interfaces/demographics.interface'
import { Request, SMSRequestRedis } from '@interfaces/request.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { HttpStatus, Inject } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import DemographicsHandler from '@utils/demographics.util'
import { getAPIResponse, getErrorLog } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import _ from 'lodash'
import { Model } from 'mongoose'
import { RequestEngagement } from './requests.engagement.schema'
import { Requests } from './requests.schema'

export class RequestsService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    private logger: VappLogger,
    @InjectModel(RequestEngagement.name) private engagement: Model<RequestEngagement>,
    @InjectModel(Requests.name) private requestModel: Model<Requests>,
    @InjectModel(Projects.name) private projectsModel: Model<Projects>,
    @InjectModel(Campaign.name) private campaignModel: Model<Campaign>,
    @InjectModel(Template.name) private templatesModel: Model<Template>,
    @InjectModel(Contact.name) private contactsDatabaseModel: Model<Contact>,
    @InjectModel(Credits.name) private creditsModel: Model<Credits>,
    @InjectModel(Link.name) private linksModel: Model<Link>,
    @InjectModel(Dashboard.name) private dashboardModel: Model<Dashboard>,
    private integrationsService: IntegrationsService
  ) {
    this.traceID = vapp_context.traceID
  }

  queryRequest = (queryID: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      // query sms request
      RedisHandler.getInstance().get(redisKeys.CAMPAIGN_REQUEST.value(queryID), (error: Error, data: string) => {
        if (_.isNil(error) && !_.isNil(data)) {
          resolve(getAPIResponse(messages.CAM021.code, this.traceID, HttpStatus.OK, JSON.parse(data) as SMSRequestRedis))
        } else {
          resolve(getAPIResponse(messages.CAM017.code, this.traceID, HttpStatus.FORBIDDEN))
        }
      })
    })

  addFirstEngagement = (requestID: string, ip: string, deviceDetection: DeviceInfo) =>
    new Promise<ServiceResponse>(async (resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void, reject: (value?: string | PromiseLike<string>) => void) => {
      // add first engagement to request
      try {
        const engagement = new this.engagement({
          time: 0
        })
        const request: Requests = await findOperations.findOne(this.requestModel, { _id: requestID }, {})
        let demographicsFetched: Demographics = null
        if (!_.isNil(request)) {
          if (_.isNil(request.demographics)) {
            const demographicsData = await DemographicsHandler.getInstance().getDemographics(ip)
            if (!_.isNil(demographicsData.country_code_iso3)) {
              demographicsFetched = {
                latitude: demographicsData.latitude,
                longitude: demographicsData.longitude,
                country_code: demographicsData.country_code_iso3,
                region_code: demographicsData.region_code,
                region: demographicsData.region,
                continent_code: demographicsData.continent_code,
                city: demographicsData.city,
                ip: demographicsData.ip
              } as Demographics
            } else {
              this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_ENGAGEMENT_DEMOGRAPHICS, this.traceID, { requestID, ip, demographicsFetched }, messages.CAM045.message))
            }
          }
          const visitedValue = true
          const linksClickCountValue = !request.visited ? 1 : 0
          const lead_operation = !request.visited ? integration_operation.CREATE : integration_operation.UPDATE
          const requestUpdateResult: Request = await createOperations.updateOne(
            this.requestModel,
            { _id: requestID },
            {
              $push: { engagementTime: engagement },
              $set: {
                visited: visitedValue,
                smsStatus: constants.SMS_STATUS.success,
                morphed: true,
                demographics: !_.isNil(demographicsFetched) ? demographicsFetched : request.demographics,
                device: deviceDetection.device,
                os: deviceDetection.os,
                deviceType: deviceDetection.type
              }
            }
          )
          if (!_.isNil(requestUpdateResult)) {
            let updateObject: any
            let statsUpdateObject: any
            let deliveryUpdateObject: any
            const demographicsObject: any = []
            // update sms delivered when request type is sms
            if (_.eq(requestUpdateResult.type, constants.CAMPAIGN_TYPES.SMS.value)) {
              updateObject = {
                linksClickCount: linksClickCountValue,
                smsLinksClickCount: linksClickCountValue,
                smsDeliveredCount: request.morphed ? 0 : linksClickCountValue,
                viewsCount: 1,
                smsViewsCount: 1
              }
              statsUpdateObject = {
                linksClickCount: linksClickCountValue,
                smsLinksClickCount: linksClickCountValue,
                smsDeliveredCount: request.morphed ? 0 : linksClickCountValue,
                viewsCount: 1,
                smsViewsCount: 1
              }
              deliveryUpdateObject = {
                smsDeliveredCount: request.morphed ? 0 : linksClickCountValue
              }
            } else if (_.eq(requestUpdateResult.type, constants.CAMPAIGN_TYPES.WHATSAPP.value)) {
              updateObject = {
                whatsappLinksClickCount: linksClickCountValue,
                linksClickCount: linksClickCountValue,
                viewsCount: 1,
                whatsappViewsCount: 1
              }
              statsUpdateObject = {
                linksClickCount: linksClickCountValue,
                viewsCount: 1,
                whatsappViewsCount: 1,
                whatsappLinksClickCount: linksClickCountValue
              }
            }
            if (!_.isNil(demographicsFetched)) {
              demographicsObject.push(demographicsFetched)
            }
            const projectUpdateResult: Projects = await createOperations.updateOne(this.projectsModel, { _id: requestUpdateResult.projectID }, { $inc: updateObject })
            if (!_.isNil(projectUpdateResult)) {
              let templates: Template[]
              let contactsDatabases: ContactDatabase[]
              let links: Link[]
              // update campaign links clicks, view count, sms delivered count
              const campaignUpdateResult: Campaign = await createOperations.updateOne(this.campaignModel, { _id: requestUpdateResult.campaignID }, { $inc: updateObject, $addToSet: { demographics: demographicsObject } })
              if (!_.isNil(campaignUpdateResult)) {
                // update contacts template if present
                if (!_.isNil(campaignUpdateResult.templateID)) {
                  const template: Template = await createOperations.updateOne(this.templatesModel, { _id: campaignUpdateResult.templateID }, { $inc: statsUpdateObject })
                  if (!_.isNil(template)) {
                    templates = await findOperations.find(this.templatesModel, { clientID: requestUpdateResult.clientID }, { __v: 0, password: 0 }, {})
                  }
                }
                // update content stats if present
                if (!_.isNil(campaignUpdateResult.linkID)) {
                  const link: Link = await createOperations.updateOne(this.linksModel, { _id: campaignUpdateResult.linkID }, { $inc: statsUpdateObject })
                  if (!_.isNil(link)) {
                    links = await findOperations.find(this.linksModel, { clientID: requestUpdateResult.clientID }, { __v: 0, password: 0 }, {})
                  }
                }
                // update contacts database if present
                if (!_.isNil(campaignUpdateResult.databaseID)) {
                  const contactsDatabase: ContactDatabase = await createOperations.updateOne(this.contactsDatabaseModel, { _id: campaignUpdateResult.databaseID }, { $inc: statsUpdateObject })
                  if (!_.isNil(contactsDatabase)) {
                    contactsDatabases = await findOperations.find(this.contactsDatabaseModel, { clientID: requestUpdateResult.clientID }, { __v: 0, password: 0 }, {})
                  }
                }
                const dashboardUpdateResult: Dashboard = await createOperations.updateOneUpsert(
                  this.dashboardModel,
                  {
                    year: new Date().getFullYear(),
                    month: new Date().getMonth() + 1,
                    clientID: requestUpdateResult.clientID
                  },
                  { $inc: updateObject }
                )
                if (!_.isNil(dashboardUpdateResult)) {
                  const creditsUpdateResult: Credits = await createOperations.updateOne(
                    this.creditsModel,
                    {
                      clientID: requestUpdateResult.clientID
                    },
                    {
                      $inc: deliveryUpdateObject
                    }
                  )
                  if (!_.isNil(creditsUpdateResult)) {
                    RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), JSON.stringify(creditsUpdateResult))
                    RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), redisKeys.USER_CREDITS.timeout())
                    RedisHandler.getInstance().set(redisKeys.PROJECT.value(projectUpdateResult._id), JSON.stringify(projectUpdateResult))
                    RedisHandler.getInstance().expire(redisKeys.PROJECT.value(projectUpdateResult._id), redisKeys.PROJECT.timeout())
                    RedisHandler.getInstance().set(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), JSON.stringify(campaignUpdateResult))
                    RedisHandler.getInstance().ttl(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), (error: Error, time: number) => {
                      if (_.isNil(error) && _.isNumber(time)) {
                        RedisHandler.getInstance().expire(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), time)
                      } else {
                        this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_ENGAGEMENT, this.traceID, { requestID, requestUpdateResult, error }, messages.CAM032.message))
                      }
                    })
                    if (!_.isNil(templates)) {
                      RedisHandler.getInstance().set(redisKeys.USER_TEMPLATES.value(requestUpdateResult.clientID), JSON.stringify(templates))
                      RedisHandler.getInstance().expire(redisKeys.USER_TEMPLATES.value(requestUpdateResult.clientID), redisKeys.USER_TEMPLATES.timeout())
                    }
                    if (!_.isNil(links)) {
                      RedisHandler.getInstance().set(redisKeys.USER_LINKS.value(requestUpdateResult.clientID), JSON.stringify(links))
                      RedisHandler.getInstance().expire(redisKeys.USER_LINKS.value(requestUpdateResult.clientID), redisKeys.USER_LINKS.timeout())
                    }
                    if (!_.isNil(contactsDatabases)) {
                      RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(requestUpdateResult.clientID), JSON.stringify(contactsDatabases))
                      RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(requestUpdateResult.clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
                    }
                    this.integrationsService.processIntegration(lead_operation, requestUpdateResult, this.traceID)
                    resolve(
                      <ServiceResponse>getAPIResponse(messages.CAM018.code, this.traceID, HttpStatus.OK, {
                        engagementID: engagement._id,
                        requestID,
                        clientID: requestUpdateResult.clientID
                      })
                    )
                  } else {
                    throw messages.REQ001.code
                  }
                } else {
                  throw messages.REQ001.code
                }
              } else {
                throw messages.REQ001.code
              }
            } else {
              throw messages.REQ001.code
            }
          } else {
            throw messages.REQ001.code
          }
        } else {
          throw messages.COM001.code
        }
      } catch (error) {
        this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_ENGAGEMENT, this.traceID, error))
        resolve(<ServiceResponse>getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      }
    })
}
