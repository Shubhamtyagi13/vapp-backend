import { variables, environments } from '@config'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Controller, Get, Param, Req, Res,
} from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { ApiBearerAuth, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { createOperations } from '@utils/crud.util'
import {
  deviceDetection, generateShortUID, getEnvironmentVariable, getExpirationTimestamp, getIP,
} from '@utils/platform.util'
import async from 'async'
import { Request, Response } from 'express'
import _ from 'lodash'
import { Model } from 'mongoose'
import { Requests } from './requests.schema'
import { RequestsService } from './requests.service'

@ApiTags(RequestsController.name)
@ApiBearerAuth('Authorization Bearer Token')
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
@Controller('requests')
export class RequestsController {
  constructor(private requestsService: RequestsService) {}

  @Get(':queryID')
  queryRequest(@Param('queryID') queryID: string, @Res() response: Response) {
    this.requestsService.queryRequest(queryID).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Get('/engagement/:requestID')
  addEngagement(@Param('requestID') requestID: string, @Req() request: Request, @Res() response: Response) {
    this.requestsService.addFirstEngagement(requestID, getIP(request), deviceDetection(request)).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }
}
