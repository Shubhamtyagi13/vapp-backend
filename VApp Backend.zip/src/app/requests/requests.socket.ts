import { VappLogger } from '@services/logger.service'
import { Campaign } from '@app/campaign/campaign.schema'
import { Dashboard } from '@app/dashboard/dashboard.schema'
import { Projects } from '@app/projects/projects.schema'
import { Requests } from '@app/requests/requests.schema'
import { constants, cronJobs, integration_operation, redisKeys, variables, websocketEvents } from '@config'
import { messages } from '@messages'
import { InjectQueue } from '@nestjs/bull'
import { InjectModel } from '@nestjs/mongoose'
import { ConnectedSocket, MessageBody, OnGatewayConnection, OnGatewayDisconnect, OnGatewayInit, SubscribeMessage, WebSocketGateway, WebSocketServer } from '@nestjs/websockets'
import { Queue } from 'bull'
import _ from 'lodash'
import { Model } from 'mongoose'
import { Server, Socket } from 'socket.io'
import { createOperations } from '@utils/crud.util'
import { RedisHandler } from '@utils/redis.util'
import { DeviceInfo } from '@interfaces/demographics.interface'
import { IntegrationsService } from '@app/integrations/integrations.service'
import { Request } from '@interfaces/request.interface'
import { getAllowedOrigin, getEnvironmentVariable, getErrorLog, getLog, wsDeviceDetection, wsGetIP } from '../../common/utils/platform.util'

@WebSocketGateway()
export class RequestsWebSocketGateway implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect {
  constructor(
    private logger: VappLogger,
    @InjectModel(Requests.name) private requestsModel: Model<Requests>,
    @InjectModel(Projects.name) private projectsModel: Model<Projects>,
    @InjectModel(Campaign.name) private campaignModel: Model<Campaign>,
    @InjectModel(Dashboard.name) private dashboardModel: Model<Dashboard>,
    @InjectQueue(cronJobs.ENGAGEMENT_TRACKING.name) private engagementTrackingQueue: Queue,
    private integrationService: IntegrationsService
  ) {
  }

  @WebSocketServer() server: Server

  async afterInit(server: Server) {
    this.logger?.log('Init from request')
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`Client disconnected request: ${client.id}`)
  }

  handleConnection(client: Socket, ...args: any[]) {
    this.logger.log(`Client connected: ${client.id}`)
  }

  @SubscribeMessage(websocketEvents.CLIENT_BROCHURE_INTERACTION)
  brochureInteraction(@MessageBody() data: { requestID: string }, @ConnectedSocket() client: Socket) {
    if (!_.isNil(data.requestID)) {
      createOperations
        .updateOne(this.requestsModel, { shortID: data.requestID, brochure: false } as Requests, {
          $set: { brochure: true }
        })
        .then((requestUpdateResult: Requests) => {
          if (!_.isNil(requestUpdateResult)) {
            this.integrationService.processIntegration(integration_operation.UPDATE, requestUpdateResult as Request, websocketEvents.CLIENT_BROCHURE_INTERACTION)
            this.logger.log(getLog(websocketEvents.CLIENT_BROCHURE_INTERACTION, { shortID: requestUpdateResult.shortID }, messages.INT007.message))
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(websocketEvents.CLIENT_BROCHURE_INTERACTION, client.id, { data, error }))
        })
    } else {
      this.logger.error(getErrorLog(websocketEvents.CLIENT_BROCHURE_INTERACTION, client.id, { data }))
    }
  }

  @SubscribeMessage(websocketEvents.CLIENT_BOT_INTERACTION)
  botInteraction(@MessageBody() data: { requestID: string }, @ConnectedSocket() client: Socket) {
    if (!_.isNil(data.requestID)) {
      createOperations
        .updateOne(this.requestsModel, { shortID: data.requestID, chatbot: false } as Requests, {
          $set: { chatbot: true }
        })
        .then((requestUpdateResult: Requests) => {
          if (!_.isNil(requestUpdateResult)) {
            this.integrationService.processIntegration(integration_operation.UPDATE, requestUpdateResult as Request, websocketEvents.CLIENT_BOT_INTERACTION)
            this.logger.log(getLog(websocketEvents.CLIENT_BOT_INTERACTION, { shortID: requestUpdateResult.shortID }, messages.INT006.message))
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(websocketEvents.CLIENT_BOT_INTERACTION, client.id, { data, error }))
        })
    } else {
      this.logger.error(getErrorLog(websocketEvents.CLIENT_BOT_INTERACTION, client.id, { data }))
    }
  }

  @SubscribeMessage(websocketEvents.CLIENT_WHATSAPP_INTERACTION)
  async whatsappInteraction(@MessageBody() data: { requestID: string }, @ConnectedSocket() client: Socket) {
    if (!_.isNil(data.requestID)) {
      try {
        const requestUpdateResult: Requests = await createOperations.updateOne(this.requestsModel, { shortID: data.requestID, whatsapp: false } as Requests, {
          $set: { whatsapp: true }
        })
        if (!_.isNil(requestUpdateResult)) {
          // update project whatsapp clicks
          const projectUpdateResult: Projects = await createOperations.updateOne(this.projectsModel, { _id: requestUpdateResult.projectID }, { $inc: { whatsappClicks: 1 } })
          if (!_.isNil(projectUpdateResult)) {
            // update campaign whatsapp clicks
            const campaignUpdateResult: Campaign = await createOperations.updateOne(this.campaignModel, { _id: requestUpdateResult.campaignID }, { $inc: { whatsappClicks: 1 } })
            if (!_.isNil(campaignUpdateResult)) {
              // update monthly dashboard whatsapp clicks
              const dashboardUpdateResult: Dashboard = await createOperations.updateOneUpsert(
                this.dashboardModel,
                {
                  year: new Date().getFullYear(),
                  month: new Date().getMonth() + 1,
                  clientID: requestUpdateResult.clientID
                },
                { $inc: { whatsappClicks: 1 } }
              )
              if (!_.isNil(dashboardUpdateResult)) {
                this.integrationService.processIntegration(integration_operation.UPDATE, requestUpdateResult as Request, websocketEvents.CLIENT_WHATSAPP_INTERACTION)
                this.logger.log(`${messages.INT005.message}:  ${requestUpdateResult.shortID}`)
                // update project in redis
                RedisHandler.getInstance().set(redisKeys.PROJECT.value(projectUpdateResult._id), JSON.stringify(projectUpdateResult))
                RedisHandler.getInstance().expire(redisKeys.PROJECT.value(projectUpdateResult._id), redisKeys.PROJECT.timeout())
                // update campaign in redis
                RedisHandler.getInstance().set(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), JSON.stringify(campaignUpdateResult))
                RedisHandler.getInstance().ttl(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), (error: Error, time: number) => {
                  if (_.isNil(error) && _.isNumber(time)) {
                    RedisHandler.getInstance().expire(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), time)
                  } else {
                    this.logger.error(getErrorLog(websocketEvents.CLIENT_WHATSAPP_INTERACTION, client.id, { data, requestUpdateResult }, messages.INT008.message))
                  }
                })
              } else {
                throw new Error(messages.INT002.message)
              }
            } else {
              throw new Error(messages.INT003.message)
            }
          } else {
            throw new Error(messages.INT001.message)
          }
        } else {
          throw new Error(messages.COM001.message)
        }
      } catch (error) {
        this.logger.error(getErrorLog(websocketEvents.CLIENT_WHATSAPP_INTERACTION, client.id, { error: JSON.stringify(error), data }, error.message))
      }
    } else {
      this.logger.error(getErrorLog(websocketEvents.CLIENT_WHATSAPP_INTERACTION, client.id, { data }))
    }
  }

  @SubscribeMessage(websocketEvents.CLIENT_TOUR_ENGAGEMENT)
  async tourInteraction(@MessageBody() data: { requestID: string; time: number; engagementID: string; socketID?: string; ip: string; deviceDetection: DeviceInfo }, @ConnectedSocket() client: Socket) {
    if (!_.isNil(data.requestID)) {
      data.ip = wsGetIP(client)
      data.deviceDetection = wsDeviceDetection(client)
      data.socketID = client.id
      this.engagementTrackingQueue.add({ payload: data, traceID: client.id })
    } else {
      this.logger.error(getErrorLog(websocketEvents.CLIENT_TOUR_ENGAGEMENT, client.id, { data }))
    }
  }
}
