import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.ENGAGEMENTS.collection })
export class RequestEngagement extends Document {
  @Prop({ type: Number })
  time: number

  @Prop({type: String})
  engagementID: string
}
export const RequestsEngagementSchema = SchemaFactory.createForClass(RequestEngagement)
