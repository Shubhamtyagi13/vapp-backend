import { Campaign, CampaignSchema } from '@app/campaign/campaign.schema'
import { CreateSMSCampaignQueueModule, CreateRBMCampaignQueueModule } from '@app/campaign/cron/queue.module'
import { Contact, ContactSchema } from '@app/contact/contact.schema'
import { Credits, CreditsSchema } from '@app/credits/credits.schema'
import { Dashboard, DashboardSchema } from '@app/dashboard/dashboard.schema'
import { Link, LinkSchema } from '@app/link/link.schema'
import { Projects, ProjectsSchema } from '@app/projects/projects.schema'
import { Template, TemplateSchema } from '@app/template/template.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { DripRequests, DripRequestsSchema } from './drip_requests.schema'
import { RequestsController } from './requests.controller'
import { RequestEngagement, RequestsEngagementSchema } from './requests.engagement.schema'
import { Requests, RequestsSchema } from './requests.schema'
import { RequestsService } from './requests.service'
import { RequestsWebSocketGateway } from './requests.socket'

@Module({
  imports: [
    CreateSMSCampaignQueueModule,
    CreateRBMCampaignQueueModule,
    MongooseModule.forFeature([
      { name: DripRequests.name, schema: DripRequestsSchema },
      { name: RequestEngagement.name, schema: RequestsEngagementSchema },
      { name: Projects.name, schema: ProjectsSchema },
      { name: Link.name, schema: LinkSchema },
      { name: Campaign.name, schema: CampaignSchema },
      { name: Template.name, schema: TemplateSchema },
      { name: Contact.name, schema: ContactSchema },
      { name: Credits.name, schema: CreditsSchema },
      { name: Dashboard.name, schema: DashboardSchema },
    ]),
  ],
  controllers: [RequestsController],
  providers: [RequestsService, VappLogger, RequestsWebSocketGateway],
})
export class DripRequestsModule {}
