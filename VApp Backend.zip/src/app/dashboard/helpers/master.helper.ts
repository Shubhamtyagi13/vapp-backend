import { ContactDatabase } from '@app/contact/contact.database.schema'
import { Credits } from '@app/credits/credits.schema'
import { Link } from '@app/link/link.schema'
import { Projects } from '@app/projects/projects.schema'
import { Template } from '@app/template/template.schema'
import { constants, redisKeys } from '@config'
import {
  DashboardTrendingDatabase,
  DashboardTrendingPerson,
  DashboardTrendingProject,
  DashboardTrendingTemplate,
  MasterDashboard,
  PerformanceStats,
  SpendingTrend,
} from '@interfaces/dashboard.interface'
import { findOperations } from '@utils/crud.util'
import { get12MonthFilter } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import _ from 'lodash'
import { Model } from 'mongoose'
import { Dashboard } from '../dashboard.schema'
import { DashboardTrendingLink, DashboardTrendingStore } from '../dashboard.trending.schema'

export const getDashboardGraphData = (clientID: string, dashboardModel: Model<Dashboard>, callback: (error: Error | null, data?: [Dashboard]) => void) => {
  findOperations
    .find(dashboardModel, {
      clientID,
      ...get12MonthFilter(),
    }, {
      __v: 0,
      password: 0,
      clientID: 0,
      year: 0,
    })
    .then((dashboardResults: [Dashboard]) => {
      if (!_.isNil(dashboardResults)) {
        callback(null, dashboardResults)
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      callback(null)
    })
}

export const getAdminDashboardGraphData = (dashboardModel: Model<Dashboard>, callback: (error: Error | null, data?: [Dashboard]) => void) => {
  findOperations
    .find(
      dashboardModel,
      {
        year: new Date().getFullYear()
      },
      {
        __v: 0,
        password: 0,
        year: 0
      }
    )
    .then((dashboardResults: [Dashboard]) => {
      if (!_.isNil(dashboardResults)) {
        callback(null, dashboardResults)
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      callback(null)
    })
}

export const getClientProjectsData = (clientID: string, projectsModel: Model<Projects>, callback: (error: Error | null, data?: [Projects]) => void) => {
  findOperations
    .find(projectsModel, {
      clientID,
    }, {
      name: 1,
      viewsCount: 1,
      smsSentCount: 1,
      whatsappViewsCount: 1,
      smsViewsCount: 1,
      smsDeliveredCount: 1,
      smsFailedCount: 1,
      whatsappSentCount: 1,
      whatsappDeliveredCount: 1,
      whatsappFailedCount: 1,
      demographics: 1,
      smsLinksClickCount: 1,
      whatsappLinksClickCount: 1,
    }, { viewsCount: -1 })
    .then((projects: [Projects]) => {
      if (!_.isNil(projects)) {
        callback(null, projects)
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      //   logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_MASTER_DASHBOARD_DATA, { clientID }, error.message))
      callback(null)
    })
}

export const getClientCredits = (clientID: string, creditsModel: Model<Credits>, callback: (error: Error | null, data?: Credits) => void) => {
  RedisHandler.getInstance().get(redisKeys.USER_CREDITS.value(clientID), (error: Error, data: string) => {
    if (_.isNil(error) && !_.isNil(data)) {
      callback(null, JSON.parse(data) as Credits)
    } else {
      findOperations
        .findOne(creditsModel, { clientID }, { __v: 0 })
        .then((credits: Credits) => {
          if (!_.isNil(credits)) {
            RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(clientID), JSON.stringify(credits))
            RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(clientID), redisKeys.USER_CREDITS.timeout())
            callback(null, credits)
          } else {
            callback(null)
          }
        })
        .catch((error: Error) => {
          // logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_MASTER_DASHBOARD_DATA, { clientID }, error.message))
          callback(null)
        })
    }
  })
}
export const getMasterBestPerformingStats = async (
  clientID: string,
  projectsModel: Model<Projects>,
  templatesModel: Model<Template>,
  contactsDatabaseModel: Model<ContactDatabase>,
  linksModel: Model<Link>,
  callback: (error: Error | null, data?: PerformanceStats) => void,
  filterObject: {
    projectID?: string
    templateIDs?: [string]
    databaseIDs?: [string]
    linkIDs?: [string]
  } = {},
) => {
  const data_1 = await new Promise<PerformanceStats>(async (resolve: (value_1?: PerformanceStats | PromiseLike<PerformanceStats>) => void, reject) => {
    const bestPerformanceStats = {} as PerformanceStats
    try {
      const projects: Projects[] = await findOperations.findLean(projectsModel, { clientID }, { _id: 1, name: 1 }, { positiveCount: -1 })
      if (!_.isNil(projects) && !_.isEmpty(projects)) {
        if (!_.isNil(filterObject.projectID)) {
          bestPerformanceStats.project = projects.find((project_1) => _.eq(project_1._id.toString(), filterObject.projectID))
        } else {
          bestPerformanceStats.project = projects[0]
        }
      }
    } catch (e) {}

    try {
      const databases: ContactDatabase[] = await findOperations.findLean(contactsDatabaseModel, { clientID }, { _id: 1, name: 1 }, { positiveCount: -1 })
      if (!_.isNil(databases) && !_.isEmpty(databases)) {
        if (!_.isNil(filterObject.databaseIDs) && !_.isEmpty(filterObject.databaseIDs)) {
          const filtered = databases.filter((database) => _.includes(filterObject.databaseIDs, database._id.toString()))
          if (!_.isNil(filtered) && !_.isEmpty(filtered)) {
            bestPerformanceStats.database = filtered[0]
          }
        } else {
          bestPerformanceStats.database = databases[0]
        }
      }
    } catch (e_1) {}
    try {
      const links: Link[] = await findOperations.findLean(linksModel, { clientID }, { _id: 1, name: 1 }, { positiveCount: -1 })
      if (!_.isNil(links) && !_.isEmpty(links)) {
        if (!_.isNil(filterObject.linkIDs) && !_.isEmpty(filterObject.linkIDs)) {
          const filtered_1 = links.filter((link) => _.includes(filterObject.linkIDs, link._id.toString()))
          if (!_.isNil(filtered_1) && !_.isEmpty(filtered_1)) {
            bestPerformanceStats.link = filtered_1[0]
          }
        } else {
          bestPerformanceStats.link = links[0]
        }
      }
    } catch (e_2) {}
    try {
      const templates: Template[] = await findOperations.findLean(templatesModel, { clientID }, { _id: 1, name: 1 }, { positiveCount: -1 })
      if (!_.isNil(templates) && !_.isEmpty(templates)) {
        if (!_.isNil(filterObject.templateIDs) && !_.isEmpty(filterObject.templateIDs)) {
          const filtered_2 = templates.filter((template) => _.includes(filterObject.templateIDs, template._id.toString()))
          if (!_.isNil(filtered_2) && !_.isEmpty(filtered_2)) {
            bestPerformanceStats.template = filtered_2[0]
          }
        } else {
          bestPerformanceStats.template = templates[0]
        }
      }
    } catch (e_3) {}
    resolve(bestPerformanceStats)
  })
  return callback(null, data_1)
}

export const getMasterDashboardTrends = (
  clientID: string,
  dashboardTrendsModel: Model<DashboardTrendingStore>,
  callback: (error: Error | null, data?: [DashboardTrendingStore]) => void,
) => {
  findOperations
    .find(dashboardTrendsModel, {
      clientID,
      ...get12MonthFilter(),
    }, {
      __v: 0,
      password: 0,
      clientID: 0,
      year: 0,
    })
    .then((dashboardTrends: [DashboardTrendingStore]) => {
      if (!_.isNil(dashboardTrends) && !_.isEmpty(dashboardTrends)) {
        callback(null, dashboardTrends)
      } else {
        callback(null, ([] as unknown) as [DashboardTrendingStore])
      }
    })
    .catch((error: Error) => {
      //   logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_MASTER_DASHBOARD_DATA, { clientID }, error.message))
      callback(null)
    })
}

export const getInitialDashboardData = () => {
  const masterDashboardObject = {} as MasterDashboard
  masterDashboardObject.performance = {} as PerformanceStats
  masterDashboardObject.demographics = null
  masterDashboardObject.trends = {
    persons: [] as DashboardTrendingPerson[],
    projects: [] as DashboardTrendingProject[],
    templates: [] as DashboardTrendingTemplate[],
    databases: [] as DashboardTrendingDatabase[],
    links: [] as DashboardTrendingLink[],
    spendingTrends: [] as SpendingTrend[],
  }
  masterDashboardObject.projectCount = 0
  masterDashboardObject.calendar = []
  masterDashboardObject.stats = {
    engagementTotal: 0,
    engagementSum: 0,
    smsEngagementTotal: 0,
    smsEngagementSum: 0,
    whatsappEngagementTotal: 0,
    whatsappEngagementSum: 0,
    whatsappClicks: 0,
    smsSentCount: 0,
    smsDeliveredCount: 0,
    smsFailedCount: 0,
    linksCount: 0,
    linksClickCount: 0,
    viewsCount: 0,
    whatsappViewsCount: 0,
    smsViewsCount: 0,
    whatsappSentCount: 0,
    whatsappDeliveredCount: 0,
    whatsappFailedCount: 0,
    smsLinksClickCount: 0,
    whatsappLinksClickCount: 0,
  } as Dashboard
  masterDashboardObject.stats.negativeCount = 0
  masterDashboardObject.stats.positiveCount = 0
  masterDashboardObject.stats.neutralCount = 0
  masterDashboardObject.graph = [] as Dashboard[]
  constants.MONTHS.forEach((month) => {
    masterDashboardObject.graph.push({
      month: month.index,
      value: month.long,
      engagementTotal: 0,
      engagementSum: 0,
      smsEngagementTotal: 0,
      smsEngagementSum: 0,
      whatsappEngagementTotal: 0,
      whatsappEngagementSum: 0,
      whatsappClicks: 0,
      smsSentCount: 0,
      smsDeliveredCount: 0,
      smsFailedCount: 0,
      linksCount: 0,
      linksClickCount: 0,
      viewsCount: 0,
      whatsappViewsCount: 0,
      smsViewsCount: 0,
      whatsappSentCount: 0,
      whatsappDeliveredCount: 0,
      whatsappFailedCount: 0,
      smsLinksClickCount: 0,
      whatsappLinksClickCount: 0,
    } as Dashboard)

    masterDashboardObject.credits = {
      credits: 0,
      frozenCount: 0,
      smsSentCount: 0,
      smsCost: 0,
      whatsappCost: 0,
      smsFailedCount: 0,
      smsDeliveredCount: 0,
      whatsappSentCount: 0,
      whatsappDeliveredCount: 0,
      whatsappFailedCount: 0,
      smsCredits: 0,
      whatsappCredits: 0,
    } as Credits
  })
  return masterDashboardObject
}

export const getInitialAdminDashboardData  = () => {
  const masterDashboardObject = {} as MasterDashboard
  
  
  masterDashboardObject.graph = [] as Dashboard[]
  constants.MONTHS.forEach((month) => {
    masterDashboardObject.graph.push({
      month: month.index,
      value: month.long,
      smsSentCount: 0,
      smsDeliveredCount: 0,
      whatsappSentCount: 0,
      whatsappDeliveredCount: 0
      
    } as Dashboard)
  })
  return masterDashboardObject
}
