import { Campaign } from '@app/campaign/campaign.schema'
import { DripCampaign } from '@app/campaign/drip_campaign.schema'
import { Tracking } from '@app/tracking/tracking.schema'
import { CampaignEvent } from '@interfaces/campaign.interface'
import { findOperations } from '@utils/crud.util'
import { get12MonthFilter } from '@utils/platform.util'
import _ from 'lodash'
import { Model } from 'mongoose'

export const getCampaignData = (clientID: string, campaignModel: Model<Campaign>, callback: (error: Error | null, data?: [Campaign]) => void, projectID = null) => {
  const filterObject = {
    clientID,
    ...get12MonthFilter(),
  }
  findOperations
    .find(campaignModel, !_.isNil(projectID) ? { ...filterObject, projectID } : filterObject, { token: 0 }, { _id: -1 })
    .then((campaignResults: [Campaign]) => {
      if (!_.isNil(campaignResults)) {
        callback(null, campaignResults)
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      callback(null)
    })
}

export const getDripCampaignData = (clientID: string, campaignModel: Model<DripCampaign>, callback: (error: Error | null, data?: [DripCampaign]) => void, projectID = null) => {
  const filterObject = {
    clientID,
    ...get12MonthFilter(),
  }
  findOperations
    .find(campaignModel, !_.isNil(projectID) ? { ...filterObject, projectID } : filterObject, { token: 0 }, { _id: -1 })
    .then((campaignResults: [DripCampaign]) => {
      if (!_.isNil(campaignResults)) {
        callback(null, campaignResults)
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      callback(null)
    })
}

export const getCampaignEventsData = (
  clientID: string,
  trackingModel: Model<Tracking>,
  callback: (error: Error | null, data?: [CampaignEvent]) => void,
  projectID = null,
) => {
  const filterObject = {
    $match: {
      ...get12MonthFilter(),
      clientID,
    },
  }
  if (!_.isNil(projectID)) {
    _.set(filterObject.$match, 'projectID', projectID)
  }
  findOperations
    .aggregate(trackingModel, [
      filterObject,
      { $addFields: { events: { $size: '$events' } } },
      {
        $group: {
          _id: '$shortID',
          shortID: { $first: '$shortID' },
          events: { $sum: '$events' },
          campaignID: { $first: '$campaignID' },
        },
      },
      {
        $project: {
          shortID: 1,
          campaignID: 1,
          events: { $cond: [{ $gt: ['$events', 0] }, 1, 0] },
          eventsThreshold: { $cond: [{ $gt: ['$events', 1] }, 1, 0] },
          _id: 0,
        },
      },
      {
        $group: {
          _id: '$campaignID',
          campaignID: { $first: '$campaignID' },
          events: { $sum: '$events' },
          eventsThreshold: { $sum: '$eventsThreshold' },
        },
      },
      {
        $project: {
          campaignID: 1,
          events: 1,
          eventsThreshold: 1,
          _id: 0,
        },
      },
    ])
    .then((campaignEventResults: [CampaignEvent]) => {
      if (!_.isNil(campaignEventResults)) {
        callback(null, campaignEventResults)
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      callback(null)
    })
}

export const getDatabaseEventsData = (
  clientID: string,
  trackingModel: Model<Tracking>,
  callback: (error: Error | null, data?: [CampaignEvent]) => void,
  projectID = null,
) => {
  const filterObject = {
    $match: {
      ...get12MonthFilter(),
      clientID,
    },
  }
  if (!_.isNil(projectID)) {
    _.set(filterObject.$match, 'projectID', projectID)
  }
  findOperations
    .aggregate(trackingModel, [
      filterObject,
      { $addFields: { events: { $size: '$events' }, eventsThreshold: { $cond: [{ $gt: [{ $size: '$events' }, 1] }, 1, 0] } } },
      {
        $group: {
          _id: '$databaseID',
          databaseID: { $first: '$databaseID' },
          events: { $sum: '$events' },
          eventsThreshold: { $sum: '$eventsThreshold' },
        },
      },
      {
        $project: {
          campaignID: 1,
          events: 1,
          eventsThreshold: 1,
          _id: 0,
        },
      },
    ])
    .then((campaignEventResults: [CampaignEvent]) => {
      if (!_.isNil(campaignEventResults)) {
        callback(null, campaignEventResults)
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      callback(null)
    })
}
