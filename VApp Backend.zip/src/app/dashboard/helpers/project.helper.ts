import { Campaign } from '@app/campaign/campaign.schema'
import { DripCampaign } from '@app/campaign/drip_campaign.schema'
import { ContactDatabase } from '@app/contact/contact.database.schema'
import { Credits } from '@app/credits/credits.schema'
import { Link } from '@app/link/link.schema'
import { Projects } from '@app/projects/projects.schema'
import { ProjectTrendingEngagementsSchemaStore } from '@app/projects/projects.trending.engagement.schema'
import { Template } from '@app/template/template.schema'
import { constants, redisKeys } from '@config'
import { PerformanceStats, ProjectDashboard } from '@interfaces/dashboard.interface'
import { Project } from '@interfaces/project.interface'
import { findOperations } from '@utils/crud.util'
import { get12MonthFilter } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import _ from 'lodash'
import { Model } from 'mongoose'

export const getProjectGraphData = (clientID: string, projectID: string, campaignModel: Model<Campaign>, callback: (error: Error | null, data?: [Campaign]) => void) => {
  findOperations
    .find(campaignModel, {
      clientID,
      projectID,
      ...get12MonthFilter(),
    }, {
      templateID: 1,
      linkID: 1,
      databaseID: 1,
      type: 1,
      cloud: 1,
      tracking: 1,
      trackingScript:1,
      url: 1,
      phone: 1,
      month: 1,
      multiple: 1,
      sms: 1,
      engagementTotal: 1,
      engagementSum: 1,
      smsEngagementTotal: 1,
      smsEngagementSum: 1,
      whatsappClicks: 1,
      smsSentCount: 1,
      smsDeliveredCount: 1,
      whatsappSentCount: 1,
      smsFailedCount: 1,
      linksCount: 1,
      linksClickCount: 1,
      viewsCount: 1,
      whatsappViewsCount: 1,
      smsViewsCount: 1,
      brochure: 1,
      success: 1,
      redirection: 1,
      ivrFinalized: 1,
      ivr:1,
      error: 1,
      whatsappEngagementTotal: 1,
      whatsappEngagementSum: 1,
      whatsappFailedCount: 1,
      whatsappDeliveredCount: 1,
      whatsappLinksClickCount: 1,
      smsLinksClickCount: 1,
      campaignName: 1,
      demographics: 1,
      negativeCount: 1,
      neutralCount: 1,
      positiveCount: 1,
      leadPositive: 1,
      leadNegative: 1,
      leadNeutral: 1,
      calls: 1,
      callsThreshold: 1,
      credits: 1,
      status: 1,
      scheduleDate: 1,
    }, { _id: -1 })
    .then((campaignResults: [Campaign]) => {
      if (!_.isNil(campaignResults)) {
        callback(null, campaignResults)
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      // logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_PROJECT_DASHBOARD_DATA, { clientID, projectID }, error.message))
      callback(null)
    })
}

export const getDripProjectGraphData = (clientID: string, projectID: string, campaignModel: Model<DripCampaign>, callback: (error: Error | null, data?: [DripCampaign]) => void) => {
  findOperations
    .find(campaignModel, {
      clientID,
      projectID,
      ...get12MonthFilter(),
    }, {
      templateID: 1,
      linkID: 1,
      databaseID: 1,
      type: 1,
      cloud: 1,
      tracking: 1,
      url: 1,
      phone: 1,
      month: 1,
      multiple: 1,
      sms: 1,
      engagementTotal: 1,
      engagementSum: 1,
      smsEngagementTotal: 1,
      smsEngagementSum: 1,
      whatsappClicks: 1,
      smsSentCount: 1,
      smsDeliveredCount: 1,
      whatsappSentCount: 1,
      smsFailedCount: 1,
      linksCount: 1,
      linksClickCount: 1,
      viewsCount: 1,
      whatsappViewsCount: 1,
      smsViewsCount: 1,
      brochure: 1,
      success: 1,
      redirection: 1,
      ivrFinalized: 1,
      error: 1,
      whatsappEngagementTotal: 1,
      whatsappEngagementSum: 1,
      whatsappFailedCount: 1,
      whatsappDeliveredCount: 1,
      whatsappLinksClickCount: 1,
      smsLinksClickCount: 1,
      campaignName: 1,
      demographics: 1,
      negativeCount: 1,
      neutralCount: 1,
      positiveCount: 1,
      leadPositive: 1,
      leadNegative: 1,
      leadNeutral: 1,
      calls: 1,
      callsThreshold: 1,
      credits: 1,
      status: 1,
    }, { _id: -1 })
    .then((campaignResults: [DripCampaign]) => {
      if (!_.isNil(campaignResults)) {
        callback(null, campaignResults)
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      // logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_PROJECT_DASHBOARD_DATA, { clientID, projectID }, error.message))
      callback(null)
    })
}

export const getClientProjects = (projectID: string, projectsModel: Model<Projects>, callback: (error: Error | null, data?: Projects) => void) => {
  RedisHandler.getInstance().get(redisKeys.PROJECT.value(projectID), (error: Error, data: string) => {
    if (_.isNil(error) && !_.isNil(data)) {
      callback(null, JSON.parse(data) as Projects)
    } else {
      findOperations
        .findOne(projectsModel, { _id: projectID }, { _id: 0, __v: 0 })
        .then((project: Projects) => {
          if (!_.isNil(project)) {
            RedisHandler.getInstance().set(redisKeys.PROJECT.value(projectID), JSON.stringify(project))
            RedisHandler.getInstance().expire(redisKeys.PROJECT.value(projectID), redisKeys.PROJECT.timeout())
            callback(null, project)
          } else {
            callback(null)
          }
        })
        .catch((error: Error) => {
          //   logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_PROJECT_DASHBOARD_DATA, { clientID, projectID }, error.message))
          callback(null)
        })
    }
  })
}

export const getClientCreditsCost = (clientID: string, creditsModel: Model<Credits>, callback: (error: Error | null, data?: {}) => void) => {
  RedisHandler.getInstance().get(redisKeys.USER_CREDITS.value(clientID), (error: Error, data: string) => {
    if (_.isNil(error) && !_.isNil(data)) {
      const credits = JSON.parse(data) as Credits
      callback(null, { smsCost: credits.smsCost, whatsappCost: credits.whatsappCost })
    } else {
      findOperations
        .findOne(creditsModel, { clientID }, {})
        .then((credits: Credits) => {
          if (!_.isNil(credits)) {
            RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(clientID), JSON.stringify(credits))
            RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(clientID), redisKeys.USER_CREDITS.timeout())
            callback(null, { smsCost: credits.smsCost, whatsappCost: credits.whatsappCost })
          } else {
            callback(null)
          }
        })
        .catch((error: Error) => {
          //   logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_PROJECT_DASHBOARD_DATA, { clientID, projectID }, error.message))
          callback(null)
        })
    }
  })
}

export const getClientProjectDashboardTrends = (
  clientID: string,
  projectID: string,
  projectTrendsModel: Model<ProjectTrendingEngagementsSchemaStore>,
  callback: (error: Error | null, data?: ProjectTrendingEngagementsSchemaStore) => void,
) => {
  findOperations
    .findOne(projectTrendsModel, {
      clientID,
      projectID,
      year: new Date().getFullYear(),
      month: new Date().getMonth() + 1,
    }, {
      __v: 0,
      password: 0,
      clientID: 0,
      year: 0,
      month: 0,
    })
    .then((projectTrends: ProjectTrendingEngagementsSchemaStore) => {
      if (!_.isNil(projectTrends)) {
        callback(null, projectTrends)
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      // logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_PROJECT_DASHBOARD_DATA, { clientID, projectID }, error.message))
      callback(null)
    })
}

export const getClientContactDatabase = (
  clientID: string,
  contactsDatabaseModel: Model<ContactDatabase>,
  callback: (error: Error | null, data?: ContactDatabase[]) => void,
) => {
  RedisHandler.getInstance().get(redisKeys.USER_CONTACT_DATABASES.value(clientID), (error: Error, data: string) => {
    if (_.isNil(error) && !_.isNil(data)) {
      callback(null, JSON.parse(data) as ContactDatabase[])
    } else {
      findOperations
        .find(contactsDatabaseModel, { clientID })
        .then((contactsDatabases: ContactDatabase[]) => {
          if (!_.isNil(contactsDatabases)) {
            RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(clientID), JSON.stringify(contactsDatabases))
            RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
            callback(null, contactsDatabases)
          } else {
            callback(null, [])
          }
        })
        .catch((error: Error) => {
          // logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_CONTACTS_DATABASES, { clientID }, error.message))
          callback(null, [])
        })
    }
  })
}

/* export const getDripCampaignData = (clientID: string, dripCampaignModel: Model<DripCampaign>, callback: (error: Error | null, data?: DripCampaign[]) => void, projectID = null) => {
  const filterObject = {
    clientID,
    projectID
  }

  findOperations
  .find(dripCampaignModel, { filterObject }, { __v: 0, password: 0 })
  .then((dripCampaigns: DripCampaign[]) => {
    if (!_.isNil(dripCampaigns)) {
      callback(null, dripCampaigns)
    } else {
      callback(null, [])
    }
  })
  .catch((error: Error) => {
    callback(null, [])
  })

} */

export const getClientTemplates = (clientID: string, templatesModel: Model<Template>, callback: (error: Error | null, data?: Template[]) => void) => {
  RedisHandler.getInstance().get(redisKeys.USER_TEMPLATES.value(clientID), (error: Error, data: string) => {
    if (_.isNil(error) && !_.isNil(data)) {
      callback(null, JSON.parse(data) as Template[])
    } else {
      findOperations
        .find(templatesModel, { clientID }, { __v: 0, password: 0 })
        .then((templates: Template[]) => {
          if (!_.isNil(templates)) {
            RedisHandler.getInstance().set(redisKeys.USER_TEMPLATES.value(clientID), JSON.stringify(templates))
            RedisHandler.getInstance().expire(redisKeys.USER_TEMPLATES.value(clientID), redisKeys.USER_TEMPLATES.timeout())
            callback(null, templates)
          } else {
            callback(null, [])
          }
        })
        .catch((error: Error) => {
          // logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_TEMPLATES, { clientID }, error.message))
          callback(null, [])
        })
    }
  })
}

export const getClientLinks = (clientID: string, linksModel: Model<Link>, callback: (error: Error | null, data?: Link[]) => void) => {
  RedisHandler.getInstance().get(redisKeys.USER_LINKS.value(clientID), (error: Error, data: string) => {
    if (_.isNil(error) && !_.isNil(data)) {
      callback(null, JSON.parse(data) as Link[])
    } else {
      findOperations
        .find(linksModel, { clientID }, { __v: 0, password: 0 })
        .then((links: Link[]) => {
          if (!_.isNil(links)) {
            RedisHandler.getInstance().set(redisKeys.USER_LINKS.value(clientID), JSON.stringify(links))
            RedisHandler.getInstance().expire(redisKeys.USER_LINKS.value(clientID), redisKeys.USER_LINKS.timeout())
            callback(null, links)
          } else {
            callback(null, [])
          }
        })
        .catch((error: Error) => {
          // logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_TEMPLATES, { clientID }, error.message))
          callback(null, [])
        })
    }
  })
}

export const getProjectInitialDashboardData = () => {
  const projectDashboardObject = {} as ProjectDashboard
  projectDashboardObject.performance = {} as PerformanceStats
  projectDashboardObject.smsCost = 0
  projectDashboardObject.demographics = null
  projectDashboardObject.calendar = []
  projectDashboardObject.stats = {
    engagementTotal: 0,
    engagementSum: 0,
    smsEngagementTotal: 0,
    smsEngagementSum: 0,
    whatsappEngagementTotal: 0,
    whatsappEngagementSum: 0,
    whatsappClicks: 0,
    smsSentCount: 0,
    smsDeliveredCount: 0,
    smsFailedCount: 0,
    linksCount: 0,
    linksClickCount: 0,
    viewsCount: 0,
    whatsappViewsCount: 0,
    smsViewsCount: 0,
    whatsappSentCount: 0,
    negativeCount: 0,
    positiveCount: 0,
    neutralCount: 0,
    whatsappDeliveredCount: 0,
    whatsappFailedCount: 0,
    smsLinksClickCount: 0,
    whatsappLinksClickCount: 0,
  } as Campaign

  projectDashboardObject.graph = []
  projectDashboardObject.campaigns = []
  projectDashboardObject.dripcampaigns = []
  projectDashboardObject.engagements = []
  projectDashboardObject.project = {} as Project
  projectDashboardObject.databaseCluster = []
  constants.MONTHS.forEach((month) => {
    projectDashboardObject.graph.push(({
      month: month.index,
      value: month.long,
      engagementTotal: 0,
      engagementSum: 0,
      smsEngagementTotal: 0,
      smsEngagementSum: 0,
      whatsappEngagementTotal: 0,
      whatsappEngagementSum: 0,
      whatsappClicks: 0,
      smsSentCount: 0,
      smsDeliveredCount: 0,
      smsFailedCount: 0,
      linksCount: 0,
      linksClickCount: 0,
      viewsCount: 0,
      whatsappViewsCount: 0,
      smsViewsCount: 0,
      whatsappSentCount: 0,
      whatsappDeliveredCount: 0,
      whatsappFailedCount: 0,
      smsLinksClickCount: 0,
      whatsappLinksClickCount: 0,
      negativeCount: 0,
      positiveCount: 0,
      neutralCount: 0,
      calls: 0,
      callsThreshold: 0,
      events: 0,
      eventsThreshold: 0,
    } as unknown) as Campaign)
  })
  return projectDashboardObject
}
