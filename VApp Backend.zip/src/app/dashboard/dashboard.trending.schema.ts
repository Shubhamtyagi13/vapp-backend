import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.DASHBOARD_TRENDING_PERSON.collection, autoCreate: false, _id: false })
export class DashboardTrendingPerson extends Document {
  @Prop({ type: String, required: true })
  firstName: string

  @Prop({ type: String, default: null })
  lastName: string

  @Prop({ type: String, default: null })
  middleName: string

  @Prop({ type: String, default: null })
  projectID: string

  @Prop({ type: String, default: null })
  requestID: string

  @Prop({ type: String, default: null })
  projectName: string

  @Prop({ type: Number, required: true })
  phone: number

  @Prop({ type: Number, index: true, default: 0 })
  engagementSum: number
}

const DashboardTrendingPersonSchema = SchemaFactory.createForClass(DashboardTrendingPerson)

@Schema({ collection: tables.DASHBOARD_TRENDING_PROJECT.collection, autoCreate: false, _id: false })
export class DashboardTrendingProject extends Document {
  @Prop({ type: String, default: null })
  projectID: string

  @Prop({ type: String, default: null })
  projectName: string

  @Prop({ type: Number, index: true, default: 0 })
  engagementSum: number

  @Prop({ type: Number, index: true, default: 0 })
  negativeCount: number

  @Prop({ type: Number, index: true, default: 0 })
  neutralCount: number

  @Prop({ type: Number, index: true, default: 0 })
  positiveCount: number
}

const DashboardTrendingProjectSchema = SchemaFactory.createForClass(DashboardTrendingProject)

@Schema({ collection: tables.DASHBOARD_TRENDING_TEMPLATE.collection, autoCreate: false, _id: false })
export class DashboardTrendingTemplate extends Document {
  @Prop({ type: String, default: null })
  templateID: string

  @Prop({ type: String, default: null })
  templateName: string

  @Prop({ type: Number, index: true, default: 0 })
  engagementSum: number

  @Prop({ type: Number, index: true, default: 0 })
  negativeCount: number

  @Prop({ type: Number, index: true, default: 0 })
  neutralCount: number

  @Prop({ type: Number, index: true, default: 0 })
  positiveCount: number
}

const DashboardTrendingTemplateSchema = SchemaFactory.createForClass(DashboardTrendingTemplate)

@Schema({ collection: tables.DASHBOARD_TRENDING_DATABASE.collection, autoCreate: false, _id: false })
export class DashboardTrendingDatabase extends Document {
  @Prop({ type: String, default: null })
  databaseID: string

  @Prop({ type: String, default: null })
  databaseName: string

  @Prop({ type: Number, index: true, default: 0 })
  engagementSum: number

  @Prop({ type: Number, index: true, default: 0 })
  negativeCount: number

  @Prop({ type: Number, index: true, default: 0 })
  neutralCount: number

  @Prop({ type: Number, index: true, default: 0 })
  positiveCount: number
}

const DashboardTrendingDatabaseSchema = SchemaFactory.createForClass(DashboardTrendingDatabase)

@Schema({ collection: tables.DASHBOARD_TRENDING_LINK.collection, autoCreate: false, _id: false })
export class DashboardTrendingLink extends Document {
  @Prop({ type: String, default: null })
  linkID: string

  @Prop({ type: String, default: null })
  linkName: string

  @Prop({ type: String, default: null })
  url: string

  @Prop({ type: Number, index: true, default: 0 })
  engagementSum: number

  @Prop({ type: Number, index: true, default: 0 })
  negativeCount: number

  @Prop({ type: Number, index: true, default: 0 })
  neutralCount: number

  @Prop({ type: Number, index: true, default: 0 })
  positiveCount: number
}

const DashboardTrendingLinkSchema = SchemaFactory.createForClass(DashboardTrendingLink)

@Schema({ collection: tables.DASHBOARD_TRENDS.collection, autoCreate: true, _id: false })
export class DashboardTrendingStore extends Document {
  @Prop({ type: String, required: true })
  clientID: string

  @Prop({ type: Number, required: true })
  year: number

  @Prop({ type: Number, required: true })
  month: number

  @Prop({ type: [DashboardTrendingPersonSchema], default: [] })
  trendingPersons: [DashboardTrendingPerson]

  @Prop({ type: [DashboardTrendingProjectSchema], default: [] })
  trendingProjects: [DashboardTrendingProject]

  @Prop({ type: [DashboardTrendingTemplateSchema], default: [] })
  trendingTemplates: [DashboardTrendingTemplate]

  @Prop({ type: [DashboardTrendingDatabaseSchema], default: [] })
  trendingDatabases: [DashboardTrendingDatabase]

  @Prop({ type: [DashboardTrendingLinkSchema], default: [] })
  trendingLinks: [DashboardTrendingLink]
}

export const DashboardTrendingStoreSchema = SchemaFactory.createForClass(DashboardTrendingStore)
