import { Campaign } from '@app/campaign/campaign.schema'
import { DripCampaign } from '@app/campaign/drip_campaign.schema'
import { ContactDatabase } from '@app/contact/contact.database.schema'
import { Credits } from '@app/credits/credits.schema'
import { Demographics } from '@app/demographics/demographics.schema'
import { Link } from '@app/link/link.schema'
import { Projects } from '@app/projects/projects.schema'
import { ProjectTrendingEngagementsSchemaStore } from '@app/projects/projects.trending.engagement.schema'
import { Template } from '@app/template/template.schema'
import { Tracking } from '@app/tracking/tracking.schema'
import { canonicalMethods, constants } from '@config'
import { CampaignEvent } from '@interfaces/campaign.interface'
import {
  DatabaseCluster, MasterDashboard, PerformanceStats, ProjectDashboard, SpendingTrend,
} from '@interfaces/dashboard.interface'
import { GenericObject } from '@interfaces/generic.interface'
import { Project } from '@interfaces/project.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { HttpStatus, Inject, Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { getAPIResponse, getCampaignSource, getErrorLog } from '@utils/platform.util'
import async from 'async'
import _ from 'lodash'
import { Model } from 'mongoose'
import { Dashboard } from './dashboard.schema'
import { DashboardTrendingStore } from './dashboard.trending.schema'
import {
  getCampaignData, getCampaignEventsData, getDatabaseEventsData, getDripCampaignData,
} from './helpers/common.helper'
import {
  getClientCredits,
  getClientProjectsData,
  getDashboardGraphData,
  getInitialDashboardData,
  getMasterBestPerformingStats,
  getMasterDashboardTrends,
  getAdminDashboardGraphData,
  getInitialAdminDashboardData
} from './helpers/master.helper'
import {
  getClientContactDatabase,
  getClientCreditsCost,
  getClientLinks,
  getClientProjectDashboardTrends,
  getClientProjects,
  getClientTemplates,
  getProjectGraphData,
  getProjectInitialDashboardData,

} from './helpers/project.helper'

@Injectable()
export class DashboardService {
  private traceID: string

  private logger: VappLogger

  private continentMap: GenericObject = {}

  private countryMap: GenericObject = {}

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    @InjectModel(Dashboard.name) private dashboardModel: Model<Dashboard>,
    @InjectModel(Projects.name) private projectsModel: Model<Projects>,
    @InjectModel(Credits.name) private creditsModel: Model<Credits>,
    @InjectModel(Campaign.name) private campaignModel: Model<Campaign>,
    @InjectModel(DripCampaign.name) private dripCampaignModel: Model<DripCampaign>,
    @InjectModel(Link.name) private linkModel: Model<Link>,
    @InjectModel(Tracking.name) private trackingModel: Model<Tracking>,
    @InjectModel(DashboardTrendingStore.name) private dashboardTrendsModel: Model<DashboardTrendingStore>,
    @InjectModel(ContactDatabase.name) private contactDatabaseModel: Model<ContactDatabase>,
    @InjectModel(Template.name) private templateModel: Model<Template>,
    @InjectModel(ProjectTrendingEngagementsSchemaStore.name) private projectTrendingModel: Model<ProjectTrendingEngagementsSchemaStore>,
  ) {
    this.traceID = vapp_context.traceID
    constants.DEMOGRAPHICS.CONTINENTS.forEach((continent) => {
      this.continentMap[`${continent.code}`] = continent.name
    })
    constants.DEMOGRAPHICS.COUNTRIES.forEach((country) => {
      this.countryMap[`${country.alpha3}`] = country.name
    })
  }
  
  adminDashboardData = (clientID: string) => {
    return new Promise<ServiceResponse>((resolve) => {
      const adminDashboardQueries = [
        (callback: (error: Error | null, data?: [Dashboard]) => void) => getAdminDashboardGraphData( this.dashboardModel, callback)
      ]
      async.parallel(adminDashboardQueries, (error: Error | undefined, results: any[]) => {
        let masterDashboardObject = {} as MasterDashboard
        if (_.isNil(error)) {
          if (!_.isNil(results)) {
            masterDashboardObject = getInitialAdminDashboardData()
            // proceed with actual data
            if (!_.isNil(results[0])) {
              const dashboardGraphResults: Dashboard[] = results[0] as Dashboard[]
              // populate graph data
              dashboardGraphResults.forEach((dashboardObject: Dashboard) => {
                masterDashboardObject.graph[dashboardObject.month - 1].smsSentCount += dashboardObject.smsSentCount
                masterDashboardObject.graph[dashboardObject.month - 1].smsDeliveredCount += dashboardObject.smsDeliveredCount
               
                masterDashboardObject.graph[dashboardObject.month - 1].whatsappSentCount += dashboardObject.whatsappSentCount
                masterDashboardObject.graph[dashboardObject.month - 1].whatsappDeliveredCount += dashboardObject.whatsappDeliveredCount
                
              })
             }
            resolve(getAPIResponse(messages.DAS002.code, this.traceID, HttpStatus.OK, masterDashboardObject))
          }
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        } else {
          this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_MASTER_DASHBOARD_DATA, this.traceID, { clientID, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        }
      })
    }
   )
  }   
  
  masterDashboardData = (clientID: string) => new Promise<ServiceResponse>((resolve) => {
    const dashboardQueries = [
      (callback: (error: Error | null, data?: [Dashboard]) => void) => getDashboardGraphData(clientID, this.dashboardModel, callback),
      (callback: (error: Error | null, data?: [Projects]) => void) => getClientProjectsData(clientID, this.projectsModel, callback),
      (callback: (error: Error | null, data?: Credits) => void) => getClientCredits(clientID, this.creditsModel, callback),
      (callback: (error: Error | null, data?: [DashboardTrendingStore]) => void) => getMasterDashboardTrends(clientID, this.dashboardTrendsModel, callback),
      (callback: (error: Error | null, data?: PerformanceStats) => void) => getMasterBestPerformingStats(clientID, this.projectsModel, this.templateModel, this.contactDatabaseModel, this.linkModel, callback),
      (callback: (error: Error | null, data?: [Campaign]) => void) => getCampaignData(clientID, this.campaignModel, callback),
    ]
    async.parallel(dashboardQueries, (error: Error | undefined, results: any[]) => {
      let masterDashboardObject = {} as MasterDashboard
      if (_.isNil(error)) {
        if (!_.isNil(results)) {
          masterDashboardObject = getInitialDashboardData()
          // proceed with actual data
          if (!_.isNil(results[0])) {
            const dashboardGraphResults: Dashboard[] = results[0] as Dashboard[]
            // populate graph data
            dashboardGraphResults.forEach((dashboardObject: Dashboard) => {
              masterDashboardObject.graph[dashboardObject.month - 1].engagementTotal += dashboardObject.engagementTotal
              masterDashboardObject.graph[dashboardObject.month - 1].engagementSum += dashboardObject.engagementSum
              masterDashboardObject.graph[dashboardObject.month - 1].smsEngagementTotal += dashboardObject.smsEngagementTotal
              masterDashboardObject.graph[dashboardObject.month - 1].smsEngagementSum += dashboardObject.smsEngagementSum
              masterDashboardObject.graph[dashboardObject.month - 1].whatsappEngagementTotal += dashboardObject.whatsappEngagementTotal
              masterDashboardObject.graph[dashboardObject.month - 1].whatsappEngagementSum += dashboardObject.whatsappEngagementSum
              masterDashboardObject.graph[dashboardObject.month - 1].whatsappClicks += dashboardObject.whatsappClicks
              masterDashboardObject.graph[dashboardObject.month - 1].smsSentCount += dashboardObject.smsSentCount
              masterDashboardObject.graph[dashboardObject.month - 1].smsDeliveredCount += dashboardObject.smsDeliveredCount
              masterDashboardObject.graph[dashboardObject.month - 1].smsFailedCount += dashboardObject.smsFailedCount
              masterDashboardObject.graph[dashboardObject.month - 1].linksCount += dashboardObject.linksCount
              masterDashboardObject.graph[dashboardObject.month - 1].linksClickCount += dashboardObject.linksClickCount
              masterDashboardObject.graph[dashboardObject.month - 1].viewsCount += dashboardObject.viewsCount
              masterDashboardObject.graph[dashboardObject.month - 1].whatsappSentCount += dashboardObject.whatsappSentCount
              masterDashboardObject.graph[dashboardObject.month - 1].whatsappFailedCount += dashboardObject.whatsappFailedCount
              masterDashboardObject.graph[dashboardObject.month - 1].whatsappDeliveredCount += dashboardObject.whatsappDeliveredCount
              masterDashboardObject.graph[dashboardObject.month - 1].smsLinksClickCount += dashboardObject.smsLinksClickCount
              masterDashboardObject.graph[dashboardObject.month - 1].whatsappLinksClickCount += dashboardObject.whatsappLinksClickCount
              masterDashboardObject.graph[dashboardObject.month - 1].whatsappViewsCount += dashboardObject.whatsappViewsCount
              masterDashboardObject.graph[dashboardObject.month - 1].smsViewsCount += dashboardObject.smsViewsCount
            })
            // populate stats
            masterDashboardObject.stats.engagementTotal = _.sumBy(dashboardGraphResults, 'engagementTotal')
            masterDashboardObject.stats.engagementSum = _.sumBy(dashboardGraphResults, 'engagementSum')
            masterDashboardObject.stats.smsEngagementTotal = _.sumBy(dashboardGraphResults, 'smsEngagementTotal')
            masterDashboardObject.stats.smsEngagementSum = _.sumBy(dashboardGraphResults, 'smsEngagementSum')
            masterDashboardObject.stats.whatsappEngagementTotal = _.sumBy(dashboardGraphResults, 'whatsappEngagementTotal')
            masterDashboardObject.stats.whatsappEngagementSum = _.sumBy(dashboardGraphResults, 'whatsappEngagementSum')
            masterDashboardObject.stats.whatsappClicks = _.sumBy(dashboardGraphResults, 'whatsappClicks')
            masterDashboardObject.stats.smsSentCount = _.sumBy(dashboardGraphResults, 'smsSentCount')
            masterDashboardObject.stats.smsDeliveredCount = _.sumBy(dashboardGraphResults, 'smsDeliveredCount')
            masterDashboardObject.stats.smsFailedCount = _.sumBy(dashboardGraphResults, 'smsFailedCount')
            masterDashboardObject.stats.linksCount = _.sumBy(dashboardGraphResults, 'linksCount')
            masterDashboardObject.stats.linksClickCount = _.sumBy(dashboardGraphResults, 'linksClickCount')
            masterDashboardObject.stats.viewsCount = _.sumBy(dashboardGraphResults, 'viewsCount')
            masterDashboardObject.stats.whatsappViewsCount = _.sumBy(dashboardGraphResults, 'whatsappViewsCount')
            masterDashboardObject.stats.smsViewsCount = _.sumBy(dashboardGraphResults, 'smsViewsCount')
            masterDashboardObject.stats.whatsappSentCount = _.sumBy(dashboardGraphResults, 'whatsappSentCount')
            masterDashboardObject.stats.whatsappFailedCount = _.sumBy(dashboardGraphResults, 'whatsappFailedCount')
            masterDashboardObject.stats.whatsappDeliveredCount = _.sumBy(dashboardGraphResults, 'whatsappDeliveredCount')
            masterDashboardObject.stats.smsLinksClickCount = _.sumBy(dashboardGraphResults, 'smsLinksClickCount')
            masterDashboardObject.stats.whatsappLinksClickCount = _.sumBy(dashboardGraphResults, 'whatsappLinksClickCount')
          }

          if (!_.isNil(results[1])) {
            const projectResults: Projects[] = results[1] as Projects[]
            // populate project count
            masterDashboardObject.projectCount = projectResults.length
            // populate trending project
            masterDashboardObject.trends.spendingTrends = _(projectResults)
              .map(
                (object) => ({
                  projectID: object._id,
                  projectName: object.name,
                  smsSentCount: object.smsSentCount,
                  smsDeliveredCount: object.smsDeliveredCount,
                  smsFailedCount: object.smsFailedCount,
                  whatsappSentCount: object.whatsappSentCount,
                  whatsappDeliveredCount: object.whatsappDeliveredCount,
                  whatsappFailedCount: object.whatsappFailedCount,
                  whatsappLinksClickCount: object.whatsappLinksClickCount,
                  smsLinksClickCount: object.smsLinksClickCount,
                } as SpendingTrend),
              )
              .value()
          }
          // populate client credits
          if (!_.isNil(results[2])) {
            masterDashboardObject.credits = results[2] as Credits
          }
          // populate trending persons
          if (!_.isNil(results[3])) {
            const currentMonth = new Date().getMonth() + 1
            const trendingStoreObjects: [DashboardTrendingStore] = results[3] as [DashboardTrendingStore]
            masterDashboardObject.trends.persons = _(
              _.flatMap(trendingStoreObjects, (trendingStoreObject) => trendingStoreObject.trendingPersons.map((obj) => ({ month: trendingStoreObject.month, ...obj.toObject() } as any))),
            )
              .orderBy(['engagementSum'], ['desc'])

              .filter((trendingStoreObject) => !_.isNil(trendingStoreObject))
              .value()
              .sort((a, b) => (_.eq(a.month, currentMonth) ? -1 : _.eq(b.month, currentMonth) ? 1 : 0))

            // best permforming project at 0 index
            masterDashboardObject.trends.projects = _(
              _.flatMap(trendingStoreObjects, (trendingStoreObject) => trendingStoreObject.trendingProjects.map((obj) => ({ month: trendingStoreObject.month, ...obj.toObject() } as any))),
            )
              .orderBy(['positiveCount'], ['desc'])
              .filter((trendingStoreObject) => !_.isNil(trendingStoreObject))
              .value()
              .sort((a, b) => (_.eq(a.month, currentMonth) ? -1 : _.eq(b.month, currentMonth) ? 1 : 0))
            masterDashboardObject.graph.forEach((dashboardObject: Dashboard) => {
              const monthWiseData = _(
                _.flatMap(trendingStoreObjects.filter((storeObject) => _.eq(storeObject.month, dashboardObject.month)), (trendingStoreObject) => trendingStoreObject.trendingProjects.map((obj) => ({ month: trendingStoreObject.month, ...obj.toObject() } as any))),
              )
                .filter((trendingStoreObject) => !_.isNil(trendingStoreObject))
                .value()
                .sort((a, b) => (_.eq(a.month, currentMonth) ? -1 : _.eq(b.month, currentMonth) ? 1 : 0))
              masterDashboardObject.graph[dashboardObject.month - 1].negativeCount = _(monthWiseData).sumBy('negativeCount')
              masterDashboardObject.graph[dashboardObject.month - 1].positiveCount = _(monthWiseData).sumBy('positiveCount')
              masterDashboardObject.graph[dashboardObject.month - 1].neutralCount = _(monthWiseData).sumBy('neutralCount')
            })
            masterDashboardObject.stats.negativeCount = _(masterDashboardObject.trends.projects).sumBy('negativeCount')
            masterDashboardObject.stats.positiveCount = _(masterDashboardObject.trends.projects).sumBy('positiveCount')
            masterDashboardObject.stats.neutralCount = _(masterDashboardObject.trends.projects).sumBy('neutralCount')
            // best permforming database at 0 index
            masterDashboardObject.trends.databases = _(
              _.flatMap(trendingStoreObjects, (trendingStoreObject) => trendingStoreObject.trendingDatabases.map((obj) => ({ month: trendingStoreObject.month, ...obj.toObject() } as any))),
            )
              .orderBy(['positiveCount'], ['desc'])
              .filter((trendingStoreObject) => !_.isNil(trendingStoreObject))
              .value()
              .sort((a, b) => (_.eq(a.month, currentMonth) ? -1 : _.eq(b.month, currentMonth) ? 1 : 0))
              // best permforming links at 0 index
            masterDashboardObject.trends.links = _(
              _.flatMap(trendingStoreObjects, (trendingStoreObject) => trendingStoreObject.trendingLinks.map((obj) => ({ month: trendingStoreObject.month, ...obj.toObject() } as any))),
            )
              .orderBy(['positiveCount'], ['desc'])
              .filter((trendingStoreObject) => !_.isNil(trendingStoreObject))
              .value()
              .sort((a, b) => (_.eq(a.month, currentMonth) ? -1 : _.eq(b.month, currentMonth) ? 1 : 0))
              // best permforming links at 0 index
            masterDashboardObject.trends.templates = _(
              _.flatMap(trendingStoreObjects, (trendingStoreObject) => trendingStoreObject.trendingTemplates.map((obj) => ({ month: trendingStoreObject.month, ...obj.toObject() } as any))),
            )
              .orderBy(['positiveCount'], ['desc'])
              .filter((trendingStoreObject) => !_.isNil(trendingStoreObject))
              .value()
              .sort((a, b) => (_.eq(a.month, currentMonth) ? -1 : _.eq(b.month, currentMonth) ? 1 : 0))
          }
          if (!_.isNil(results[4])) {
            const performanceStats: PerformanceStats = results[4] as PerformanceStats
            masterDashboardObject.performance = performanceStats
          }
          if (!_.isNil(results[5])) {
            let whatsappClicks = 0
            let smsClicks = 0
            _.each(results[5], (campaign: Campaign) => {
              if (_.eq(campaign.type, constants.CAMPAIGN_TYPES.SMS.value)) {
                smsClicks += campaign.whatsappClicks
              } else if (_.eq(campaign.type, constants.CAMPAIGN_TYPES.WHATSAPP.value)) {
                whatsappClicks += campaign.whatsappClicks
              }
            })
            _.set(masterDashboardObject, 'stats.whatsappClicksSMS', smsClicks)
            _.set(masterDashboardObject, 'stats.whatsappClicksWhatsapp', whatsappClicks)
            masterDashboardObject.calendar = Object.assign([], _(_.groupBy(results[5], 'month'))
              .flatMap((subObjects) => {
                const groupedByDayObject = _.groupBy(subObjects, 'day')
                const usage = []
                _.mapKeys(groupedByDayObject, (value, day) => {
                  const projects = _.map(value, 'projectID')
                  const campaigns = _.map(value, (val: any) => ({
                    projectID: val.projectID,
                    campaignID: val._id,
                    negativeCount: val.negativeCount,
                    positiveCount: val.positiveCount,
                    neutralCount: val.neutralCount,
                    campaignName: val.campaignName,
                  }))
                  usage.push({
                    day: parseInt(day, 10), useCount: value.length, acrossProjectsCount: _.uniq(projects).length, projects, campaigns,
                  })
                })
                return { month: subObjects[0]?.month, year: subObjects[0]?.year, usage }
              })
              .value())
            masterDashboardObject.demographics = this.processDemographics(_.flatMap(results[5], (campaign) => campaign.demographics) as [Demographics])
          }
          resolve(getAPIResponse(messages.DAS002.code, this.traceID, HttpStatus.OK, masterDashboardObject))
        }
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      } else {
        this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_MASTER_DASHBOARD_DATA, this.traceID, { clientID, error }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      }
    })
  })

  projectDashboardData = (clientID: string, projectID: string) => new Promise<ServiceResponse>((resolve) => {
    const dashboardQueries = [
      (callback: (error: Error | null, data?: [Campaign]) => void) => getProjectGraphData(clientID, projectID, this.campaignModel, callback),
      (callback: (error: Error | null, data?: Projects) => void) => getClientProjects(projectID, this.projectsModel, callback),
      (callback: (error: Error | null, data?: Credits) => void) => getClientCreditsCost(clientID, this.creditsModel, callback),
      (callback: (error: Error | null, data?: ProjectTrendingEngagementsSchemaStore) => void) => getClientProjectDashboardTrends(clientID, projectID, this.projectTrendingModel, callback),
      (callback: (error: Error | null, data?: ContactDatabase[]) => void) => getClientContactDatabase(clientID, this.contactDatabaseModel, callback),
      (callback: (error: Error | null, data?: Template[]) => void) => getClientTemplates(clientID, this.templateModel, callback),
      (callback: (error: Error | null, data?: Link[]) => void) => getClientLinks(clientID, this.linkModel, callback),
      (callback: (error: Error | null, data?: [Campaign]) => void) => getCampaignData(clientID, this.campaignModel, callback, projectID),
      (callback: (error: Error | null, data?: [CampaignEvent]) => void) => getCampaignEventsData(clientID, this.trackingModel, callback, projectID),
      (callback: (error: Error | null, data?: [CampaignEvent]) => void) => getDatabaseEventsData(clientID, this.trackingModel, callback, projectID),
      (callback: (error: Error | null, data?: [DripCampaign]) => void) => getDripCampaignData(clientID, this.dripCampaignModel, callback, projectID),
    ]
    async.parallel(dashboardQueries, async (error: Error | undefined, results: any[]) => {
      let projectDashboardObject = {} as ProjectDashboard
      if (_.isNil(error)) {
        if (!_.isNil(results)) {
          projectDashboardObject = getProjectInitialDashboardData()
          // proceed with actual data
          if (!_.isNil(results[0])) {
            const projectCampaignResults: Campaign[] = results[0] as Campaign[]

            const projectDripCampaignResults: DripCampaign[] = results[10] as DripCampaign[]
            // populate campaigns
            projectDashboardObject.campaigns = projectCampaignResults
            projectDashboardObject.dripcampaigns = projectDripCampaignResults
            // populate graph data
            projectCampaignResults.forEach((campaignObject: Campaign) => {
              projectDashboardObject.graph[campaignObject.month - 1].engagementTotal += campaignObject.engagementTotal
              projectDashboardObject.graph[campaignObject.month - 1].engagementSum += campaignObject.engagementSum
              projectDashboardObject.graph[campaignObject.month - 1].smsEngagementTotal += campaignObject.smsEngagementTotal
              projectDashboardObject.graph[campaignObject.month - 1].smsEngagementSum += campaignObject.smsEngagementSum
              projectDashboardObject.graph[campaignObject.month - 1].whatsappEngagementTotal += campaignObject.whatsappEngagementTotal
              projectDashboardObject.graph[campaignObject.month - 1].whatsappEngagementSum += campaignObject.whatsappEngagementSum
              projectDashboardObject.graph[campaignObject.month - 1].whatsappClicks += campaignObject.whatsappClicks
              projectDashboardObject.graph[campaignObject.month - 1].smsSentCount += campaignObject.smsSentCount
              projectDashboardObject.graph[campaignObject.month - 1].smsDeliveredCount += campaignObject.smsDeliveredCount
              projectDashboardObject.graph[campaignObject.month - 1].smsFailedCount += campaignObject.smsFailedCount
              projectDashboardObject.graph[campaignObject.month - 1].linksCount += campaignObject.linksCount
              projectDashboardObject.graph[campaignObject.month - 1].linksClickCount += campaignObject.linksClickCount
              projectDashboardObject.graph[campaignObject.month - 1].whatsappSentCount += campaignObject.whatsappSentCount
              projectDashboardObject.graph[campaignObject.month - 1].smsLinksClickCount += campaignObject.smsLinksClickCount
              projectDashboardObject.graph[campaignObject.month - 1].whatsappLinksClickCount += campaignObject.whatsappLinksClickCount
              projectDashboardObject.graph[campaignObject.month - 1].whatsappFailedCount += campaignObject.whatsappFailedCount
              projectDashboardObject.graph[campaignObject.month - 1].whatsappDeliveredCount += campaignObject.whatsappDeliveredCount
              projectDashboardObject.graph[campaignObject.month - 1].viewsCount += campaignObject.viewsCount
              projectDashboardObject.graph[campaignObject.month - 1].whatsappViewsCount += campaignObject.whatsappViewsCount
              projectDashboardObject.graph[campaignObject.month - 1].smsViewsCount += campaignObject.smsViewsCount
              projectDashboardObject.graph[campaignObject.month - 1].negativeCount += campaignObject.negativeCount
              projectDashboardObject.graph[campaignObject.month - 1].positiveCount += campaignObject.positiveCount
              projectDashboardObject.graph[campaignObject.month - 1].neutralCount += campaignObject.neutralCount
              projectDashboardObject.graph[campaignObject.month - 1].calls += campaignObject.calls || 0
              projectDashboardObject.graph[campaignObject.month - 1].callsThreshold += campaignObject.callsThreshold || 0
            })
            // populate stats
            projectDashboardObject.stats.engagementTotal = _.sumBy(projectCampaignResults, 'engagementTotal')
            projectDashboardObject.stats.engagementSum = _.sumBy(projectCampaignResults, 'engagementSum')
            projectDashboardObject.stats.smsEngagementTotal = _.sumBy(projectCampaignResults, 'smsEngagementTotal')
            projectDashboardObject.stats.smsEngagementSum = _.sumBy(projectCampaignResults, 'smsEngagementSum')
            projectDashboardObject.stats.whatsappEngagementTotal = _.sumBy(projectCampaignResults, 'whatsappEngagementTotal')
            projectDashboardObject.stats.whatsappEngagementSum = _.sumBy(projectCampaignResults, 'whatsappEngagementSum')
            projectDashboardObject.stats.whatsappClicks = _.sumBy(projectCampaignResults, 'whatsappClicks')
            projectDashboardObject.stats.smsSentCount = _.sumBy(projectCampaignResults, 'smsSentCount') + _.sumBy(projectDripCampaignResults, 'smsSentCount')
            projectDashboardObject.stats.smsDeliveredCount = _.sumBy(projectCampaignResults, 'smsDeliveredCount') + _.sumBy(projectDripCampaignResults, 'smsDeliveredCount')
            projectDashboardObject.stats.smsFailedCount = _.sumBy(projectCampaignResults, 'smsFailedCount')
            projectDashboardObject.stats.linksCount = _.sumBy(projectCampaignResults, 'linksCount')
            projectDashboardObject.stats.linksClickCount = _.sumBy(projectCampaignResults, 'linksClickCount')
            projectDashboardObject.stats.viewsCount = _.sumBy(projectCampaignResults, 'viewsCount')
            projectDashboardObject.stats.whatsappViewsCount = _.sumBy(projectCampaignResults, 'whatsappViewsCount')
            projectDashboardObject.stats.smsViewsCount = _.sumBy(projectCampaignResults, 'smsViewsCount')
            projectDashboardObject.stats.whatsappSentCount = _.sumBy(projectCampaignResults, 'whatsappSentCount')
            projectDashboardObject.stats.smsLinksClickCount = _.sumBy(projectCampaignResults, 'smsLinksClickCount')
            projectDashboardObject.stats.whatsappLinksClickCount = _.sumBy(projectCampaignResults, 'whatsappLinksClickCount')
            projectDashboardObject.stats.whatsappFailedCount = _.sumBy(projectCampaignResults, 'whatsappFailedCount')
            projectDashboardObject.stats.whatsappDeliveredCount = _.sumBy(projectCampaignResults, 'whatsappDeliveredCount')
          }

          if (!_.isNil(results[1])) {
            const projectResult: Project = results[1] as Project
            projectDashboardObject.stats.negativeCount = projectResult.negativeCount
            projectDashboardObject.stats.positiveCount = projectResult.positiveCount
            projectDashboardObject.stats.neutralCount = projectResult.neutralCount
            // best permforming database at 0 index
            // populate project

            projectDashboardObject.project = projectResult
          }
          // populate sms cost
          if (!_.isNil(results[2])) {
            if (!_.isNil(results[2].smsCost)) {
              projectDashboardObject.smsCost = Number((results[2] as Credits).smsCost)
            }
            if (!_.isNil(results[2].whatsappCost)) {
              projectDashboardObject.whatsappCost = Number((results[2] as Credits).whatsappCost)
            }
          }
          // populate trending engagements
          if (!_.isNil(results[3])) {
            const trendingEngagementsObject: ProjectTrendingEngagementsSchemaStore = results[3] as ProjectTrendingEngagementsSchemaStore
            if (!_.isNil(trendingEngagementsObject.trendingEngagements)) {
              projectDashboardObject.engagements = trendingEngagementsObject.trendingEngagements
            }
          }
          let clientDatabases: ContactDatabase[] = []
          let clientTemplates: Template[] = [] as Template[]
          let clientLinks: Link[] = [] as Link[]
          let clientDripCampaign: DripCampaign[] = [] as DripCampaign[]

          // add client databases
          if (!_.isNil(results[4])) {
            clientDatabases = results[4] as ContactDatabase[]
            clientDatabases.forEach((database) => {
              const eventsDatabaseObject: CampaignEvent = ((results[9] || []) as [CampaignEvent]).find((e) => _.eq(database._id, e.databaseID))
              const filteredCampaigns = projectDashboardObject.campaigns.filter((e) => _.eq(database._id, e.databaseID))
              projectDashboardObject.databaseCluster.push({
                databaseID: database._id,
                databaseName: database.name,
                clicks: _.sumBy(filteredCampaigns, 'linksClickCount'),
                calls: _.sumBy(filteredCampaigns, 'calls'),
                callsThreshold: _.sumBy(filteredCampaigns, 'callsThreshold'),
                events: !_.isNil(eventsDatabaseObject) ? eventsDatabaseObject.events : 0,
                eventsThreshold: !_.isNil(eventsDatabaseObject) ? eventsDatabaseObject.eventsThreshold : 0,
                avgClicks: _.sumBy(filteredCampaigns, 'linksClickCount') / filteredCampaigns.length || 0,
                avgCalls: _.sumBy(filteredCampaigns, 'calls') / filteredCampaigns.length || 0,
                avgCallsThreshold: _.sumBy(filteredCampaigns, 'callsThreshold') / filteredCampaigns.length || 0,
                avgEvents: (!_.isNil(eventsDatabaseObject) ? eventsDatabaseObject.events : 0) / filteredCampaigns.length || 0,
                avgEventsThreshold: (!_.isNil(eventsDatabaseObject) ? eventsDatabaseObject.eventsThreshold : 0) / filteredCampaigns.length || 0,
              } as DatabaseCluster)
            })
          }

          // add client dripcampaign
          if (!_.isNil(results[10])) {
            clientDripCampaign = results[10] as DripCampaign[]
          }
          // add client templates
          if (!_.isNil(results[5])) {
            clientTemplates = results[5] as Template[]
          }
          // add client links
          if (!_.isNil(results[6])) {
            clientLinks = results[6] as Link[]
          }
          if (!_.isNil(results[7])) {
            let whatsappClicks = 0
            let smsClicks = 0
            _.each(results[7], (campaign: Campaign) => {
              if (_.eq(campaign.type, constants.CAMPAIGN_TYPES.SMS.value)) {
                smsClicks += campaign.whatsappClicks
              } else if (_.eq(campaign.type, constants.CAMPAIGN_TYPES.WHATSAPP.value)) {
                whatsappClicks += campaign.whatsappClicks
              }
            })
            _.set(projectDashboardObject, 'stats.whatsappClicksSMS', smsClicks)
            _.set(projectDashboardObject, 'stats.whatsappClicksWhatsapp', whatsappClicks)
            projectDashboardObject.calendar = Object.assign([], _(_.groupBy(results[7], 'month'))
              .flatMap((subObjects) => {
                const groupedByDayObject = _.groupBy(subObjects, 'day')
                const usage = []
                _.mapKeys(groupedByDayObject, (value, day) => {
                  const projects = _.map(value, 'projectID')
                  const campaigns = _.map(value, (val: any) => ({
                    projectID: val.projectID,
                    campaignID: val._id,
                    negativeCount: val.negativeCount,
                    positiveCount: val.positiveCount,
                    neutralCount: val.neutralCount,
                    campaignName: val.campaignName,
                  }))
                  usage.push({
                    day: parseInt(day, 10), useCount: value.length, acrossProjectsCount: _.uniq(projects).length, projects, campaigns,
                  })
                })
                return { month: subObjects[0]?.month, year: subObjects[0]?.year, usage }
              })
              .value())
            projectDashboardObject.demographics = this.processDemographics(_.flatMap(results[7], (campaign) => campaign.demographics) as [Demographics])
          }
          const foundTemplateIDs = []
          const foundDatabaseIDs = []
          const foundLinkIDs = []
          projectDashboardObject.campaigns.forEach((campaign: Campaign, index: number) => {
            projectDashboardObject.campaigns[index] = projectDashboardObject.campaigns[index].toObject() as any
            if (!_.isNil(campaign.databaseID)) {
              foundDatabaseIDs.push(campaign.databaseID)
              _.set(projectDashboardObject.campaigns[index], 'databaseName', clientDatabases.find((database) => _.eq(database._id, campaign.databaseID))?.name)
            } else {
              _.set(projectDashboardObject.campaigns[index], 'databaseName', 'N/A')
            }
            if (!_.isNil(campaign.demographics) && !_.isEmpty(campaign.demographics)) {
              delete projectDashboardObject.campaigns[index].demographics
              projectDashboardObject.campaigns[index].demographics = _.assign(projectDashboardObject.campaigns[index].demographics, this.processDemographics(campaign.demographics))
            } else {
              projectDashboardObject.campaigns[index].demographics = null
            }

            if (!_.isNil(campaign.campaignID)) {
              _.set(projectDashboardObject.campaigns[index], 'DripCampaignName', clientDripCampaign.find((dripCampaign) => _.eq(dripCampaign.campaignID, campaign.campaignID))?.dripCampaignName)
            } else {
              _.set(projectDashboardObject.campaigns[index], 'DripCampaignName', 'N/A')
            }

            if (!_.isNil(campaign.templateID)) {
              foundTemplateIDs.push(campaign.templateID)
              _.set(projectDashboardObject.campaigns[index], 'templateName', clientTemplates.find((template) => _.eq(template._id, campaign.templateID))?.name)
            } else {
              _.set(projectDashboardObject.campaigns[index], 'templateName', 'N/A')
            }
            if (_.isNil(campaign.campaignName)) {
              _.set(projectDashboardObject.campaigns[index], 'campaignName', 'N/A')
            }
            if (_.isNil(campaign.leadNegative)) {
              _.set(projectDashboardObject.campaigns[index], 'leadNegative', 0)
            }
            if (_.isNil(campaign.ivrFinalized)) {
              _.set(projectDashboardObject.campaigns[index], 'ivrFinalized', false)
            }
            if (_.isNil(campaign.leadPositive)) {
              _.set(projectDashboardObject.campaigns[index], 'leadPositive', 0)
            }
            if (_.isNil(campaign.leadNeutral)) {
              _.set(projectDashboardObject.campaigns[index], 'leadNeutral', 0)
            }
            if (_.isNil(campaign.callsThreshold)) {
              _.set(projectDashboardObject.campaigns[index], 'callsThreshold', 0)
            }
            if (_.isNil(campaign.ivrFinalized)) {
              _.set(projectDashboardObject.campaigns[index], 'ivrFinalized', false)
            }
            if (_.isNil(campaign.calls)) {
              _.set(projectDashboardObject.campaigns[index], 'calls', 0)
            }
            const eventsObject: CampaignEvent = ((results[8] || []) as [CampaignEvent]).find((e) => _.eq(campaign.id, e.campaignID))
            if (!_.isNil(eventsObject)) {
              _.set(projectDashboardObject.campaigns[index], 'eventsThreshold', eventsObject.eventsThreshold)
              _.set(projectDashboardObject.campaigns[index], 'events', eventsObject.events)
            } else {
              _.set(projectDashboardObject.campaigns[index], 'eventsThreshold', 0)
              _.set(projectDashboardObject.campaigns[index], 'events', 0)
            }
            if (!_.isNil(campaign.linkID)) {
              foundLinkIDs.push(campaign.linkID)
              _.set(projectDashboardObject.campaigns[index], 'linkName', clientLinks.find((link) => _.eq(link._id, campaign.linkID))?.name)
            } else {
              _.set(projectDashboardObject.campaigns[index], 'linkName', 'N/A')
            }
            _.set(projectDashboardObject.campaigns[index], 'source', getCampaignSource(campaign.type))
          })
          try {
            _(
              _.groupBy(_.map(projectDashboardObject.campaigns, (e) => {
                const { month, events, eventsThreshold } = e as any
                return { month, events, eventsThreshold }
              }), 'month'),
            )
              .mapValues((e) => ({
                events: _.sumBy(e, 'events'),
                eventsThreshold: _.sumBy(e, 'eventsThreshold'),
                month: e[0].month,
              }))
              .flatMap()
              .value()
              .map((e) => {
                _.set(projectDashboardObject.graph[e.month - 1], 'events', e.events)
                _.set(projectDashboardObject.graph[e.month - 1], 'eventsThreshold', e.eventsThreshold)
              })
          } catch (e) {}

          /* DripCampaign Start */
          projectDashboardObject.dripcampaigns.forEach((dripcampaigns: DripCampaign, index: number) => {
            projectDashboardObject.dripcampaigns[index] = projectDashboardObject.dripcampaigns[index].toObject() as any
            if (!_.isNil(dripcampaigns.databaseID)) {
              foundDatabaseIDs.push(dripcampaigns.databaseID)
              _.set(projectDashboardObject.dripcampaigns[index], 'databaseName', clientDatabases.find((database) => _.eq(database._id, dripcampaigns.databaseID))?.name)
            } else {
              _.set(projectDashboardObject.dripcampaigns[index], 'databaseName', 'N/A')
            }
            if (!_.isNil(dripcampaigns.clientID)) {
              _.set(projectDashboardObject.dripcampaigns[index], 'dripCampaignName', clientDripCampaign.find((dripCampaign) => _.eq(dripcampaigns.campaignID, dripCampaign.campaignID))?.dripCampaignName)
            } else {
              _.set(projectDashboardObject.dripcampaigns[index], 'dripCampaignName', 'Drip Sathish')
            }

            if (!_.isNil(dripcampaigns.dripTemplateID)) {
              foundTemplateIDs.push(dripcampaigns.dripTemplateID)
              _.set(projectDashboardObject.dripcampaigns[index], 'templateName', clientTemplates.find((template) => _.eq(template._id, dripcampaigns.dripTemplateID))?.name)
            } else {
              _.set(projectDashboardObject.dripcampaigns[index], 'templateName', 'N/A')
            }
            _.set(projectDashboardObject.dripcampaigns[index], 'campaignID', dripcampaigns.campaignID)
            _.set(projectDashboardObject.dripcampaigns[index], 'dripTemplateID', dripcampaigns.dripTemplateID)
            _.set(projectDashboardObject.dripcampaigns[index], 'brochure', '')
            _.set(projectDashboardObject.dripcampaigns[index], 'cloud', '')
            _.set(projectDashboardObject.dripcampaigns[index], 'linkID', 'Link Id')
            _.set(projectDashboardObject.dripcampaigns[index], 'redirection', false)
            _.set(projectDashboardObject.dripcampaigns[index], 'tracking', false)
            _.set(projectDashboardObject.dripcampaigns[index], 'type', false)
            _.set(projectDashboardObject.dripcampaigns[index], 'url', 'null')
            _.set(projectDashboardObject.dripcampaigns[index], 'leadNegative', 'N/A')
            _.set(projectDashboardObject.dripcampaigns[index], 'ivrFinalized', false)
            /* Is Drip campaign */
            _.set(projectDashboardObject.dripcampaigns[index], 'isDripCampaign', true)
            _.set(projectDashboardObject.dripcampaigns[index], 'leadPositive', 'N/A')
            _.set(projectDashboardObject.dripcampaigns[index], 'leadNeutral', 'N/A')
            _.set(projectDashboardObject.dripcampaigns[index], 'callsThreshold', 'N/A')
            _.set(projectDashboardObject.dripcampaigns[index], 'ivrFinalized', 'N/A')
            _.set(projectDashboardObject.dripcampaigns[index], 'calls', 'N/A')
            _.set(projectDashboardObject.dripcampaigns[index], 'eventsThreshold', 'N/A')
            _.set(projectDashboardObject.dripcampaigns[index], 'events', 'N/A')
            _.set(projectDashboardObject.dripcampaigns[index], 'linkName', 'Test')
            _.set(projectDashboardObject.dripcampaigns[index], 'source', getCampaignSource(dripcampaigns.type))
            delete projectDashboardObject.dripcampaigns[index].dripCriteriaID
            delete projectDashboardObject.dripcampaigns[index].dripTemplateID
            delete projectDashboardObject.dripcampaigns[index].projectID
            delete projectDashboardObject.dripcampaigns[index].whatsappButton
            delete projectDashboardObject.dripcampaigns[index].year
            delete projectDashboardObject.dripcampaigns[index].chatbotButton
            delete projectDashboardObject.dripcampaigns[index].day
            delete projectDashboardObject.dripcampaigns[index].clientID
          })
          try {
            _(
              _.groupBy(_.map(projectDashboardObject.campaigns, (e) => {
                const { month, events, eventsThreshold } = e as any
                return { month, events, eventsThreshold }
              }), 'month'),
            )
              .mapValues((e) => ({
                events: _.sumBy(e, 'events'),
                eventsThreshold: _.sumBy(e, 'eventsThreshold'),
                month: e[0].month,
              }))
              .flatMap()
              .value()
              .map((e) => {
                _.set(projectDashboardObject.graph[e.month - 1], 'events', e.events)
                _.set(projectDashboardObject.graph[e.month - 1], 'eventsThreshold', e.eventsThreshold)
              })
          } catch (e) {}

          await getMasterBestPerformingStats(clientID, this.projectsModel, this.templateModel, this.contactDatabaseModel, this.linkModel, (error, data: PerformanceStats) => {
            if (!_.isNil(data)) {
              projectDashboardObject.performance = data
            }
          }, {
            projectID,
            linkIDs: _.uniq(foundLinkIDs) as [string],
            databaseIDs: _.uniq(foundDatabaseIDs) as [string],
            templateIDs: _.uniq(foundTemplateIDs) as [string],
          })
          resolve(getAPIResponse(messages.DAS003.code, this.traceID, HttpStatus.OK, projectDashboardObject))
        }
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      } else {
        this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_PROJECT_DASHBOARD_DATA, this.traceID, { clientID, projectID, error }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      }
    })
  })

  processDemographics = (demographics: [Demographics]) => {
    const countinentGroupBy = _(_.groupBy(demographics, 'continent_code'))
      .map((subObjects) => subObjects)
      .value()
      .map((coordinatesArray) => ({
        coordinate: {
          latitude: _.sumBy(coordinatesArray, 'latitude') / _.size(coordinatesArray),
          longitude: _.sumBy(coordinatesArray, 'longitude') / _.size(coordinatesArray),
        },
        metadata: coordinatesArray[0].continent_code,
        name: this.continentMap[`${coordinatesArray[0].continent_code}`],
        value: coordinatesArray.length,
      }))
    const countryGroupBy = _(_.groupBy(demographics, 'country_code'))
      .map((subObjects) => subObjects)
      .value()
      .map((coordinatesArray) => ({
        coordinate: {
          latitude: _.sumBy(coordinatesArray, 'latitude') / _.size(coordinatesArray),
          longitude: _.sumBy(coordinatesArray, 'longitude') / _.size(coordinatesArray),
        },
        metadata: coordinatesArray[0].country_code,
        name: this.countryMap[`${coordinatesArray[0].country_code}`],
        value: coordinatesArray.length,
      }))

    const regionGroupBy = _(_.groupBy(demographics, 'country_code'))
      .flatMap((subObjects) => _(_.groupBy(subObjects, 'region_code'))
        .map((coordinatesArray) => coordinatesArray)
        .value())
      .value()
      .map((subRegionGroupedCoordinates) => ({
        coordinate: {
          latitude: _.sumBy(subRegionGroupedCoordinates, 'latitude') / _.size(subRegionGroupedCoordinates),
          longitude: _.sumBy(subRegionGroupedCoordinates, 'longitude') / _.size(subRegionGroupedCoordinates),
        },
        metadata: subRegionGroupedCoordinates[0].region_code,
        name: subRegionGroupedCoordinates[0].region,
        value: subRegionGroupedCoordinates.length,
      }))

    const cityGroupBy = _(_.groupBy(demographics, 'country_code'))
      .flatMap((subObjects) => _(_.groupBy(subObjects, 'region_code'))
        .map((coordinatesArray) => coordinatesArray)
        .value())
      .flatMap((subObjects) => _(_.groupBy(subObjects, 'city'))
        .map((coordinatesArray) => coordinatesArray)
        .value())
      .value()
      .map((subCityGroupedCoordinates) => ({
        coordinate: {
          latitude: _.sumBy(subCityGroupedCoordinates, 'latitude') / _.size(subCityGroupedCoordinates),
          longitude: _.sumBy(subCityGroupedCoordinates, 'longitude') / _.size(subCityGroupedCoordinates),
        },
        name: subCityGroupedCoordinates[0].city,
        value: subCityGroupedCoordinates.length,
      }))
    return {
      continent: { label: 'Continents', data: countinentGroupBy },
      country: { label: 'Countries', data: countryGroupBy },
      state: { label: 'States', data: regionGroupBy },
      city: { label: 'Cities', data: cityGroupBy },
    }
  }
}
