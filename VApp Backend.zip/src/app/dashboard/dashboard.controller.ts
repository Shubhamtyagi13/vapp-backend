import { audience, environments, variables } from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { APIResponse } from '@interfaces/response.interface'
import {
  Controller, Get, Param, Req, Res, UseGuards,
} from '@nestjs/common'
import { ApiBearerAuth, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import { DashboardService } from './dashboard.service'

@ApiTags(DashboardController.name)
@ApiBearerAuth('Authorization Bearer Token')
@UseGuards(AuthenticationGuard)
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
@Controller('dashboard')
export class DashboardController {
  constructor(private dashboardService: DashboardService) {}

  @Audience([audience.CLIENT, audience.ADMIN])
  @Get(['/master'])
  upload(@Res() response: Response<APIResponse>, @Req() request: Request) {
    this.dashboardService.masterDashboardData(request.user._id).then((service_response) => response.status(service_response.status).send(service_response))
  }
  
  @Audience([audience.CLIENT, audience.ADMIN])
  @Get(['/admin'])
  adminUpload(@Res() response: Response<APIResponse>, @Req() request: Request) {
    this.dashboardService.adminDashboardData(request.user._id).then((service_response) => {
      return response.status(service_response.status).send(service_response)
    })
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @Get(['/project/:projectID'])
  fetchDatabases(@Res() response: Response<APIResponse>, @Req() request: Request, @Param('projectID') projectID: string) {
    this.dashboardService.projectDashboardData(request.user._id, projectID).then((service_response) => response.status(service_response.status).send(service_response))
  }
}
