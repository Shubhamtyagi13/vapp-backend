import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.DASHBOARD.collection, autoCreate: true })
export class Dashboard extends Document {
  @Prop({ type: String, index: true, required: true })
  clientID: string

  @Prop({ type: Number, index: true, required: true })
  year: number

  @Prop({ type: Number, index: true, required: true })
  month: number

  @Prop({ type: String })
  value: string

  @Prop({ type: Number, index: true, default: 0 })
  engagementTotal: number

  @Prop({ type: Number, index: true, default: 0 })
  engagementSum: number

  @Prop({ type: Number, index: true, default: 0 })
  smsEngagementTotal: number

  @Prop({ type: Number, index: true, default: 0 })
  smsEngagementSum: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappClicks: number

  @Prop({ type: Number, index: true, default: 0 })
  smsSentCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsDeliveredCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsFailedCount: number

  @Prop({ type: Number, index: true, default: 0 })
  linksCount: number

  @Prop({ type: Number, index: true, default: 0 })
  linksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappLinksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsLinksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
  viewsCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappViewsCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsViewsCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappEngagementTotal: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappEngagementSum: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappSentCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappFailedCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappDeliveredCount: number
}
export const DashboardSchema = SchemaFactory.createForClass(Dashboard)
