import { CampaignModule } from '@app/campaign/campaign.module'
import { ContactModule } from '@app/contact/contact.module'
import { CreditsModule } from '@app/credits/credits.module'
import { ProjectsModule } from '@app/projects/projects.module'
import { TemplateModule } from '@app/template/template.module'
import { Tracking, TrackingSchema } from '@app/tracking/tracking.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { DashboardController } from './dashboard.controller'
import { Dashboard, DashboardSchema } from './dashboard.schema'
import { DashboardService } from './dashboard.service'
import { DashboardTrendingStore, DashboardTrendingStoreSchema } from './dashboard.trending.schema'

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: Dashboard.name, schema: DashboardSchema },
      { name: Tracking.name, schema: TrackingSchema },
      { name: DashboardTrendingStore.name, schema: DashboardTrendingStoreSchema }
    ]),
    ProjectsModule,
    CreditsModule,
    ContactModule,
    TemplateModule,
    CampaignModule
  ],
  controllers: [DashboardController],
  providers: [DashboardService]
})
export class DashboardModule {}
