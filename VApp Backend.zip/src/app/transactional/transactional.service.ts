import { User } from '@app/user/user.schema'
import {
  canonicalMethods, constants, transactional_aggregation, redisKeys, variables, cronJobs, cache_client, redis_client, report_types,
} from '@config'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { HttpStatus, Inject, Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import {
  createCSV, deleteFolderRecursive, getAPIResponse, getCreditsFromMessage, getEnvironmentVariable, getErrorLog, getRequestMessage,
} from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import { Credits } from '@app/credits/credits.schema'
import _ from 'lodash'
import { zip } from 'zip-a-folder'
import randomize from 'randomatic'
import { Model } from 'mongoose'
import { TransactionalDailyStatsObject, TransactionalDashboard, TransactionalMetricObject } from '@interfaces/transactional.interface'

import async from 'async'

import { Template } from '@app/template/template.schema'
import { InjectQueue } from '@nestjs/bull'
import { Queue } from 'bull'
import { Reports } from '@app/reports/reports.schema'
import { S3Handler } from '@utils/s3.util'
import { ReportRequest } from '@interfaces/reports.interface'
import { CampaignCronPayload } from '@interfaces/sms-campaign.interface'
import { campaignProviderObject } from '@interfaces/sms.interface'
import uniqid from 'uniqid'
import { TransactionOptions } from 'mongodb'
import path from 'path'
import fs from 'fs'
import { ProcessSMPPDTO } from '@app/campaign/dto/smpp-campaign'
import { HTTPService } from '@services/http.service'
import { TransactionalReportDTO } from './dto/transactional-report.dto'
import { getTransactionalCalendarData, getTransactionalData, getReportData } from './helpers/trasactional.helper'
import { Transactional } from './transactional.schema'
import { RequestTransactionalDTO } from './dto/request-transactional.dto'

@Injectable()
export class TransactionalService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    private logger: VappLogger,
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(Transactional.name) private transactionalModel: Model<Transactional>,
    @InjectModel(Reports.name) private reportsModel: Model<Reports>,
    @InjectModel(Template.name) private templateModel: Model<Template>,
    @InjectModel(Credits.name) private creditsModel: Model<Credits>,
    @InjectQueue(cronJobs.CREATE_REPORT.name) private reportQueue: Queue,
  ) {
    this.traceID = this.vapp_context.traceID
  }

  requestTransactional = (payload: RequestTransactionalDTO): Promise<ServiceResponse> => new Promise<ServiceResponse>((resolve) => {
    const {
      apiKey, phone, var1, var2, var3, var4, clientName, firstName, middleName, templateID, lastName,
    } = payload // first name and validity ??
    RedisHandler.getInstance().get(redisKeys.USER_API_KEY.value(apiKey), async (error: Error, data: string) => {
      let user: User
      if (_.isNil(data)) {
        user = await findOperations.findOne(this.userModel, { apiKey })
        if (!_.isNil(user)) {
          RedisHandler.getInstance().set(redisKeys.USER_API_KEY.value(apiKey), JSON.stringify(user))
          RedisHandler.getInstance().expire(redisKeys.USER_API_KEY.value(apiKey), redisKeys.USER_API_KEY.timeout())
        } else {
          return resolve(getAPIResponse(messages.TRANS003.code, this.traceID, HttpStatus.FORBIDDEN))
        }
      } else {
        user = JSON.parse(data)
      }
      if (_.includes(user?.access, constants.FEATURES_ACCESS.TRANSACTIONAL.NAME)) {
        const template: Template = await findOperations.findOne(this.templateModel, { _id: templateID })
        if (_.isNil(template)) {
          return resolve(getAPIResponse(messages.TRANS009.code, this.traceID, HttpStatus.FORBIDDEN))
        }
        if (!_.isNil(template.senderIDList) && !_.isEmpty(template.senderIDList)) {
          if (!_.isEqual(template.type, constants.TEMPLATE_TYPE.transactional)) {
            return resolve(getAPIResponse(messages.TRANS010.code, this.traceID, HttpStatus.FORBIDDEN))
          }
          if (_.isNil(template.templateID) || _.isEmpty(template.templateID)) {
            return resolve(getAPIResponse(messages.TRANS011.code, this.traceID, HttpStatus.FORBIDDEN))
          }
          const smsTemplateID = template.templateID
          const shortID = `${randomize('Aa0', 4)}${uniqid.time()}`
          const transactional_request = new this.transactionalModel(<Transactional>{
            clientID: user._id,
            date: new Date(),
            templateID,
            shortID,
            phone,
          })

          let totalCredits = 0
          const smsSenderID = template.senderIDList[_.random(0, template.senderIDList.length - 1)]
          const { peID } = user
          let route = -1
          if (!_.isNaN(user.route)) {
            route = user.route
          }
          const smsProviderPayload: campaignProviderObject[] = []
          const payload = <CampaignCronPayload>{
            dynamic: true,
            message: template.text,
            firstName,
            middleName,
            lastName,
            var1,
            var2,
            var3,
            var4,
            clientName: !_.isNil(clientName) ? clientName : user.companyName,
            clientID: user._id,
          }
          const compiledMessage: string = getRequestMessage(payload, null, false, true)
          transactional_request.credits = getCreditsFromMessage(compiledMessage)
          const credits: Credits = await findOperations.findOne(this.creditsModel, { clientID: payload.clientID }, {})
          if (!_.isNil(credits)) {
            if (credits.credits > 0 && credits.credits - totalCredits > 0) {
              totalCredits += transactional_request.credits
              smsProviderPayload.push({
                phone: parseInt(String(Math.abs(Number(phone))), 10),
                message: compiledMessage,
              })
              const response = await HTTPService.getInstance().post(`${getEnvironmentVariable(variables.SMPP_SERVICE_BASE_URL.name)}campaign/common`, <ProcessSMPPDTO>{
                smpp_config: 'TRANSACTIONAL',
                data: smsProviderPayload,
                smsSenderID,
                templateID: smsTemplateID,
                campaignID: transactional_request._id,
                peID,
                reportType: report_types.TRANSACTIONAL,
              })
              const smppMessageID = response.data?.data?.smppMessageID
              if (_.isNil(smppMessageID)) {
                return resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              }
              // RedisHandler.getInstance(cache_client.DEFAULT, redis_client.SMPP_DELIVERY).set(redisKeys.SMPP_DELIVERY_RESPONSE.value(`report_${report_types.TRANSACTIONAL}_${smppMessageID}`), JSON.stringify(response))
              // RedisHandler.getInstance(cache_client.DEFAULT, redis_client.SMPP_DELIVERY).expire(redisKeys.SMPP_DELIVERY_RESPONSE.value(`report_${report_types.TRANSACTIONAL}_${smppMessageID}`), redisKeys.SMPP_DELIVERY_RESPONSE.timeout())
              transactional_request.deliveryID = smppMessageID
              const session = await this.userModel.db.startSession()
              await session.withTransaction(async () => {
                await transactional_request.save()
                const creditsUpdateResult: Credits = await createOperations.updateOne(this.creditsModel, { clientID: payload.clientID }, { $inc: { credits: -totalCredits } }, session)
                await session.commitTransaction()
                RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), JSON.stringify(creditsUpdateResult))
                RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), redisKeys.USER_CREDITS.timeout())
              }, <TransactionOptions>constants.TRANSACTION_OPTIONS)
              session.endSession()
              try {
                return resolve(getAPIResponse(messages.TRANS001.code, this.traceID, HttpStatus.OK))
              } catch (e) {
                return resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              }
            } else {
              return resolve(getAPIResponse(messages.CRE009.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            }
          } else {
            return resolve(getAPIResponse(messages.CRE010.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          }
        } else {
          return resolve(getAPIResponse(messages.TRANS012.code, this.traceID, HttpStatus.FORBIDDEN))
        }
      } else {
        return resolve(getAPIResponse(messages.TRANS002.code, this.traceID, HttpStatus.FORBIDDEN))
      }
    })
  })

  getAnalytics = (clientID: string) => new Promise<ServiceResponse>((resolve) => {
    const dashboardData = {} as TransactionalDashboard
    dashboardData.metrics = {} as any
    const baseMetricObject = {
      sentTotal: 0,
      sent: _.times(24, _.constant(0)),
      deliveredTotal: 0,
      delivered: _.times(24, _.constant(0)),
    } as TransactionalMetricObject
    dashboardData.metrics.today = _.assign({}, baseMetricObject) as TransactionalMetricObject
    const current_date = new Date()
    const total_days = new Date(current_date.getFullYear(), current_date.getMonth() + 1, 0).getDate()
    baseMetricObject.sent = _.times(total_days, _.constant(0))
    baseMetricObject.delivered = _.times(total_days, _.constant(0))
    dashboardData.metrics.month = _.assign({}, baseMetricObject) as TransactionalMetricObject
    baseMetricObject.sent = _.times(12, _.constant(0))
    baseMetricObject.delivered = _.times(12, _.constant(0))
    dashboardData.metrics.year = _.assign({}, baseMetricObject) as TransactionalMetricObject
    dashboardData.calendar = _.assign([], _.times(12, (month) => ({ month: month + 1, dailystats: [] })))
    const dashboardQueries = [
      (callback: (error: Error | null, data?: TransactionalMetricObject) => void) => getTransactionalData(clientID, this.transactionalModel, transactional_aggregation.TODAY, callback),
      (callback: (error: Error | null, data?: TransactionalMetricObject) => void) => getTransactionalData(clientID, this.transactionalModel, transactional_aggregation.MONTH, callback),
      (callback: (error: Error | null, data?: TransactionalMetricObject) => void) => getTransactionalData(clientID, this.transactionalModel, transactional_aggregation.YEAR, callback),
      (
        callback: (
            error: Error | null,
            data?: Array<{
              month: number
              dailyStats: Array<TransactionalDailyStatsObject>
            }>
          ) => void,
      ) => getTransactionalCalendarData(clientID, this.transactionalModel, callback),
      (callback: (error: Error | null, data?: Array<ReportRequest>) => void) => getReportData(clientID, this.reportsModel, callback),
    ]
    async.parallel(dashboardQueries, (error: Error | undefined, results: any[]) => {
      if (_.isNil(error)) {
        if (!_.isNil(results)) {
          // transactional today's data
          if (!_.isNil(results[0])) {
            dashboardData.metrics.today = _.assign({}, results[0])
          }
          // transactional months's data
          if (!_.isNil(results[1])) {
            dashboardData.metrics.month = _.assign({}, results[1])
          }
          // transactional year's data
          if (!_.isNil(results[2])) {
            dashboardData.metrics.year = _.assign({}, results[2])
          }
          // transactional calendar stats data
          if (!_.isNil(results[3])) {
            dashboardData.calendar = _.assign([], results[3])
          }
          // Report Request
          if (!_.isNil(results[4])) {
            dashboardData.reportRequest = _.assign([], results[4])
          }
          resolve(getAPIResponse(messages.TRANS004.code, this.traceID, HttpStatus.OK, dashboardData))
        } else {
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        }
      } else {
        this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_TRANSACTIONAL_DASHBOARD_DATA, this.traceID, { clientID, error }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      }
    })
  })

  requestReport = (clientID: string, requestReport: TransactionalReportDTO) => new Promise<ServiceResponse>((resolve) => {
    Object.assign(requestReport, {
      type: report_types.TRANSACTIONAL,
      expiry_days: parseInt(getEnvironmentVariable(variables.REPORT_EXPIRY_DAYS.name), 10),
      expiry_timestamp: new Date(new Date().getTime() + parseInt(getEnvironmentVariable(variables.REPORT_EXPIRY_DAYS.name), 10) * 24 * 60 * 60 * 1000),
      clientID,
    })
    if (_.lte(Math.abs(new Date(requestReport.end_date).getTime() - new Date(requestReport.start_date).getTime()) / (1000 * 3600 * 24), 90)) {
      createOperations
        .save(new this.reportsModel(requestReport))
        .then((reportRequest) => {
          this.reportQueue.add({ payload: reportRequest, traceID: this.traceID })
          resolve(getAPIResponse(messages.TRANS008.code, this.traceID, HttpStatus.OK, reportRequest))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.TRANSACTIONAL_REPORT_REQUST, this.traceID, { requestReport, error }))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    } else {
      resolve(getAPIResponse(messages.TRANS007.code, this.traceID, HttpStatus.BAD_REQUEST))
    }
  })

  downloadReport = (clientID: string, report_id: string) => new Promise<ServiceResponse>((resolve) => {
    RedisHandler.getInstance(cache_client.DEFAULT, redis_client.CREATE_REPORT).get(redisKeys.USER_REPORT.value(clientID, report_types.TRANSACTIONAL, report_id), async (error: Error, data: string) => {
      if (_.isNil(error) && !_.isNil(data)) {
        S3Handler.getInstance().getObject({ Bucket: getEnvironmentVariable(variables.S3_TRANSACTIONAL_BUCKET.name), Key: `${report_id}.json` }, (error, file_data) => {
          if (_.isNil(error) && !_.isNil(file_data)) {
            try {
              const file_json = JSON.parse(file_data.Body.toString()) as Array<{
                      date: string
                      data: Array<{
                        phone: number
                        short_id: string
                        delivered: number
                        credits: number
                        time: Date
                      }>
                    }>
              const temp_report_directory = `/${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.TEMP_WORK_DIRECTORY.name)}/${report_id}`
              const directoryExists = fs.existsSync(path.join(process.cwd(), temp_report_directory))
              if (!directoryExists) {
                fs.mkdirSync(path.join(process.cwd(), temp_report_directory), { recursive: true })
              }
              file_json.forEach((report) => {
                if (!_.isNil(report.data) && !_.isEmpty(report.data)) {
                  const reportPath = path.join(process.cwd(), temp_report_directory, `transactional_report_${report.date.replace(/-/g, '_')}.csv`)
                  const csv_data = createCSV(report.data)
                  fs.writeFileSync(reportPath, csv_data)
                }
              })
              zip(path.join(process.cwd(), temp_report_directory), path.join(process.cwd(), `transactional_reports_${report_id}.zip`))
                .then(() => {
                  deleteFolderRecursive(path.join(process.cwd(), temp_report_directory))
                  resolve(getAPIResponse(messages.TRANS005.code, this.traceID, HttpStatus.OK))
                })
                .catch((error: Error) => {
                  this.logger.error(getErrorLog(canonicalMethods.DOWNLOAD_TRANSACTIONAL_REPORT, this.traceID, { clientID, error }, error.message))
                  resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                })
            } catch (error) {
              this.logger.error(getErrorLog(canonicalMethods.DOWNLOAD_TRANSACTIONAL_REPORT, this.traceID, { clientID, error }, error.message))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            }
          } else {
            this.logger.error(getErrorLog(canonicalMethods.DOWNLOAD_TRANSACTIONAL_REPORT, this.traceID, { clientID, error }, error.message))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          }
        })
      } else {
        resolve(getAPIResponse(messages.TRANS006.code, this.traceID, HttpStatus.BAD_REQUEST))
      }
    })
  })
}
