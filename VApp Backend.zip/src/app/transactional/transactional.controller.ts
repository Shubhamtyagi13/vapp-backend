import {
  audience, contentTypes, environments, variables,
} from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Body, Controller, Get, HttpStatus, Param, Post, Req, Res, UseGuards,
} from '@nestjs/common'
import {
  ApiBearerAuth, ApiExcludeController, ApiExcludeEndpoint, ApiTags,
} from '@nestjs/swagger'
import { Request, Response } from 'express'

import { messages } from '@messages'
import { deleteFile, getEnvironmentVariable } from '@utils/platform.util'
import _ from 'lodash'
import path from 'path'
import { TransactionalReportDTO } from './dto/transactional-report.dto'
import { RequestTransactionalDTO } from './dto/request-transactional.dto'
import { TransactionalService } from './transactional.service'

@ApiBearerAuth('Authorization Bearer Token')
@ApiTags(TransactionalController.name)
@Controller('transactional')
export class TransactionalController {
  constructor(private readonly transactionalService: TransactionalService) {}

  @Post('request')
  requestTransactional(@Res() response: Response, @Body() payload: RequestTransactionalDTO) {
    this.transactionalService.requestTransactional(payload).then((serviceResponse: ServiceResponse) => response.status(serviceResponse.status).send(<APIResponse>serviceResponse))
  }

  @UseGuards(AuthenticationGuard)
  @Audience([audience.CLIENT, audience.ADMIN])
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  @Get('analytics')
  getAnalytics(@Res() response: Response, @Req() request: Request) {
    this.transactionalService.getAnalytics(request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @UseGuards(AuthenticationGuard)
  @Audience([audience.CLIENT, audience.ADMIN])
  @Post('request-report')
  requestReport(@Res() response: Response, @Body() reportRequest: TransactionalReportDTO, @Req() request: Request) {
    this.transactionalService.requestReport(request.user._id, reportRequest).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @UseGuards(AuthenticationGuard)
  @Audience([audience.CLIENT, audience.ADMIN])
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  @Get('download-report/:id')
  downloadReport(@Res() response: Response<APIResponse>, @Req() request: Request, @Param('id') report_id: string) {
    this.transactionalService.downloadReport(request.user._id, report_id).then((service_response: ServiceResponse) => {
      if (_.eq(service_response.status, HttpStatus.OK)) {
        const report_file_path = path.join(process.cwd(), `transactional_reports_${report_id}.zip`)
        response.sendFile(report_file_path, (err) => {
          if (err) {
            return response.status(service_response.status).send(<APIResponse>{
              code: messages.COM001.code,
              message: messages.COM001.message,
              traceID: service_response.traceID,
              status: HttpStatus.INTERNAL_SERVER_ERROR,
              data: {},
            })
          }
          deleteFile(report_file_path)
        })
      } else {
        return response.status(service_response.status).send(<APIResponse>service_response)
      }
    })
  }
}
