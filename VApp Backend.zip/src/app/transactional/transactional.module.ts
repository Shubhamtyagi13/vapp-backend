import { Credits, CreditsSchema } from '@app/credits/credits.schema'
import { ReportsQueueModule } from '@app/reports/cron/queue.module'
import { Reports, ReportsSchema } from '@app/reports/reports.schema'
import { Template, TemplateSchema } from '@app/template/template.schema'
import { User, UserSchema } from '@app/user/user.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { UploadDeliveryReportModule } from '@app/delivery/cron/queue.module'
import { TransactionalController } from './transactional.controller'
import { Transactional, TransactionalSchema } from './transactional.schema'
import { TransactionalService } from './transactional.service'

@Module({
  imports: [
    UploadDeliveryReportModule,
    ReportsQueueModule,
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Transactional.name, schema: TransactionalSchema },
      { name: Template.name, schema: TemplateSchema },
      { name: Reports.name, schema: ReportsSchema },
      { name: Credits.name, schema: CreditsSchema },
    ]),
  ],
  controllers: [TransactionalController],
  providers: [TransactionalService, VappLogger],
})
export class TransactionalModule {}
