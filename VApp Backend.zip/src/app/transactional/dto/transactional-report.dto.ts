import { otp_types } from '@config'
import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import {
  IsDefined, IsNumber, IsOptional, IsString, IsMongoId, Min, Max, IsIn,
} from 'class-validator'

export class TransactionalReportDTO {
  @ApiProperty({ required: true })
  @IsDefined()
    start_date: Date

  @ApiProperty({ required: true })
  @IsDefined()
    end_date: Date
}
