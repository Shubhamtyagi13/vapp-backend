import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import { IsValidTemplateVariable } from '@transformers/template-variable.transformer'
import {
  IsDefined, IsString, IsMongoId, IsOptional,
} from 'class-validator'

// it may contain the variables
export class RequestTransactionalDTO {
  @ApiProperty({ required: true, description: 'API key of your VAPP Account' })
  @IsString()
  @IsDefined()
  @IsMongoId()
    apiKey: string

  @ApiProperty({ required: true, description: 'Template id of the template containing dlt infromation' })
  @IsString()
  @IsDefined()
  @IsMongoId()
    templateID: string

  @ApiProperty({ required: true, description: '10 digits phone number (india) for otp' })
  @IsDefined()
  @IsValidPhone()
    phone: number

  @ApiProperty({ required: true, description: 'Optional variable' })
  @IsOptional()
  @IsString()
    clientName: string

  @ApiProperty({ required: true, description: 'Optional variable' })
  @IsOptional()
  @IsString()
    firstName: string

  @ApiProperty({ required: true, description: 'Optional variable' })
  @IsOptional()
  @IsString()
    middleName: string

  @ApiProperty({ required: true, description: 'Optional variable' })
  @IsOptional()
  @IsString()
    lastName: string

  @ApiProperty({ required: true, description: 'Optional variable' })
  @IsOptional()
  @IsString()
    var1: string

  @ApiProperty({ required: true, description: 'Optional variable' })
  @IsOptional()
  @IsString()
    var2: string

  @ApiProperty({ required: true, description: 'Optional variable' })
  @IsOptional()
  @IsString()
    var3: string

  @ApiProperty({ required: true, description: 'Optional variable' })
  @IsOptional()
  @IsString()
    var4: string
}
