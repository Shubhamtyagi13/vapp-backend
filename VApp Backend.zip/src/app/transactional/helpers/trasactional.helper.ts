import { report_types, transactional_aggregation } from '@config'
import { TransactionalDailyStatsObject, TransactionalDashboard, TransactionalMetricObject } from '@interfaces/transactional.interface'
import { findOperations } from '@utils/crud.util'
import _ from 'lodash'
import { Model } from 'mongoose'
import { Reports } from '@app/reports/reports.schema'
import { ReportRequest } from '@interfaces/reports.interface'
import { Transactional } from '../transactional.schema'

export const getTransactionalData = (
  clientID: string,
  TransactionalModel: Model<Transactional>,
  type: transactional_aggregation,
  callback: (error: Error | null, data?: TransactionalMetricObject) => void
) => {
  let startDate; let endDate

  if (_.eq(type, transactional_aggregation.YEAR)) {
    startDate = new Date(new Date().getFullYear(), 1, 1, 0, 0, 0, 0)
    endDate = new Date(new Date().getFullYear() + 1, 1, 1, 0, 0, 0, 0)
  }

  if (_.eq(type, transactional_aggregation.MONTH)) {
    startDate = new Date(new Date().getFullYear(), new Date().getMonth(), 1, 0, 0, 0, 0)
    endDate = new Date(new Date().getFullYear() , new Date().getMonth() + 1, 1, 0, 0, 0, 0)
  }
  if (_.eq(type, transactional_aggregation.TODAY)) {
    startDate = new Date(new Date().getFullYear(), new Date().getMonth(), new Date().getDate(), 0, 0, 0, 0)
    endDate = new Date(new Date().getFullYear(), new Date().getMonth() , new Date().getDate() + 1, 0, 0, 0, 0)
  }

  const filter_object = {
    clientID,
    date: {
      $gte: startDate,
      $lt: endDate
    }
  }
  findOperations
    .aggregate(TransactionalModel, [
      [
        {
          $match: filter_object
        },
        {
          $addFields: {
            date: {
              $dateToParts: {
                date: '$date'
              }
            }
          }
        },
        {
          $group: {
            _id: `$date.${type.toLowerCase()}`,
            key: { $first: `$date.${type.toLowerCase()}` },
            sent: { $push: 1 },
            delivered: {
              $push: {
                $cond: [{ $eq: ['$smsStatus', 2] }, 1, 0]
              }
            }
          }
        },
        {
          $project: {
            sent: { $sum: '$sent' },
            delivered: { $sum: '$delivered' },
            key: 1
          }
        },
        {
          $group: {
            _id: null,
            sentTotal: { $sum: '$sent' },
            deliveredTotal: { $sum: '$delivered' },
            sent: { $push: { key: '$key', value: '$sent' } },
            delivered: { $push: { key: '$key', value: '$delivered' } }
          }
        },
        { $project: { _id: 0 } }
      ]
    ])
    .then((result: Array<TransactionalMetricObject>) => {
      if (!_.isNil(result[0])) {
        let temp = []
        let end = 24
        let start = 0
        if (_.eq(type, transactional_aggregation.MONTH)) {
          const current_date = new Date()
          start = 1
          end = new Date(current_date.getFullYear(), current_date.getMonth() + 1, 0).getDate() + 1
        }
        if (_.eq(type, transactional_aggregation.YEAR)) {
          start = 1
          end = 12 + 1
        }
        const keys = ['sent', 'delivered']
        for (let j = 0; j < keys.length; j++) {
          temp = []
          for (let i = start; i < end; i++) {
            const data = result[0][`${keys[j]}`]
            const value = (data as Array<{ key: number; value: number }>).find((e) => _.eq(e.key, i))?.value
            temp.push(!_.isNil(value) ? value : 0)
          }
          result[0][`${keys[j]}`] = _.assign([], temp)
        }
        callback(null, result[0])
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      callback(null)
    })
}

export const getTransactionalCalendarData = (
  clientID: string,
  TransactionalModel: Model<Transactional>,
  callback: (
    error: Error | null,
    data?: Array<{
      month: number
      dailyStats: Array<TransactionalDailyStatsObject>
    }>
  ) => void
) => {
  const startDate = new Date(new Date().getFullYear(), 1, 1, 0, 0, 0, 0)
  const endDate = new Date(new Date().getFullYear() + 1, 1, 1, 0, 0, 0, 0)

  findOperations
    .aggregate(TransactionalModel, [
      {
        $match: {
          clientID,
          date: {
            $gte: startDate,
            $lt: endDate
          }
        }
      },
      {
        $addFields: {
          date: {
            $dateToParts: {
              date: '$date'
            }
          }
        }
      },

      {
        $group: {
          _id: { month: '$date.month', day: '$date.day' },
          month: { $first: '$date.month' },
          day: { $first: '$date.day' },

          sent: { $push: 1 },
          delivered: {
            $push: {
              $cond: [{ $eq: ['$smsStatus', 2] }, 1, 0]
            }
          }
        }
      },
      {
        $project: {
          sent: { $sum: '$sent' },
          delivered: { $sum: '$delivered' },
          month: 1,
          day: 1
        }
      },
      {
        $group: {
          _id: '$month',
          month: { $first: '$month' },
          dailyStats: {
            $push: {
              day: '$day',
              sent: '$sent',
              delivered: '$delivered'
            }
          }
        }
      },
      { $project: { _id: 0 } }
    ])
    .then(
      (
        result: Array<{
          month: number
          dailyStats: Array<TransactionalDailyStatsObject>
        }>
      ) => {
        if (!_.isNil(result)) {
          result = _.orderBy(
            [
              ..._.difference(
                _.times(12, (month) => ++month),
                _.map(result, (e) => e.month)
              ).map((month) => ({ month, dailyStats: [] })),
              ...result
            ],
            'month'
          )
          callback(null, result)
        } else {
          callback(null)
        }
      }
    )
    .catch((error: Error) => {
      callback(null)
    })
}

export const getReportData = (clientID: string, reportsModel: Model<Reports>, callback: (error: Error | null, data?: Array<ReportRequest>) => void) => {
  const current_date = new Date()
  findOperations
    .aggregate(reportsModel, [
      {
        $addFields: {
          datepart: {
            $dateToParts: {
              date: '$created'
            }
          }
        }
      },
      {
        $match: {
          clientID,
          'datepart.year': current_date.getFullYear(),
          type: report_types.TRANSACTIONAL
        }
      },
      {
        $sort: {
          created: -1
        }
      },
      {
        $project: {
          _id: 1,
          created: 1,
          start_date: 1,
          end_date: 1,
          status: 1,
          type: 1,
          url: 1
        }
      }
    ])
    .then((reportRequest: Array<ReportRequest>) => {
      if (!_.isNil(reportRequest)) {
        callback(null, reportRequest)
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      callback(null)
    })
}
