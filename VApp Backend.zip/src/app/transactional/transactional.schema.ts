import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'
import { constants, tables } from '@config'

// change collection name to plural if required
@Schema({ collection: tables.TRANSACTIONAL.collection, autoCreate: true })
export class Transactional extends Document {
  @Prop({ type: String, required: true, default: null, index: true })
  clientID: string

  @Prop({ type: Date, index: true, required: true })
  date: Date

  @Prop({ type: String, required: true, default: null, index: true })
  templateID: string

  @Prop({ type: Number, required: true, default: 0 })
  credits: number

  @Prop({ type: String, index: true, required: true })
  shortID: string

  @Prop({ type: Boolean, index: true, default: false })
  morphed: boolean

  @Prop({ type: Number, index: true, default: constants.SMS_STATUS.submitted })
  smsStatus: number

  @Prop({ type: Number, index: true, required: true })
  phone: number

  @Prop({ type: String, index: true, default: null })
  deliveryID: string
}

export const TransactionalSchema = SchemaFactory.createForClass(Transactional)
