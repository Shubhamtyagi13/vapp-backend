import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.CONTACTS_DATABASE.collection, autoCreate: true })
export class ContactDatabase extends Document {
  @Prop({ type: String, index: true, required: true })
  clientID: string

  @Prop({ type: String, index: true, required: true })
  name: string

  @Prop({ type: String, index: true, default: null })
  region: string

  @Prop({ type: Boolean, index: true, default: true })
  active: boolean

  @Prop({ type: Number, index: true, default: 0 })
  linksCount: number

  @Prop({ type: Number, index: true, default: 0 })
  linksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsSentCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsDeliveredCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsFailedCount: number

  @Prop({ type: Number, index: true, default: 0 })
  viewsCount: number

  @Prop({ type: String, index: true, required: true, default: 0 })
  contactsCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsLinksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappLinksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappSentCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappFailedCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappViewsCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsViewsCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappDeliveredCount: number

  @Prop({ type: Number, index: true, default: 0 })
  negativeCount: number

  @Prop({ type: Number, index: true, default: 0 })
  neutralCount: number

  @Prop({ type: Number, index: true, default: 0 })
  positiveCount: number

  @Prop({ type: Number, index: true, default: 0 })
  leadPositive: number

  @Prop({ type: Number, index: true, default: 0 })
  leadNegative: number

  @Prop({ type: Number, index: true, default: 0 })
  leadNeutral: number

  @Prop({ type: Number, index: true, default: 0 })
  callsThreshold: number

  @Prop({ type: Number, index: true, default: 0 })
  calls: number
}

export const ContactDatabaseSchema = SchemaFactory.createForClass(ContactDatabase)
