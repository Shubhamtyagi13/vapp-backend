import { UserMetadataDTO } from '@app/website/dto/create-metadata.dto'
import { cache_client, redis_client, redisKeys } from '@config'
import { CronError } from '@interfaces/error.interface'
import { RedisHandler } from '@utils/redis.util'
import _ from 'lodash'

export const storeUserMetadata = (payload: Array<UserMetadataDTO>, traceID: string) =>
  new Promise<boolean>((resolve) => {
    RedisHandler.getInstance(cache_client.DEFAULT, redis_client.COMMON_JOB_DATA)
      .multi()
      .setnx(traceID, JSON.stringify(payload))
      .expire(traceID, redisKeys.USER_METADATA.timeout())
      .exec(() => {
        resolve(true)
      })
  })

export const extractUserMetadata = (traceID: string) =>
  new Promise<Array<UserMetadataDTO>>((resolve, rej) => {
    RedisHandler.getInstance(cache_client.DEFAULT, redis_client.COMMON_JOB_DATA).get(traceID, (error: Error, data: string) => {
      if (_.isNil(error) && !_.isNil(data)) {
        const job_data = JSON.parse(data) as Array<UserMetadataDTO>
        resolve(job_data)
      } else {
        throw new CronError('data not found')
      }
    })
  })
