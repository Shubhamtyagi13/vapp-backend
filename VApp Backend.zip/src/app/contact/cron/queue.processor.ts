import { UploadContactDTO } from '@app/contact/dto/upload-contacts.dto'
import { CreateMetadataDTO, UserMetadataDTO } from '@app/website/dto/create-metadata.dto'
import { UserMetadata } from '@app/website/user-metadata.schema'
import { cronJobs, redisKeys } from '@config'
import { CronPayload } from '@interfaces/cron.interface'
import { OnQueueActive, OnQueueCompleted, OnQueueFailed, Process, Processor } from '@nestjs/bull'
import { Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import { getErrorLog } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import { Job } from 'bull'
import _ from 'lodash'
import { Model } from 'mongoose'
import { ContactDatabase } from '../contact.database.schema'
import { Contact } from '../contact.schema'
import { createContactsDirectory, createContactsFile } from '../helpers/excel.helper'
import { extractUserMetadata } from './helper/common.helper'

@Injectable()
@Processor(cronJobs.UPLOAD_CLIENT_CONTACTS.name)
export class UploadClientContactsProcessor {
  constructor(
    @InjectModel(Contact.name) private contactsModel: Model<Contact>,
    @InjectModel(ContactDatabase.name) private contactsDatabaseModel: Model<ContactDatabase>,
    @InjectModel(UserMetadata.name) private userMetadataModel: Model<UserMetadata>,
    private logger: VappLogger
  ) {}

  @Process({ concurrency: 1 })
  async processUploadContacts(job: Job<CronPayload<UploadContactDTO> | CronPayload<CreateMetadataDTO>>) {
    let { payload } = job.data
    const { traceID, instance } = job.data
    if (_.isEqual(instance, UploadContactDTO.name)) {
      payload = payload as UploadContactDTO
      try {
        const uploadObject = new this.contactsDatabaseModel({
          name: payload.name,
          clientID: payload.clientID
        })
        if (!_.isNil(payload.region)) {
          uploadObject.region = payload.region
        }
        _.each(payload.contacts, (contact) => _.set(contact, 'databaseID', uploadObject._id))
        uploadObject.contactsCount = payload.contacts.length
        await createOperations.create(this.contactsDatabaseModel, [uploadObject])
        await createOperations.insertMany(this.contactsModel, payload.contacts)
        _.each(payload.contacts, (contact) => _.unset(contact, 'databaseID'))
        const contactsDirectory = createContactsDirectory(payload.clientID)
        createContactsFile(contactsDirectory, uploadObject._id, payload.contacts as unknown as Contact[])
        const contactsDatabases: ContactDatabase[] = await findOperations.find(this.contactsDatabaseModel, { clientID: payload.clientID }, {}, {})
        if (!_.isNil(contactsDatabases)) {
          RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(payload.clientID), JSON.stringify(contactsDatabases))
          RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(payload.clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
        }
      } catch (error) {
        this.logger.error(getErrorLog(cronJobs.UPLOAD_CLIENT_CONTACTS.name, traceID, { error, clientID: payload.clientID }, error.message))
        throw error
      }
    } else if (_.isEqual(instance, CreateMetadataDTO.name)) {
      payload = payload as CreateMetadataDTO
      try {
        const metaDataRequests: Array<UserMetadata> = []
        payload.data = await extractUserMetadata(traceID)
        payload.data.forEach((contact) => {
          metaDataRequests.push(
            new this.userMetadataModel({
              name: contact.name.trim(),
              phone: contact.phone
            })
          )
        })
        await createOperations.processBulkInsertionMetadata(this.userMetadataModel, metaDataRequests)
      } catch (error) {
        this.logger.error(getErrorLog(cronJobs.UPLOAD_CLIENT_CONTACTS.name, traceID, { error }, error.message))
        throw error
      }
    }
  }

  @OnQueueActive()
  onActive(job: Job<CronPayload<UploadContactDTO>>) {
    this.logger.log(`Processing: Job name: ${cronJobs.UPLOAD_CLIENT_CONTACTS.name} Job ID: ${job.id}`)
  }

  @OnQueueCompleted()
  onCompleted(job: Job<CronPayload<UploadContactDTO>>) {
    this.logger.log(`Completed: Job name: ${cronJobs.UPLOAD_CLIENT_CONTACTS.name} Job ID: ${job.id}`)
  }

  @OnQueueFailed()
  onFailed(job: Job<CronPayload<UploadContactDTO>>) {
    this.logger.error(getErrorLog(cronJobs.UPLOAD_CLIENT_CONTACTS.name, job.data.traceID, { id: job.id, reason: job.failedReason, stack: job.stacktrace }))
  }
}
