import { cronJobs, redis_client, variables } from '@config'
import { BullModule } from '@nestjs/bull'
import { getEnvironmentVariable } from '@utils/platform.util'

const redis = {
  host: getEnvironmentVariable(variables.REDIS_URL.name),
  port: getEnvironmentVariable(variables.REDIS_PORT.name)
}

export const UploadClientContactsQueueModule = BullModule.registerQueueAsync({
  name: cronJobs.UPLOAD_CLIENT_CONTACTS.name,
  useFactory: () => ({
    redis: { ...redis, db: redis_client.UPLOAD_CLIENT_CONTACTS },
    defaultJobOptions: {
      priority: cronJobs.UPLOAD_CLIENT_CONTACTS.priority,
      removeOnComplete: true,
      removeOnFail: false,
      attempts: cronJobs.UPLOAD_CLIENT_CONTACTS.attempts
    },
    prefix: cronJobs.UPLOAD_CLIENT_CONTACTS.name,
    settings: {
      lockRenewTime: cronJobs.UPLOAD_CLIENT_CONTACTS.lockRenew,
      maxStalledCount: cronJobs.UPLOAD_CLIENT_CONTACTS.maxStalledCount,
      lockDuration: cronJobs.UPLOAD_CLIENT_CONTACTS.lockLifeTime
    }
  })
})
