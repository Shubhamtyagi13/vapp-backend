import { Campaign, CampaignSchema } from '@app/campaign/campaign.schema'
import { Tracking, TrackingSchema } from '@app/tracking/tracking.schema'
import { UserMetadata, UserMetadataSchema } from '@app/website/user-metadata.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { ContactController } from './contact.controller'
import { ContactDatabase, ContactDatabaseSchema } from './contact.database.schema'
import { Contact, ContactSchema } from './contact.schema'
import { ContactService } from './contact.service'
import { UploadClientContactsQueueModule } from './cron/queue.module'
import { UploadClientContactsProcessor } from './cron/queue.processor'
import { QueueUIProvider } from './cron/queue.ui'

@Module({
  imports: [
    UploadClientContactsQueueModule,
    MongooseModule.forFeature([
      { name: Contact.name, schema: ContactSchema },
      { name: Tracking.name, schema: TrackingSchema },
      { name: Campaign.name, schema: CampaignSchema },
      { name: ContactDatabase.name, schema: ContactDatabaseSchema },
      { name: UserMetadata.name, schema: UserMetadataSchema }
    ])
  ],
  controllers: [ContactController],
  providers: [ContactService, VappLogger, UploadClientContactsProcessor, QueueUIProvider],
  exports: [MongooseModule]
})
export class ContactCronModule {}
