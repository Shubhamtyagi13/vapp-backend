import {
  audience, contentTypes, environments, variables,
} from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { APIResponse } from '@interfaces/response.interface'
import {
  Body, Controller, Get, HttpStatus, Param, Post, Req, Res, UseGuards,
} from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { ApiBearerAuth, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import { Model } from 'mongoose'
import path from 'path'
import { Contact } from './contact.schema'
import { ContactService } from './contact.service'
import { UploadContactDTO } from './dto/upload-contacts.dto'

@ApiTags(ContactController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('contacts')
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
@UseGuards(AuthenticationGuard)
export class ContactController {
  constructor(@InjectModel(Contact.name) private userModel: Model<Contact>, private contactService: ContactService) {}

  @Audience([audience.CLIENT, audience.ADMIN])
  @Post('upload')
  upload(@Body() payload: UploadContactDTO, @Res() response: Response<APIResponse>, @Req() request: Request) {
    this.contactService.uploadContacts(payload, request.user._id).then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @Get(['active_database', 'database'])
  fetchDatabases(@Res() response: Response<APIResponse>, @Req() request: Request) {
    this.contactService.fetchDatabases(request.user._id, request.url.replace('/', '')).then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @Get('regions')
  fetchUniqueDatabaseRegions(@Res() response: Response<APIResponse>, @Req() request: Request) {
    this.contactService.fetchUniqueDatabaseRegions(request.user._id).then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @Get('fetch/:databaseID')
  fetchContactsForDatabase(@Res() response: Response<APIResponse>, @Req() request: Request, @Param('databaseID') databaseID: string) {
    this.contactService.fetchContactsForDatabase(request.user._id, databaseID).then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @Get('download/:databaseID')
  downloadContactsFileForDatabase(@Res() response: Response<APIResponse>, @Req() request: Request, @Param('databaseID') databaseID: string) {
    this.contactService.downloadContactsFileForDatabase(request.user._id, databaseID).then((service_response) => {
      if (_.eq(service_response.status, HttpStatus.OK)) {
        response.setHeader('Content-Type', contentTypes.APPLICATION.SPREADSHEET)
        response.setHeader('Content-Disposition', `attachment; filename=${databaseID}.xlsx`)
        response.sendFile(
          path.join(process.cwd(), `/${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.CONTACT_DIRECTORY.name)}/${request.user._id}/${databaseID}.xlsx`),
        )
      } else {
        return response.status(service_response.status).send(service_response)
      }
    })
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @Get('/toggle/:databaseID/:flag')
  toggle(@Res() response: Response<APIResponse>, @Req() request: Request, @Param('databaseID') databaseID: string, @Param('flag') flag: string) {
    this.contactService.toggle(request.user._id, databaseID, flag).then((service_response) => response.status(service_response.status).send(service_response))
  }
}
