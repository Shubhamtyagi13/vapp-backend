import { Campaign } from '@app/campaign/campaign.schema'
import { Tracking } from '@app/tracking/tracking.schema'
import {
  canonicalMethods, constants, cronJobs, redisKeys,
} from '@config'
import { CampaignEvent } from '@interfaces/campaign.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { InjectQueue } from '@nestjs/bull'
import { HttpStatus, Inject, Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import { getAPIResponse, getErrorLog } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import { Queue } from 'bull'
import fs from 'fs'
import _ from 'lodash'
import { Model } from 'mongoose'
import path from 'path'
import { ContactDatabase } from './contact.database.schema'
import { Contact } from './contact.schema'
import { UploadContactDTO } from './dto/upload-contacts.dto'
import { createContactsDirectory, createContactsFile } from './helpers/excel.helper'

@Injectable()
export class ContactService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    @InjectModel(ContactDatabase.name) private contactDatabaseModel: Model<ContactDatabase>,
    @InjectModel(Contact.name) private contactModel: Model<Contact>,
    @InjectModel(Tracking.name) private trackingModel: Model<Tracking>,
    @InjectModel(Campaign.name) private campaignsModel: Model<Campaign>,
    @InjectQueue(cronJobs.UPLOAD_CLIENT_CONTACTS.name) private contactsUploadQueue: Queue,
    private logger: VappLogger,
  ) {
    this.traceID = vapp_context.traceID
  }

  uploadContacts = (payload: UploadContactDTO, userID: string) => new Promise<ServiceResponse>((resolve) => {
    payload.clientID = userID
    this.contactsUploadQueue.add({ payload, traceID: this.traceID, instance: UploadContactDTO.name }).catch((error: Error) => {
      this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_CONTACTS, this.traceID, { payload, userID }, error.message))
      resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
    })
    resolve(getAPIResponse(messages.CONT002.code, this.traceID, HttpStatus.OK))
  })

  fetchDatabases = (clientID: string, requestUrl: string) =>
    // eslint-disable-next-line no-async-promise-executor
    new Promise<ServiceResponse>(async (resolve) => {
      let fetchActive = false
      if (_.includes(requestUrl, 'active')) {
        fetchActive = true
      }
      const campaigns = await findOperations.findLean(this.campaignsModel, { clientID, year: new Date().getFullYear(), databaseID: { $ne: null } }, {
        month: 1,
        projectID: 1,
        databaseID: 1,
        negativeCount: 1,
        positiveCount: 1,
        neutralCount: 1,
        campaignName: 1,
        leadPositive: 1,
        leadNegative: 1,
        leadNeutral: 1,
        calls: 1,
        callsThreshold: 1,
      })
      let events: [CampaignEvent] = [] as unknown as [CampaignEvent]
      try {
        events = await findOperations.aggregate(this.trackingModel, [
          {
            $match: {
              year: new Date().getFullYear(),
              clientID,
            },
          },
          { $addFields: { events: { $size: '$events' } } },
          {
            $group: {
              _id: '$shortID',
              shortID: { $first: '$shortID' },
              events: { $sum: '$events' },
              campaignID: { $first: '$campaignID' },
            },
          },
          {
            $project: {
              shortID: 1,
              campaignID: 1,
              events: { $cond: [{ $gt: ['$events', 0] }, 1, 0] },
              eventsThreshold: { $cond: [{ $gt: ['$events', 1] }, 1, 0] },
              _id: 0,
            },
          },
          {
            $group: {
              _id: '$databaseID',
              databaseID: { $first: '$databaseID' },
              events: { $sum: '$events' },
              eventsThreshold: { $sum: '$eventsThreshold' },
            },
          },
          {
            $project: {
              databaseID: 1,
              events: 1,
              eventsThreshold: 1,
              _id: 0,
            },
          },
        ])
      } catch (e) {}
      RedisHandler.getInstance().get(redisKeys.USER_CONTACT_DATABASES.value(clientID), (error: Error, data: string) => {
        if (_.isNil(error) && !_.isNil(data)) {
          const contactsDatabases: [ContactDatabase] = JSON.parse(data) as [ContactDatabase]
          let output = this.processUsageStats(campaigns, contactsDatabases)
          output = this.processEvents(events, output)
          resolve(getAPIResponse(messages.CONT008.code, this.traceID, HttpStatus.OK, fetchActive ? output.filter((database) => database.active) : output))
        }
        findOperations
          .findLean(this.contactDatabaseModel, { clientID }, { __v: 0, password: 0 })
          .then(async (contactsDatabases: [ContactDatabase]) => {
            if (!_.isNil(contactsDatabases)) {
              let output = this.processUsageStats(campaigns, contactsDatabases)
              output = this.processEvents(events, output)
              if (contactsDatabases.length > 0) {
                resolve(getAPIResponse(messages.CONT008.code, this.traceID, HttpStatus.OK, fetchActive ? output.filter((database) => database.active) : output))
              }
              resolve(getAPIResponse(messages.CONT009.code, this.traceID, HttpStatus.OK, []))
              RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(clientID), JSON.stringify(contactsDatabases))
              RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
            }
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
          .catch((error: Error) => {
            this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_CONTACTS_DATABASES, this.traceID, { clientID }, error.message))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR, error.message))
          })
      })
    })

  fetchUniqueDatabaseRegions = (clientID: string) => new Promise<ServiceResponse>((resolve) => {
    RedisHandler.getInstance().get(redisKeys.USER_CONTACT_DATABASES.value(clientID), (error: Error, data: string) => {
      if (_.isNil(error) && !_.isNil(data)) {
        resolve(getAPIResponse(messages.CONT005.code, this.traceID, HttpStatus.OK, _.map(_.uniqBy(JSON.parse(data) as ContactDatabase[], 'region'))))
      }
      findOperations
        .find(this.contactDatabaseModel, { clientID })
        .then((contactsDatabases: ContactDatabase[]) => {
          if (!_.isNil(contactsDatabases)) {
            RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(clientID), JSON.stringify(contactsDatabases))
            RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
            if (contactsDatabases.length > 0) {
              resolve(getAPIResponse(messages.CONT005.code, this.traceID, HttpStatus.OK, _.map(_.uniqBy(JSON.parse(data) as ContactDatabase[], 'region'))))
            }
            resolve(getAPIResponse(messages.CONT005.code, this.traceID, HttpStatus.OK, []))
          }
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_CONTACTS_DATABASES, this.traceID, { clientID }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })
  })

  fetchContactsForDatabase = (clientID: string, databaseID: string) => new Promise<ServiceResponse>((resolve) => {
    findOperations
      .find(this.contactModel, { databaseID })
      .then((contacts: Contact[]) => {
        if (!_.isNil(contacts)) {
          if (contacts.length > 0) {
            resolve(getAPIResponse(messages.CONT003.code, this.traceID, HttpStatus.OK, contacts))
          }
          resolve(getAPIResponse(messages.CONT004.code, this.traceID, HttpStatus.OK, []))
        }
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
      .catch((error: Error) => {
        this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_CONTACTS, this.traceID, { error, databaseID, clientID }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
  })

  downloadContactsFileForDatabase = (clientID: string, databaseID: string) => new Promise<ServiceResponse>((resolve) => {
    const contactsDirectory = createContactsDirectory(clientID)
    const fileExists = fs.existsSync(path.join(process.cwd(), contactsDirectory, `${databaseID}.xlsx`))
    if (!fileExists) {
      findOperations
        .findLean(this.contactModel, { databaseID }, { __v: 0, databaseID: 0, _id: 0 })
        .then((contacts: Contact[]) => {
          if (!_.isNil(contacts)) {
            if (contacts.length > 0) {
              createContactsFile(contactsDirectory, databaseID, contacts)
              resolve(getAPIResponse(messages.CONT012.code, this.traceID, HttpStatus.OK, []))
            }
            resolve(getAPIResponse(messages.CONT004.code, this.traceID, HttpStatus.OK, []))
          }
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.DOWNLOAD_CLIENT_CONTACTS_FILE, this.traceID, { error, databaseID, clientID }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    } else {
      resolve(getAPIResponse(messages.CONT012.code, this.traceID, HttpStatus.OK, []))
    }
  })

  toggle = (clientID: string, databaseID: string, flag: string) => new Promise<ServiceResponse>((resolve) => {
    createOperations
      .updateOne(this.contactDatabaseModel, { _id: databaseID }, { $set: { active: flag === 'true' } })
      .then((contactDatabase: ContactDatabase) => {
        if (!_.isNil(contactDatabase)) {
          findOperations
            .find(this.contactDatabaseModel, { clientID })
            .then(async (contactsDatabases: ContactDatabase[]) => {
              if (!_.isNil(contactsDatabases)) {
                RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(clientID), JSON.stringify(contactsDatabases))
                RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
              }
              const campaigns = await findOperations.findLean(this.campaignsModel, { clientID, year: new Date().getFullYear(), databaseID }, {
                month: 1,
                projectID: 1,
                databaseID: 1,
                negativeCount: 1,
                positiveCount: 1,
                neutralCount: 1,
                campaignName: 1,
              })
              const output = this.processUsageStats(campaigns, [contactDatabase.toObject() as any])
              resolve(getAPIResponse(messages.CONT011.code, this.traceID, HttpStatus.OK, output[0]))
            })
            .catch((error: Error) => {
              this.logger.error(getErrorLog(canonicalMethods.TOGGLE_CLIENT_DATABASE, this.traceID, {
                error, databaseID, clientID, flag,
              }, error.message))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            })
        } else {
          this.logger.error(getErrorLog(canonicalMethods.TOGGLE_CLIENT_DATABASE, this.traceID, { databaseID, clientID, flag }))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        }
      })
      .catch((error: Error) => {
        this.logger.error(getErrorLog(canonicalMethods.TOGGLE_CLIENT_DATABASE, this.traceID, {
          error, databaseID, clientID, flag,
        }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
  })

  processEvents = (events: [CampaignEvent], input: [ContactDatabase]) => {
    if (input.length > 0) {
      input.forEach((database, index) => {
        if (_.isNaN(database.leadPositive) || _.isNil(database.leadPositive)) _.set(input[index], 'leadPositive', 0)
        if (_.isNaN(database.leadNegative) || _.isNil(database.leadNegative)) _.set(input[index], 'leadNegative', 0)
        if (_.isNaN(database.leadNeutral) || _.isNil(database.leadNeutral)) _.set(input[index], 'leadNeutral', 0)
        if (_.isNaN(database.calls) || _.isNil(database.calls)) _.set(input[index], 'calls', 0)
        if (_.isNaN(database.callsThreshold) || _.isNil(database.callsThreshold)) _.set(input[index], 'callsThreshold', 0)
        const subEventObject = events.find((e) => _.eq(database.id, e.databaseID))
        if (!_.isNil(subEventObject)) {
          _.set(input[index], 'events', subEventObject.events)
          _.set(input[index], 'eventsThreshold', subEventObject.eventsThreshold)
        } else {
          _.set(input[index], 'events', 0)
          _.set(input[index], 'eventsThreshold', 0)
        }
      })
    }
    return input
  }

  processUsageStats = (campaigns: [Campaign], input: [ContactDatabase]) => {
    const currentMonth = new Date().getMonth() + 1
    const usageStatsMap = {}
    campaigns.forEach((campaign) => {
      if (_.isNil(usageStatsMap[`${campaign.databaseID}`])) {
        _.set(usageStatsMap, `${campaign.databaseID}`, _.assign({}, {
          year: {
            useCount: 0, acrossProjectsCount: 0, projects: {}, campaigns: {},
          },
          month: {
            useCount: 0, acrossProjectsCount: 0, projects: {}, campaigns: {},
          },
        }))
      }
      // check year wise
      if (_.isNil(usageStatsMap[`${campaign.databaseID}`].year.projects[`${campaign.projectID}`])) {
        usageStatsMap[`${campaign.databaseID}`].year.acrossProjectsCount += 1
        usageStatsMap[`${campaign.databaseID}`].year.projects[`${campaign.projectID}`] = true
      }
      usageStatsMap[`${campaign.databaseID}`].year.useCount += 1
      if (_.isNil(usageStatsMap[`${campaign.databaseID}`].year.campaigns[`${campaign._id}`])) {
        usageStatsMap[`${campaign.databaseID}`].year.campaigns[`${campaign._id}`] = {
          projectID: campaign.projectID,
          negativeCount: campaign.negativeCount,
          positiveCount: campaign.positiveCount,
          neutralCount: campaign.neutralCount,
          campaignName: campaign.campaignName,
        }
      }
      // check month wise
      if (_.eq(currentMonth, campaign.month)) {
        if (_.isNil(usageStatsMap[`${campaign.databaseID}`].month.projects[`${campaign.projectID}`])) {
          usageStatsMap[`${campaign.databaseID}`].month.acrossProjectsCount += 1
          usageStatsMap[`${campaign.databaseID}`].month.projects[`${campaign.projectID}`] = true
        }
        usageStatsMap[`${campaign.databaseID}`].month.useCount += 1
        if (_.isNil(usageStatsMap[`${campaign.databaseID}`].month.campaigns[`${campaign._id}`])) {
          usageStatsMap[`${campaign.databaseID}`].month.campaigns[`${campaign._id}`] = {
            projectID: campaign.projectID,
            negativeCount: campaign.negativeCount,
            positiveCount: campaign.positiveCount,
            neutralCount: campaign.neutralCount,
            campaignName: campaign.campaignName,
          }
        }
      }
    })
    input.forEach((ele, index) => {
      if (!_.isNil(usageStatsMap[`${ele._id}`])) {
        const data = usageStatsMap[`${ele._id}`]
        if (!_.isArray(data.year.projects)) data.year.projects = _.map(_.keys(data.year.projects), (key) => key)
        if (!_.isArray(data.year.campaigns)) {
          data.year.campaigns = _.map(_.keys(data.year.campaigns), (key) => {
            const {
              projectID, negativeCount, positiveCount, neutralCount, campaignName,
            } = data.year.campaigns[`${key}`]
            return {
              _id: key,
              projectID,
              negativeCount: !_.isNil(negativeCount) ? negativeCount : 0,
              positiveCount: !_.isNil(positiveCount) ? positiveCount : 0,
              neutralCount: !_.isNil(neutralCount) ? neutralCount : 0,
              campaignName: !_.isNil(campaignName) ? campaignName : 'N/A',
            }
          })
        }
        if (!_.isArray(data.month.projects)) data.month.projects = _.map(_.keys(data.month.projects), (key) => key)
        if (!_.isArray(data.month.campaigns)) {
          data.month.campaigns = _.map(_.keys(data.month.campaigns), (key) => {
            const {
              projectID, negativeCount, positiveCount, neutralCount, campaignName,
            } = data.month.campaigns[`${key}`]
            return {
              _id: key,
              projectID,
              negativeCount: !_.isNil(negativeCount) ? negativeCount : 0,
              positiveCount: !_.isNil(positiveCount) ? positiveCount : 0,
              neutralCount: !_.isNil(neutralCount) ? neutralCount : 0,
              campaignName: !_.isNil(campaignName) ? campaignName : 'N/A',
            }
          })
        }
        input[index] = { ...ele, usage: { ...data } } as any
      } else {
        input[index] = {
          ...ele,
          usage: {
            year: {
              useCount: 0, acrossProjectsCount: 0, projects: [], campaigns: [],
            },
            month: {
              useCount: 0, acrossProjectsCount: 0, projects: [], campaigns: [],
            },
          },
        } as any
      }
    })
    return input
  }
}
