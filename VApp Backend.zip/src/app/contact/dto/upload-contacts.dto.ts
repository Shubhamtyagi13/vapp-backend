import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import { Type } from 'class-transformer'
import { ArrayMinSize, IsArray, IsDefined, IsMongoId, IsOptional, IsString, ValidateNested } from 'class-validator'

export class ContactDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsValidPhone()
  readonly phone: number

  @ApiProperty({ required: false })
  @IsOptional()
  @IsMongoId()
  @IsString()
  readonly databaseID: string

  @ApiProperty({ required: false })
  @IsString()
  @IsOptional()
  readonly firstName: string

  @ApiProperty({ required: false })
  @IsString()
  @IsOptional()
  readonly middleName: string

  @ApiProperty({ required: false })
  @IsString()
  @IsOptional()
  readonly lastName: string
}

export class UploadContactDTO extends ClientUserIDDTO {
  @ApiProperty({ required: true })
  @IsString()
  readonly name: string

  @ApiProperty({ required: true })
  @IsArray()
  @ValidateNested({ each: true })
  @ArrayMinSize(1)
  @Type(() => ContactDTO)
  readonly contacts: [ContactDTO]

  @ApiProperty({ required: false })
  @IsString()
  @IsOptional()
  readonly region: string

  @ApiProperty({ required: true })
  @IsString()
  @IsMongoId()
  @IsOptional()
  clientID: string
}
