import { variables } from '@config'
import { getEnvironmentVariable } from '@utils/platform.util'
import fs from 'fs'
import path from 'path'
import xlsx from 'xlsx'
import { Contact } from '../contact.schema'

export const createContactsDirectory = (clientID: string) => {
  const contactsDirectory = `/${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.CONTACT_DIRECTORY.name)}/${clientID}`
  const directoryExists = fs.existsSync(path.join(process.cwd(), contactsDirectory))
  if (!directoryExists) {
    fs.mkdirSync(path.join(process.cwd(), contactsDirectory), { recursive: true })
  }
  return contactsDirectory
}

export const createContactsFile = (directoryPath: string, databaseID: string, contacts: Contact[]) => {
  try {
    const workbook = xlsx.utils.book_new()
    const worksheet = xlsx.utils.json_to_sheet(contacts)
    xlsx.utils.book_append_sheet(workbook, worksheet, 'contacts')
    xlsx.writeFile(workbook, path.join(process.cwd(), directoryPath, `${databaseID}.xlsx`))
  } catch {}
}
