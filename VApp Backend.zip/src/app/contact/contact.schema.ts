import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.CONTACTS.collection, autoCreate: true })
export class Contact extends Document {
  @Prop({ type: String, index: true, required: true })
  databaseID: string

  @Prop({ type: String, default: null })
  firstName: string

  @Prop({ type: String, default: null })
  middleName: string

  @Prop({ type: String, default: null })
  lastName: string

  @Prop({ type: String, required: true, index: true })
  phone: string
}

export const ContactSchema = SchemaFactory.createForClass(Contact)
