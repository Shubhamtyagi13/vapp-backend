import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.TRACKING_UNIQUE_EVENTS.collection, autoCreate: true })
export class TrackingUniqueEvents extends Document {
  @Prop({ type: String, index: true, required: true })
  campaignID: string

  @Prop({ type: [String], required: true })
  events: string[]
}
export const TrackingUniqueEventsSchema = SchemaFactory.createForClass(TrackingUniqueEvents)
