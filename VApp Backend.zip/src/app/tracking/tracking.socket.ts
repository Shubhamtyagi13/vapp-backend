import { variables } from '@config'
import { OnGatewayConnection, OnGatewayDisconnect, OnGatewayInit, WebSocketGateway, WebSocketServer } from '@nestjs/websockets'
import { VappLogger } from '@services/logger.service'
import { Server, Socket } from 'socket.io'
import websocketRedisAdapter from 'socket.io-redis'
import { getAllowedOrigin, getEnvironmentVariable } from '../../common/utils/platform.util'

@WebSocketGateway()
export class TrackingWebSocketGateway implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect {
  constructor(private logger: VappLogger) {}

  @WebSocketServer() server: Server

  afterInit(server: Server) {
    this.logger.log('Init')
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`Client disconnected: ${client.id}`)
  }

  handleConnection(client: Socket, ...args: any[]) {
    this.logger.log(`Client connected: ${client.id}`)
  }
}
