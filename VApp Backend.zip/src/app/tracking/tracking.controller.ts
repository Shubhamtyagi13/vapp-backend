import {
  audience, contentTypes, environments, variables,
} from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import {
  Body, Controller, Get, Header, Param, Post, Query, Req, Res, UseGuards,
} from '@nestjs/common'
import { ApiBearerAuth, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { ParseStringPipe } from '@pipes/parse-string.pipe'
import { deviceDetection, getEnvironmentVariable, getIP } from '@utils/platform.util'
import { Response, Request } from 'express'
import _ from 'lodash'
import { ProjectTrackingDTO } from './dto/project-tracking-report'
import { TourEngagementDTO } from './dto/tour-engagement.dto'
import { TrackingEventDTO } from './dto/tracking-event.dto'
import { TrackingReportDTO } from './dto/tracking-report.dto'
import { TrackingUniqueEventsDTO } from './dto/tracking-unique-events.dto'
import { TrackingDTO } from './dto/tracking.dto'
import { TrackingModule } from './tracking.module'
import { TrackingService } from './tracking.service'

@ApiTags(TrackingController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('interaction')
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class TrackingController {
  constructor(private trackingService: TrackingService) {}

  @Get('expiry/:shortID')
  fetchExpirationTime(@Res() response: Response, @Param('shortID') shortID: string) {
    this.trackingService.fetchExpirationTime(shortID).then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Get('eventset/:campaignID')
  trackingEventSet(@Res() response: Response, @Param('campaignID') campaignID: string) {
    this.trackingService.trackingEventSet(campaignID).then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Header('Content-Type', contentTypes.APPLICATION.JAVASCRIPT)
  @Get('script')
  fetchScript(@Res() response: Response, @Query('apiKey', ParseStringPipe()) apiKey: string) {
    this.trackingService.fetchScript(apiKey).then((service_response) => {
      response.status(service_response.status).write(service_response.data.script)
      response.end()
    })
  }

  @Post('engagement')
  trackEngagement(@Res() response: Response, @Body() engagementObject: TourEngagementDTO, @Req() request: Request) {
    this.trackingService.trackEngagement(engagementObject, getIP(request), deviceDetection(request)).then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Post('interaction-event')
  trackEvent(@Res() response: Response, @Body() trackingObject: TrackingDTO) {
    this.trackingService.trackEvent(trackingObject).then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post('interaction-data/:campaignID')
  trackEventData(@Res() response: Response, @Param('campaignID') campaignID: string, @Body() trackingObject: TrackingEventDTO) {
    this.trackingService.trackEventData(campaignID, trackingObject).then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post('interaction-report')
  trackingReport(@Res() response: Response, @Body() trackingObject: TrackingReportDTO) {
    this.trackingService.trackingsReport(trackingObject).then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post('project-event-report/:projectID')
  projectEventReport(@Res() response: Response, @Param('projectID') projectID: string, @Body() projectTrackingObject: ProjectTrackingDTO) {
    this.trackingService.projectEventReport(projectTrackingObject, projectID).then((service_response) => response.status(service_response.status).send(service_response))
  }
}
