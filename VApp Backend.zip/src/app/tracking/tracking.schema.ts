import { Demographics, DemographicsSchema } from '@app/demographics/demographics.schema'
import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'
import { Events, EventsSchema } from './events.schema'

@Schema({ collection: tables.TRACKING.collection, autoCreate: true })
export class Tracking extends Document {
  @Prop({ type: String, index: true, required: true })
  requestID: string

  @Prop({ type: String, index: true, required: true })
  campaignID: string

  @Prop({ type: String, index: true, required: true })
  engagementID: string

  @Prop({ type: String, index: true, required: true })
  shortID: string

  @Prop({ type: [EventsSchema], default: [], indexes: EventsSchema.indexes })
  events: [Events]

  @Prop({ type: String })
  name: string

  @Prop({ type: String })
  projectID: string

  @Prop({ type: String })
  clientID: string

  @Prop({ type: Number })
  smsStatus: number

  @Prop({ type: Number })
  year: number

  @Prop({ type: Number })
  month: number

  @Prop({ type: Number })
  day: number

  @Prop({ type: Number })
  phone: number

  @Prop({ type: String, default: null })
  device: string

  @Prop({ type: String, default: null })
  deviceType: string

  @Prop({ type: String, default: null })
  os: string

  @Prop({ type: DemographicsSchema, default: null })
  demographics: Demographics
}
export const TrackingSchema = SchemaFactory.createForClass(Tracking)
