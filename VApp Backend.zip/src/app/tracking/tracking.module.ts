import { Campaign, CampaignSchema } from '@app/campaign/campaign.schema'
import { CreateSMSCampaignQueueModule, CreateRBMCampaignQueueModule, EngagementTrackingQueueModule } from '@app/campaign/cron/queue.module'
import { ContactDatabase, ContactDatabaseSchema } from '@app/contact/contact.database.schema'
import { Contact, ContactSchema } from '@app/contact/contact.schema'
import { Dashboard, DashboardSchema } from '@app/dashboard/dashboard.schema'
import { DashboardTrendingStore, DashboardTrendingStoreSchema } from '@app/dashboard/dashboard.trending.schema'
import { Link, LinkSchema } from '@app/link/link.schema'
import { Projects, ProjectsSchema } from '@app/projects/projects.schema'
import { ProjectTrendingEngagementsSchema, ProjectTrendingEngagementsSchemaStore } from '@app/projects/projects.trending.engagement.schema'
import { Requests, RequestsSchema } from '@app/requests/requests.schema'
import { Template, TemplateSchema } from '@app/template/template.schema'
import { User, UserSchema } from '@app/user/user.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { QueueUIProvider } from './cron/queue.ui'
import { TrackingUniqueEvents, TrackingUniqueEventsSchema } from './tracking-unique-event.schema'
import { TrackingController } from './tracking.controller'
import { Tracking, TrackingSchema } from './tracking.schema'
import { TrackingService } from './tracking.service'

@Module({
  imports: [
    CreateSMSCampaignQueueModule,
    CreateRBMCampaignQueueModule,
    EngagementTrackingQueueModule,
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Contact.name, schema: ContactSchema },
      { name: ContactDatabase.name, schema: ContactDatabaseSchema },
      { name: Requests.name, schema: RequestsSchema },
      { name: Projects.name, schema: ProjectsSchema },
      { name: Campaign.name, schema: CampaignSchema },
      { name: Link.name, schema: LinkSchema },
      { name: Template.name, schema: TemplateSchema },
      { name: DashboardTrendingStore.name, schema: DashboardTrendingStoreSchema },
      { name: Dashboard.name, schema: DashboardSchema },
      { name: ProjectTrendingEngagementsSchemaStore.name, schema: ProjectTrendingEngagementsSchema },
      { name: Tracking.name, schema: TrackingSchema },
      { name: TrackingUniqueEvents.name, schema: TrackingUniqueEventsSchema },
    ]),
  ],
  controllers: [TrackingController],
  providers: [TrackingService, VappLogger, QueueUIProvider],
})
export class TrackingModule {}
