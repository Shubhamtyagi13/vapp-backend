import { Campaign } from '@app/campaign/campaign.schema'
import { ContactDatabase } from '@app/contact/contact.database.schema'
import {
  DashboardTrendingDatabase,
  DashboardTrendingLink,
  DashboardTrendingProject,
  DashboardTrendingStore,
  DashboardTrendingTemplate,
} from '@app/dashboard/dashboard.trending.schema'
import { Link } from '@app/link/link.schema'
import { Projects } from '@app/projects/projects.schema'
import { ProjectTrendingEngagementsSchemaStore } from '@app/projects/projects.trending.engagement.schema'
import { Requests } from '@app/requests/requests.schema'
import { Template } from '@app/template/template.schema'
import { TourEngagementDTO } from '@app/tracking/dto/tour-engagement.dto'
import { constants } from '@config'
import { EngagementLevel, TrendsEngagement } from '@interfaces/engagement.interface'
import { GenericObject } from '@interfaces/generic.interface'
import { messages } from '@messages'
import { createOperations, findOperations } from '@utils/crud.util'
import _ from 'lodash'
import { Model } from 'mongoose'

export const upadateRequestEngagement = (
  requestModel: Model<Requests>,
  payload: TourEngagementDTO,
  requestEngagementUpdateObject: GenericObject,
) => createOperations.updateOne(requestModel, {
  shortID: payload.requestID,
  'engagementTime.engagementID': payload.engagementID,
}, {
  $inc: { 'engagementTime.$.time': payload.time },
  $set: requestEngagementUpdateObject,
})

export const updateProjectEngagement = (projectsModel: Model<Projects>, request: Requests, engagementIncrementObject: GenericObject) => new Promise((resolve, reject) => {
  createOperations.updateOne(projectsModel, { _id: request.projectID }, { $inc: engagementIncrementObject }).then((project) => {
    if (!_.isNil(project)) {
      resolve(project)
    } else {
      reject({ request, message: messages.INT015.message })
    }
  })
})

export const updateCampaignEngagement = (campaignModel: Model<Campaign>, request: Requests, engagementIncrementObject: GenericObject) => new Promise((resolve, reject) => {
  createOperations.updateOne(campaignModel, { _id: request.campaignID }, { $inc: engagementIncrementObject }).then((campaign) => {
    if (!_.isNil(campaign)) {
      resolve(campaign)
    } else {
      reject({ request, message: messages.INT016.message })
    }
  })
})

export const updateCommonEngagement = (
  databaseModel: Model<ContactDatabase>,
  templateModel: Model<Template>,
  linkModel: Model<Link>,
  templateID: string,
  linkID: string,
  databaseID: string,
  clientID: string,
  engagementIncrementObject: GenericObject,
) => new Promise<{
    templates: Template[]
    contactsDatabases: ContactDatabase[]
    links: Link[]
  }>(async (resolve, reject) => {
    let templates: Template[]
    let contactsDatabases: ContactDatabase[]
    let links: Link[]
    try {
      if (!_.isNil(databaseID)) {
        await createOperations.updateOne(databaseModel, { _id: databaseID }, { $inc: engagementIncrementObject })
        contactsDatabases = await findOperations.find(databaseModel, { clientID }, { __v: 0, password: 0 }, {})
      }
    } catch (error) {
      reject(error)
    }
    try {
      if (!_.isNil(templateID)) {
        await createOperations.updateOne(templateModel, { _id: templateID }, { $inc: engagementIncrementObject })
        templates = await findOperations.find(templateModel, { clientID }, { __v: 0, password: 0 }, {})
      }
    } catch (error) {
      reject(error)
    }
    try {
      if (!_.isNil(linkID)) {
        await createOperations.updateOne(linkModel, { _id: linkID }, { $inc: engagementIncrementObject })
        links = await findOperations.find(linkModel, { clientID }, { __v: 0, password: 0 }, {})
      }
    } catch (error) {
      reject(error)
    }
    resolve({ templates, links, contactsDatabases })
  })

export const updateProjectTrendsModel = (
  projectTrendsModel: Model<ProjectTrendingEngagementsSchemaStore>,
  request: Requests,
  projectTrendObject: TrendsEngagement,
) => createOperations.updateOneUpsert(projectTrendsModel, {
  clientID: request.clientID,
  year: new Date().getFullYear(),
  month: new Date().getMonth() + 1,
  projectID: request.projectID,
}, { $push: { trendingEngagements: projectTrendObject } })

export const getEngagementIncrementObject = (request: Requests, payload: TourEngagementDTO, isRecurringEngagement: boolean) => {
  if (_.eq(request.type, constants.CAMPAIGN_TYPES.SMS.value)) {
    return {
      engagementTotal: isRecurringEngagement ? 1 : 0,
      engagementSum: payload.time,
      smsEngagementSum: payload.time,
      smsEngagementTotal: isRecurringEngagement ? 1 : 0,
    }
  } if (_.eq(request.type, constants.CAMPAIGN_TYPES.WHATSAPP.value)) {
    return {
      engagementTotal: isRecurringEngagement ? 1 : 0,
      engagementSum: payload.time,
      whatsappEngagementSum: payload.time,
      whatsappEngagementTotal: isRecurringEngagement ? 1 : 0,
    }
  }
}

export const getDashboardTrendingProjects = (
  dashboardTrendingStore: DashboardTrendingStore,
  requestUpdateResult: Requests,
  projectUpdateResult: Projects,
  data: any,
  engagementLevelObject: EngagementLevel,
) => {
  let dashboardTrendingProjects: DashboardTrendingProject[] = [] as DashboardTrendingProject[]
  if (!_.isNil(dashboardTrendingStore.trendingProjects) && dashboardTrendingStore.trendingProjects.length > 0) {
    dashboardTrendingProjects = dashboardTrendingStore.trendingProjects
  }
  const requestProjectIndex = _.findIndex(dashboardTrendingProjects, (project) => _.eq(project.projectID, requestUpdateResult.projectID))
  if (_.eq(requestProjectIndex, -1)) {
    const trendingProjectObject: DashboardTrendingProject = {} as DashboardTrendingProject
    trendingProjectObject.projectID = requestUpdateResult.projectID
    trendingProjectObject.projectName = projectUpdateResult.name
    trendingProjectObject.engagementSum = Number(data.time)
    trendingProjectObject.negativeCount = engagementLevelObject.negativeCount
    trendingProjectObject.neutralCount = engagementLevelObject.neutralCount
    trendingProjectObject.positiveCount = engagementLevelObject.positiveCount
    dashboardTrendingProjects.push(trendingProjectObject)
  } else {
    dashboardTrendingProjects[requestProjectIndex].engagementSum += Number(data.time)
    dashboardTrendingProjects[requestProjectIndex].negativeCount += engagementLevelObject.negativeCount
    dashboardTrendingProjects[requestProjectIndex].neutralCount += engagementLevelObject.neutralCount
    dashboardTrendingProjects[requestProjectIndex].positiveCount += engagementLevelObject.positiveCount
  }
  return dashboardTrendingProjects
}

export const getDashboardTrendingTemplate = (
  dashboardTrendingStore: DashboardTrendingStore,
  templateObject: Template,
  data: any,
  engagementLevelObject: EngagementLevel,
) => {
  let dashboardTrendingTemplates: DashboardTrendingTemplate[] = [] as DashboardTrendingTemplate[]
  if (!_.isNil(dashboardTrendingStore.trendingTemplates) && dashboardTrendingStore.trendingTemplates.length > 0) {
    dashboardTrendingTemplates = dashboardTrendingStore.trendingTemplates
  }
  const requestTemplateIndex = _.findIndex(dashboardTrendingTemplates, (template) => _.eq(template.templateID, templateObject.id))
  if (_.eq(requestTemplateIndex, -1)) {
    const trendingTemplateObject: DashboardTrendingTemplate = {} as DashboardTrendingTemplate
    trendingTemplateObject.templateID = templateObject.id
    trendingTemplateObject.templateName = templateObject.name
    trendingTemplateObject.engagementSum = Number(data.time)
    trendingTemplateObject.negativeCount = engagementLevelObject.negativeCount
    trendingTemplateObject.neutralCount = engagementLevelObject.neutralCount
    trendingTemplateObject.positiveCount = engagementLevelObject.positiveCount
    dashboardTrendingTemplates.push(trendingTemplateObject)
  } else {
    dashboardTrendingTemplates[requestTemplateIndex].engagementSum += Number(data.time)
    dashboardTrendingTemplates[requestTemplateIndex].negativeCount += engagementLevelObject.negativeCount
    dashboardTrendingTemplates[requestTemplateIndex].neutralCount += engagementLevelObject.neutralCount
    dashboardTrendingTemplates[requestTemplateIndex].positiveCount += engagementLevelObject.positiveCount
  }
  return dashboardTrendingTemplates
}

export const getDashboardTrendingLink = (dashboardTrendingStore: DashboardTrendingStore, linkObject: Link, data: any, engagementLevelObject: EngagementLevel) => {
  let dashboardTrendingLinks: DashboardTrendingLink[] = [] as DashboardTrendingLink[]
  if (!_.isNil(dashboardTrendingStore.trendingLinks) && dashboardTrendingStore.trendingLinks.length > 0) {
    dashboardTrendingLinks = dashboardTrendingStore.trendingLinks
  }
  const requestLinkIndex = _.findIndex(dashboardTrendingLinks, (link) => _.eq(link.linkID, linkObject.id))
  if (_.eq(requestLinkIndex, -1)) {
    const trendingLinkObject: DashboardTrendingLink = {} as DashboardTrendingLink
    trendingLinkObject.linkID = linkObject.id
    trendingLinkObject.linkName = linkObject.name
    trendingLinkObject.url = linkObject.url
    trendingLinkObject.engagementSum = Number(data.time)
    trendingLinkObject.negativeCount = engagementLevelObject.negativeCount
    trendingLinkObject.neutralCount = engagementLevelObject.neutralCount
    trendingLinkObject.positiveCount = engagementLevelObject.positiveCount
    dashboardTrendingLinks.push(trendingLinkObject)
  } else {
    dashboardTrendingLinks[requestLinkIndex].engagementSum += Number(data.time)
    dashboardTrendingLinks[requestLinkIndex].negativeCount += engagementLevelObject.negativeCount
    dashboardTrendingLinks[requestLinkIndex].neutralCount += engagementLevelObject.neutralCount
    dashboardTrendingLinks[requestLinkIndex].positiveCount += engagementLevelObject.positiveCount
  }
  return dashboardTrendingLinks
}

export const getDashboardTrendingDatabases = (
  dashboardTrendingStore: DashboardTrendingStore,
  databaseObject: ContactDatabase,
  data: any,
  engagementLevelObject: EngagementLevel,
) => {
  let dashboardTrendingDatabases: DashboardTrendingDatabase[] = [] as DashboardTrendingDatabase[]
  if (!_.isNil(dashboardTrendingStore.trendingDatabases) && dashboardTrendingStore.trendingDatabases.length > 0) {
    dashboardTrendingDatabases = dashboardTrendingStore.trendingDatabases
  }
  const requestDatabasesIndex = _.findIndex(dashboardTrendingDatabases, (database) => _.eq(database.databaseID, databaseObject.id))
  if (_.eq(requestDatabasesIndex, -1)) {
    const trendingDatabasesObject: DashboardTrendingDatabase = {} as DashboardTrendingDatabase
    trendingDatabasesObject.databaseID = databaseObject.id
    trendingDatabasesObject.databaseName = databaseObject.name
    trendingDatabasesObject.engagementSum = Number(data.time)
    trendingDatabasesObject.negativeCount = engagementLevelObject.negativeCount
    trendingDatabasesObject.neutralCount = engagementLevelObject.neutralCount
    trendingDatabasesObject.positiveCount = engagementLevelObject.positiveCount
    dashboardTrendingDatabases.push(trendingDatabasesObject)
  } else {
    dashboardTrendingDatabases[requestDatabasesIndex].engagementSum += Number(data.time)
    dashboardTrendingDatabases[requestDatabasesIndex].negativeCount += engagementLevelObject.negativeCount
    dashboardTrendingDatabases[requestDatabasesIndex].neutralCount += engagementLevelObject.neutralCount
    dashboardTrendingDatabases[requestDatabasesIndex].positiveCount += engagementLevelObject.positiveCount
  }
  return dashboardTrendingDatabases
}
