import { findOperations } from '@utils/crud.util'
import { Model } from 'mongoose'
import _ from 'lodash'
import { Requests } from '@app/requests/requests.schema'
import { GenericObject } from '@interfaces/generic.interface'
import { ProjectReport } from '@interfaces/report.interface'
import { Events } from '../events.schema'
import { Tracking } from '../tracking.schema'

export const getTrackingCollection = (campaignID: string, trackingModel: Model<Tracking>, callback: (error: Error | null, data?: [Tracking]) => void) => {
  findOperations
    .find(trackingModel, { campaignID })
    .then((trackingResults: [Tracking]) => {
      if (!_.isNil(trackingResults)) {
        callback(null, trackingResults)
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      // logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_PROJECT_DASHBOARD_DATA, { clientID, projectID }, error.message))
      callback(null)
    })
}

export const getRequestCollection = (campaignID: string, requestModel: Model<Requests>, callback: (error: Error | null, data?: [Requests]) => void) => {
  findOperations
    .find(requestModel, { campaignID })
    .then((requestResults: [Requests]) => {
      if (!_.isNil(requestResults)) {
        callback(null, requestResults)
      } else {
        callback(null)
      }
    })
    .catch((error: Error) => {
      // logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_PROJECT_DASHBOARD_DATA, { clientID, projectID }, error.message))
      callback(null)
    })
}

export const getTrackingEventsData = (trackingData: Tracking[]) : ProjectReport[] => {
  const map = new Map()
  trackingData.forEach((eventData: Tracking) => {
    eventData.events.forEach((data: Events) => {
      let set = new Set<number>()
      if (!_.isNil(map.get(data.eventName))) {
        set = map.get(data.eventName)
      }
      set.add(eventData.phone)
      map.set(data.eventName, set)
    })
  })
  const finalEventDataObject: ProjectReport[] = []

  for (const key of map.keys()) {
    finalEventDataObject.push(
      {
        eventName: key,
        phones:  Array.from(map.get(key))
      }
    )
  }
  return finalEventDataObject
}
