import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsMongoId, IsNumber, IsOptional, IsString } from 'class-validator'

export class TrackingDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  requestID: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  campaignID: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  engagementID: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  shortID: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  event: string

  @ApiProperty()
  @IsOptional()
  @IsString()
  identification: string
}
