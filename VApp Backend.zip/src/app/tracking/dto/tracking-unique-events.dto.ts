import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsMongoId, IsNumber, IsNumberString, IsOptional, IsString, Length, Max } from 'class-validator'

export class TrackingUniqueEventsDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  event: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  campaignID: string
}
