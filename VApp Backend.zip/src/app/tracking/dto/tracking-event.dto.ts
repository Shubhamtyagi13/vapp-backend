import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsMongoId, IsNumber, IsNumberString, IsOptional, IsString, Length, Max } from 'class-validator'

export class TrackingEventDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  pageNumber: number

  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  numberOfItems: number

  @IsOptional()
  @ApiProperty()
  @Length(3, 10)
  @IsNumberString()
  regexString: string
}
