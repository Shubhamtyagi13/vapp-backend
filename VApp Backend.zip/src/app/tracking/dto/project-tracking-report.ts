import { ApiProperty } from '@nestjs/swagger'
import { ArrayMinSize, IsArray, IsBoolean, IsDefined, IsMongoId, IsNumber, IsNumberString, IsOptional, IsString, Length, Max } from 'class-validator'

export class ProjectTrackingDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsNumber()
  month: number
}
