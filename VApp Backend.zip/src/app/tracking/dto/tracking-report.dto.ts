import { ApiProperty } from '@nestjs/swagger'
import { ArrayMinSize, IsArray, IsBoolean, IsDefined, IsMongoId, IsNumber, IsNumberString, IsOptional, IsString, Length, Max } from 'class-validator'

export class TrackingReportDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsArray()
  @IsString({ each: true })
  @ArrayMinSize(1)
  events: string[]

  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  campaignID: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsBoolean()
  mustHave: boolean
}
