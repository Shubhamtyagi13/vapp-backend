import { DeviceInfo } from '@interfaces/demographics.interface'
import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsMongoId, IsNumber, IsOptional, IsString } from 'class-validator'

export class TourEngagementDTO {
  @ApiProperty()
  @IsDefined()
  @IsString()
  requestID: string

  @ApiProperty()
  @IsDefined()
  @IsNumber()
  time: number

  @ApiProperty()
  @IsDefined()
  @IsString()
  // @IsMongoId()
  engagementID: string

  @ApiProperty({ required: false })
  @IsString()
  @IsOptional()
  socketID?: string

  @ApiProperty({ required: false })
  @IsString()
  @IsOptional()
  ip?: string

  @ApiProperty({ required: false })
  @IsString()
  @IsOptional()
  deviceDetection?: DeviceInfo
}
