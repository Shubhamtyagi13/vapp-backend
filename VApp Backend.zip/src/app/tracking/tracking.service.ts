import { Requests } from '@app/requests/requests.schema'
import { User } from '@app/user/user.schema'
import {
  canonicalMethods, constants, cronJobs, redisKeys,
} from '@config'
import { SMSRequestRedis } from '@interfaces/request.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { InjectQueue } from '@nestjs/bull'
import { HttpStatus, Inject, Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import {
  epochTimeFromDate, getAPIResponse, getErrorLog, getSanatisedName,
} from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import { Queue } from 'bull'
import fs from 'fs'
import _ from 'lodash'
import { Model } from 'mongoose'
import path from 'path'
import async from 'async'
import { DeviceInfo } from '@interfaces/demographics.interface'
import { TourEngagementDTO } from './dto/tour-engagement.dto'
import { TrackingEventDTO } from './dto/tracking-event.dto'
import { TrackingDTO } from './dto/tracking.dto'
import { getRequestCollection, getTrackingCollection, getTrackingEventsData } from './helper/tracking-data.helper'
import { Tracking } from './tracking.schema'
import { TrackingUniqueEventsDTO } from './dto/tracking-unique-events.dto'
import { TrackingUniqueEvents } from './tracking-unique-event.schema'
import { TrackingReportDTO } from './dto/tracking-report.dto'
import { ProjectTrackingDTO } from './dto/project-tracking-report'

@Injectable()
export class TrackingService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    private logger: VappLogger,
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(Tracking.name) private trackingsModel: Model<Tracking>,
    @InjectModel(Requests.name) private requestModel: Model<Requests>,
    @InjectModel(TrackingUniqueEvents.name) private trackingUniqueEventsModel: Model<TrackingUniqueEvents>,
    @InjectQueue(cronJobs.ENGAGEMENT_TRACKING.name) private engagementTrackingQueue: Queue,
  ) {
    this.traceID = vapp_context.traceID
  }

  fetchExpirationTime(shortID: string) {
    return new Promise<ServiceResponse>((resolve) => {
      RedisHandler.getInstance().get(redisKeys.CAMPAIGN_REQUEST.value(shortID), (error: Error, data: string) => {
        if (_.isNil(error) && !_.isNil(data)) {
          const smsRequestPayload = JSON.parse(data) as SMSRequestRedis
          RedisHandler.getInstance().ttl(redisKeys.CAMPAIGN_REQUEST.value(shortID), (error: Error, time: number) => {
            if (_.isNil(error)) {
              if (_.eq(time, -2) || _.lt(time, 0)) {
                resolve(getAPIResponse(messages.TRACK002.code, this.traceID, HttpStatus.BAD_REQUEST))
              }
              try {
                const expirationDate = new Date()
                expirationDate.setSeconds(expirationDate.getSeconds() + time)
                const expirationTimeStamp = epochTimeFromDate(expirationDate)
                resolve(getAPIResponse(messages.TRACK001.code, this.traceID, HttpStatus.OK, { ...{ expiration: expirationTimeStamp }, ...smsRequestPayload }))
              } catch (error) {
                this.logger.error(getErrorLog(canonicalMethods.FETCH_TRACKING_SCRIPT_EXPIRATION, this.traceID, { shortID, error }, error.message))
                resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              }
            }
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
        } else {
          resolve(getAPIResponse(messages.TRACK002.code, this.traceID, HttpStatus.BAD_REQUEST))
        }
      })
    })
  }

  fetchScript(apiKey: string) {
    return new Promise<ServiceResponse>((resolve) => {
      if (_.isNil(apiKey)) {
        resolve(getAPIResponse(messages.TRACK003.code, this.traceID, HttpStatus.BAD_REQUEST))
      }
      RedisHandler.getInstance().get(redisKeys.USER_API_KEY.value(apiKey), (error: Error, data: string) => {
        if (_.isNil(error) && !_.isNil(data)) {
          resolve(
            getAPIResponse(messages.TRACK005.code, this.traceID, HttpStatus.OK, {
              script: fs.readFileSync(path.join(process.cwd(), 'scripts/tracking/', 'tracking.min.js'), 'utf8').replace('API_KEY', apiKey),
            }),
          )
        } else {
          findOperations
            .findOne(this.userModel, { apiKey })
            .then((user: User) => {
              if (!_.isNil(user)) {
                RedisHandler.getInstance().set(redisKeys.USER_API_KEY.value(apiKey), JSON.stringify({ apiKey }))
                RedisHandler.getInstance().expire(redisKeys.USER_API_KEY.value(apiKey), redisKeys.USER_API_KEY.timeout())
                resolve(
                  getAPIResponse(messages.TRACK005.code, this.traceID, HttpStatus.OK, {
                    script: fs.readFileSync(path.join(process.cwd(), 'scripts/tracking/', 'tracking.min.js'), 'utf8').replace('API_KEY', apiKey),
                  }),
                )
              } else {
                resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              }
            })
            .catch((error) => {
              this.logger.error(getErrorLog(canonicalMethods.FETCH_TRACKING_SCRIPT, this.traceID, { apiKey, error }, error.message))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            })
        }
      })
    })
  }

  trackEngagement(payload: TourEngagementDTO, ip: string, deviceDetection: DeviceInfo) {
    return new Promise<ServiceResponse>((resolve) => {
      payload.ip = ip
      payload.deviceDetection = deviceDetection
      this.engagementTrackingQueue.add({ payload, traceID: this.traceID }).catch((error: Error) => {
        this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_CONTACTS, this.traceID, { payload }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
      resolve(getAPIResponse(messages.TRACK001.code, this.traceID, HttpStatus.OK))
    })
  }

  trackingEventSet(campaignID) {
    return new Promise<ServiceResponse>((resolve) => {
      findOperations
        .findOne(this.trackingUniqueEventsModel, { campaignID }, { events: 1 })
        .then((trackEventsResult) => {
          resolve(getAPIResponse(messages.TRACK008.code, this.traceID, HttpStatus.OK, !_.isNil(trackEventsResult?.events) ? trackEventsResult.events : []))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.TRACK_GET_UNIQUE_EVENT, this.traceID, null, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })
  }

  trackingsReport(payload: TrackingReportDTO) {
    return new Promise<ServiceResponse>((resolve) => {
      const { campaignID, events, mustHave } = payload
      let query
      if (mustHave) query = { 'sessions.events.eventName': { $all: events } }
      else query = { 'sessions.events.eventName': { $in: events } }

      findOperations
        .aggregate(this.trackingsModel, [
          {
            $match: {
              campaignID,
            },
          },
          {
            $project: {
              _id: '$_id',
              projectID: 1,
              campaignID: 1,
              phone: 1,
              name: 1,
              month: 1,
              year: 1,
              day: 1,
              requestID: 1,
              shortID: 1,
              device: 1,
              deviceType: 1,
              os: 1,
              demographics: 1,
              engagementID: 1,
              events: 1,
            },
          },
          {
            $addFields: {
              sessions: {
                events: '$events',
                engagementID: '$engagementID',
                device: '$device',
                deviceType: '$deviceType',
                os: '$os',
                demographics: '$demographics',
              },
            },
          },
          {
            $group: {
              _id: '$requestID',
              phone: { $first: '$phone' },
              campaignID: { $first: '$campaignID' },
              name: { $first: '$name' },
              sessions: { $push: '$sessions' },
            },
          },
          {
            $match: query,
          },
        ])
        .then((reportResult) => {
          resolve(getAPIResponse(messages.TRACK009.code, this.traceID, HttpStatus.OK, reportResult))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.TRACK_GET_UNIQUE_EVENT, this.traceID, { payload }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })
  }

  projectEventReport(payload: ProjectTrackingDTO, projectID: string) {
    return new Promise<ServiceResponse>(async (resolve) => {
      const { month } = payload
      const year = new Date().getFullYear()
      try {
        const trackingData = (await findOperations.find(this.trackingsModel, {
          projectID,
          month,
          year,
        })) as Tracking[]
        const projectReport = getTrackingEventsData(trackingData)
        resolve(getAPIResponse(messages.TRACK009.code, this.traceID, HttpStatus.OK, projectReport))
      } catch (error) {
        this.logger.error(getErrorLog(canonicalMethods.TRACK_GET_UNIQUE_EVENT, this.traceID, { payload }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      }
    })
  }

  trackEvent(payload: TrackingDTO) {
    return new Promise<ServiceResponse>((resolve) => {
      const {
        requestID, shortID, campaignID, engagementID, event, identification,
      } = payload
      createOperations
        .updateOneUpsert(this.trackingUniqueEventsModel, { campaignID }, {
          $addToSet: { events: event },
          $set: {
            campaignID,
          },
        })
        .then(() => {
          findOperations.findById(this.requestModel, requestID, { engagementTime: 0 }).then((requestResult: Requests) => {
            createOperations
              .updateOneUpsert(this.trackingsModel, {
                requestID, shortID, campaignID, engagementID,
              }, {
                $push: { events: { eventName: event, identification } },
                $set: {
                  requestID,
                  shortID,
                  campaignID,
                  engagementID,
                  name: getSanatisedName(requestResult.firstName, requestResult.middleName, requestResult.lastName),
                  smsStatus: requestResult.smsStatus,
                  projectID: requestResult.projectID,
                  clientID: requestResult.clientID,
                  year: requestResult.year,
                  month: requestResult.month,
                  day: requestResult.day,
                  phone: requestResult.phone,
                  device: requestResult.device,
                  deviceType: requestResult.deviceType,
                  os: requestResult.os,
                  demographics: requestResult.demographics,
                },
              })
              .then(() => {
                resolve(getAPIResponse(messages.TRACK006.code, this.traceID, HttpStatus.OK))
              })
              .catch((error: Error) => {
                this.logger.error(getErrorLog(canonicalMethods.TRACK_EVENT_RECORD, this.traceID, { payload }, error.message))
                resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              })
          })
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.TRACK_UNIQUE_EVENT, this.traceID, { payload }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })
  }

  trackEventData(campaignID: string, payload: TrackingEventDTO) {
    return new Promise<ServiceResponse>((resolve) => {
      const { pageNumber, numberOfItems } = payload
      let { regexString } = payload
      if (!regexString) regexString = ''
      const regex = new RegExp(regexString)
      let totalLength
      findOperations
        .find(this.trackingsModel, {
          campaignID,
          $expr: {
            $regexMatch: {
              input: { $toString: { $toLong: '$phone' } },
              regex,
            },
          },
        })
        .then((res) => {
          res = _.groupBy(res, 'requestID')
          totalLength = Object.keys(res).length

          findOperations
            .aggregate(this.trackingsModel, [
              {
                $match: {
                  campaignID,
                  $expr: {
                    $regexMatch: {
                      input: { $toString: { $toLong: '$phone' } },
                      regex,
                    },
                  },
                },
              },
              {
                $project: {
                  _id: '$_id',
                  projectID: 1,
                  campaignID: 1,
                  phone: 1,
                  name: 1,
                  month: 1,
                  year: 1,
                  day: 1,
                  requestID: 1,
                  shortID: 1,
                  device: 1,
                  deviceType: 1,
                  os: 1,
                  demographics: 1,
                  engagementID: 1,
                  events: 1,
                },
              },
              {
                $addFields: {
                  sessions: {
                    events: '$events',
                    engagementID: '$engagementID',
                    device: '$device',
                    deviceType: '$deviceType',
                    os: '$os',
                    demographics: '$demographics',
                  },
                },
              },
              {
                $group: {
                  _id: '$requestID',
                  phone: { $first: '$phone' },
                  campaignID: { $first: '$campaignID' },
                  name: { $first: '$name' },
                  sessions: { $push: '$sessions' },
                },
              },
              {
                $sort: { _id: 1 },
              },
              {
                $skip: (pageNumber - 1) * numberOfItems,
              },
              {
                $limit: numberOfItems,
              },
            ])
            .then((result) => {
              resolve(getAPIResponse(messages.TRACK007.code, this.traceID, HttpStatus.OK, { data: result, length: totalLength }))
            })
            .catch((error: Error) => {
              this.logger.error(getErrorLog(canonicalMethods.TRACK_EVENT_RECORD, this.traceID, { payload }, error.message))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            })
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.TRACK_EVENT_RECORD, this.traceID, { payload }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })
  }
}
