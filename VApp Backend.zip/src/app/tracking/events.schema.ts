import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ _id: true })
export class Events extends Document {
  @Prop({ type: String })
  identification: string

  @Prop({ type: String, required: true })
  eventName: string
}
export const EventsSchema = SchemaFactory.createForClass(Events)

// EventsSchema.index({ eventName: 'text', identification: 'text' })
