import { ApiProperty } from '@nestjs/swagger'
import { Transform, Type } from 'class-transformer'
import { IsBoolean, IsDefined, IsOptional, IsString, ValidateNested } from 'class-validator'
import _ from 'lodash'
import { BaseCampaignDTO } from './base-campaign-dto'
import { SingleContactDTO } from './bulk-campaign-dto'

export class WhatsappCampaignDTO extends BaseCampaignDTO {
  @ApiProperty({ required: true })
  @ValidateNested({ each: true })
  @Transform(({ value }) => (_.isString(value) ? JSON.parse(value) : value))
  @Type(() => SingleContactDTO)
  @IsDefined()
  contacts: SingleContactDTO[]

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  channelID: string

  @IsOptional()
  @Transform(({ value }) => JSON.parse(value) || false)
  @IsBoolean()
  persistSession?: boolean

  @IsOptional()
  @Transform(({ value }) => JSON.parse(value) || false)
  @IsBoolean()
  isCaptionMessage?: boolean

  @ApiProperty({ type: 'file' })
  @IsOptional()
  files: any
}
