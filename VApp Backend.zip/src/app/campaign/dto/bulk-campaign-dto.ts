import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import { Type } from 'class-transformer'
import { IsDefined, IsNumber, IsOptional, IsString, ValidateNested } from 'class-validator'
import { BaseCampaignDTO } from './base-campaign-dto'

export class SingleContactDTO {
  @ApiProperty({ required: true })
  @IsNumber()
  @IsDefined()
  @IsValidPhone()
  phone: number

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  firstName: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  lastName: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  middleName: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  var1: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  var2: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  var3: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  var4: string
}

export class BulkCampaignDTO extends BaseCampaignDTO {
  @ApiProperty({ required: true })
  @ValidateNested({ each: true })
  @Type(() => SingleContactDTO)
  @IsDefined()
  contacts: SingleContactDTO[]
}
