import { report_types, smpp_client } from '@config'
import { campaignProviderObject } from '@interfaces/sms.interface'
import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import { Type } from 'class-transformer'
import {
  IsArray, IsBoolean, IsDefined, IsEnum, IsNumber, IsOptional, IsString,
} from 'class-validator'

export class CampaignProviderObject {
  @ApiProperty({ required: true })
  @IsNumber()
  @IsDefined()
  @IsValidPhone()
  readonly phone: number

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly message: string
}

export class TestSMPPDTO {
  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly smpp_config: string

  @ApiProperty({ required: true })
  @Type(() => CampaignProviderObject)
  @IsArray()
    data: Array<campaignProviderObject>

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly smsSenderID: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly templateID: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly peID: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly campaignID: string
}

export class ProcessSMPPDTO {
  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly smpp_config: string

  @ApiProperty({ required: true })
  @Type(() => CampaignProviderObject)
  @IsArray()
    data: Array<campaignProviderObject>

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly smsSenderID: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly templateID: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly peID: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly campaignID: string

  @ApiProperty({ required: true })
  @IsEnum(report_types)
  @IsDefined()
  readonly reportType: report_types
}
