import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsValidIVR } from '@transformers/ivr.transformer'
import { Transform, Type } from 'class-transformer'
import { IsBoolean, IsDateString, IsDefined, IsMongoId, IsNumber, IsOptional, IsString, IsUrl } from 'class-validator'
//
export class BaseCampaignDTO extends ClientUserIDDTO {
  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  message: string

  @ApiProperty({ required: false })
  @IsString()
  @IsDefined()
  dripmessage: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  campaignName: string

  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value))
  @IsBoolean()
  @IsDefined()
  cloud: boolean

  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value))
  @IsBoolean()
  @IsDefined()
  redirection: boolean

  @ApiProperty()
  @IsOptional()
  @IsUrl({ protocols: ['http', 'https'], require_protocol: true, require_host: true })
  url: string

  @ApiProperty({ required: true })
  @Transform(({ value }) => JSON.parse(value) || false)
  @IsBoolean()
  @IsDefined()
  tracking: boolean

  @ApiProperty({ required: true })
  @Transform(({ value }) => JSON.parse(value) || false)
  @IsBoolean()
  @IsDefined()
  dynamic: boolean

  @ApiProperty({ required: false })
  @IsString()
  @IsOptional()
  @IsMongoId()
  databaseID: string

  @ApiProperty()
  @IsString()
  @IsOptional()
  @IsMongoId()
  templateID: string

  @ApiProperty()
  @IsString()
  @IsOptional()
  @IsMongoId()
  dripTemplateID: string

  @ApiProperty()
  @IsString()
  @IsOptional()
  @IsMongoId()
  dripCriteriaID: string

  @ApiProperty({ required: false })
  @IsMongoId()
  @IsOptional()
  @IsString()
  linkID: string

  @ApiProperty({ required: false })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @IsValidIVR()
  ivr: number

  @ApiProperty({ required: false })
  @IsOptional()
  @IsDateString()
  scheduleDate: Date

  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value) || false)
  @IsBoolean()
  @IsOptional()
  whatsappButton: boolean

  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value) || false)
  @IsBoolean()
  @IsOptional()
  dripWhatsappButton: boolean

  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value) || false)
  @IsBoolean()
  @IsOptional()
  chatbotButton: boolean

  @ApiProperty()
  @IsString()
  @IsOptional()
  registeredTemplateID: string

  @ApiProperty()
  @IsString()
  @IsOptional()
  registeredDripTemplateID: string

  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value) || false)
  @IsBoolean()
  @IsOptional()
  trackingScript: boolean

  @ApiProperty()
  @Transform(({ value }) => JSON.parse(value) || false)
  @IsBoolean()
  @IsOptional()
  isDripCampaign: boolean

  @ApiProperty()
  @IsString()
  @IsOptional()
  dripSmsSenderId: string

  @ApiProperty()
  @IsString()
  @IsOptional()
  dripCampaignName: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsDateString()
  scheduleDripDate: Date

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  rcs?: boolean

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  failover?: boolean
}
