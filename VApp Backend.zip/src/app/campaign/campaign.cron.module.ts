import { ContactDatabase, ContactDatabaseSchema } from '@app/contact/contact.database.schema'
import { Contact, ContactSchema } from '@app/contact/contact.schema'
import { Credits, CreditsSchema } from '@app/credits/credits.schema'
import { Dashboard, DashboardSchema } from '@app/dashboard/dashboard.schema'
import { Link, LinkSchema } from '@app/link/link.schema'
import { Projects, ProjectsSchema } from '@app/projects/projects.schema'
import { CreateCampaignReportQueueModule } from '@app/reports/cron/queue.module'
import { Requests, RequestsSchema } from '@app/requests/requests.schema'
import { DripRequests, DripRequestsSchema } from '@app/requests/drip_requests.schema'
import { Template, TemplateSchema } from '@app/template/template.schema'
import { User, UserSchema } from '@app/user/user.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { UploadDeliveryReportModule } from '@app/delivery/cron/queue.module'
import { Tracking, TrackingSchema } from '@app/tracking/tracking.schema'
import { DashboardTrendingStore, DashboardTrendingStoreSchema } from '@app/dashboard/dashboard.trending.schema'
import { ProjectTrendingEngagementsSchemaStore, ProjectTrendingEngagementsSchema } from '@app/projects/projects.trending.engagement.schema'
import { TrackingUniqueEvents, TrackingUniqueEventsSchema } from '@app/tracking/tracking-unique-event.schema'
import { TrackingWebSocketGateway } from '@app/tracking/tracking.socket'
import { RequestEngagement, RequestsEngagementSchema } from '@app/requests/requests.engagement.schema'
import { DripCriteriaModule } from '@app/dripcriteria/dripcriteria.module'
import { DripCriteria, DripCriteriaSchema } from '@app/dripcriteria/dripcriteria.schema'
import { cronJobs } from '@config'
import { GenericObject } from '@interfaces/generic.interface'
import { getArgs } from '@utils/platform.util'
import { IntegrationsModule } from '@app/integrations/integrations.module'
import { CampaignController } from './campaign.controller'
import { Campaign, CampaignSchema } from './campaign.schema'
import { CampaignService } from './campaign.service'
import { CampaignWebSocketGateway } from './campaign.socket'
import { CreateWhatsappCampaignQueueModule, CreateDripSMSCampaignQueueModule, CreateDripWhatsAPPCampaignQueueModule, CreateSMSCampaignQueueModule, EngagementTrackingQueueModule, CreateRBMCampaignQueueModule } from './cron/queue.module'
import { CreateDripSMSCampaignProcessor, CreateSMSCampaignProcessor, CreateWhatsappCampaignProcessor, CreateRBMCampaignProcessor, EngagementTrackingProcessor } from './cron/queue.processor'
import { QueueUIProvider } from './cron/queue.ui'
import { DripCampaign, DripCampaignSchema } from './drip_campaign.schema'

const cronSwitcher = () => {
  const cron_processor = (getArgs() as GenericObject).cron
  let processor_array: Array<any> = []
  switch (cron_processor) {
    case cronJobs.ENGAGEMENT_TRACKING.name:
      processor_array = [EngagementTrackingProcessor]
      break
    case cronJobs.CREATE_SMS_CAMPAIGN.name:
      processor_array = [CreateSMSCampaignProcessor]
      break
    case cronJobs.CREATE_RBM_CAMPAIGN.name:
      processor_array = [CreateRBMCampaignProcessor]
      break
    case cronJobs.CREATE_WHATSAPP_CAMPAIGN.name:
      processor_array = [CreateWhatsappCampaignProcessor]
      break
    case cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name:
      processor_array = [CreateDripSMSCampaignProcessor]
      break
    case cronJobs.CREATE_DRIP_WHATSAPP_CAMPAIGN.name:
      processor_array = [CreateDripSMSCampaignProcessor]
      break
  }
  return processor_array
}
@Module({
  imports: [
    CreateSMSCampaignQueueModule,
    CreateRBMCampaignQueueModule,
    CreateWhatsappCampaignQueueModule,
    CreateCampaignReportQueueModule,
    UploadDeliveryReportModule,
    EngagementTrackingQueueModule,
    CreateDripSMSCampaignQueueModule,
    CreateDripWhatsAPPCampaignQueueModule,
    DripCriteriaModule,
    IntegrationsModule,
    MongooseModule.forFeature([
      { name: Campaign.name, schema: CampaignSchema },
      { name: User.name, schema: UserSchema },
      { name: Contact.name, schema: ContactSchema },
      { name: ContactDatabase.name, schema: ContactDatabaseSchema },
      { name: Requests.name, schema: RequestsSchema },
      { name: DripRequests.name, schema: DripRequestsSchema },
      { name: Credits.name, schema: CreditsSchema },
      { name: Projects.name, schema: ProjectsSchema },
      { name: Campaign.name, schema: CampaignSchema },
      { name: DripCriteria.name, schema: DripCriteriaSchema },
      { name: DripCampaign.name, schema: DripCampaignSchema },
      { name: Link.name, schema: LinkSchema },
      { name: Template.name, schema: TemplateSchema },
      { name: DashboardTrendingStore.name, schema: DashboardTrendingStoreSchema },
      { name: Dashboard.name, schema: DashboardSchema },
      { name: ProjectTrendingEngagementsSchemaStore.name, schema: ProjectTrendingEngagementsSchema },
      { name: Tracking.name, schema: TrackingSchema },
      { name: TrackingUniqueEvents.name, schema: TrackingUniqueEventsSchema },
      { name: RequestEngagement.name, schema: RequestsEngagementSchema }
    ])
  ],
  controllers: [CampaignController],
  providers: [CampaignService, VappLogger, QueueUIProvider, ...cronSwitcher(), CampaignWebSocketGateway, TrackingWebSocketGateway],
  exports: [MongooseModule]
})
export class CampaignCronModule {}
