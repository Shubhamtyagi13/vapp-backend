/* eslint-disable no-async-promise-executor */
import { Contact } from '@app/contact/contact.schema'
import { Link } from '@app/link/link.schema'
import { Projects } from '@app/projects/projects.schema'
import { Template } from '@app/template/template.schema'
import { Tracking } from '@app/tracking/tracking.schema'
import { User } from '@app/user/user.schema'
import { cache_client, canonicalMethods, constants, cronJobs, CRON_SCHEDULES_TIME, redisKeys, redis_client, variables } from '@config'
import { CampaignAnalysis, CampaignEvent, FileObject } from '@interfaces/campaign.interface'
import { GenericObject } from '@interfaces/generic.interface'
import { Project } from '@interfaces/project.interface'
import { RbmReport } from '@interfaces/rbm.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { InjectQueue } from '@nestjs/bull'
import { HttpStatus, Inject, Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { findOperations, createOperations } from '@utils/crud.util'
import { daysInMonth, deleteFolderRecursive, generateUID, getAPIResponse, getEnvironmentVariable, getErrorLog, getMilliseconds } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import { Queue } from 'bull'
import _ from 'lodash'
import { Model } from 'mongoose'
import { join } from 'path'
import { Campaign, CampaignAnalysisObject } from './campaign.schema'
import { CampaignWebSocketGateway } from './campaign.socket'
import { DripCampaign } from './drip_campaign.schema'
import { BulkCampaignDTO, SingleContactDTO } from './dto/bulk-campaign-dto'
import { SingleCampaignDTO } from './dto/single-campaign-dto'
import { WhatsappCampaignDTO } from './dto/whatsapp-campaign-dto'
import { addCampaignJob, getContacts, getLink, getTemplate } from './helpers/sms_campaign.helper'

@Injectable()
export class CampaignService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    @InjectModel(Campaign.name) private campaignModel: Model<Campaign>,
    @InjectModel(DripCampaign.name) private dripCampaignModel: Model<DripCampaign>,
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(Template.name) private templatesModel: Model<Template>,
    @InjectModel(Contact.name) private contactsModel: Model<Contact>,
    @InjectModel(Projects.name) private projectsModel: Model<Projects>,
    @InjectModel(Tracking.name) private trackingModel: Model<Tracking>,
    @InjectModel(Link.name) private linksModel: Model<Link>,
    @InjectQueue(cronJobs.CREATE_SMS_CAMPAIGN.name) private createSMSCampaignQueue: Queue,
    @InjectQueue(cronJobs.CREATE_RBM_CAMPAIGN.name) private createRBMCampaignQueue: Queue,
    @InjectQueue(cronJobs.CREATE_WHATSAPP_CAMPAIGN.name) private createWhatsappCampaignQueue: Queue,
    @InjectQueue(cronJobs.UPLOAD_DELIVERY_REPORT.name) private uploadDeliveryReportQueue: Queue,
    private readonly _socketGateway: CampaignWebSocketGateway,
    private logger: VappLogger
  ) {
    this.traceID = vapp_context?.traceID
  }

  getSingleCampaignData = (campaignID: string) =>
    new Promise<ServiceResponse>((resolve) => {
      findOperations
        .findById(this.campaignModel, campaignID, { __v: 0 })
        .then((campaign) => {
          if (_.isNil(campaign)) {
            resolve(getAPIResponse(messages.CAM043.code, this.traceID, HttpStatus.BAD_REQUEST))
          } else {
            findOperations
              .aggregate(this.trackingModel, [
                {
                  $match: {
                    campaignID
                  }
                },
                { $addFields: { events: { $size: '$events' } } },
                {
                  $group: {
                    _id: '$shortID',
                    shortID: { $first: '$shortID' },
                    events: { $sum: '$events' },
                    campaignID: { $first: '$campaignID' }
                  }
                },
                {
                  $project: {
                    shortID: 1,
                    campaignID: 1,
                    events: { $cond: [{ $gt: ['$events', 0] }, 1, 0] },
                    eventsThreshold: { $cond: [{ $gt: ['$events', 1] }, 1, 0] },
                    _id: 0
                  }
                },
                {
                  $group: {
                    _id: '$campaignID',
                    campaignID: { $first: '$campaignID' },
                    events: { $sum: '$events' },
                    eventsThreshold: { $sum: '$eventsThreshold' }
                  }
                },
                {
                  $project: {
                    campaignID: 1,
                    events: 1,
                    eventsThreshold: 1,
                    _id: 0
                  }
                }
              ])
              .then((campaignEventResult: [CampaignEvent]) => {
                const campaignUpdated = _.cloneDeep(campaign.toObject())
                if (!_.isNil(campaignEventResult) && !_.isEmpty(campaignEventResult)) {
                  _.set(campaignUpdated, 'events', campaignEventResult[0].events)
                  _.set(campaignUpdated, 'eventsThreshold', campaignEventResult[0].eventsThreshold)
                } else {
                  _.set(campaignUpdated, 'events', 0)
                  _.set(campaignUpdated, 'eventsThreshold', 0)
                }
                return resolve(getAPIResponse(messages.CAM047.code, this.traceID, HttpStatus.OK, campaignUpdated))
              })
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.CLIENT_SINGLE_SMS_CAMPAIGN, this.traceID, { campaignID }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  processRBMWebhook = (messageID: string) =>
    new Promise<ServiceResponse>((resolve) => {
      RedisHandler.getInstance(cache_client.DEFAULT, redis_client.SMPP_DELIVERY).get(messageID, (error: Error, data: string) => {
        if (!_.isNil(data)) {
          const parsed_data = JSON.parse(data) as RbmReport
          this.uploadDeliveryReportQueue.add({
            payload: {
              isFinal: true,
              isSmpp: true,
              data: {
                campaignID: parsed_data.campaignID,
                phone: parsed_data.phone.toString().substring(3),
                status: 'dlvrd',
                smppMessageID: messageID,
                reportType: parsed_data.reportType
              }
            },
            traceID: generateUID()
          })
        }
      })
    })

  createSingleCampaign = (payload: SingleCampaignDTO, clientID: string, projectID: string) =>
    new Promise<ServiceResponse>(async (resolve) => {
      if ((payload.redirection || payload.cloud) && _.isNil(payload.url)) {
        return resolve(getAPIResponse(messages.CAM040.code, this.traceID, HttpStatus.BAD_REQUEST))
      }
      let clientName: string
      try {
        const client = (await findOperations.findById(this.userModel, clientID)) as User
        if (!_.isEmpty(client)) {
          clientName = client.companyName

          if (!_.isNil(payload.templateID) || !_.isNil(payload.dripTemplateID)) {
            let template: Template
            let dripTemplate: Template
            if (!_.isNil(payload.templateID)) {
              template = (await getTemplate(this.templatesModel, clientID, payload.templateID)) as Template
            }

            if (!_.isNil(payload.dripTemplateID)) {
              dripTemplate = (await getTemplate(this.templatesModel, clientID, payload.dripTemplateID)) as Template
            }

            if (!_.isNil(template)) {
              payload.registeredTemplateID = template.templateID

              if (!_.isNil(dripTemplate)) {
                payload.registeredDripTemplateID = dripTemplate.templateID
                payload.dripmessage = dripTemplate.text
              }

              if (!template.text.includes('{{url}}') && payload.tracking && template.dynamic) {
                return resolve(getAPIResponse(messages.CAM052.code, this.traceID, HttpStatus.BAD_REQUEST))
              }
              payload.message = template.text
              if (!template.dynamic && payload.dynamic) {
                return resolve(getAPIResponse(messages.CAM050.code, this.traceID, HttpStatus.BAD_REQUEST))
              }
              if (template.dynamic && !payload.dynamic) {
                return resolve(getAPIResponse(messages.CAM048.code, this.traceID, HttpStatus.BAD_REQUEST))
              }
            } else {
              return resolve(getAPIResponse(messages.CAM035.code, this.traceID, HttpStatus.BAD_REQUEST))
            }
          }
          if (!_.isNil(payload.linkID)) {
            const link: Link = await getLink(this.linksModel, clientID, payload.linkID)
            if (!_.isNil(link)) {
              payload.url = link.url
            } else {
              return resolve(getAPIResponse(messages.CAM041.code, this.traceID, HttpStatus.BAD_REQUEST))
            }
          }
          // let campaign = await createOperations
        }
      } catch (error) {
        this.logger.error(getErrorLog(canonicalMethods.CLIENT_SINGLE_SMS_CAMPAIGN, this.traceID, { clientID }, error.message))
        return resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      }
      addCampaignJob(
        false,
        this.userModel,
        this.projectsModel,
        this.campaignModel,
        this.dripCampaignModel,
        [
          {
            phone: Number(Math.abs(payload.phone)),
            firstName: payload.firstName,
            lastName: payload.lastName,
            middleName: payload.middleName,
            var1: payload.var1,
            var2: payload.var2,
            var3: payload.var3,
            var4: payload.var4
          }
        ],
        this.traceID,
        payload,
        false,
        clientID,
        clientName,
        projectID,
        payload.rcs ? this.createRBMCampaignQueue : this.createSMSCampaignQueue
      )
      return resolve(getAPIResponse(messages.CAM011.code, this.traceID, HttpStatus.OK))
    })

  createBulkCampaign = (payload: BulkCampaignDTO, clientID: string, projectID: string) =>
    new Promise<ServiceResponse>(async (resolve) => {
      if ((payload.redirection || payload.cloud) && _.isNil(payload.url)) {
        return resolve(getAPIResponse(messages.CAM040.code, this.traceID, HttpStatus.BAD_REQUEST))
      }
      let clientName: string
      try {
        const client = (await findOperations.findById(this.userModel, clientID)) as User
        if (!_.isEmpty(client)) {
          clientName = client.companyName
          if (!_.isNil(payload.templateID) || !_.isNil(payload.dripTemplateID)) {
            let template: Template
            let dripTemplate: Template

            if (!_.isNil(payload.templateID)) {
              template = (await getTemplate(this.templatesModel, clientID, payload.templateID)) as Template
            }

            if (!_.isNil(payload.dripTemplateID)) {
              dripTemplate = (await getTemplate(this.templatesModel, clientID, payload.dripTemplateID)) as Template
            }

            if (!_.isNil(template)) {
              payload.registeredTemplateID = template.templateID
              payload.message = template.text

              if (!_.isNil(dripTemplate)) {
                payload.registeredDripTemplateID = dripTemplate.templateID
                payload.dripmessage = dripTemplate.text
              }

              if (!template.text.includes('{{url}}') && payload.tracking && template.dynamic) {
                return resolve(getAPIResponse(messages.CAM052.code, this.traceID, HttpStatus.BAD_REQUEST))
              }
              if (!template.dynamic && payload.dynamic) {
                return resolve(getAPIResponse(messages.CAM050.code, this.traceID, HttpStatus.BAD_REQUEST))
              }
              if (template.dynamic && !payload.dynamic) {
                return resolve(getAPIResponse(messages.CAM048.code, this.traceID, HttpStatus.BAD_REQUEST))
              }
            } else {
              return resolve(getAPIResponse(messages.CAM035.code, this.traceID, HttpStatus.BAD_REQUEST))
            }
          }
          if (!_.isNil(payload.linkID)) {
            const link: Link = await getLink(this.linksModel, clientID, payload.linkID)
            if (!_.isNil(link)) {
              payload.url = link.url
            } else {
              return resolve(getAPIResponse(messages.CAM041.code, this.traceID, HttpStatus.BAD_REQUEST))
            }
          }
          if (!_.isNil(payload.databaseID)) {
            const contacts: Contact[] = await getContacts(this.contactsModel, payload.databaseID)
            if (!_.isNil(contacts) && !_.isEmpty(contacts)) {
              payload.contacts = contacts as unknown as SingleContactDTO[]
            } else {
              return resolve(getAPIResponse(messages.CAM036.code, this.traceID, HttpStatus.BAD_REQUEST))
            }
          }
        }
      } catch (error) {
        this.logger.error(getErrorLog(canonicalMethods.CLIENT_BULK_SMS_CAMPAIGN, this.traceID, { clientID }, error.message))
        return resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      }
      payload.contacts = _.uniqBy(payload.contacts, 'phone')

      if (_.lte(payload.contacts.length, parseInt(getEnvironmentVariable(variables.CAMPAIGN_LIMIT.name), 10))) {
        addCampaignJob(
          false,
          this.userModel,
          this.projectsModel,
          this.campaignModel,
          this.dripCampaignModel,
          payload.contacts,
          this.traceID,
          payload,
          true,
          clientID,
          clientName,
          projectID,
          payload.rcs ? this.createRBMCampaignQueue : this.createSMSCampaignQueue
        )
      } else {
        return resolve(getAPIResponse(messages.CAM054.code, this.traceID, HttpStatus.BAD_REQUEST))
      }
      return resolve(getAPIResponse(messages.CAM011.code, this.traceID, HttpStatus.OK))
    })

  clearWhatsappSession(userID: string) {
    return new Promise<ServiceResponse>((resolve) => {
      createOperations.updateOne(this.userModel, { _id: userID }, { primaryWhatsappToken: null }).then((user: User) => {
        deleteFolderRecursive(join(process.cwd(), 'tokens', userID))
        RedisHandler.getInstance().set(redisKeys.USER.value(userID), JSON.stringify(_.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))))
        RedisHandler.getInstance().expire(redisKeys.USER.value(userID), redisKeys.USER.timeout())
        resolve(getAPIResponse(messages.USER011.code, this.traceID, HttpStatus.OK, _.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))))
      })
    })
  }

  getDailyAnalysis = (clientID: string, projectID = null) =>
    new Promise<ServiceResponse>((resolve) => {
      let viaProjectID = false
      let driptempObject: Campaign[] = []

      if (!_.isNil(projectID)) {
        viaProjectID = true
      }

      if (!_.isNil(clientID)) {
        const dayWiseGroupedCampaigns: CampaignAnalysis<number, CampaignAnalysisObject> = [] as CampaignAnalysis<number, CampaignAnalysisObject>
        const fromMonth = new Date().getMonth() + 1
        let toMonth = fromMonth > 3 ? fromMonth - 2 : 1

        let queryObject: GenericObject = {
          clientID,
          year: new Date().getFullYear(),
          month: { $gte: toMonth, $lte: fromMonth }
        }

        if (viaProjectID) {
          toMonth = fromMonth
          queryObject = {
            projectID,
            clientID,
            year: new Date().getFullYear(),
            month: { $gte: toMonth, $lte: fromMonth }
          }
        }

        findOperations.find(this.projectsModel, { clientID }, { __v: 0, password: 0 }).then((projects: Project[]) => {
          findOperations
            .findLean(this.campaignModel, queryObject)
            .then(async (campaigns: Campaign[]) => {
              await findOperations.findLean(this.dripCampaignModel, queryObject).then((dripcampaigns: Campaign[]) => {
                driptempObject = driptempObject.concat(dripcampaigns)
              })

              const concatCampign = campaigns.concat(driptempObject)

              if (!_.isNil(concatCampign)) {
                const result = _(concatCampign)
                  .groupBy('month')
                  .map((value, key) => ({ month: parseInt(key, 10), objects: value }))
                  .value()

                let processedObject = []
                _.forEach(result, (value) => {
                  const tempCurrentMonthObject: CampaignAnalysisObject[] = _(value.objects)
                    .groupBy('day')
                    .map((objects, key) => ({
                      projects: _(objects)
                        .groupBy('projectID')
                        .map(
                          (subObjects, subKey) =>
                            ({
                              projectID: subKey,
                              engagementSum: _.sumBy(subObjects, 'engagementSum'),
                              smsEngagementTotal: _.sumBy(subObjects, 'smsEngagementTotal'),
                              smsEngagementSum: _.sumBy(subObjects, 'smsEngagementSum'),
                              whatsappClicks: _.sumBy(subObjects, 'whatsappClicks'),
                              smsSentCount: _.sumBy(subObjects, 'smsSentCount'),
                              whatsappSentCount: _.sumBy(subObjects, 'whatsappSentCount'),
                              whatsappDeliveredCount: _.sumBy(subObjects, 'whatsappDeliveredCount'),
                              whatsappFailedCount: _.sumBy(subObjects, 'whatsappFailedCount'),
                              projectName: _.find(projects, (project) => _.eq(project.id, subKey))?.name,
                              smsDeliveredCount: _.sumBy(subObjects, 'smsDeliveredCount'),
                              smsFailedCount: _.sumBy(subObjects, 'smsFailedCount'),
                              linksCount: _.sumBy(subObjects, 'linksCount'),
                              linksClickCount: _.sumBy(subObjects, 'linksClickCount'),
                              smsLinksClickCount: _.sumBy(subObjects, 'smsLinksClickCount'),
                              whatsappLinksClickCount: _.sumBy(subObjects, 'whatsappLinksClickCount'),
                              engagementTotal: _.sumBy(subObjects, 'engagementTotal'),
                              viewsCount: _.sumBy(subObjects, 'viewsCount'),
                              whatsappViewsCount: _.sumBy(subObjects, 'whatsappViewsCount'),
                              smsViewsCount: _.sumBy(subObjects, 'smsViewsCount'),
                              whatsappEngagementTotal: _.sumBy(subObjects, 'whatsappEngagementTotal'),
                              whatsappEngagementSum: _.sumBy(subObjects, 'whatsappEngagementSum'),
                              positiveCount: _.sumBy(subObjects, 'positiveCount'),
                              negativeCount: _.sumBy(subObjects, 'negativeCount'),
                              neutralCount: _.sumBy(subObjects, 'neutralCount')
                            } as unknown as Campaign)
                        )
                        .value(),
                      day: parseInt(key, 10),
                      month: value.month
                    }))
                    .orderBy(['day'], ['asc'])
                    .value()

                  processedObject = processedObject.concat(tempCurrentMonthObject)
                })

                for (let i = toMonth; i <= fromMonth; i++) {
                  const daysInCurrentMonth = daysInMonth(i, new Date().getFullYear())
                  _.range(1, daysInCurrentMonth + 1).forEach((currentDay: number) => {
                    const currentObject: CampaignAnalysisObject = _.find(processedObject, { month: i, day: currentDay }) as CampaignAnalysisObject
                    if (!_.isNil(currentObject)) {
                      dayWiseGroupedCampaigns[i * (daysInCurrentMonth + 1) + currentDay] = currentObject
                    } else {
                      dayWiseGroupedCampaigns[i * (daysInCurrentMonth + 1) + currentDay] = null
                    }
                  })
                }
                resolve(getAPIResponse(messages.CAM037.code, this.traceID, HttpStatus.OK, dayWiseGroupedCampaigns))
              }
              // this.logger.error(getErrorLog(canonicalMethods.CLIENT_DAILY_ANALYSIS, this.traceID, { clientID }))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.BAD_REQUEST))
            })
            .catch((error: Error) => {
              // this.logger.error(getErrorLog(canonicalMethods.CLIENT_DAILY_ANALYSIS, this.traceID, { clientID }, error.message))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.BAD_REQUEST))
            })
        })
      }
    })

  createWhatsappCampaign = (projectID: string, payload: WhatsappCampaignDTO, clientID: string, files: [FileObject], allImages: boolean) =>
    new Promise<ServiceResponse>(async (resolve) => {
      if ((payload.redirection || payload.cloud) && _.isNil(payload.url)) {
        return resolve(getAPIResponse(messages.CAM040.code, this.traceID, HttpStatus.BAD_REQUEST))
      }
      let clientName: string
      try {
        const client = (await findOperations.findById(this.userModel, clientID)) as User
        if (!_.isEmpty(client)) {
          clientName = client.companyName
          if (!_.isNil(payload.templateID)) {
            const template = await getTemplate(this.templatesModel, clientID, payload.templateID)
            if (!_.isNil(template)) {
              payload.registeredTemplateID = template.templateID
              payload.message = template.text
            } else {
              return resolve(getAPIResponse(messages.CAM035.code, this.traceID, HttpStatus.BAD_REQUEST))
            }
          }
          if (!_.isNil(payload.linkID)) {
            const link: Link = await getLink(this.linksModel, clientID, payload.linkID)
            if (!_.isNil(link)) {
              payload.url = link.url
            } else {
              return resolve(getAPIResponse(messages.CAM041.code, this.traceID, HttpStatus.BAD_REQUEST))
            }
          }
          if (!_.isNil(payload.databaseID)) {
            const contacts: Contact[] = await getContacts(this.contactsModel, payload.databaseID)
            if (!_.isNil(contacts) && !_.isEmpty(contacts)) {
              if (_.lte(contacts.length, getEnvironmentVariable(variables.WHATSAPP_CAMPAIGN_LIMIT.name))) {
                payload.contacts = contacts as unknown as SingleContactDTO[]
              } else {
                return resolve(getAPIResponse(messages.CAM042.code, this.traceID, HttpStatus.BAD_REQUEST))
              }
            } else {
              return resolve(getAPIResponse(messages.CAM036.code, this.traceID, HttpStatus.BAD_REQUEST))
            }
          }
          payload.scheduleDate = null
        }
      } catch (error) {
        this.logger.error(getErrorLog(canonicalMethods.CREATE_WHATSAPP_CAMPAIGN, this.traceID, { clientID }, error.message))
        return resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      }
      const addJob = (contacts: SingleContactDTO[]) => {
        addCampaignJob(
          true,
          this.userModel,
          this.projectsModel,
          this.campaignModel,
          this.dripCampaignModel,
          contacts,
          this.traceID,
          payload,
          !_.eq(payload.contacts.length, 1),
          clientID,
          clientName,
          projectID,
          this.createWhatsappCampaignQueue,
          constants.CAMPAIGN_TYPES.WHATSAPP.value,
          !!payload.isCaptionMessage,
          files,
          allImages
        )
      }

      if (!_.eq(payload.contacts.length, 1)) addJob(payload.contacts)
      else {
        let i
        let j
        const chunk = 1000
        for (i = 0, j = payload.contacts.length; i < j; i += chunk) addJob(payload.contacts.slice(i, i + chunk))
      }

      return resolve(getAPIResponse(messages.CAM011.code, this.traceID, HttpStatus.OK))
    })
}
