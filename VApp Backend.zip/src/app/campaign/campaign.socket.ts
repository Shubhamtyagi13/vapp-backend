/* eslint-disable @typescript-eslint/no-unused-vars */
import { OnGatewayConnection, OnGatewayDisconnect, OnGatewayInit, WebSocketGateway, WebSocketServer } from '@nestjs/websockets'
import { VappLogger } from '@services/logger.service'
import { Server, Socket } from 'socket.io'

@WebSocketGateway()
export class CampaignWebSocketGateway implements OnGatewayInit, OnGatewayConnection, OnGatewayDisconnect {
  constructor(private logger: VappLogger) {}

  @WebSocketServer() server: Server

  afterInit(server: Server) {
    this.logger.log('Client Socket Initiated')
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`Client disconnected: ${client.id}`)
  }

  handleConnection(client: Socket, ...args: any[]) {
    this.logger.log(`Client connected: ${client.id}`)
  }
}
