import {
  canonicalMethods, constants, environments, variables,
} from '@config'
import { FileObject, WhatsappCampaignResult } from '@interfaces/campaign.interface'
import { CampaignCronPayload } from '@interfaces/sms-campaign.interface'
import { campaignProviderObject } from '@interfaces/sms.interface'
import { messages } from '@messages'
import { VappLogger } from '@services/logger.service'
import { deleteFile, generateUID, getErrorLog } from '@utils/platform.util'
import async from 'async'
import _ from 'lodash'
import { Server } from 'socket.io'
import { create, Whatsapp, SocketState } from 'venom-bot'
// import { tokenSession } from 'venom-bot/dist/config/tokenSession.config'

interface WhatsappCampaignProps {
  logger: VappLogger
  socketServer: Server
  whatsappCampaignObject: CampaignCronPayload
  projectID: string
  clientID: string
  whatsappPhoneRequests: campaignProviderObject[]
  files: [FileObject]
  isCaptionMessage: boolean
  userToken?: string
  allImages?: boolean
}

export class WhatsappHelper {
  private logger: VappLogger

  private socketServer: Server

  private whatsappCampaignObject: CampaignCronPayload

  private projectID: string

  private clientID: string

  private whatsappPhoneRequests: campaignProviderObject[]

  private isCaptionMessage: boolean

  private files: [FileObject]

  private userToken?: string

  private qrCode: string

  private browserSessionToken: any

  private allImages: boolean

  constructor({
    logger,
    socketServer,
    whatsappCampaignObject,
    projectID,
    clientID,
    whatsappPhoneRequests,
    files,
    isCaptionMessage,
    userToken,
    allImages,
  }: WhatsappCampaignProps) {
    this.logger = logger
    this.socketServer = socketServer
    this.whatsappCampaignObject = whatsappCampaignObject
    this.projectID = projectID
    this.clientID = clientID
    this.whatsappPhoneRequests = whatsappPhoneRequests
    this.files = files
    this.isCaptionMessage = isCaptionMessage
    this.userToken = userToken
    this.allImages = allImages
  }

  async startSession(): Promise<WhatsappCampaignResult> {
    let result: WhatsappCampaignResult
    try {
      const started = false
      const params = {
        session: this.clientID,
        disableSpins: true,
        disableWelcome: true,
        updatesLog: false,
      } as any
      if (!_.isNil(this.userToken)) {
        params.browserSessionToken = JSON.parse(this.userToken)
        delete (params.browserSessionToken).phone
      }
      const conflits = [SocketState.CONFLICT, SocketState.UNPAIRED, SocketState.UNLAUNCHED]
      const client:Whatsapp = await create({
        ...params,
        headless: true,
        multidevice: true,
        logQR: false,
        waitForLogin: true,
        createPathFileToken: true,
        browserArgs: constants.WHATSAPP_CAMPAIGN.browser_arguments,
        catchQR: (base64Qrimg, asciiQR, attempts, urlCode) => {
          if (!_.isNil(urlCode)) {
            if (!started) {
              if (_.isNil(this.qrCode)) {
                this.socketServer.emit(this.whatsappCampaignObject.channelID, {
                  event: constants.WHATSAPP_CAMPAIGN.events.qr_code_started,
                  oldValue: false,
                  value: true,
                })
              }
              this.socketServer.emit(this.whatsappCampaignObject.channelID, {
                event: constants.WHATSAPP_CAMPAIGN.events.qr_code_changed,
                oldValue: this.qrCode,
                value: urlCode,
              })
              this.qrCode = urlCode
            }
          }
        },
      })
      let connected = false
      client.onStateChange((state) => {
        console.log('State changed: ', state)
        // force whatsapp take over
        if (conflits.includes(state)) client.useHere()
        // detect disconnect on whatsapp
        if ('UNPAIRED'.includes(state)) console.log('logout')
      })
      let time = setTimeout(() => { }, 0)
      client.onStreamChange((state) => {
        clearTimeout(time)
        if (_.eq(state, SocketState.CONNECTED)) {
          connected = true
        }
        // if (_.eq(state, SocketState.CONNECTED) && !started) {
        //   startClient()
        //   started = true
        // }
        if (_.eq(state, SocketState.DISCONNECTED) || _.eq(state, SocketState.SYNCING)) {
          time = setTimeout(() => {
            client.close()
          }, 80000)
        }
      })

      const token = (await client.waPage
        .evaluate(() => {
          if (window.localStorage) {
            return {
              WABrowserId: window.localStorage.getItem('WABrowserId'),
              WebEncKeySalt: window.localStorage.getItem('WebEncKeySalt'),
              WANoiseInfoIv: window.localStorage.getItem('WANoiseInfoIv'),
              WANoiseInfo: window.localStorage.getItem('WANoiseInfo'),
            }
          }
          return undefined
        })
        .catch(() => undefined))
      this.browserSessionToken = await client.getSessionTokenBrowser()
      const hostDevice = await client.getHostDevice()
      const phone = hostDevice?.wid?.user || (hostDevice?.id as any)?.user
      if (!_.isNil(hostDevice)) {
        this.browserSessionToken = { ...this.browserSessionToken, phone } as any
      }
      const campaignPromises = []
      const filePromises = []
      if (!_.isNil(this.files) && !_.isEmpty(this.files)) {
        this.whatsappPhoneRequests.forEach((clientObject) => {
          this.files.forEach((file, index) => {
            const file_params = {
              to: `${String(91).trim()}${String(clientObject.phone).trim()}@c.us`,
              filePath: file.filePath,
              filename: file.originalFileName,
              caption: null,
            }
            if (_.eq(index, this.files.length - 1)) {
              if (this.isCaptionMessage && this.allImages) {
                file_params.caption = clientObject.message
              }
            }
            filePromises.push((callback: any) => {
              client
                .sendFile(file_params.to, file_params.filePath, file_params.filename, file_params.caption)
                .then((result) => {
                  deleteFile(file_params.filePath)
                  callback(null, true)
                })
                .catch((e) => {
                  callback(null, false)
                })
            })
          })

          campaignPromises.push((callback: any) => {
            async.parallelLimit(filePromises, Number.MAX_SAFE_INTEGER, async (err, results) => {
              if (this.isCaptionMessage && this.allImages) {
                callback(null, true)
              } else {
                client
                  .sendText(`${String(91).trim()}${String(clientObject.phone).trim()}@c.us`, clientObject.message)
                  .then((result) => {
                    callback(null, true)
                  })
                  .catch((e) => {
                    callback(null, false)
                  })
              }
            })
          })
        })
      } else {
        this.whatsappPhoneRequests.forEach((clientObject) => {
          campaignPromises.push((callback: any) => {
            client
              .sendText(`${String(91).trim()}${String(clientObject.phone).trim()}@c.us`, clientObject.message)
              .then((result) => {
                callback(null, true)
              })
              .catch((e) => {
                callback(null, false)
              })
          })
        })
      }

      const { success, failed } = await this.processWhatsppCampaign(campaignPromises)

      this.logger.log(`Whatsapp campaign finished!, projectID: ${this.projectID}, clientID: ${this.clientID}`)
      this.socketServer.emit(this.whatsappCampaignObject.channelID, {
        event: constants.WHATSAPP_CAMPAIGN.events.campaign_finished,
        value: `Whatsapp campaign completed.\nFailed: ${failed}, Success: ${success}`,
      })
      try {
        await client.close()
        await client.waPage.browser().close()
      } catch (e) {}
      result = {
        success: true,
        results: {
          success,
          failed,
        },
        usertoken: !_.isNil(this.browserSessionToken) ? JSON.stringify(this.browserSessionToken) : null,
      }
    } catch (error) {
      console.log(error)
    }
    return result
  }

  private processWhatsppCampaign = (campaignPromises:any) => new Promise<{success:number, failed:number}>((res, rej) => {
    async.series(campaignPromises, (err, results) => {
      const failed = results.filter((e) => !e).length
      const success = results.filter((e) => e).length
      res({ failed, success })
    })
  })
}
