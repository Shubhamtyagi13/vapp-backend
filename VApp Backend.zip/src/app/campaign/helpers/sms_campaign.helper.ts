/* eslint-disable default-param-last */
import { Contact } from '@app/contact/contact.schema'
import { Link } from '@app/link/link.schema'
import { Projects } from '@app/projects/projects.schema'
import { Template } from '@app/template/template.schema'
import { User } from '@app/user/user.schema'
import { cache_client, campaignStates, constants, cronJobs, redisKeys, redis_client } from '@config'
import { CampaignInitialAlert } from '@interfaces/alert.interface'
import { FileObject } from '@interfaces/campaign.interface'
import { GenericObject } from '@interfaces/generic.interface'
import { CampaignCronPayload } from '@interfaces/sms-campaign.interface'
import { AlertService } from '@services/alert.service'
import { createOperations, findOperations } from '@utils/crud.util'
import { getDateTimeString, getSanatisedName, getTotalCredits, getTokenSignOptions, getAPIResponse } from '@utils/platform.util'
import AuthHandler from '@utils/auth.util'
import { Queue } from 'bull'
import _ from 'lodash'
import { Model } from 'mongoose'
import { messages } from '@messages'
import { HttpStatus } from '@nestjs/common'
import { RedisHandler } from '@utils/redis.util'
import { Campaign } from '../campaign.schema'
import { DripCampaign } from '../drip_campaign.schema'
import { BaseCampaignDTO } from '../dto/base-campaign-dto'
import { SingleContactDTO } from '../dto/bulk-campaign-dto'
import { WhatsappCampaignDTO } from '../dto/whatsapp-campaign-dto'

export const getTemplate = (templatesModel: Model<Template>, clientID: string, templateID: string) => findOperations.findOne(templatesModel, { clientID, _id: templateID })

export const getLink = (linksModel: Model<Link>, clientID: string, linkID: string) => findOperations.findOne(linksModel, { clientID, _id: linkID })

export const getContacts = (contactsModel: Model<Contact>, databaseID: string) => findOperations.find(contactsModel, { databaseID }, { databaseID: 0 })

export const addCampaignJob = async (
  isWhatsapp = false,
  userModel: Model<User>,
  projectModel: Model<Projects>,
  campaignModel: Model<Campaign>,
  dripCampaignModel: Model<DripCampaign>,
  contacts: SingleContactDTO[],
  traceID: string,
  payload: BaseCampaignDTO,
  multiple = false,
  clientID: string,
  clientName: string,
  projectID: string,
  queue: Queue,
  type = constants.CAMPAIGN_TYPES.SMS.value,
  isCaptionMessage = false,
  files?: [FileObject],
  allImages?: boolean
) => {
  const user: User = await findOperations.findById(userModel, clientID)
  const project: Projects = await findOperations.findById(projectModel, projectID)

  const campaignObj = new campaignModel({
    projectID,
    clientID,
    phone: project.phone,
    type,
    year: new Date().getFullYear(),
    ivr: !_.isNil(payload.ivr) && !_.isNaN(parseInt(String(payload.ivr), 10)) ? parseInt(String(payload.ivr), 10) : -1,
    month: new Date().getMonth() + 1,
    day: new Date().getDate(),
    cloud: payload.cloud,
    redirection: payload.redirection,
    rcs: payload.rcs,
    tracking: payload.tracking,
    url: payload.url,
    route: !_.isNil(user.route) ? user.route : -1,
    campaignName: payload.campaignName,
    sms: payload.message,
    multiple,
    chatbotButton: payload.chatbotButton,
    whatsappButton: payload.whatsappButton,
    status: campaignStates.SCHEDULED,
    scheduleDate: payload.scheduleDate
  } as Campaign)
  if (!_.isNil(payload.databaseID)) {
    campaignObj.databaseID = payload.databaseID
  }
  // assign template id if present
  if (!_.isNil(payload.templateID)) {
    campaignObj.templateID = payload.templateID
  }
  // assign link id if present
  if (!_.isNil(payload.linkID)) {
    campaignObj.linkID = payload.linkID
  }
  if (!_.isNil(payload.trackingScript)) {
    campaignObj.trackingScript = payload.trackingScript
  }
  // assign campaign token
  campaignObj.token = AuthHandler.getInstance()
    .campaignTokenHandler()
    .sign(
      {
        projectID: project._id,
        userID: user._id
      },
      getTokenSignOptions(_.toString(campaignObj._id), constants.JWT_AUDIENCE.public)
    )

  const campaignResult = await createOperations.save(new campaignModel(campaignObj))
  const cronPayload = <CampaignCronPayload>{
    multiple,
    type,
    url: payload.url,
    cloud: payload.cloud,
    clientID,
    clientName,
    projectID,
    ivr: payload.ivr,
    contactData: [],
    campaignName: payload.campaignName,
    message: payload.message,
    dripmessage: payload.dripmessage,
    smsCount: contacts.length,
    tracking: payload.tracking,
    dynamic: payload.dynamic,
    failover: payload.failover,
    redirection: payload.redirection,
    databaseID: payload.databaseID,
    templateID: payload.templateID,
    isDripCampaign: payload.isDripCampaign,
    dripTemplateID: payload.dripTemplateID,
    dripCriteriaID: payload.dripCriteriaID,
    scheduleDripDate: payload.scheduleDripDate,
    registeredTemplateID: payload.registeredTemplateID,
    registeredDripTemplateID: payload.registeredDripTemplateID,
    dripSmsSenderId: payload.dripSmsSenderId,
    dripCampaignName: payload.dripCampaignName,
    linkID: payload.linkID,
    channelID: (payload as GenericObject).channelID,
    isCaptionMessage,
    files,
    persistSession: !!(payload as WhatsappCampaignDTO).persistSession,
    allImages,
    whatsappButton: payload.whatsappButton,
    dripWhatsappButton: payload.dripWhatsappButton,
    chatbotButton: payload.chatbotButton,
    campaignID: campaignResult._id
  }

  let difference = -1

  if (!_.isNil(payload.scheduleDate)) {
    difference = new Date(payload.scheduleDate).getTime() - new Date().getTime()
  }

  await storeCampaignData(contacts, traceID, difference)
  await sendCampaignInitiationAlert(
    difference < 0 ? new Date() : new Date(payload.scheduleDate),
    user,
    cronPayload.contactData.length,
    project.name,
    difference,
    getTotalCredits(cronPayload),
    payload.tracking,
    payload.message,
    traceID,
    _.find(constants.CAMPAIGN_TYPES, (subType) => _.eq(subType.value, type))?.name
  )
  await queue.add({ payload: cronPayload, traceID }, { delay: difference < 0 ? 0 : difference, priority: isWhatsapp ? 2 : 1 })
  // await queue.add({ payload: cronPayload, traceID }, { delay: difference < 0 ? 0 : difference, priority: isWhatsapp ? 2 : 1 })
  // await queue.add({ payload: cronPayload, traceID }, { delay: difference < 0 ? 0 : difference, priority: isWhatsapp ? 2 : 1 })
  // await queue.add({ payload: cronPayload, traceID }, { delay: difference < 0 ? 0 : difference, priority: isWhatsapp ? 2 : 1 })
  if (payload.isDripCampaign) {
    addDripCampaignJOB(payload.dripWhatsappButton, userModel, projectModel, dripCampaignModel, contacts, traceID, payload, multiple, clientID, clientName, projectID, queue, cronPayload.campaignID, type, isCaptionMessage, files, allImages)
  }
  return cronPayload
}

const storeCampaignData = (payload: SingleContactDTO[], traceID: string, difference: number) =>
  new Promise<boolean>((resolve) => {
    RedisHandler.getInstance(cache_client.DEFAULT, redis_client.COMMON_JOB_DATA)
      .multi()
      .setnx(traceID, JSON.stringify(payload))
      .expire(traceID, difference < 0 ? redisKeys.CAMPAIGN_DATA.timeout() : redisKeys.CAMPAIGN_DATA.timeout() + Math.abs(difference / 1000) + 180)
      .exec(() => {
        resolve(true)
      })
  })

export const addDripCampaignJOB = async (
  isWhatsapp = false,
  userModel: Model<User>,
  projectModel: Model<Projects>,
  dripCampaignModel: Model<DripCampaign>,
  contacts: SingleContactDTO[],
  traceID: string,
  payload: BaseCampaignDTO,
  multiple = false,
  clientID: string,
  clientName: string,
  projectID: string,
  queue: Queue,
  campaignID: string,
  type = constants.CAMPAIGN_TYPES.SMS.value,
  isCaptionMessage = false,
  files?: [FileObject],
  allImages?: boolean
) => {
  const user: User = await findOperations.findById(userModel, clientID)
  const project: Projects = await findOperations.findById(projectModel, projectID)
  const dripCampaignObj = new dripCampaignModel({
    projectID,
    clientID,
    phone: project.phone,
    multiple,
    year: new Date().getFullYear(),
    month: new Date().getMonth() + 1,
    day: new Date().getDate(),
    sms: payload.dripmessage,
    chatbotButton: payload.chatbotButton,
    whatsappButton: payload.whatsappButton,
    status: campaignStates.SCHEDULED,
    campaignID,
    type
  } as DripCampaign)
  if (!_.isNil(payload.databaseID)) {
    dripCampaignObj.databaseID = payload.databaseID
  }
  // assign template id if present
  if (!_.isNil(payload.dripTemplateID)) {
    dripCampaignObj.dripTemplateID = payload.dripTemplateID
  }
  // assign template id if present
  if (!_.isNil(payload.dripCriteriaID)) {
    dripCampaignObj.dripCriteriaID = payload.dripCriteriaID
  }
  dripCampaignObj.dripCampaignName = `Drip-${payload.campaignName}`
  // assign campaign token
  dripCampaignObj.token = AuthHandler.getInstance()
    .campaignTokenHandler()
    .sign(
      {
        projectID: project._id,
        userID: user._id
      },
      getTokenSignOptions(_.toString(dripCampaignObj._id), constants.JWT_AUDIENCE.public)
    )
  const campaignResult = await createOperations.save(new dripCampaignModel(dripCampaignObj))
}

const sendCampaignInitiationAlert = async (date: Date, user: User, sent: number, project: string, difference: number, credits: number, tracking: boolean, message: string, traceID: string, type: string) => {
  const dateTime = getDateTimeString(date)
  const { firstName, middleName, lastName } = user
  const alertPayload: CampaignInitialAlert = {
    date: dateTime.date,
    time: dateTime.time,
    project,
    client: getSanatisedName(firstName, middleName, lastName),
    sent: String(sent),
    tracking: tracking ? 'enabled' : 'disabled',
    credits: String(credits),
    message,
    status: difference < 0 ? 'initiated' : 'scheduled',
    type,
    year: String(new Date().getFullYear())
  }
  if (!_.isNil(user.alerts) && user.alerts) {
    AlertService.getInstance().sendCampaignInitialAlert(alertPayload, user.contact, user.email, traceID)
  }
  return true
}
