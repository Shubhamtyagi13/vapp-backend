import { ContactDatabase, ContactDatabaseSchema } from '@app/contact/contact.database.schema'
import { Contact, ContactSchema } from '@app/contact/contact.schema'
import { Credits, CreditsSchema } from '@app/credits/credits.schema'
import { Dashboard, DashboardSchema } from '@app/dashboard/dashboard.schema'
import { DashboardTrendingStore, DashboardTrendingStoreSchema } from '@app/dashboard/dashboard.trending.schema'
import { DripCriteriaModule } from '@app/dripcriteria/dripcriteria.module'
import { DripCriteria, DripCriteriaSchema } from '@app/dripcriteria/dripcriteria.schema'
import { Link, LinkSchema } from '@app/link/link.schema'
import { Projects, ProjectsSchema } from '@app/projects/projects.schema'
import { ProjectTrendingEngagementsSchemaStore, ProjectTrendingEngagementsSchema } from '@app/projects/projects.trending.engagement.schema'
import { CreateCampaignReportQueueModule } from '@app/reports/cron/queue.module'
import { DripRequests, DripRequestsSchema } from '@app/requests/drip_requests.schema'
import { RequestEngagement, RequestsEngagementSchema } from '@app/requests/requests.engagement.schema'
import { Requests, RequestsSchema } from '@app/requests/requests.schema'
import { Template, TemplateSchema } from '@app/template/template.schema'
import { TrackingUniqueEvents, TrackingUniqueEventsSchema } from '@app/tracking/tracking-unique-event.schema'
import { Tracking, TrackingSchema } from '@app/tracking/tracking.schema'
import { TrackingWebSocketGateway } from '@app/tracking/tracking.socket'
import { User, UserSchema } from '@app/user/user.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { UploadDeliveryReportModule } from '@app/delivery/cron/queue.module'
import { CampaignController } from './campaign.controller'
import { Campaign, CampaignSchema } from './campaign.schema'
import { CampaignService } from './campaign.service'
import { CampaignWebSocketGateway } from './campaign.socket'
import { CreateWhatsappCampaignQueueModule, CreateSMSCampaignQueueModule, CreateRBMCampaignQueueModule, CreateDripSMSCampaignQueueModule, EngagementTrackingQueueModule, CreateDripWhatsAPPCampaignQueueModule } from './cron/queue.module'
import { QueueUIProvider } from './cron/queue.ui'
import { DripCampaign, DripCampaignSchema } from './drip_campaign.schema'

@Module({
  imports: [
    CreateSMSCampaignQueueModule,
    CreateRBMCampaignQueueModule,
    CreateWhatsappCampaignQueueModule,
    CreateCampaignReportQueueModule,
    UploadDeliveryReportModule,
    EngagementTrackingQueueModule,
    CreateDripSMSCampaignQueueModule,
    CreateDripWhatsAPPCampaignQueueModule,
    DripCriteriaModule,
    MongooseModule.forFeature([
      { name: DripCriteria.name, schema: DripCriteriaSchema },
      { name: DripRequests.name, schema: DripRequestsSchema },
      { name: Campaign.name, schema: CampaignSchema },
      { name: User.name, schema: UserSchema },
      { name: Contact.name, schema: ContactSchema },
      { name: ContactDatabase.name, schema: ContactDatabaseSchema },
      { name: Requests.name, schema: RequestsSchema },
      { name: Credits.name, schema: CreditsSchema },
      { name: Projects.name, schema: ProjectsSchema },
      { name: Campaign.name, schema: CampaignSchema },
      { name: DripCampaign.name, schema: DripCampaignSchema },
      { name: Link.name, schema: LinkSchema },
      { name: Template.name, schema: TemplateSchema },
      { name: DashboardTrendingStore.name, schema: DashboardTrendingStoreSchema },
      { name: Dashboard.name, schema: DashboardSchema },
      { name: ProjectTrendingEngagementsSchemaStore.name, schema: ProjectTrendingEngagementsSchema },
      { name: Tracking.name, schema: TrackingSchema },
      { name: TrackingUniqueEvents.name, schema: TrackingUniqueEventsSchema },
      { name: RequestEngagement.name, schema: RequestsEngagementSchema }
    ])
  ],
  controllers: [CampaignController],
  providers: [CampaignService, VappLogger, QueueUIProvider, CampaignWebSocketGateway, TrackingWebSocketGateway],
  exports: [MongooseModule]
})
export class CampaignModule {}
