import { Demographics, DemographicsSchema } from '@app/demographics/demographics.schema'
import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.DRIP_CAMPAIGN.collection, autoCreate: true })
export class DripCampaign extends Document {
  @Prop({ type: String, index: true, default: null })
    campaignID: string

  @Prop({ type: String, index: true, default: null })
    dripTemplateID: string

  @Prop({ type: String, index: true, default: null })
    dripCriteriaID:string

  @Prop({ type: String, index: true, default: null })
    databaseID: string

  @Prop({ type: String, index: true, required: true })
    projectID: string

  @Prop({ type: String, index: true, required: true })
    clientID: string

  @Prop({ type: Number, index: true, required: true })
    phone: number

  @Prop({ type: Number, index: true, required: true })
    year: number

  @Prop({ type: Number, index: true, required: true })
    month: number

  @Prop({ type: Number, index: true, required: true })
    day: number

  @Prop({ type: String, default: null })
    sms: string

  @Prop({ type: String, required: true })
    token: string

  @Prop({ type: Boolean, index: true, required: true })
    multiple: boolean

  @Prop({ type: Number, index: true, default: 0 })
    engagementTotal: number

  @Prop({ type: Number, index: true, default: 0 })
    engagementSum: number

  @Prop({ type: Number, index: true, default: 0 })
    smsEngagementTotal: number

  @Prop({ type: Number, index: true, default: 0 })
    smsEngagementSum: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappEngagementTotal: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappEngagementSum: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappClicks: number

  @Prop({ type: Number, index: true, default: 0 })
    smsSentCount: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappSentCount: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappFailedCount: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappDeliveredCount: number

  @Prop({ type: Number, index: true, default: 0 })
    smsDeliveredCount: number

  @Prop({ type: Number, index: true, default: 0 })
    smsFailedCount: number

  @Prop({ type: Number, index: true, default: 0 })
    linksCount: number

  @Prop({ type: Number, index: true, default: 0 })
    linksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappLinksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
    smsLinksClickCount: number

  @Prop({ type: Number, index: true, default: 0 })
    viewsCount: number

  @Prop({ type: Number, index: true, default: 0 })
    whatsappViewsCount: number

  @Prop({ type: Number, index: true, default: 0 })
    smsViewsCount: number

  @Prop({ type: Number, index: true, default: 0 })
    credits: number

  @Prop({ type: Boolean, index: true, default: false })
    success: boolean

  @Prop({ type: Number, index: true, default: 0 })
    status: number

  @Prop({ type: String, default: null })
    error: string

  @Prop({ type: Number, index: true, default: 0 })
    negativeCount: number

  @Prop({ type: Number, index: true, default: 0 })
    neutralCount: number

  @Prop({ type: Number, index: true, default: 0 })
    positiveCount: number

  @Prop({ type: Number, index: true, default: 0 })
    leadPositive: number

  @Prop({ type: Number, index: true, default: 0 })
    leadNegative: number

  @Prop({ type: Number, index: true, default: 0 })
    leadNeutral: number

  @Prop({ type: Number, index: true, default: 0 })
    callsThreshold: number

  @Prop({ type: Number, index: true, default: 0 })
    calls: number

  @Prop({ type: [DemographicsSchema], default: [] })
    demographics: [Demographics]

  @Prop({ type: Boolean, index: true, default: true })
    whatsappButton: boolean

  @Prop({ type: Boolean, index: true, default: true })
    chatbotButton: boolean

  @Prop({ type: String, index: true, default: null })
    dripCampaignName: string

  @Prop({ type: Number, index: true, default: null })
    dripDifference: number

  @Prop({ type: Number, index: true, required: true })
    type: number
}

export class DripCampaignAnalysisObject {
  day: number

  month: number

  projects: DripCampaign[]
}
export const DripCampaignSchema = SchemaFactory.createForClass(DripCampaign)
