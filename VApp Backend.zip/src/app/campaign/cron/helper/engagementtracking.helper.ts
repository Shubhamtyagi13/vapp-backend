import { Campaign } from '@app/campaign/campaign.schema'
import { ContactDatabase } from '@app/contact/contact.database.schema'
import { Credits } from '@app/credits/credits.schema'
import { Link } from '@app/link/link.schema'
import { Projects } from '@app/projects/projects.schema'
import { Requests } from '@app/requests/requests.schema'
import { Template } from '@app/template/template.schema'
import { TourEngagementDTO } from '@app/tracking/dto/tour-engagement.dto'
import { canonicalMethods, constants, redisKeys } from '@config'
import { Dashboard } from '@interfaces/dashboard.interface'
import { Demographics, DeviceInfo } from '@interfaces/demographics.interface'
import { Engagement } from '@interfaces/engagement.interface'
import { FirstEngagementUpdateContext } from '@interfaces/request.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { messages } from '@messages'
import { HttpStatus } from '@nestjs/common'
import { findOperations, createOperations } from '@utils/crud.util'
import DemographicsHandler from '@utils/demographics.util'
import { getErrorLog, deviceDetection, getAPIResponse } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import session from 'express-session'
import _ from 'lodash'

export const updateFirstEngagement = (request: Requests, payload: TourEngagementDTO, firstEngagementUpdateContext: FirstEngagementUpdateContext) => new Promise(async (resolve, reject) => {
  try {
    //   const request: Requests = await findOperations.findOne(this.requestModel, { _id: requestID }, {}, session)
    const {
      requestModel, templatesModel, campaignModel, contactsDatabaseModel, creditsModel, dashboardModel, projectsModel, engagementModel, linksModel,
    } = firstEngagementUpdateContext
    let demographicsFetched: Demographics = null
    const { ip, deviceDetection } = payload
    const engagement = new engagementModel({
      time: 0,
      engagementID: payload.engagementID,
    })
    if (!_.isNil(request)) {
      if (_.isNil(request.demographics)) {
        const demographicsData = await DemographicsHandler.getInstance().getDemographics(ip)
        if (!_.isNil(demographicsData.country_code_iso3)) {
          demographicsFetched = ({

            latitude: demographicsData.latitude,
            longitude: demographicsData.longitude,
            country_code: demographicsData.country_code_iso3,
            region_code: demographicsData.region_code,
            region: demographicsData.region,
            continent_code: demographicsData.continent_code,
            city: demographicsData.city,
            ip: demographicsData.ip,
          }) as Demographics
        } else {
          // logger.error(
          //   getErrorLog(canonicalMethods.UPDATE_CLIENT_ENGAGEMENT_DEMOGRAPHICS, this.traceID, { requestID, ip, demographicsFetched }, messages.CAM045.message)
          // )
        }
      }
      const requestID = request._id
      const visitedValue = true
      const linksClickCountValue = !request.visited ? 1 : 0
      const requestUpdateResult: Requests = await createOperations.updateOne(requestModel, { _id: requestID }, {
        $push: { engagementTime: engagement },
        $set: {
          visited: visitedValue,
          smsStatus: constants.SMS_STATUS.success,
          morphed: true,
          demographics: !_.isNil(demographicsFetched) ? demographicsFetched : request.demographics,
          device: deviceDetection.device,
          os: deviceDetection.os,
          deviceType: deviceDetection.type,
        },
      })
      if (!_.isNil(requestUpdateResult)) {
        let updateObject: any
        let statsUpdateObject: any
        let deliveryUpdateObject: any
        const demographicsObject: any = []
        // update sms delivered when request type is sms
        if (_.eq(requestUpdateResult.type, constants.CAMPAIGN_TYPES.SMS.value)) {
          updateObject = {
            linksClickCount: linksClickCountValue,
            smsLinksClickCount: linksClickCountValue,
            smsDeliveredCount: request.morphed ? 0 : linksClickCountValue,
            viewsCount: 1,
            smsViewsCount: 1,
          }
          statsUpdateObject = {
            linksClickCount: linksClickCountValue,
            smsLinksClickCount: linksClickCountValue,
            smsDeliveredCount: request.morphed ? 0 : linksClickCountValue,
            viewsCount: 1,
            smsViewsCount: 1,
          }
          deliveryUpdateObject = {
            smsDeliveredCount: request.morphed ? 0 : linksClickCountValue,
          }
        } else if (_.eq(requestUpdateResult.type, constants.CAMPAIGN_TYPES.WHATSAPP.value)) {
          updateObject = {
            whatsappLinksClickCount: linksClickCountValue,
            linksClickCount: linksClickCountValue,
            viewsCount: 1,
            whatsappViewsCount: 1,
          }
          statsUpdateObject = {
            linksClickCount: linksClickCountValue,
            viewsCount: 1,
            whatsappViewsCount: 1,
            whatsappLinksClickCount: linksClickCountValue,
          }
        }
        if (!_.isNil(demographicsFetched)) {
          demographicsObject.push(demographicsFetched)
        }
        const projectUpdateResult: Projects = await createOperations.updateOne(projectsModel, { _id: requestUpdateResult.projectID }, { $inc: updateObject })
        if (!_.isNil(projectUpdateResult)) {
          let templates: Template[]
          let contactsDatabases: ContactDatabase[]
          let links: Link[]
          // update campaign links clicks, view count, sms delivered count
          const campaignUpdateResult: Campaign = await createOperations.updateOne(campaignModel, { _id: requestUpdateResult.campaignID }, { $inc: updateObject, $addToSet: { demographics: demographicsObject } })
          if (!_.isNil(campaignUpdateResult)) {
            // update contacts template if present
            if (!_.isNil(campaignUpdateResult.templateID)) {
              const template: Template = await createOperations.updateOne(templatesModel, { _id: campaignUpdateResult.templateID }, { $inc: statsUpdateObject })
              if (!_.isNil(template)) {
                templates = await findOperations.find(templatesModel, { clientID: requestUpdateResult.clientID }, { __v: 0, password: 0 }, {})
              }
            }
            // update content stats if present
            if (!_.isNil(campaignUpdateResult.linkID)) {
              const link: Link = await createOperations.updateOne(linksModel, { _id: campaignUpdateResult.linkID }, { $inc: statsUpdateObject })
              if (!_.isNil(link)) {
                links = await findOperations.find(linksModel, { clientID: requestUpdateResult.clientID }, { __v: 0, password: 0 }, {})
              }
            }
            // update contacts database if present
            if (!_.isNil(campaignUpdateResult.databaseID)) {
              const contactsDatabase: ContactDatabase = await createOperations.updateOne(contactsDatabaseModel, { _id: campaignUpdateResult.databaseID }, { $inc: statsUpdateObject })
              if (!_.isNil(contactsDatabase)) {
                contactsDatabases = await findOperations.find(contactsDatabaseModel, { clientID: requestUpdateResult.clientID }, { __v: 0, password: 0 }, {})
              }
            }
            const dashboardUpdateResult: Dashboard = await createOperations.updateOneUpsert(dashboardModel, {
              year: new Date().getFullYear(),
              month: new Date().getMonth() + 1,
              clientID: requestUpdateResult.clientID,
            }, { $inc: updateObject })
            if (!_.isNil(dashboardUpdateResult)) {
              const creditsUpdateResult: Credits = await createOperations.updateOne(creditsModel, {
                clientID: requestUpdateResult.clientID,
              }, {
                $inc: deliveryUpdateObject,
              })
              if (!_.isNil(creditsUpdateResult)) {
                //   await session.commitTransaction()
                RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), JSON.stringify(creditsUpdateResult))
                RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), redisKeys.USER_CREDITS.timeout())
                RedisHandler.getInstance().set(redisKeys.PROJECT.value(projectUpdateResult._id), JSON.stringify(projectUpdateResult))
                RedisHandler.getInstance().expire(redisKeys.PROJECT.value(projectUpdateResult._id), redisKeys.PROJECT.timeout())
                RedisHandler.getInstance().set(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), JSON.stringify(campaignUpdateResult))
                RedisHandler.getInstance().ttl(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), (error: Error, time: number) => {
                  if (_.isNil(error) && _.isNumber(time)) {
                    RedisHandler.getInstance().expire(redisKeys.CAMPAIGN.value(campaignUpdateResult._id), time)
                  } else {
                    //   this.logger.error(
                    //     getErrorLog(canonicalMethods.UPDATE_CLIENT_ENGAGEMENT, this.traceID, { requestID, requestUpdateResult, error }, messages.CAM032.message)
                    //   )
                  }
                })
                if (!_.isNil(templates)) {
                  RedisHandler.getInstance().set(redisKeys.USER_TEMPLATES.value(requestUpdateResult.clientID), JSON.stringify(templates))
                  RedisHandler.getInstance().expire(redisKeys.USER_TEMPLATES.value(requestUpdateResult.clientID), redisKeys.USER_TEMPLATES.timeout())
                }
                if (!_.isNil(links)) {
                  RedisHandler.getInstance().set(redisKeys.USER_LINKS.value(requestUpdateResult.clientID), JSON.stringify(links))
                  RedisHandler.getInstance().expire(redisKeys.USER_LINKS.value(requestUpdateResult.clientID), redisKeys.USER_LINKS.timeout())
                }
                if (!_.isNil(contactsDatabases)) {
                  RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(requestUpdateResult.clientID), JSON.stringify(contactsDatabases))
                  RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(requestUpdateResult.clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
                }
                resolve(engagement)
              } else {
                throw messages.REQ001.code
              }
            } else {
              throw messages.REQ001.code
            }
          } else {
            throw messages.REQ001.code
          }
        } else {
          throw messages.REQ001.code
        }
      } else {
        throw messages.REQ001.code
      }
    } else {
      throw messages.COM001.code
    }
  } catch (error) {
    reject(error)
  }
})
