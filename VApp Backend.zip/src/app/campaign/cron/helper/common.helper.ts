import { SingleContactDTO } from '@app/campaign/dto/bulk-campaign-dto'
import { ContactDatabase } from '@app/contact/contact.database.schema'
import { Link } from '@app/link/link.schema'
import { Template } from '@app/template/template.schema'
import { cache_client, redis_client } from '@config'
import { CronError } from '@interfaces/error.interface'
import { GenericObject } from '@interfaces/generic.interface'
import { campaignProviderObject } from '@interfaces/sms.interface'
import { createOperations, findOperations } from '@utils/crud.util'
import { RedisHandler } from '@utils/redis.util'
import _ from 'lodash'
import { Model } from 'mongoose'

export const updateCommonEngagement = async (
  databaseModel: Model<ContactDatabase>,
  templateModel: Model<Template>,
  linkModel: Model<Link>,
  templateID: string,
  linkID: string,
  databaseID: string,
  clientID: string,
  updateObject: GenericObject,
) => {
  let templates: Template[]
  let contactsDatabases: ContactDatabase[]
  let links: Link[]
  if (!_.isNil(databaseID)) {
    await createOperations.updateOne(databaseModel, { _id: databaseID }, !_.isNil(updateObject.$inc) ? updateObject : { $inc: updateObject })
    contactsDatabases = await findOperations.find(databaseModel, { clientID }, { __v: 0, password: 0 }, {})
  }

  if (!_.isNil(templateID)) {
    await createOperations.updateOne(templateModel, { _id: templateID }, !_.isNil(updateObject.$inc) ? updateObject : { $inc: updateObject })
    templates = await findOperations.find(templateModel, { clientID }, { __v: 0, password: 0 }, {})
  }

  if (!_.isNil(linkID)) {
    await createOperations.updateOne(linkModel, { _id: linkID }, !_.isNil(updateObject.$inc) ? updateObject : { $inc: updateObject })
    links = await findOperations.find(linkModel, { clientID }, { __v: 0, password: 0 }, {})
  }
  return ({ templates, links, contactsDatabases })
}

export const extractCampaignData = (traceID: string) => new Promise<Array<SingleContactDTO> >((resolve, rej) => {
  RedisHandler.getInstance(cache_client.DEFAULT, redis_client.COMMON_JOB_DATA).get(traceID, (error: Error, data: string) => {
    if (_.isNil(error) && !_.isNil(data)) {
      const job_data = JSON.parse(data) as Array<SingleContactDTO>
      resolve(job_data)
    } else {
      throw new CronError('data not found')
    }
  })
})

export const deleteCampaignData = (traceID: string) => new Promise<boolean>((resolve, rej) => {
  RedisHandler.getInstance(cache_client.DEFAULT, redis_client.COMMON_JOB_DATA).del(traceID, (error: Error, data: number) => {
    if (_.isNil(error) && !_.isNil(data) && data === 1) {
      resolve(true)
    } else {
      resolve(false)
    }
  })
})
