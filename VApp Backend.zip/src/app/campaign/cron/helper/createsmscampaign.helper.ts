import { Campaign } from '@app/campaign/campaign.schema'
import { DripCampaign } from '@app/campaign/drip_campaign.schema'
import { Projects } from '@app/projects/projects.schema'
import { DripRequests } from '@app/requests/drip_requests.schema'
import { Requests } from '@app/requests/requests.schema'
import { Template } from '@app/template/template.schema'
import { User } from '@app/user/user.schema'
import { redisKeys } from '@config'
import { CampaignCronPayload } from '@interfaces/sms-campaign.interface'
import { messages } from '@messages'
import { getSecondsFromHours } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import _ from 'lodash'

export const RedisUpdateRequests = (request: Requests, campaign: Campaign, user: User, project: Projects, payload: CampaignCronPayload) => {
  RedisHandler.getInstance().set(redisKeys.CAMPAIGN_REQUEST.value(request.shortID), JSON.stringify({
    message: messages.CAM021.message,
    code: messages.CAM021.code,
    projectID: payload.projectID,
    phoneNumber: project.phone,
    ivr: !_.isNil(payload.ivr) && !_.isNaN(parseInt(String(payload.ivr), 10)) ? parseInt(String(payload.ivr), 10) : -1,
    url: payload.url,
    cloud: payload.cloud,
    redirection: payload.redirection,
    requestID: request._id,
    campaignID: campaign._id,
    projectName: project.name,
    companyName: user.companyName,
    brochure: project.brochure,
    greeting: user.greeting,
    chatbotButton: payload.chatbotButton,
    whatsappButton: payload.whatsappButton,
    trackingScript: campaign.trackingScript,
  }))
  RedisHandler.getInstance().expire(redisKeys.CAMPAIGN_REQUEST.value(request.shortID), user.defaultCampaignExpireyTime ? getSecondsFromHours(user.defaultCampaignExpireyTime) : redisKeys.CAMPAIGN_REQUEST.timeout())
}

export const RedisUpdateDripRequests = (request: DripRequests, campaign: DripCampaign, user: User, project: Projects, payload: CampaignCronPayload) => {
  RedisHandler.getInstance().set(redisKeys.CAMPAIGN_REQUEST.value(request.shortID), JSON.stringify({
    message: messages.CAM021.message,
    code: messages.CAM021.code,
    projectID: payload.projectID,
    phoneNumber: project.phone,
    ivr: !_.isNil(payload.ivr) && !_.isNaN(parseInt(String(payload.ivr), 10)) ? parseInt(String(payload.ivr), 10) : -1,
    url: payload.url,
    cloud: payload.cloud,
    redirection: payload.redirection,
    requestID: request._id,
    campaignID: campaign._id,
    projectName: project.name,
    companyName: user.companyName,
    brochure: project.brochure,
    greeting: user.greeting,
    chatbotButton: payload.chatbotButton,
    whatsappButton: payload.whatsappButton,
  }))
  RedisHandler.getInstance().expire(redisKeys.CAMPAIGN_REQUEST.value(request.shortID), user.defaultCampaignExpireyTime ? getSecondsFromHours(user.defaultCampaignExpireyTime) : redisKeys.CAMPAIGN_REQUEST.timeout())
}
