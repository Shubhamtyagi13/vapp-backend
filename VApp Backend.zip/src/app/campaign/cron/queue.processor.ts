import { ContactDatabase } from '@app/contact/contact.database.schema'
import { Credits } from '@app/credits/credits.schema'
import { Dashboard } from '@app/dashboard/dashboard.schema'
import { DashboardTrendingStore as DashboardTrendingStoreSchema } from '@app/dashboard/dashboard.trending.schema'
import { DripCriteria } from '@app/dripcriteria/dripcriteria.schema'
import { RBMCredentials } from '@app/integrations/helpers/rbm/interfaces/credentials.interface'
import { Integrations } from '@app/integrations/integrations.schema'
import { IntegrationsService } from '@app/integrations/integrations.service'
import { Link } from '@app/link/link.schema'
import { Projects } from '@app/projects/projects.schema'
import { ProjectTrendingEngagementsSchemaStore } from '@app/projects/projects.trending.engagement.schema'
import { DripRequests } from '@app/requests/drip_requests.schema'
import { RequestEngagement } from '@app/requests/requests.engagement.schema'
import { Requests } from '@app/requests/requests.schema'
import { Template } from '@app/template/template.schema'
import {
  getDashboardTrendingDatabases,
  getDashboardTrendingLink,
  getDashboardTrendingProjects,
  getDashboardTrendingTemplate,
  getEngagementIncrementObject,
  upadateRequestEngagement,
  updateCampaignEngagement,
  updateProjectEngagement,
  updateProjectTrendsModel,
} from '@app/tracking/cron/helpers/engagement.cron.helper'
import { TourEngagementDTO } from '@app/tracking/dto/tour-engagement.dto'
import { TrackingWebSocketGateway } from '@app/tracking/tracking.socket'
import { User } from '@app/user/user.schema'
import {
  cache_client,
  campaignStates,
  constants,
  CRON_SCHEDULES_TIME,
  cronJobs,
  redisKeys,
  report_types,
  variables,
  websocketEvents,
  redis_client,
  integration_operation,
  integration_type,
} from '@config'
import {
  CampaignReportCronPayload,
  CronPayload,
} from '@interfaces/cron.interface'
import {
  DashboardTrendingDatabase,
  DashboardTrendingLink,
  DashboardTrendingPerson,
  DashboardTrendingTemplate,
} from '@interfaces/dashboard.interface'
import {
  EngagementLevel,
  TrendsEngagement,
} from '@interfaces/engagement.interface'
import { CronError } from '@interfaces/error.interface'
import { GenericObject } from '@interfaces/generic.interface'
import { ProjectTrendingEngagementsStore } from '@interfaces/project.interface'
import { RbmDialAction, RbmMessageWithActions, RbmMessageWithImage, RbmOpenUrlAction, RbmReport, RbmRichCard, RbmRichCardCarosuel, RbmSimpleMessage } from '@interfaces/rbm.interface'
import {
} from '@interfaces/report.interface'
import { FirstEngagementUpdateContext } from '@interfaces/request.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import {
  CampaignCronPayload,
  FinalizeCampaignCronPayload,
} from '@interfaces/sms-campaign.interface'
import { campaignProviderObject } from '@interfaces/sms.interface'
import { rbmApiHelper } from '@libraries/rbm/rbm.helper'
import { RBMClient } from '@libraries/rbm/rbm.service'
import { messages } from '@messages'
import {
  InjectQueue,
  OnQueueActive,
  OnQueueCompleted,
  OnQueueFailed,
  Process,
  Processor,
} from '@nestjs/bull'
import { Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { HTTPService } from '@services/http.service'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import {
  deleteFolderRecursive,
  generateShortUID,
  getCreditsFromMessage,
  getDripRequestMessage,
  getEnvironmentVariable,
  getErrorLog,
  getExpirationTimestamp,
  getMilliseconds,
  getRequestMessage,
  getSecondsFromHours,
  switchSMPPClientRoute,
} from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import async from 'async'
import { Job, Queue } from 'bull'
import _ from 'lodash'
import { Model, Types } from 'mongoose'
import { join } from 'path'
import { Campaign } from '../campaign.schema'
import { CampaignWebSocketGateway } from '../campaign.socket'
import { DripCampaign } from '../drip_campaign.schema'
import { SingleContactDTO } from '../dto/bulk-campaign-dto'
import { ProcessSMPPDTO } from '../dto/smpp-campaign'
import { WhatsappHelper } from '../helpers/whatsapp_campaign.helper'
import { updateCommonEngagement, extractCampaignData, deleteCampaignData } from './helper/common.helper'
import {
  RedisUpdateDripRequests,
  RedisUpdateRequests,
} from './helper/createsmscampaign.helper'
import { updateFirstEngagement } from './helper/engagementtracking.helper'

@Injectable()
@Processor(cronJobs.CREATE_SMS_CAMPAIGN.name)
export class CreateSMSCampaignProcessor {
  constructor(
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(Projects.name) private projectsModel: Model<Projects>,
    @InjectModel(Campaign.name) private campaignModel: Model<Campaign>,
    @InjectModel(DripCampaign.name) private dripCampaignModel: Model<DripCampaign>,
    @InjectModel(Credits.name) private creditsModel: Model<Credits>,
    @InjectModel(Link.name) private linksModel: Model<Link>,
    @InjectModel(Requests.name) private requestsModel: Model<Requests>,
    @InjectModel(Dashboard.name) private dashboardModel: Model<Dashboard>,
    @InjectModel(Template.name) private templatesModel: Model<Template>,
    @InjectModel(ContactDatabase.name) private contactDatabaseModel: Model<ContactDatabase>,
    @InjectQueue(cronJobs.CREATE_CAMPAIGN_REPORT.name) private createCampaignReportQueue: Queue,
    @InjectQueue(cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name) private createDripSMSCampaignQueue: Queue,
    private logger: VappLogger,
  ) { }

  @Process({ concurrency: 10 })
  async createSMSCampaign(job: Job<CronPayload<CampaignCronPayload>>) {
    const { payload, traceID } = job.data
    payload.contactData = await extractCampaignData(traceID)
    let smsSenderID: string
    let peID: string
    let templateID: string
    let route = -1
    const smsRequests: Requests[] = []
    let { campaignID } = payload
    try {
      const campaign = await createOperations.updateOne(this.campaignModel, { _id: campaignID }, {
        status: campaignStates.RUNNING,
      })
      /* ToDo : to be moved to after SMPP */
      /* this.commonQueue.add(
            payload.dripWhatsappButton ? cronJobs.CREATE_DRIP_WHATSAPP_CAMPAIGN.name : cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name,
            { payload: payload, campaignID:campaignID, traceID },
            { delay:0, priority: 1}
          ) */
      const user: User = await findOperations.findById(this.userModel, payload.clientID, {})
      if (!_.isNil(user)) {
        smsSenderID = user.smsSenderID
        peID = user.peID
        templateID = payload.registeredTemplateID
        if (!_.isNaN(user.route)) {
          route = user.route
        }
        const project: Projects = await findOperations.findOne(this.projectsModel, {
          clientID: payload.clientID,
          _id: payload.projectID,
        }, {})
        if (!_.isNil(project)) {
          // assign project sms sender id in case present else use default user sms sender id
          if (
            !_.isNil(project.smsSenderID)
            && !_.isEmpty(project.smsSenderID)
          ) {
            smsSenderID = project.smsSenderID
          }
          campaignID = _.toString(campaign._id)
          let totalCredits = 0
          const smsProviderPayload: campaignProviderObject[] = []
          payload.contactData.forEach((contact: SingleContactDTO) => {
            const request = new this.requestsModel({
              projectID: payload.projectID,
              clientID: payload.clientID,
              campaignID: campaign._id,
              shortID: generateShortUID(),
              expiresOn: getExpirationTimestamp(campaign.token),
              firstName: contact.firstName,
              middleName: contact.middleName,
              lastName: contact.lastName,
              var1: contact.var1,
              var2: contact.var2,
              var3: contact.var3,
              var4: contact.var4,
              year: new Date().getFullYear(),
              month: new Date().getMonth() + 1,
              day: new Date().getDate(),
              phone: parseInt(String(Math.abs(Number(contact.phone))), 10),
              type: payload.type,
            }) as Requests
            const compiledMessage: string = getRequestMessage(payload, request, user.altDomain)
            request.credit = getCreditsFromMessage(compiledMessage)
            totalCredits += request.credit
            smsProviderPayload.push({
              phone: parseInt(String(Math.abs(Number(contact.phone))), 10),
              message: compiledMessage,
            })
            smsRequests.push(request)
            RedisUpdateRequests(request, campaign, user, project, payload)
          })
          const creditsSession = await this.creditsModel.db.startSession()
          await creditsSession.withTransaction(async () => {
            const credits: Credits = await findOperations.findOne(this.creditsModel, { clientID: payload.clientID }, {}, creditsSession)
            if (credits.credits > 0 && credits.credits - totalCredits > 0) {
              await createOperations.updateOne(this.creditsModel, { clientID: payload.clientID }, { $inc: { frozenCount: totalCredits, credits: -totalCredits } }, creditsSession)
            } else {
              throw new CronError(messages.CRE009.message)
            }
          }, constants.TRANSACTION_OPTIONS)
          creditsSession.endSession()
          const requestsSaveResult = await createOperations.processBulkInsertion(this.requestsModel, smsRequests, job)
          if (!_.isNil(requestsSaveResult)) {
            const commonUpdateObject = { $inc: { linksCount: payload.tracking ? payload.contactData.length : 0, smsSentCount: payload.contactData.length } }
            const campaignUpdateResult: Campaign = await createOperations.updateOne(this.campaignModel, { _id: campaign._id }, commonUpdateObject)
            if (!_.isNil(campaignUpdateResult)) {
              const commonEngagementUpdateResult = await updateCommonEngagement(this.contactDatabaseModel, this.templatesModel, this.linksModel, campaignUpdateResult.templateID, campaignUpdateResult.linkID, campaignUpdateResult.databaseID, campaignUpdateResult.clientID, commonUpdateObject)
              const projectUpdateResult: Projects = await createOperations.updateOne(this.projectsModel, { _id: project._id }, commonUpdateObject)
              if (!_.isNil(projectUpdateResult)) {
                // update monthly dashboard links clicks, view count, sms delivered count
                const dashboardUpdateResult: Dashboard = await createOperations.updateOneUpsert(this.dashboardModel, {
                  year: new Date().getFullYear(),
                  month: new Date().getMonth() + 1,
                  clientID: campaignUpdateResult.clientID,
                }, commonUpdateObject)
                if (!_.isNil(dashboardUpdateResult)) {
                  const creditsSession = await this.creditsModel.db.startSession()
                  await creditsSession.withTransaction(async () => {
                    await createOperations.updateOne(this.creditsModel, { clientID: campaignUpdateResult.clientID }, {
                      $inc: {
                        frozenCount: -totalCredits,
                        smsSentCount: payload.contactData.length,
                        smsCredits: totalCredits,
                      },
                    }, creditsSession)
                  }, constants.TRANSACTION_OPTIONS)
                  creditsSession.endSession()
                  const creditsUpdateResult = await findOperations.findOne(this.creditsModel, { clientID: campaignUpdateResult.clientID })
                  if (!_.isNil(creditsUpdateResult)) {
                    // update credits in redis
                    if (_.isNil(templateID)) {
                      throw new CronError(messages.TEM008.message)
                    }
                    const campaignFinalResult: Campaign = await createOperations.updateOne(this.campaignModel, { _id: campaign._id }, {
                      $set: {
                        success: true,
                        campaignID: generateShortUID(),
                        credits: totalCredits,
                      },
                    })
                    if (!_.isNil(campaignFinalResult)) {
                      /* check if drip and add to queue */
                      let dripDifference = -1
                      if (!_.isNil(payload.scheduleDripDate)) {
                        dripDifference = new Date(payload.scheduleDripDate).getTime() - new Date().getTime()
                        if (dripDifference < 6 * 60 * 60 * 1000) {
                          dripDifference = 6 * 60 * 60 * 1000
                        }
                      }

                      if (payload.isDripCampaign) {
                        const drip_payload = payload
                        drip_payload.var1 = payload.contactData[0].var1
                        drip_payload.var2 = payload.contactData[0].var2
                        drip_payload.var3 = payload.contactData[0].var3
                        drip_payload.var4 = payload.contactData[0].var4
                        drip_payload.contactData = []

                        this.createDripSMSCampaignQueue.add({ payload: drip_payload, campaignID, traceID }, {
                          delay: dripDifference < 0 ? getMilliseconds(CRON_SCHEDULES_TIME.DRIP_CAMPAIGN)
                            : dripDifference,
                          priority: 1,
                        })
                      }

                      await this.createCampaignReportQueue.add({
                        payload: {
                          clientID: payload.clientID,
                          campaignID: campaign.id,
                        } as CampaignReportCronPayload,
                        traceID,
                      }, { delay: getMilliseconds(CRON_SCHEDULES_TIME.CREATE_CAMAPAIGN_REPORT) })
                      // set campaign in redis
                      RedisHandler.getInstance().set(redisKeys.CAMPAIGN.value(campaign._id), JSON.stringify(campaignFinalResult))
                      RedisHandler.getInstance().expire(redisKeys.CAMPAIGN.value(campaign._id), redisKeys.CAMPAIGN.timeout())
                      // set credits in redis
                      RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), JSON.stringify(creditsUpdateResult))
                      RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), redisKeys.USER_CREDITS.timeout())
                      // set projects in redis
                      RedisHandler.getInstance().set(redisKeys.PROJECT.value(project._id), JSON.stringify(projectUpdateResult))
                      RedisHandler.getInstance().expire(redisKeys.PROJECT.value(project._id), redisKeys.PROJECT.timeout())
                      // set templates in redis
                      if (!_.isNil(commonEngagementUpdateResult.templates)) {
                        RedisHandler.getInstance().set(redisKeys.USER_TEMPLATES.value(campaignUpdateResult.clientID), JSON.stringify(commonEngagementUpdateResult.templates))
                        RedisHandler.getInstance().expire(redisKeys.USER_TEMPLATES.value(campaignUpdateResult.clientID), redisKeys.USER_TEMPLATES.timeout())
                      }
                      // set databases in redis
                      if (!_.isNil(commonEngagementUpdateResult.contactsDatabases)) {
                        RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(campaignUpdateResult.clientID), JSON.stringify(commonEngagementUpdateResult.contactsDatabases))
                        RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(campaignUpdateResult.clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
                      }
                      // set links in redis
                      if (!_.isNil(commonEngagementUpdateResult.links)) {
                        RedisHandler.getInstance().set(redisKeys.USER_LINKS.value(campaignUpdateResult.clientID), JSON.stringify(commonEngagementUpdateResult.links))
                        RedisHandler.getInstance().expire(redisKeys.USER_LINKS.value(campaignUpdateResult.clientID), redisKeys.USER_LINKS.timeout())
                      }
                    } else {
                      throw new CronError(messages.CAM031.message)
                    }
                    await HTTPService.getInstance().post(`${getEnvironmentVariable(variables.SMPP_SERVICE_BASE_URL.name)}campaign/process`, <ProcessSMPPDTO>{
                      smpp_config: switchSMPPClientRoute(route),
                      data: smsProviderPayload,
                      smsSenderID,
                      templateID,
                      campaignID: campaign.id,
                      peID,
                      reportType: report_types.CAMPAIGN,
                    })
                    await deleteCampaignData(traceID)
                  } else {
                    throw new CronError(messages.CRE011.message)
                  }
                } else {
                  throw new CronError(messages.DAS001.message)
                }
              } else {
                throw new CronError(messages.PROJ042.message)
              }
            } else {
              throw new CronError(messages.CAM031.message)
            }
          } else {
            throw new CronError(messages.REQ003.message)
          }
        } else {
          throw new CronError(messages.PROJ019.message)
        }
      } else {
        throw new CronError(messages.USER009.message)
      }
    } catch (error) {
      // decrease credits again
      if (!_.isNil(error.name) && error.name.includes(CronError.name)) {
        error.stack = 'CronError'
      }
      throw error
    }
    job.progress(100)
    return true
  }

  @OnQueueActive()
  onActive(job: Job<CronPayload<CampaignCronPayload>>) {
    this.logger.log(`Processing: Job name: ${job.name} Job ID: ${job.id}`)
  }

  @OnQueueCompleted()
  async onCompleted(job: Job<CronPayload<CampaignCronPayload>>) {
    const { payload } = job.data

    if (payload.isDripCampaign && job.name === cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name) {
      await createOperations.updateOne(this.dripCampaignModel, { campaignID: payload.campaignID }, {
        status: campaignStates.PROCESSED,
      })
    } else {
      await createOperations.updateOne(this.campaignModel, { _id: payload.campaignID }, {
        status: campaignStates.PROCESSED,
      })
    }
    this.logger.log(`Completed: Job name: ${job.name} Job ID: ${job.id}`)
  }

  @OnQueueFailed()
  async onFailed(job: Job<CronPayload<CampaignCronPayload>>) {
    const error = job.stacktrace.includes(CronError.name) ? job.failedReason : messages.COM001.message
    const { payload } = job.data
    if (_.eq(job.attemptsMade, cronJobs.CREATE_SMS_CAMPAIGN.attempts)) {
      await createOperations.updateOne(this.campaignModel, { _id: payload.campaignID }, {
        success: false,
        error,
        status: campaignStates.PROCESSED,
      })
    }
    this.logger.error(getErrorLog(job.name, job.data.traceID, { id: job.id, reason: job.failedReason, stack: job.stacktrace }))
  }
}

@Injectable()
@Processor(cronJobs.CREATE_RBM_CAMPAIGN.name)
export class CreateRBMCampaignProcessor {
  constructor(
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(Projects.name) private projectsModel: Model<Projects>,
    @InjectModel(Campaign.name) private campaignModel: Model<Campaign>,
    @InjectModel(DripCampaign.name) private dripCampaignModel: Model<DripCampaign>,
    @InjectModel(Credits.name) private creditsModel: Model<Credits>,
    @InjectModel(Link.name) private linksModel: Model<Link>,
    @InjectModel(Requests.name) private requestsModel: Model<Requests>,
    @InjectModel(Dashboard.name) private dashboardModel: Model<Dashboard>,
    @InjectModel(Template.name) private templatesModel: Model<Template>,
    @InjectModel(ContactDatabase.name) private contactDatabaseModel: Model<ContactDatabase>,
    @InjectQueue(cronJobs.CREATE_CAMPAIGN_REPORT.name) private createCampaignReportQueue: Queue,
    @InjectQueue(cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name) private createDripSMSCampaignQueue: Queue,
    @InjectQueue(cronJobs.CREATE_SMS_CAMPAIGN.name) private creatSMSCampaignQueue: Queue,
    private integrationsService: IntegrationsService,
    private rbmClient: RBMClient,
    private logger: VappLogger,
  ) { }

  @Process({ concurrency: 10 })
  async createRBMCampaign(job: Job<CronPayload<CampaignCronPayload>>) {
    const { payload, traceID } = job.data
    payload.contactData = await extractCampaignData(traceID)
    let templateID: string
    let { campaignID } = payload
    const smsProviderPayload: Array<campaignProviderObject & {shortID: string, credits: number}> = []
    const smsRequests: Requests[] = []
    try {
      const integrations_response: ServiceResponse = await this.integrationsService.fetchIntegrations(payload.clientID, traceID, true)
      const rbm_integration: Integrations = integrations_response.data.find((integration: Integrations) => _.eq(integration.type, integration_type.RBM))
      if (!_.isNil(rbm_integration)) {
        const campaign = await createOperations.updateOne(this.campaignModel, { _id: campaignID }, {
          status: campaignStates.RUNNING,
          rcs: true
        })
        const user: User = await findOperations.findById(this.userModel, payload.clientID, {})
        if (!_.isNil(user)) {
          templateID = payload.registeredTemplateID

          const project: Projects = await findOperations.findOne(this.projectsModel, {
            clientID: payload.clientID,
            _id: payload.projectID,
          }, {})
          if (!_.isNil(project)) {
            // assign project sms sender id in case present else use default user sms sender id

            campaignID = _.toString(campaign._id)
            let totalCredits = 0
            payload.contactData.forEach((contact: SingleContactDTO) => {
              const request = new this.requestsModel({
                projectID: payload.projectID,
                clientID: payload.clientID,
                campaignID: campaign._id,
                shortID: generateShortUID(),
                expiresOn: getExpirationTimestamp(campaign.token),
                firstName: contact.firstName,
                middleName: contact.middleName,
                lastName: contact.lastName,
                var1: contact.var1,
                var2: contact.var2,
                var3: contact.var3,
                rcs: true,
                var4: contact.var4,
                year: new Date().getFullYear(),
                month: new Date().getMonth() + 1,
                day: new Date().getDate(),
                phone: parseInt(String(Math.abs(Number(contact.phone))), 10),
                type: payload.type,
              }) as Requests
              const compiledMessage: string = getRequestMessage(payload, request, user.altDomain, false, true)
              request.credit = getCreditsFromMessage(compiledMessage)
              totalCredits += request.credit
              smsProviderPayload.push({ phone: parseInt(String(Math.abs(Number(contact.phone))), 10), message: compiledMessage, shortID: request.shortID, credits: request.credit })
              smsRequests.push(request)
              RedisUpdateRequests(request, campaign, user, project, payload)
            })

            const creditsSession = await this.creditsModel.db.startSession()
            await creditsSession.withTransaction(async () => {
              const credits: Credits = await findOperations.findOne(this.creditsModel, { clientID: payload.clientID }, {}, creditsSession)
              if (credits.credits > 0 && credits.credits - totalCredits > 0) {
                await createOperations.updateOne(this.creditsModel, { clientID: payload.clientID }, { $inc: { frozenCount: totalCredits, credits: -totalCredits } }, creditsSession)
              } else {
                throw new CronError(messages.CRE009.message)
              }
            }, constants.TRANSACTION_OPTIONS)
            creditsSession.endSession()
            const requestsSaveResult = await createOperations.processBulkInsertion(this.requestsModel, smsRequests, job)
            if (!_.isNil(requestsSaveResult)) {
              const commonUpdateObject = { $inc: { linksCount: payload.tracking ? payload.contactData.length : 0, smsSentCount: payload.contactData.length } }
              const campaignUpdateResult: Campaign = await createOperations.updateOne(this.campaignModel, { _id: campaign._id }, commonUpdateObject)
              if (!_.isNil(campaignUpdateResult)) {
                const commonEngagementUpdateResult = await updateCommonEngagement(this.contactDatabaseModel, this.templatesModel, this.linksModel, campaignUpdateResult.templateID, campaignUpdateResult.linkID, campaignUpdateResult.databaseID, campaignUpdateResult.clientID, commonUpdateObject)
                const projectUpdateResult: Projects = await createOperations.updateOne(this.projectsModel, { _id: project._id }, commonUpdateObject)
                if (!_.isNil(projectUpdateResult)) {
                  // update monthly dashboard links clicks, view count, sms delivered count
                  const dashboardUpdateResult: Dashboard = await createOperations.updateOneUpsert(this.dashboardModel, {
                    year: new Date().getFullYear(),
                    month: new Date().getMonth() + 1,
                    clientID: campaignUpdateResult.clientID,
                  }, commonUpdateObject)
                  if (!_.isNil(dashboardUpdateResult)) {
                    const creditsSession = await this.creditsModel.db.startSession()
                    await creditsSession.withTransaction(async () => {
                      await createOperations.updateOne(this.creditsModel, { clientID: campaignUpdateResult.clientID }, {
                        $inc: {
                          frozenCount: -totalCredits,
                          smsSentCount: payload.contactData.length,
                          smsCredits: totalCredits,
                        },
                      }, creditsSession)
                    }, constants.TRANSACTION_OPTIONS)
                    creditsSession.endSession()
                    const creditsUpdateResult = await findOperations.findOne(this.creditsModel, { clientID: campaignUpdateResult.clientID })
                    if (!_.isNil(creditsUpdateResult)) {
                      // update credits in redis
                      if (_.isNil(templateID)) {
                        throw new CronError(messages.TEM008.message)
                      }
                      const campaignFinalResult: Campaign = await createOperations.updateOne(this.campaignModel, { _id: campaign._id }, {
                        $set: {
                          success: true,
                          campaignID: generateShortUID(),
                          credits: totalCredits,
                        },
                      })
                      if (!_.isNil(campaignFinalResult)) {
                        /* check if drip and add to queue */
                        let dripDifference = -1
                        if (!_.isNil(payload.scheduleDripDate)) {
                          dripDifference = new Date(payload.scheduleDripDate).getTime() - new Date().getTime()
                          if (dripDifference < 6 * 60 * 60 * 1000) {
                            dripDifference = 6 * 60 * 60 * 1000
                          }
                        }

                        if (payload.isDripCampaign) {
                          const drip_payload = payload
                          drip_payload.var1 = payload.contactData[0].var1
                          drip_payload.var2 = payload.contactData[0].var2
                          drip_payload.var3 = payload.contactData[0].var3
                          drip_payload.var4 = payload.contactData[0].var4
                          drip_payload.contactData = []

                          this.createDripSMSCampaignQueue.add({ payload: drip_payload, campaignID, traceID }, {
                            delay: dripDifference < 0 ? getMilliseconds(CRON_SCHEDULES_TIME.DRIP_CAMPAIGN)
                              : dripDifference,
                            priority: 1,
                          })
                        }

                        await this.createCampaignReportQueue.add({
                          payload: {
                            clientID: payload.clientID,
                            campaignID: campaign.id,
                          } as CampaignReportCronPayload,
                          traceID,
                        }, { delay: getMilliseconds(CRON_SCHEDULES_TIME.CREATE_CAMAPAIGN_REPORT) })
                        // set campaign in redis
                        RedisHandler.getInstance().set(redisKeys.CAMPAIGN.value(campaign._id), JSON.stringify(campaignFinalResult))
                        RedisHandler.getInstance().expire(redisKeys.CAMPAIGN.value(campaign._id), redisKeys.CAMPAIGN.timeout())
                        // set credits in redis
                        RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), JSON.stringify(creditsUpdateResult))
                        RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), redisKeys.USER_CREDITS.timeout())
                        // set projects in redis
                        RedisHandler.getInstance().set(redisKeys.PROJECT.value(project._id), JSON.stringify(projectUpdateResult))
                        RedisHandler.getInstance().expire(redisKeys.PROJECT.value(project._id), redisKeys.PROJECT.timeout())
                        // set templates in redis
                        if (!_.isNil(commonEngagementUpdateResult.templates)) {
                          RedisHandler.getInstance().set(redisKeys.USER_TEMPLATES.value(campaignUpdateResult.clientID), JSON.stringify(commonEngagementUpdateResult.templates))
                          RedisHandler.getInstance().expire(redisKeys.USER_TEMPLATES.value(campaignUpdateResult.clientID), redisKeys.USER_TEMPLATES.timeout())
                        }
                        // set databases in redis
                        if (!_.isNil(commonEngagementUpdateResult.contactsDatabases)) {
                          RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(campaignUpdateResult.clientID), JSON.stringify(commonEngagementUpdateResult.contactsDatabases))
                          RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(campaignUpdateResult.clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
                        }
                        // set links in redis
                        if (!_.isNil(commonEngagementUpdateResult.links)) {
                          RedisHandler.getInstance().set(redisKeys.USER_LINKS.value(campaignUpdateResult.clientID), JSON.stringify(commonEngagementUpdateResult.links))
                          RedisHandler.getInstance().expire(redisKeys.USER_LINKS.value(campaignUpdateResult.clientID), redisKeys.USER_LINKS.timeout())
                        }
                      } else {
                        throw new CronError(messages.CAM031.message)
                      }
                      const rbmClient = await this.rbmClient.initRbmApi(rbm_integration.credentials as RBMCredentials)
                      const rbmInstance = rbmApiHelper(rbmClient.rbmApi, rbmClient.authClient)
                      const rbm_promises = []
                      let refund_credits = 0
                      const failed: Array<SingleContactDTO> = []
                      smsProviderPayload.forEach((smsRequest) => {
                        rbm_promises.push((callback) => {
                          const rbm_message_payload: RbmSimpleMessage | RbmMessageWithImage | RbmRichCard | RbmRichCardCarosuel | RbmMessageWithActions = { messageText: smsRequest.message, msisdn: `+91${smsRequest.phone}`, suggestions: [] }
                          if (payload.tracking) {
                            rbm_message_payload.suggestions.push({
                              action: {
                                text: 'Visit',
                                postbackData: 'site_visited',
                                 openUrlAction: {
                                  url: `${user.altDomain}/${smsRequest.shortID}`
                                 }
                              }
                           })
                          }
                          if (payload.ivr) {
                            rbm_message_payload.suggestions.push({
                              action: {
                                 text: 'Call',
                                 postbackData: 'ivr_called',
                                 dialAction: {
                                  phoneNumber: `+91${smsRequest.phone}`
                                 }
                              }
                           })
                          }
                          // rbm_message_payload.suggestions = suggestions
                          rbmInstance.sendMessage(rbm_message_payload, (response) => {
                            if (!_.isNil(response)) {
                              const { messageId } = response.config.params
                              const report = {
                                phone: response.data.name.split('/')[1],
                                rbmMessageID: messageId,
                                reportType: report_types.RBM_CAMPAIGN,
                                campaignID
                              } as RbmReport
                              RedisHandler.getInstance(cache_client.DEFAULT, redis_client.SMPP_DELIVERY)
                                .multi()
                                .setnx(redisKeys.SMPP_DELIVERY_RESPONSE.value(report.rbmMessageID), JSON.stringify(report))
                                .expire(redisKeys.SMPP_DELIVERY_RESPONSE.value(report.rbmMessageID), redisKeys.SMPP_DELIVERY_RESPONSE.timeout())
                                .exec(() => { })
                              callback(null, true)
                            } else {
                              failed.push(payload.contactData.find((contact) => _.isEqual(contact.phone, smsRequest.phone)))
                              refund_credits += smsRequest.credits
                              callback(null, true)
                            }
                          })
                        })
                      })
                      await this.processUpdates(rbm_promises)
                      if (_.gt(failed.length, 0)) {
                        if (payload.failover) {
                        RedisHandler.getInstance(cache_client.DEFAULT, redis_client.COMMON_JOB_DATA)
                          .multi()
                          .setnx(traceID, JSON.stringify(failed))
                          .expire(traceID, redisKeys.CAMPAIGN_DATA.timeout())
                          .exec(() => {
                          })
                          const campaignObj = new this.campaignModel({
                            projectID: campaign.projectID,
                            clientID: campaign.clientID,
                            phone: campaign.phone,
                            type: campaign.type,
                            year: campaign.year,
                            ivr: campaign.ivr,
                            month: campaign.month,
                            day: campaign.day,
                            cloud: campaign.cloud,
                            redirection: campaign.redirection,
                            rcs: false,
                            tracking: campaign.tracking,
                            url: campaign.url,
                            route: campaign.route,
                            campaignName: campaign.campaignName,
                            sms: campaign.sms,
                            multiple: campaign.multiple,
                            chatbotButton: campaign.chatbotButton,
                            whatsappButton: campaign.whatsappButton,
                            status: campaign.status,
                            scheduleDate: campaign.scheduleDate,
                            databaseID: campaign.databaseID,
                            linkID: payload.linkID,
                            trackingScript: campaign.trackingScript,
                            token: campaign.token,
                            templateID: campaign.templateID
                          } as Campaign)
                          const campaignResult = await createOperations.save(campaignObj)
                          await this.creatSMSCampaignQueue.add({
                            payload: { ...payload, campaignID: campaignResult._id, failover: false, rcs: false },
                            traceID
                          })
                        } else {
                          const creditsSession = await this.creditsModel.db.startSession()
                          await creditsSession.withTransaction(async () => {
                              await findOperations.findOne(this.creditsModel, { clientID: payload.clientID }, {}, creditsSession)
                              await createOperations.updateOne(this.creditsModel, { clientID: payload.clientID }, { $inc: { credits: refund_credits } }, creditsSession)
                          }, constants.TRANSACTION_OPTIONS)
                          creditsSession.endSession()
                          const creditsUpdateResult = await findOperations.findOne(this.creditsModel, { clientID: campaignUpdateResult.clientID })
                          if (!_.isNil(creditsUpdateResult)) {
                             // set credits in redis
                            RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), JSON.stringify(creditsUpdateResult))
                            RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), redisKeys.USER_CREDITS.timeout())
                          }
                          await deleteCampaignData(traceID)
                        }
                      } else {
                        await deleteCampaignData(traceID)
                      }
                    } else {
                      throw new CronError(messages.CRE011.message)
                    }
                  } else {
                    throw new CronError(messages.DAS001.message)
                  }
                } else {
                  throw new CronError(messages.PROJ042.message)
                }
              } else {
                throw new CronError(messages.CAM031.message)
              }
            } else {
              throw new CronError(messages.REQ003.message)
            }
          } else {
            throw new CronError(messages.PROJ019.message)
          }
        } else {
          throw new CronError(messages.USER009.message)
        }
      } else {
        throw new CronError(messages.ING006.message)
      }
    } catch (error) {
      // decrease credits again
      if (!_.isNil(error.name) && error.name.includes(CronError.name)) {
        error.stack = 'CronError'
      }
      throw error
    }
    job.progress(100)
    return true
  }

  private processUpdates = (updatePromises) =>
    new Promise<Array<any>>((resolve, reject) => {
      async.parallelLimit(updatePromises, 100, async (error, results) => {
        if (!_.isNil(results) && !_.isEmpty(results)) {
          resolve(results)
        } else {
          resolve([])
        }
      })
    })

  @OnQueueActive()
  onActive(job: Job<CronPayload<CampaignCronPayload>>) {
    this.logger.log(`Processing: Job name: ${job.name} Job ID: ${job.id}`)
  }

  @OnQueueCompleted()
  async onCompleted(job: Job<CronPayload<CampaignCronPayload>>) {
    const { payload } = job.data

    if (payload.isDripCampaign && job.name === cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name) {
      await createOperations.updateOne(this.dripCampaignModel, { campaignID: payload.campaignID }, {
        status: campaignStates.PROCESSED,
      })
    } else {
      await createOperations.updateOne(this.campaignModel, { _id: payload.campaignID }, {
        status: campaignStates.PROCESSED,
      })
    }
    this.logger.log(`Completed: Job name: ${job.name} Job ID: ${job.id}`)
  }

  @OnQueueFailed()
  async onFailed(job: Job<CronPayload<CampaignCronPayload>>) {
    const error = job.stacktrace.includes(CronError.name) ? job.failedReason : messages.COM001.message
    const { payload } = job.data
    if (_.eq(job.attemptsMade, cronJobs.CREATE_RBM_CAMPAIGN.attempts)) {
      await createOperations.updateOne(this.campaignModel, { _id: payload.campaignID }, {
        success: false,
        error,
        status: campaignStates.PROCESSED,
      })
    }
    this.logger.error(getErrorLog(job.name, job.data.traceID, { id: job.id, reason: job.failedReason, stack: job.stacktrace }))
  }
}

@Injectable()
@Processor(cronJobs.CREATE_WHATSAPP_CAMPAIGN.name)
export class CreateWhatsappCampaignProcessor {
  constructor(
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(Projects.name) private projectsModel: Model<Projects>,
    @InjectModel(Campaign.name) private campaignModel: Model<Campaign>,
    @InjectModel(DripCampaign.name) private dripCampaignModel: Model<DripCampaign>,
    @InjectModel(Credits.name) private creditsModel: Model<Credits>,
    @InjectModel(Link.name) private linksModel: Model<Link>,
    @InjectModel(Requests.name) private requestsModel: Model<Requests>,
    @InjectModel(Dashboard.name) private dashboardModel: Model<Dashboard>,
    @InjectModel(Template.name) private templatesModel: Model<Template>,
    @InjectModel(ContactDatabase.name) private contactDatabaseModel: Model<ContactDatabase>,
    @InjectQueue(cronJobs.CREATE_CAMPAIGN_REPORT.name) private createCampaignReportQueue: Queue,
    private logger: VappLogger,
    private readonly _socketGateway: CampaignWebSocketGateway,
  ) { }

  @Process({ concurrency: 5 })
  async createWhatsappCampaign(job: Job<CronPayload<CampaignCronPayload>>) {
    const whatsappRequests: Requests[] = []
    const { payload, traceID } = job.data
    payload.contactData = await extractCampaignData(traceID)
    let { campaignID } = payload
    try {
      const campaign = await createOperations.updateOne(this.campaignModel, { _id: campaignID }, {
        status: campaignStates.RUNNING,
      })
      const user: User = await findOperations.findById(this.userModel, payload.clientID, {})
      let updatedUser: User
      if (!_.isNil(user)) {
        const project: Projects = await findOperations.findOne(this.projectsModel, {
          clientID: payload.clientID,
          _id: payload.projectID,
        }, {})
        if (!_.isNil(project)) {
          campaignID = _.toString(campaign._id)
          let totalCredits = 0
          const whatsappProviderPayload: campaignProviderObject[] = []
          payload.contactData.forEach((contact: SingleContactDTO) => {
            const request = new this.requestsModel({
              projectID: payload.projectID,
              clientID: payload.clientID,
              campaignID: campaign._id,
              shortID: generateShortUID(),
              expiresOn: getExpirationTimestamp(campaign.token),
              firstName: contact.firstName,
              middleName: contact.middleName,
              lastName: contact.lastName,
              var1: contact.var1,
              var2: contact.var2,
              var3: contact.var3,
              var4: contact.var4,
              year: new Date().getFullYear(),
              month: new Date().getMonth() + 1,
              day: new Date().getDate(),
              phone: parseInt(String(Math.abs(Number(contact.phone))), 10),
              type: payload.type,
            })
            const compiledMessage: string = getRequestMessage(payload, request, user.altDomain)
            request.credit = getCreditsFromMessage(compiledMessage)
            totalCredits += request.credit
            whatsappProviderPayload.push({
              phone: parseInt(String(Math.abs(Number(contact.phone))), 10),
              message: compiledMessage,
            })
            whatsappRequests.push(request)
            RedisHandler.getInstance().set(redisKeys.CAMPAIGN_REQUEST.value(request.shortID), JSON.stringify({
              message: messages.CAM021.message,
              code: messages.CAM021.code,
              projectID: payload.projectID,
              phoneNumber: project.phone,
              ivr: !_.isNil(payload.ivr) && !_.isNaN(parseInt(String(payload.ivr), 10)) ? parseInt(String(payload.ivr), 10) : -1,
              url: payload.url,
              cloud: payload.cloud,
              redirection: payload.redirection,
              requestID: request._id,
              campaignID: campaign._id,
              projectName: project.name,
              companyName: user.companyName,
              brochure: project.brochure,
              greeting: user.greeting,
              chatbotButton: payload.chatbotButton,
              whatsappButton: payload.whatsappButton,
            }))
            RedisHandler.getInstance().expire(redisKeys.CAMPAIGN_REQUEST.value(request.shortID), user.defaultCampaignExpireyTime ? getSecondsFromHours(user.defaultCampaignExpireyTime) : redisKeys.CAMPAIGN_REQUEST.timeout())
          })
          const creditsSession = await this.creditsModel.db.startSession()
          await creditsSession.withTransaction(async () => {
            const credits: Credits = await findOperations.findOne(this.creditsModel, { clientID: payload.clientID }, {}, creditsSession)
            if (credits.credits > 0 && credits.credits - totalCredits > 0) {
              await createOperations.updateOne(this.creditsModel, { clientID: payload.clientID }, { $inc: { frozenCount: totalCredits, credits: -totalCredits } }, creditsSession)
            } else {
              throw new CronError(messages.CRE009.message)
            }
          }, constants.TRANSACTION_OPTIONS)
          creditsSession.endSession()
          const requestsSaveResult = await createOperations.processBulkInsertion(this.requestsModel, whatsappRequests, job)
          if (!payload.persistSession) {
            deleteFolderRecursive(join(process.cwd(), 'tokens', campaign.clientID))
          }
          if (!_.isNil(requestsSaveResult)) {
            const whatsappResult = await new WhatsappHelper({
              logger: this.logger,
              socketServer: this._socketGateway.server,
              whatsappCampaignObject: payload,
              projectID: campaign.projectID,
              clientID: campaign.clientID,
              whatsappPhoneRequests: whatsappProviderPayload,
              isCaptionMessage: payload.isCaptionMessage,
              files: payload.files,
              userToken: user.primaryWhatsappToken,
              allImages: payload.allImages,
            }).startSession()
            const commonUpdateObject = {
              $inc: {
                linksCount: payload.tracking ? payload.contactData.length : 0, whatsappSentCount: payload.contactData.length, whatsappDeliveredCount: whatsappResult.results.success, whatsappFailedCount: whatsappResult.results.failed,
              },
            }
            const campaignUpdateResult: Campaign = await createOperations.updateOne(this.campaignModel, { _id: campaign._id }, commonUpdateObject)
            if (!_.isNil(campaignUpdateResult)) {
              const commonEngagementUpdateResult = await updateCommonEngagement(this.contactDatabaseModel, this.templatesModel, this.linksModel, campaignUpdateResult.templateID, campaignUpdateResult.linkID, campaignUpdateResult.databaseID, campaignUpdateResult.clientID, commonUpdateObject)
              const projectUpdateResult: Projects = await createOperations.updateOne(this.projectsModel, { _id: project._id }, commonUpdateObject)
              if (!_.isNil(projectUpdateResult)) {
                // update monthly dashboard links clicks, view count, sms delivered count
                const dashboardUpdateResult: Dashboard = await createOperations.updateOneUpsert(this.dashboardModel, {
                  year: new Date().getFullYear(),
                  month: new Date().getMonth() + 1,
                  clientID: campaignUpdateResult.clientID,
                }, commonUpdateObject)
                if (!_.isNil(dashboardUpdateResult)) {
                  const creditsSession = await this.creditsModel.db.startSession()
                  await creditsSession.withTransaction(async () => {
                    await createOperations.updateOne(this.creditsModel, { clientID: campaignUpdateResult.clientID }, {
                      $inc: {
                        frozenCount: -totalCredits,
                        whatsappSentCount: payload.contactData.length,
                        whatsaappCredits: totalCredits,
                      },
                    }, creditsSession)
                  }, constants.TRANSACTION_OPTIONS)
                  creditsSession.endSession()
                  const creditsUpdateResult = await findOperations.findOne(this.creditsModel, { clientID: campaignUpdateResult.clientID })
                  if (!_.isNil(creditsUpdateResult)) {
                    if (!_.isNil(whatsappResult.usertoken)) {
                      updatedUser = await createOperations.updateOne(this.userModel, { _id: campaignUpdateResult.clientID }, { primaryWhatsappToken: whatsappResult.usertoken })
                    }
                    const campaignFinalResult: Campaign = await createOperations.updateOne(this.campaignModel, { _id: campaign._id }, {
                      $set: { success: true, credits: totalCredits },
                      $inc: { whatsappDeliveredCount: whatsappResult.results.success, whatsappFailedCount: whatsappResult.results.failed },
                    })
                    if (!_.isNil(campaignFinalResult)) {
                      await this.createCampaignReportQueue.add({
                        payload: {
                          clientID: payload.clientID,
                          campaignID: campaign.id,
                        } as CampaignReportCronPayload,
                        traceID: job.data.traceID,
                      }, { delay: getMilliseconds(CRON_SCHEDULES_TIME.CREATE_CAMAPAIGN_REPORT) })
                      // set campaign in redis
                      RedisHandler.getInstance().set(redisKeys.CAMPAIGN.value(campaign._id), JSON.stringify(campaignFinalResult))
                      RedisHandler.getInstance().expire(redisKeys.CAMPAIGN.value(campaign._id), redisKeys.CAMPAIGN.timeout())
                      // set credits in redis
                      RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), JSON.stringify(creditsUpdateResult))
                      RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), redisKeys.USER_CREDITS.timeout())
                      // set projects in redis
                      RedisHandler.getInstance().set(redisKeys.PROJECT.value(project._id), JSON.stringify(projectUpdateResult))
                      RedisHandler.getInstance().expire(redisKeys.PROJECT.value(project._id), redisKeys.PROJECT.timeout())
                      // update user in redis
                      if (!payload.persistSession) {
                        RedisHandler.getInstance().set(redisKeys.USER.value(campaign.clientID), JSON.stringify(updatedUser))
                        RedisHandler.getInstance().expire(redisKeys.USER.value(campaign.clientID), redisKeys.USER.timeout())
                      }
                      // set templates in redis
                      if (!_.isNil(commonEngagementUpdateResult.templates)) {
                        RedisHandler.getInstance().set(redisKeys.USER_TEMPLATES.value(campaignUpdateResult.clientID), JSON.stringify(commonEngagementUpdateResult.templates))
                        RedisHandler.getInstance().expire(redisKeys.USER_TEMPLATES.value(campaignUpdateResult.clientID), redisKeys.USER_TEMPLATES.timeout())
                      }
                      // set databases in redis
                      if (!_.isNil(commonEngagementUpdateResult.contactsDatabases)) {
                        RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(campaignUpdateResult.clientID), JSON.stringify(commonEngagementUpdateResult.contactsDatabases))
                        RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(campaignUpdateResult.clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
                      }
                      // set links in redis
                      if (!_.isNil(commonEngagementUpdateResult.links)) {
                        RedisHandler.getInstance().set(redisKeys.USER_LINKS.value(campaignUpdateResult.clientID), JSON.stringify(commonEngagementUpdateResult.links))
                        RedisHandler.getInstance().expire(redisKeys.USER_LINKS.value(campaignUpdateResult.clientID), redisKeys.USER_LINKS.timeout())
                      }
                      this._socketGateway.server.emit(payload.channelID, {
                        event: constants.WHATSAPP_CAMPAIGN.events.update_profile,
                        value: true,
                      })
                      await deleteCampaignData(traceID)
                    } else {
                      throw new CronError(messages.CAM031.message)
                    }
                  } else {
                    throw new CronError(messages.CRE011.message)
                  }
                } else {
                  throw new CronError(messages.DAS001.message)
                }
              } else {
                throw new CronError(messages.PROJ042.message)
              }
            } else {
              throw new CronError(messages.CAM031.message)
            }
          } else {
            throw new CronError(messages.REQ003.message)
          }
        } else {
          throw new CronError(messages.PROJ019.message)
        }
      } else {
        throw new CronError(messages.USER009.message)
      }
    } catch (error) {
      whatsappRequests.forEach((request) => {
        RedisHandler.getInstance().del(redisKeys.CAMPAIGN_REQUEST.value(request.shortID))
      })
      if (!_.isNil(error.name) && error.name.includes(CronError.name)) {
        error.stack = 'CronError'
      }
      throw error
    }
    job.progress(100)
    return true
  }

  @OnQueueActive()
  onActive(job: Job<CronPayload<CampaignCronPayload>>) {
    this.logger.log(`Processing: Job name: ${job.name} Job ID: ${job.id}`)
  }

  @OnQueueCompleted()
  async onCompleted(job: Job<CronPayload<CampaignCronPayload>>) {
    const { payload } = job.data

    if (payload.isDripCampaign && job.name === cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name) {
      await createOperations.updateOne(this.dripCampaignModel, { campaignID: payload.campaignID }, {
        status: campaignStates.PROCESSED,
      })
    } else {
      await createOperations.updateOne(this.campaignModel, { _id: payload.campaignID }, {
        status: campaignStates.PROCESSED,
      })
    }
    this.logger.log(`Completed: Job name: ${job.name} Job ID: ${job.id}`)
  }

  @OnQueueFailed()
  async onFailed(job: Job<CronPayload<CampaignCronPayload>>) {
    const error = job.stacktrace.includes(CronError.name) ? job.failedReason : messages.COM001.message
    const { payload } = job.data
    if (_.eq(job.attemptsMade, cronJobs.CREATE_SMS_CAMPAIGN.attempts)) {
      await createOperations.updateOne(this.campaignModel, { _id: payload.campaignID }, {
        success: false,
        error,
        status: campaignStates.PROCESSED,
      })
    }
    this.logger.error(getErrorLog(job.name, job.data.traceID, { id: job.id, reason: job.failedReason, stack: job.stacktrace }))
  }
}

@Injectable()
@Processor(cronJobs.ENGAGEMENT_TRACKING.name)
export class EngagementTrackingProcessor {
  constructor(
    @InjectModel(Projects.name) private projectsModel: Model<Projects>,
    @InjectModel(Campaign.name) private campaignModel: Model<Campaign>,
    @InjectModel(Credits.name) private creditsModel: Model<Credits>,
    @InjectModel(Link.name) private linksModel: Model<Link>,
    @InjectModel(Requests.name) private requestsModel: Model<Requests>,
    @InjectModel(Dashboard.name) private dashboardModel: Model<Dashboard>,
    @InjectModel(Template.name) private templatesModel: Model<Template>,
    @InjectModel(RequestEngagement.name) private requestEngagementModel: Model<RequestEngagement>,
    @InjectModel(ContactDatabase.name) private contactDatabaseModel: Model<ContactDatabase>,
    @InjectModel(DashboardTrendingStoreSchema.name) private dashboardTrendsModel: Model<DashboardTrendingStoreSchema>,
    private readonly _trackingSocketGateway: TrackingWebSocketGateway,
    @InjectModel(ProjectTrendingEngagementsSchemaStore.name) private projectTrendsModel: Model<ProjectTrendingEngagementsSchemaStore>,
    private logger: VappLogger,
    private integrationsService: IntegrationsService
  ) { }

  @Process({ concurrency: 1 })
  async processTourEngagement(job: Job<CronPayload<TourEngagementDTO>>) {
    const { payload, traceID } = job.data
    try {
      // fetch request object
      let request = (await findOperations.findOne(this.requestsModel, {
        shortID: payload.requestID,
      }, {})) as Requests
      if (_.isNil(request)) {
        throw new CronError(messages.INT011.message)
      }
      let engagementObj = _.find(request.engagementTime, (engagement) => _.eq(engagement.engagementID, payload.engagementID))
      if (_.isNil(engagementObj)) {
        const firstEngagementUpdateContext: FirstEngagementUpdateContext = {
          projectsModel: this.projectsModel,
          requestModel: this.requestsModel,
          templatesModel: this.templatesModel,
          campaignModel: this.campaignModel,
          creditsModel: this.creditsModel,
          linksModel: this.linksModel,
          contactsDatabaseModel: this.contactDatabaseModel,
          dashboardModel: this.dashboardModel,
          engagementModel: this.requestEngagementModel,
        }
        engagementObj = (await updateFirstEngagement(request, payload, firstEngagementUpdateContext)) as RequestEngagement
      }
      const lead_operation = !request.visited ? integration_operation.CREATE : integration_operation.UPDATE

      const isFirstEngagement = !_.isNil(request.engagementTime)
        && _.eq((request.engagementTime.find((time) => _.eq(time.engagementID, payload.engagementID)) || {}).time, 0)
        && _.eq(request.engagementTime.length, 1)
      const isRecurringEngagement = !_.isNil(request.engagementTime) && _.eq((request.engagementTime.find((time) => _.eq(time.engagementID, payload.engagementID)) || {}).time, 0)
      const engagementLevelObject: EngagementLevel = {
        negativeCount: 0,
        neutralCount: 0,
        positiveCount: 0,
      } as EngagementLevel
      const engagementTotal = _.sumBy(request.engagementTime, 'time')
      const engagementCap = getEnvironmentVariable(variables.ENGAGEMENT_CAP.name)
      const engagementLevel = request.engagementLevel ? request.engagementLevel : 0
      const requestEngagementUpdateObject = { engagementLevel }
      const engagementIncrementObject = getEngagementIncrementObject(request, payload, isRecurringEngagement)
      const openRate = _.isNil(request.engagementTime) ? 0 : request.engagementTime.filter((time) => !_.eq(time.time, 0)).length
      // engagement >= 1 min  or open Rate > 1 or whatsapp clicked or brochure downloaded
      const positiveProgression = _.gte(engagementTotal, constants.ENGAGEMENT_LOWER_LIMITS.positive) || request.whatsapp || request.brochure || openRate > 1
      // engagement > 30 sec < 1min
      const neutralProgression = _.lt(engagementTotal, constants.ENGAGEMENT_LOWER_LIMITS.positive) && _.gt(engagementTotal, constants.ENGAGEMENT_LOWER_LIMITS.neutral)
      // engagement <= 30sec
      const negativeProgression = _.lte(engagementTotal, constants.ENGAGEMENT_LOWER_LIMITS.neutral)
      if (_.eq(engagementLevel, constants.ENGAGEMENT_LEVELS.neutral) && positiveProgression) {
        requestEngagementUpdateObject.engagementLevel = constants.ENGAGEMENT_LEVELS.positive
        engagementLevelObject.neutralCount = -1
        engagementLevelObject.positiveCount = 1
      } else if (_.eq(engagementLevel, constants.ENGAGEMENT_LEVELS.negative) && positiveProgression) {
        requestEngagementUpdateObject.engagementLevel = constants.ENGAGEMENT_LEVELS.positive
        engagementLevelObject.negativeCount = -1
        engagementLevelObject.positiveCount = 1
      } else if (_.eq(engagementLevel, constants.ENGAGEMENT_LEVELS.negative) && neutralProgression) {
        if (!positiveProgression) {
          requestEngagementUpdateObject.engagementLevel = constants.ENGAGEMENT_LEVELS.neutral
          engagementLevelObject.negativeCount = -1
          engagementLevelObject.neutralCount = 1
        }
      } else if (_.eq(engagementLevel, constants.ENGAGEMENT_LEVELS.initial) && positiveProgression) {
        requestEngagementUpdateObject.engagementLevel = constants.ENGAGEMENT_LEVELS.positive
        engagementLevelObject.positiveCount = 1
      } else if (_.eq(engagementLevel, constants.ENGAGEMENT_LEVELS.initial) && neutralProgression) {
        requestEngagementUpdateObject.engagementLevel = constants.ENGAGEMENT_LEVELS.neutral
        engagementLevelObject.neutralCount = 1
      } else if (_.eq(engagementLevel, constants.ENGAGEMENT_LEVELS.initial) && negativeProgression) {
        requestEngagementUpdateObject.engagementLevel = constants.ENGAGEMENT_LEVELS.negative
        engagementLevelObject.negativeCount = 1
      }
      // only register the engagement if engagementTotal is less then cap
      if (engagementTotal > engagementCap) {
        try {
          this._trackingSocketGateway.server.to(traceID).emit(websocketEvents.CLIENT_TOUR_ENGAGEMENT_MAX_CAP_REACHED, { status: true })
        } catch (error) {
        }
        throw new CronError(messages.INT023.message)
      } else {
        // increment engagement time & set engagement level in request
        request = (await upadateRequestEngagement(this.requestsModel, payload, requestEngagementUpdateObject)) as Requests
        // increment engagement time & engagement quality in projects
        const project = (await updateProjectEngagement(this.projectsModel, request, { ...engagementIncrementObject, ...engagementLevelObject })) as Projects
        // increment engagement time & engagement quality in campaign
        const campaign = (await updateCampaignEngagement(this.campaignModel, request, { ...engagementIncrementObject, ...engagementLevelObject })) as Campaign
        // increment engagement time & engagement quality in database/template/links
        const commonEngagement = await updateCommonEngagement(this.contactDatabaseModel, this.templatesModel, this.linksModel, campaign.templateID, campaign.linkID, campaign.databaseID, campaign.clientID, { ...engagementIncrementObject, ...engagementLevelObject })
        if (isFirstEngagement) {
          const engagementDate: Date = new Types.ObjectId((request.engagementTime.find((time) => _.eq(time.id, payload.engagementID)) || {})._id).getTimestamp()
          const projectTrendObject: TrendsEngagement = {} as TrendsEngagement
          projectTrendObject.date = engagementDate.toISOString()
          projectTrendObject.hour = engagementDate.getHours()
          projectTrendObject.minutes = engagementDate.getMinutes()
          projectTrendObject.seconds = engagementDate.getSeconds()
          projectTrendObject.time = _.sumBy(request.engagementTime, 'time')
          // update the projectTrendModel
          const projectTrendStore = (await updateProjectTrendsModel(this.projectTrendsModel, request, projectTrendObject)) as ProjectTrendingEngagementsStore
          if (_.isNil(projectTrendStore)) {
            throw new CronError(messages.INT019.message)
          }
        }
        // create trending person object
        const trendingPersonObject: DashboardTrendingPerson = {} as DashboardTrendingPerson
        trendingPersonObject.projectID = request.projectID
        trendingPersonObject.projectName = project.name
        trendingPersonObject.firstName = request.firstName
        trendingPersonObject.lastName = request.lastName
        trendingPersonObject.middleName = request.middleName
        trendingPersonObject.phone = request.phone
        trendingPersonObject.requestID = payload.requestID
        trendingPersonObject.engagementSum = Number(payload.time)

        // find dashboard trends
        let dashboardTrendingStore = await findOperations.findOne(this.dashboardTrendsModel, {
          clientID: request.clientID,
          year: new Date().getFullYear(),
          month: new Date().getMonth() + 1,
        }, {})
        if (!_.isNil(dashboardTrendingStore)) {
          let dashboardTrendingPersons: DashboardTrendingPerson[] = [] as DashboardTrendingPerson[]
          if (!_.isNil(dashboardTrendingStore.trendingPersons) && dashboardTrendingStore.trendingPersons.length > 0) {
            dashboardTrendingPersons = dashboardTrendingStore.trendingPersons
          }
          dashboardTrendingPersons.push(trendingPersonObject)
          dashboardTrendingPersons = _(dashboardTrendingPersons)
            .groupBy('requestID')
            .map(
              (objects, key) => ({
                requestID: key,
                projectID: objects[0].projectID,
                projectName: objects[0].projectName,
                firstName: objects[0].firstName,
                lastName: objects[0].lastName,
                middleName: objects[0].middleName,
                phone: objects[0].phone,
                engagementSum: _.sumBy(objects, 'engagementSum'),
              } as DashboardTrendingPerson),
            )
            .orderBy(['engagementSum'], ['desc'])
            .slice(constants.DASHBOARD_TRENDS_LIMIT.PERSONS_LIMIT.start, constants.DASHBOARD_TRENDS_LIMIT.PERSONS_LIMIT.end)
            .value()

          const dashboardtrendingProjects = getDashboardTrendingProjects(dashboardTrendingStore, request, project, payload, engagementLevelObject)
          const trendsObject = <GenericObject>{
            // this will always retains as common across all campaigns
            trendingPersons: dashboardTrendingPersons,
            trendingProjects: dashboardtrendingProjects,
          }
          let dashboardTrendingTemplates: DashboardTrendingTemplate[] = [] as DashboardTrendingTemplate[]
          let dashboardTrendingLinks: DashboardTrendingLink[] = [] as DashboardTrendingLink[]
          let dashboardTrendingDatabases: DashboardTrendingDatabase[] = [] as DashboardTrendingDatabase[]
          if (!_.isNil(campaign.templateID)) {
            const template = (await findOperations.findOne(this.templatesModel, { _id: campaign.templateID }, {})) as Template
            dashboardTrendingTemplates = getDashboardTrendingTemplate(dashboardTrendingStore, template, payload, engagementLevelObject)
            trendsObject.trendingTemplates = dashboardTrendingTemplates
          }
          if (!_.isNil(campaign.linkID)) {
            const link = (await findOperations.findOne(this.linksModel, { _id: campaign.linkID }, {})) as Link
            dashboardTrendingLinks = getDashboardTrendingLink(dashboardTrendingStore, link, payload, engagementLevelObject)
            trendsObject.trendingLinks = dashboardTrendingLinks
          }
          if (!_.isNil(campaign.databaseID)) {
            const database = (await findOperations.findOne(this.contactDatabaseModel, { _id: campaign.databaseID }, {})) as ContactDatabase
            dashboardTrendingDatabases = getDashboardTrendingDatabases(dashboardTrendingStore, database, payload, engagementLevelObject)
            trendsObject.trendingDatabases = dashboardTrendingDatabases
          }
          dashboardTrendingStore = await createOperations.updateOneUpsert(this.dashboardTrendsModel, {
            clientID: request.clientID,
            year: new Date().getFullYear(),
            month: new Date().getMonth() + 1,
          }, {
            $set: trendsObject,
          })
          if (_.isNil(dashboardTrendingStore)) {
            throw new CronError(messages.INT018.message)
          }
        } else {
          dashboardTrendingStore = await createOperations.updateOneUpsert(this.dashboardTrendsModel, {
            clientID: request.clientID,
            year: new Date().getFullYear(),
            month: new Date().getMonth() + 1,
          }, {
            $push: { trendingPersons: trendingPersonObject },
            $set: {
              trendingProjects: [],
              trendingTemplates: [],
              trendingDatabases: [],
              trendingLinks: [],
            },
          })
        }

        if (!_.isNil(campaign)) {
          const dashboard = createOperations.updateOneUpsert(this.dashboardModel, {
            year: new Date().getFullYear(),
            month: new Date().getMonth() + 1,
            clientID: request.clientID,
          }, { $inc: engagementIncrementObject })
          if (!_.isNil(dashboard)) {
            this.integrationsService.processIntegration(lead_operation, request, traceID)
            // update project in redis
            RedisHandler.getInstance().set(redisKeys.PROJECT.value(project._id), JSON.stringify(project))
            RedisHandler.getInstance().expire(redisKeys.PROJECT.value(project._id), redisKeys.PROJECT.timeout())
            // update campaign in redis
            RedisHandler.getInstance().set(redisKeys.CAMPAIGN.value(campaign._id), JSON.stringify(campaign))
            RedisHandler.getInstance().ttl(redisKeys.CAMPAIGN.value(campaign._id), (error: Error, time: number) => {
              if (_.isNil(error) && _.isNumber(time)) {
                RedisHandler.getInstance().expire(redisKeys.CAMPAIGN.value(campaign._id), time)
              }
            })
            if (!_.isNil(commonEngagement.contactsDatabases)) {
              RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(campaign.clientID), JSON.stringify(commonEngagement.contactsDatabases))
              RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(campaign.clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
            }
            if (!_.isNil(commonEngagement.templates)) {
              RedisHandler.getInstance().set(redisKeys.USER_TEMPLATES.value(campaign.clientID), JSON.stringify(commonEngagement.templates))
              RedisHandler.getInstance().expire(redisKeys.USER_TEMPLATES.value(campaign.clientID), redisKeys.USER_TEMPLATES.timeout())
            }
            if (!_.isNil(commonEngagement.links)) {
              RedisHandler.getInstance().set(redisKeys.USER_LINKS.value(campaign.clientID), JSON.stringify(commonEngagement.links))
              RedisHandler.getInstance().expire(redisKeys.USER_LINKS.value(campaign.clientID), redisKeys.USER_LINKS.timeout())
            }
          } else {
            throw new CronError(messages.INT017.message)
          }
        }
      }
    } catch (error) {
      if (!_.isNil(error.name) && error.name.includes(CronError.name)) {
        error.stack = 'CronError'
      }
      throw error
    }
    job.progress(100)
    return true
  }

  @OnQueueActive()
  onActive(job: Job<CronPayload<CampaignCronPayload>>) {
    this.logger.log(`Processing: Job name: ${job.name} Job ID: ${job.id}`)
  }

  @OnQueueCompleted()
  async onCompleted(job: Job<CronPayload<CampaignCronPayload>>) {
    const { payload } = job.data
    this.logger.log(`Completed: Job name: ${job.name} Job ID: ${job.id}`)
  }

  @OnQueueFailed()
  async onFailed(job: Job<CronPayload<CampaignCronPayload>>) {
    const error = job.stacktrace.includes(CronError.name) ? job.failedReason : messages.COM001.message
    const { payload } = job.data
    this.logger.error(getErrorLog(job.name, job.data.traceID, { id: job.id, reason: job.failedReason, stack: job.stacktrace }))
  }
}

@Injectable()
@Processor(cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name)
export class CreateDripSMSCampaignProcessor {
  constructor(
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(Projects.name) private projectsModel: Model<Projects>,
    @InjectModel(DripCriteria.name) private dripCriteriaModel: Model<DripCriteria>,
    @InjectModel(DripCampaign.name) private dripCampaignModel: Model<DripCampaign>,
    @InjectModel(Credits.name) private creditsModel: Model<Credits>,
    @InjectModel(Link.name) private linksModel: Model<Link>,
    @InjectModel(Requests.name) private requestsModel: Model<Requests>,
    @InjectModel(Dashboard.name) private dashboardModel: Model<Dashboard>,
    @InjectModel(Template.name) private templatesModel: Model<Template>,
    @InjectModel(DripRequests.name) private dripRequestsModel: Model<DripRequests>,
    @InjectQueue(cronJobs.CREATE_CAMPAIGN_REPORT.name) private createCampaignReportQueue: Queue,
    @InjectModel(ContactDatabase.name) private contactDatabaseModel: Model<ContactDatabase>,
    private logger: VappLogger,
  ) { }

  @Process({ concurrency: 1 })
  async createDripCampaign(job: Job<CronPayload<CampaignCronPayload>>) {
    const { payload, traceID } = job.data
    try {
      let smsSenderID: string
      let peID: string
      let templateID: string
      let route = -1
      const dripSmsRequests: DripRequests[] = []
      const { campaignID } = payload
      let eventJSON: string
      let criteriaAndJSON: string
      let criteriaOrJSON: string
      const campaign = await createOperations.updateOne(this.dripCampaignModel, { campaignID }, {
        status: campaignStates.RUNNING,
      })

      const user: User = await findOperations.findById(this.userModel, payload.clientID, {})
      if (!_.isNil(user)) {
        smsSenderID = user.smsSenderID
        peID = user.peID
        templateID = payload.registeredDripTemplateID
        if (!_.isNaN(user.route)) {
          route = user.route
        }
        const project: Projects = await findOperations.findOne(this.projectsModel, {
          clientID: payload.clientID,
          _id: payload.projectID,
        }, {})

        // assign project sms sender id in case present else use default user sms sender id
        if (!_.isNil(project.smsSenderID) && !_.isEmpty(project.smsSenderID)) {
          smsSenderID = project.smsSenderID
        }

        const dripCampaign: DripCampaign = await findOperations.findOne(this.dripCampaignModel, { campaignID })

        const dripcCriteria: DripCriteria = await findOperations.findOne(this.dripCriteriaModel, <DripCriteria>{ _id: dripCampaign.dripCriteriaID })
        if (!_.isNil(dripcCriteria)) {
          dripcCriteria.eventCondition.forEach((element) => {
            eventJSON = '"'
              .concat(element.condition.toString())
              .concat('":')
              .concat(element.value.toString())
          })
          dripcCriteria.andConditions.forEach((element) => {
            if (_.isNil(criteriaAndJSON) || criteriaAndJSON.toString().length === 0) {
              criteriaAndJSON = '"'.concat(element.name).concat('"')
                .concat(':')
                .concat('{"')
                .concat(element.condition.toString())
                .concat('":')
                .concat(element.value.toString())
                .concat('}')
            } else {
              criteriaAndJSON = criteriaAndJSON.concat('},')
                .concat('{"')
                .concat(element.name)
                .concat('":')
                .concat('{"')
                .concat(element.condition.toString())
                .concat('":')
                .concat(element.value.toString())
                .concat('}')
            }
          })
          dripcCriteria.orConditions.forEach((element) => {
            if (_.isNil(criteriaOrJSON) || criteriaOrJSON.toString().length === 0) {
              criteriaOrJSON = '"'.concat(element.name).concat('":')
                .concat('{"')
                .concat(element.condition)
                .concat('":')
                .concat(element.value.toString())
                .concat('}')
            } else {
              criteriaOrJSON = criteriaOrJSON.concat('},')
                .concat('"')
                .concat(element.name)
                .concat('":')
                .concat('{"')
                .concat(element.condition)
                .concat('":')
                .concat(element.value.toString())
                .concat('}')
            }
          })
          if (eventJSON.length <= 0) {
            criteriaAndJSON = '"$gte":0'
          }
          if (criteriaAndJSON) {
            criteriaAndJSON = '"$and":[{'.concat(criteriaAndJSON).concat('}]')
          } else {
            criteriaAndJSON = '"$and":[{}]'
          }
          if (criteriaOrJSON) {
            criteriaOrJSON = '"$or":[{'.concat(criteriaOrJSON).concat('}]')
          } else {
            criteriaOrJSON = '"$or":[{}]'
          }
        }
        let criteriaObj = `{${criteriaAndJSON},${criteriaOrJSON}}`
        criteriaObj = JSON.parse(criteriaObj)
        const filterObject = {
          $match: criteriaObj,
        }
        const dripRequests = await findOperations.aggregate(this.requestsModel, [
          {
            $match: {
              campaignID,
            },
          }, {
            $project: {
              _id: 1,
              campaignID: 1,
              firstName: 1,
              lastName: 1,
              phone: 1,
              engagementTime: 1,
              projectID: 1,
              clientID: 1,
              whatsapp: {
                $cond: [{ $eq: ['$whatsapp', true] }, 1, 0],
              },
              ivr: {
                $cond: [{ $gte: [{ $size: { $ifNull: ['$ivr', []] } }, 1] }, 1, 0],
              },
            },
          }, {
            $unwind: {
              path: '$engagementTime',
              preserveNullAndEmptyArrays: true,
            },
          }, {
            $group: {
              _id: '$_id',
              totalEngagements: { $sum: 1 },
              totalEngagementTime: { $sum: '$engagementTime.time' },
              lastName: { $first: '$lastName' },
              firstName: { $first: '$firstName' },
              phone: { $first: '$phone' },
              projectID: { $first: '$projectID' },
              clientID: { $first: '$clientID' },
              whatsapp: { $first: '$whatsapp' },
              ivr: { $first: '$ivr' },
            },
          },
          filterObject,
          {
            $project: {
              _id: 1,
              lastName: 1,
              totalEngagements: 1,
              firstName: 1,
              phone: 1,
              totalEngagementTime: 1,
              projectID: 1,
              clientID: 1,
              whatsapp: 1,
              ivr: 1,
            },
          },
          {
            $lookup: {
              from: 'tracking',
              let: { cID: '$campaignID' },
              pipeline:
                [
                  {
                    $match: {
                      $expr: {
                        $and: [
                          {
                            $eq: ['$campaignID', '$$cID'],
                          },
                        ],
                      },
                      events: {
                        $exists: true,
                        eventJSON,
                        // $gte: 0,
                        $not: {
                          $size: 0,
                        },
                      },
                    },
                  },
                  {
                    $project: { _id: 0, event: '$events' },
                  },
                ],
              as: 'event',
            },
          },
          {
            $project: {
              _id: 1,
              lastName: 1,
              totalEngagements: 1,
              totalEngagementTime: 1,
              firstName: 1,
              phone: 1,
              event: 1,
              projectID: 1,
              clientID: 1,
              whatsapp: 1,
              ivr: 1,
            },
          },
        ])
        // this.sendSMS(data, payload.contactData[0], campaign, payload, project, user, traceID)
        let totalCredits = 0
        const smsProviderPayload: campaignProviderObject[] = []
        dripRequests.forEach(async (request: Requests) => {
          const drip_request = new this.dripRequestsModel({
            projectID: request.projectID,
            clientID: request.clientID,
            campaignID: campaign.campaignID,
            shortID: generateShortUID(),
            expiresOn: getExpirationTimestamp(campaign.token),
            firstName: request.firstName,
            middleName: request.middleName,
            lastName: request.lastName,
            var1: payload.var1,
            var2: payload.var2,
            var3: payload.var3,
            var4: payload.var4,
            year: new Date().getFullYear(),
            month: new Date().getMonth() + 1,
            day: new Date().getDate(),
            phone: parseInt(String(Math.abs(Number(request.phone))), 10),
            type: request.type,
          }) as DripRequests
          dripSmsRequests.push(drip_request)
          const compiledMessage: string = getDripRequestMessage(payload, drip_request)
          drip_request.credit = getCreditsFromMessage(compiledMessage)
          totalCredits += drip_request.credit
          smsProviderPayload.push({
            phone: parseInt(String(Math.abs(Number(request.phone))), 10),
            message: compiledMessage,
          })
          drip_request.credit = totalCredits
          drip_request.projectID = request.projectID
          drip_request.clientID = request.clientID
          RedisUpdateDripRequests(drip_request, campaign, user, project, payload)
        })
        const creditsSession = await this.creditsModel.db.startSession()
        await creditsSession.withTransaction(async () => {
          const credits: Credits = await findOperations.findOne(this.creditsModel, { clientID: payload.clientID }, {}, creditsSession)
          if (credits.credits > 0 && credits.credits - totalCredits > 0) {
            await createOperations.updateOne(this.creditsModel, { clientID: payload.clientID }, { $inc: { frozenCount: totalCredits, credits: -totalCredits } }, creditsSession)
          } else {
            throw new CronError(messages.CRE009.message)
          }
        }, constants.TRANSACTION_OPTIONS)
        creditsSession.endSession()
        const requestsSaveResult = await createOperations.processBulkInsertion(this.dripRequestsModel, dripSmsRequests, job)

        // await SmsHandler.getInstance(route).sendBulkSMS(project.smsSenderID, smsProviderPayload, user.impersonation, this.uploadDeliveryReportQueue, payload.registeredDripTemplateID, user.peID, campaign.campaignID, this.smppIDUpdateQueue, report_types.DRIP_CAMPAIGN)
        if (!_.isNil(requestsSaveResult)) {
          const commonUpdateObject = { $inc: { smsSentCount: payload.contactData.length } }
          const campaignUpdateResult: Campaign = await createOperations.updateOne(this.dripCampaignModel, { _id: campaign._id }, commonUpdateObject)
          if (!_.isNil(campaignUpdateResult)) {
            const commonEngagementUpdateResult = await updateCommonEngagement(this.contactDatabaseModel, this.templatesModel, this.linksModel, campaignUpdateResult.templateID, campaignUpdateResult.linkID, campaignUpdateResult.databaseID, campaignUpdateResult.clientID, commonUpdateObject)
            const projectUpdateResult: Projects = await createOperations.updateOne(this.projectsModel, { _id: project._id }, commonUpdateObject)
            if (!_.isNil(projectUpdateResult)) {
              const dashboardUpdateResult: Dashboard = await createOperations.updateOneUpsert(this.dashboardModel, {
                year: new Date().getFullYear(),
                month: new Date().getMonth() + 1,
                clientID: campaignUpdateResult.clientID,
              }, commonUpdateObject)
              if (!_.isNil(dashboardUpdateResult)) {
                const creditsSession = await this.creditsModel.db.startSession()
                await creditsSession.withTransaction(async () => {
                  await createOperations.updateOne(this.creditsModel, { clientID: campaignUpdateResult.clientID }, {
                    $inc: {
                      frozenCount: -totalCredits,
                      smsSentCount: payload.contactData.length,
                      smsCredits: totalCredits,
                    },
                  }, creditsSession)
                }, constants.TRANSACTION_OPTIONS)
                creditsSession.endSession()
                const creditsUpdateResult = await findOperations.findOne(this.creditsModel, { clientID: campaignUpdateResult.clientID })
                if (!_.isNil(creditsUpdateResult)) {
                  const campaignFinalResult: Campaign = await createOperations.updateOne(this.dripCampaignModel, { campaignID: campaign.campaignID }, {
                    $set: {
                      success: true,
                      campaignID: generateShortUID(),
                      credits: totalCredits,
                    },
                  })
                  if (!_.isNil(campaignFinalResult)) {
                    await this.createCampaignReportQueue.add({
                      payload: {
                        clientID: payload.clientID,
                        campaignID: campaign.campaignID,
                      } as CampaignReportCronPayload,
                      traceID,
                    }, { delay: getMilliseconds(CRON_SCHEDULES_TIME.CREATE_CAMAPAIGN_REPORT) })
                    // set campaign in redis
                    RedisHandler.getInstance().set(redisKeys.CAMPAIGN.value(campaign._id), JSON.stringify(campaignFinalResult))
                    RedisHandler.getInstance().expire(redisKeys.CAMPAIGN.value(campaign._id), redisKeys.CAMPAIGN.timeout())
                    // set credits in redis
                    RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), JSON.stringify(creditsUpdateResult))
                    RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(creditsUpdateResult.clientID), redisKeys.USER_CREDITS.timeout())
                    // set projects in redis
                    RedisHandler.getInstance().set(redisKeys.PROJECT.value(project._id), JSON.stringify(projectUpdateResult))
                    RedisHandler.getInstance().expire(redisKeys.PROJECT.value(project._id), redisKeys.PROJECT.timeout())
                    // set templates in redis
                    if (!_.isNil(commonEngagementUpdateResult.templates)) {
                      RedisHandler.getInstance().set(redisKeys.USER_TEMPLATES.value(campaignUpdateResult.clientID), JSON.stringify(commonEngagementUpdateResult.templates))
                      RedisHandler.getInstance().expire(redisKeys.USER_TEMPLATES.value(campaignUpdateResult.clientID), redisKeys.USER_TEMPLATES.timeout())
                    }
                    // set databases in redis
                    if (!_.isNil(commonEngagementUpdateResult.contactsDatabases)) {
                      RedisHandler.getInstance().set(redisKeys.USER_CONTACT_DATABASES.value(campaignUpdateResult.clientID), JSON.stringify(commonEngagementUpdateResult.contactsDatabases))
                      RedisHandler.getInstance().expire(redisKeys.USER_CONTACT_DATABASES.value(campaignUpdateResult.clientID), redisKeys.USER_CONTACT_DATABASES.timeout())
                    }
                    // set links in redis
                    if (!_.isNil(commonEngagementUpdateResult.links)) {
                      RedisHandler.getInstance().set(redisKeys.USER_LINKS.value(campaignUpdateResult.clientID), JSON.stringify(commonEngagementUpdateResult.links))
                      RedisHandler.getInstance().expire(redisKeys.USER_LINKS.value(campaignUpdateResult.clientID), redisKeys.USER_LINKS.timeout())
                    }
                    HTTPService.getInstance().post(`${getEnvironmentVariable(variables.SMPP_SERVICE_BASE_URL.name)}campaign/process`, <ProcessSMPPDTO>{
                      smpp_config: switchSMPPClientRoute(route),
                      data: smsProviderPayload,
                      smsSenderID,
                      templateID,
                      campaignID: campaign.id,
                      peID,
                      reportType: report_types.DRIP_CAMPAIGN,
                    })
                  } else {
                    throw new CronError(messages.CAM031.message)
                  }
                } else {
                  throw new CronError(messages.CRE011.message)
                }
              } else {
                throw new CronError(messages.DAS001.message)
              }
            } else {
              throw new CronError(messages.PROJ042.message)
            }
          } else {
            throw new CronError(messages.CAM031.message)
          }
        } else {
          throw new CronError(messages.REQ003.message)
        }
      }
    } catch (error) {
      if (!_.isNil(error.name) && error.name.includes(CronError.name)) {
        error.stack = 'CronError'
      }
      throw error
    }
    job.progress(100)
    return true
  }

  @OnQueueActive()
  onActive(job: Job<CronPayload<CampaignCronPayload>>) {
    this.logger.log(`Processing: Job name: ${cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name} Job ID: ${job.id}`)
  }

  @OnQueueCompleted()
  onCompleted(job: Job<CronPayload<CampaignCronPayload>>) {
    this.logger.log(`Completed: Job name: ${cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name} Job ID: ${job.id}`)
  }
}
