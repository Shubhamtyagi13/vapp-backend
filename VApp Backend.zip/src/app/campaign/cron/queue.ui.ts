import { cronJobs } from '@config'
import { InjectQueue } from '@nestjs/bull'
import { Injectable } from '@nestjs/common'
import { Queue } from 'bull'
import { BullAdapter } from '@bull-board/api/bullAdapter'
import { BullInterfaceService } from '@services/bull-ui.service'

@Injectable()
export class QueueUIProvider {
  constructor(
    @InjectQueue(cronJobs.CREATE_SMS_CAMPAIGN.name) private createSMSCampaign: Queue,
    @InjectQueue(cronJobs.CREATE_WHATSAPP_CAMPAIGN.name) private createWhatsappCampaign: Queue,
    @InjectQueue(cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name) private createDripSMSCampaign: Queue,
    @InjectQueue(cronJobs.CREATE_DRIP_WHATSAPP_CAMPAIGN.name) private createDripWhatsappCampaign: Queue,
    @InjectQueue(cronJobs.CREATE_CAMPAIGN_REPORT.name) private createCampaignReportQueue: Queue,
    @InjectQueue(cronJobs.ENGAGEMENT_TRACKING.name) private engagementTrackingQueue: Queue,
    @InjectQueue(cronJobs.CREATE_RBM_CAMPAIGN.name) private createRBMCampaign: Queue,
  ) {
    BullInterfaceService.getInstance().registerQueues([
      new BullAdapter(engagementTrackingQueue),
      new BullAdapter(createSMSCampaign),
      new BullAdapter(createWhatsappCampaign),
      new BullAdapter(createDripSMSCampaign),
      new BullAdapter(createDripWhatsappCampaign),
      new BullAdapter(createCampaignReportQueue),
      new BullAdapter(createRBMCampaign),

    ])
  }
}
