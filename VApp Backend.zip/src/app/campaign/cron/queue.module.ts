import { cronJobs, redis_client, variables } from '@config'
import { BullModule } from '@nestjs/bull'
import { getEnvironmentVariable } from '@utils/platform.util'

const redis = {
  host: getEnvironmentVariable(variables.REDIS_URL.name),
  port: getEnvironmentVariable(variables.REDIS_PORT.name),
}

export const CreateSMSCampaignQueueModule = BullModule.registerQueueAsync({
  name: cronJobs.CREATE_SMS_CAMPAIGN.name,
  useFactory: () => ({
    redis: { ...redis, db: redis_client.CREATE_SMS_CAMPAIGN },
    defaultJobOptions: {
      priority: cronJobs.CREATE_SMS_CAMPAIGN.priority,
      removeOnComplete: true,
      removeOnFail: false,
      attempts: cronJobs.CREATE_SMS_CAMPAIGN.attempts,
    },
    prefix: cronJobs.CREATE_SMS_CAMPAIGN.name,
    settings: {
      retryProcessDelay: cronJobs.CREATE_SMS_CAMPAIGN.retryProcessDelay,
      lockRenewTime: cronJobs.CREATE_SMS_CAMPAIGN.lockRenew,
      maxStalledCount: cronJobs.CREATE_SMS_CAMPAIGN.maxStalledCount,
      lockDuration: cronJobs.CREATE_SMS_CAMPAIGN.lockLifeTime,
    },
  }),
})

export const CreateRBMCampaignQueueModule = BullModule.registerQueueAsync({
  name: cronJobs.CREATE_RBM_CAMPAIGN.name,
  useFactory: () => ({
    redis: { ...redis, db: redis_client.CREATE_SMS_CAMPAIGN },
    defaultJobOptions: {
      priority: cronJobs.CREATE_RBM_CAMPAIGN.priority,
      removeOnComplete: true,
      removeOnFail: false,
      attempts: cronJobs.CREATE_RBM_CAMPAIGN.attempts,
    },
    prefix: cronJobs.CREATE_RBM_CAMPAIGN.name,
    settings: {
      retryProcessDelay: cronJobs.CREATE_RBM_CAMPAIGN.retryProcessDelay,
      lockRenewTime: cronJobs.CREATE_RBM_CAMPAIGN.lockRenew,
      maxStalledCount: cronJobs.CREATE_RBM_CAMPAIGN.maxStalledCount,
      lockDuration: cronJobs.CREATE_RBM_CAMPAIGN.lockLifeTime,
    },
  }),
})

export const CreateWhatsappCampaignQueueModule = BullModule.registerQueueAsync({
  name: cronJobs.CREATE_WHATSAPP_CAMPAIGN.name,
  useFactory: () => ({
    redis: { ...redis, db: redis_client.CREATE_WHATSAPP_CAMPAIGN },
    defaultJobOptions: {
      priority: cronJobs.CREATE_WHATSAPP_CAMPAIGN.priority,
      removeOnComplete: true,
      removeOnFail: false,
      attempts: cronJobs.CREATE_WHATSAPP_CAMPAIGN.attempts,
    },
    prefix: cronJobs.CREATE_WHATSAPP_CAMPAIGN.name,
    settings: {
      lockRenewTime: cronJobs.CREATE_WHATSAPP_CAMPAIGN.lockRenew,
      maxStalledCount: cronJobs.CREATE_WHATSAPP_CAMPAIGN.maxStalledCount,
      lockDuration: cronJobs.CREATE_WHATSAPP_CAMPAIGN.lockLifeTime,
    },
  }),
})

export const CreateDripSMSCampaignQueueModule = BullModule.registerQueueAsync({
  name: cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name,
  useFactory: () => ({
    redis: { ...redis, db: redis_client.CREATE_WHATSAPP_CAMPAIGN },
    defaultJobOptions: {
      priority: cronJobs.CREATE_DRIP_SMS_CAMPAIGN.priority,
      removeOnComplete: true,
      removeOnFail: false,
      attempts: cronJobs.CREATE_DRIP_SMS_CAMPAIGN.attempts,
    },
    prefix: cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name,
    settings: {
      lockRenewTime: cronJobs.CREATE_DRIP_SMS_CAMPAIGN.lockRenew,
      maxStalledCount: cronJobs.CREATE_DRIP_SMS_CAMPAIGN.maxStalledCount,
      lockDuration: cronJobs.CREATE_DRIP_SMS_CAMPAIGN.lockLifeTime,
    },
  }),
})

export const CreateDripWhatsAPPCampaignQueueModule = BullModule.registerQueueAsync({
    name: cronJobs.CREATE_DRIP_WHATSAPP_CAMPAIGN.name,
    useFactory: () => ({
      redis: { ...redis, db: redis_client.CREATE_DRIP_WHATSAPP_CAMPAIGN },
      defaultJobOptions: {
        priority: cronJobs.CREATE_DRIP_WHATSAPP_CAMPAIGN.priority,
        removeOnComplete: true,
        removeOnFail: false,
        attempts: cronJobs.CREATE_DRIP_WHATSAPP_CAMPAIGN.attempts,
      },
      prefix: cronJobs.CREATE_DRIP_WHATSAPP_CAMPAIGN.name,
      settings: {
        lockRenewTime: cronJobs.CREATE_DRIP_WHATSAPP_CAMPAIGN.lockRenew,
        maxStalledCount: cronJobs.CREATE_DRIP_WHATSAPP_CAMPAIGN.maxStalledCount,
        lockDuration: cronJobs.CREATE_DRIP_WHATSAPP_CAMPAIGN.lockLifeTime,
      },
    }),
  })

export const EngagementTrackingQueueModule = BullModule.registerQueueAsync({
  name: cronJobs.ENGAGEMENT_TRACKING.name,
  useFactory: () => ({
    redis: { ...redis, db: redis_client.ENGAGEMENT_TRACKING },
    defaultJobOptions: {
      priority: cronJobs.ENGAGEMENT_TRACKING.priority,
      removeOnComplete: true,
      removeOnFail: false,
      attempts: cronJobs.ENGAGEMENT_TRACKING.attempts,
    },
    prefix: cronJobs.ENGAGEMENT_TRACKING.name,
    settings: {
      lockRenewTime: cronJobs.ENGAGEMENT_TRACKING.lockRenew,
      maxStalledCount: cronJobs.ENGAGEMENT_TRACKING.maxStalledCount,
      lockDuration: cronJobs.ENGAGEMENT_TRACKING.lockLifeTime,
    },
  }),
})
