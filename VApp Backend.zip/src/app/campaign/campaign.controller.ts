import { audience, contentTypes, environments, variables } from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { WhatsAppInterceptor } from '@interceptors/whatsapp.interceptor'
import { GenericObject } from '@interfaces/generic.interface'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import { Body, Controller, Get, Param, Post, Req, Res, UploadedFiles, UseGuards, UseInterceptors, ValidationPipe } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { ApiBearerAuth, ApiConsumes, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { plainToClass } from 'class-transformer'
import { Request, Response } from 'express'
import _ from 'lodash'
import { Model } from 'mongoose'
import { Campaign } from './campaign.schema'
import { CampaignService } from './campaign.service'
import { BulkCampaignDTO } from './dto/bulk-campaign-dto'
import { SingleCampaignDTO } from './dto/single-campaign-dto'
import { WhatsappCampaignDTO } from './dto/whatsapp-campaign-dto'

@ApiTags(CampaignController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('campaign')
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class CampaignController {
  constructor(@InjectModel(Campaign.name) private campaignModel: Model<Campaign>, private campaignService: CampaignService) {}

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post('sms/single/:projectID')
  createSingleCampaign(@Res() response: Response, @Body() campaignObject: SingleCampaignDTO, @Req() request: Request, @Param('projectID') projectID: string) {
    this.campaignService.createSingleCampaign(campaignObject, request.user._id, projectID).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post('sms/bulk/:projectID')
  createBulkCampaign(@Res() response: Response, @Body() campaignObject: BulkCampaignDTO, @Req() request: Request, @Param('projectID') projectID: string) {
    this.campaignService.createBulkCampaign(campaignObject, request.user._id, projectID).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Post('rbm')
  rbmWebHook(@Res() response: Response, @Body() body: GenericObject) {
    const response_data = {}

    if (!_.isNil(body.secret)) {
      _.set(response_data, 'secret', body.secret)
    }
    let parsed_data: { senderPhoneNumber: string; eventType: string; messageId: string } = null
    try {
      parsed_data = JSON.parse(Buffer.from(body.message.data, 'base64').toString())
      if (!_.isNil(parsed_data.messageId) && !_.isNil(parsed_data.eventType) && _.isEqual(parsed_data.eventType.toLowerCase(), 'delivered')) {
        this.campaignService.processRBMWebhook(parsed_data.messageId)
      }
    } catch (e) {}
    response.send(response_data).status(200)
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get(['analysis', '/analysis/:projectID'])
  getDailyAnalysis(@Res() response: Response, @Req() request: Request, @Param('projectID') projectID: string) {
    this.campaignService.getDailyAnalysis(request.user._id, projectID).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post('clear-whatsapp-sessions')
  clearWhatsapp(@Res() response: Response, @Req() request: Request) {
    this.campaignService.clearWhatsappSession(request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @ApiConsumes(contentTypes.MULTIPART.FORM_DATA)
  @UseInterceptors(WhatsAppInterceptor())
  @Post('/whatsapp/:projectID')
  createWhatsappCampaign(
    @Res() response: Response<APIResponse>,
    @Req() request: Request,
    @Param('projectID') projectID: string,
    @Body()
    campaignObject: WhatsappCampaignDTO
  ) {
    this.campaignService
      .createWhatsappCampaign(projectID, plainToClass(WhatsappCampaignDTO, campaignObject), request.user._id, !_.isNil(request.whatsappFiles) && !_.isEmpty(request.whatsappFiles) ? request.whatsappFiles : ([] as any), request.allImages)
      .then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Get('info/single/:campaignID')
  getSingleCampaignData(@Res() response: Response, @Req() request: Request, @Param('campaignID') campaignID: string) {
    this.campaignService.getSingleCampaignData(campaignID).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }
}
