import { redisKeys } from '@config'
import { messages } from '@messages'
import { HttpStatus } from '@nestjs/common'
import { extractParameterFromURL, generateUID, getAPIResponse } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import { NextFunction, Request, Response } from 'express'
import _ from 'lodash'

// check is direct access to tour is authenticated or not
export const isTourValid = (request: Request, response: Response, next: NextFunction) => {
  response.header('Access-Control-Allow-Origin', '*')
  response.header('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept')
  let queryID: string
  if (!_.isNil(request.query.id) && _.isNil(extractParameterFromURL('id', request.headers.referer))) {
    queryID = <string>request.query.id
  } else {
    queryID = extractParameterFromURL('id', request.headers.referer)
  }
  if (!_.isNil(queryID)) {
    RedisHandler.getInstance().get(redisKeys.CAMPAIGN_REQUEST.value(queryID), (error: Error, data: string) => {
      if (_.isNil(error) && !_.isNil(data)) {
        return next()
      }
      return response.send(getAPIResponse(messages.COM002.code, generateUID(), HttpStatus.FORBIDDEN))
    })
  } else {
    return response.send(getAPIResponse(messages.COM002.code, generateUID(), HttpStatus.FORBIDDEN))
  }
}
