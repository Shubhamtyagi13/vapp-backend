import { variables, environments } from '@config'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Controller, Get, Param, Res,
} from '@nestjs/common'
import { ApiBearerAuth, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Response } from 'express'
import _ from 'lodash'
import { TourService } from './tour.service'

@ApiTags(TourController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('tour')
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class TourController {
  constructor(private tourService: TourService) {}

  @Get(':tourID')
  fetchTour(@Res() response: Response, @Param('tourID') tourID: string) {
    this.tourService.fetchTour(tourID).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }
}
