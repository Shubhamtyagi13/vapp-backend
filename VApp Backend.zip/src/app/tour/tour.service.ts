import { constants, redisKeys, variables } from '@config'
import { SMSRequestRedis } from '@interfaces/request.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { HttpStatus, Inject, Injectable } from '@nestjs/common'
import { getAPIResponse, getEnvironmentVariable } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import { response } from 'express'
import fs from 'fs'
import _ from 'lodash'
import path from 'path'

@Injectable()
export class TourService {
  private traceID: string

  constructor(@Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext) {
    this.traceID = vapp_context.traceID
  }

  fetchTour = (tourID: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      RedisHandler.getInstance().get(redisKeys.CAMPAIGN_REQUEST.value(tourID), (error: Error, data: string) => {
        if (_.isNil(error) && !_.isNil(data)) {
          const smsRequestPayload = JSON.parse(data) as SMSRequestRedis
          const slug = fs.existsSync(
            path.join(process.cwd(), `/${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.WALKTHROUGH_DIRECTORY.name)}/${
              smsRequestPayload.projectID
            }/tour.html`),
          )
            ? 'tour.html'
            : fs.existsSync(
              path.join(process.cwd(), `/${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.WALKTHROUGH_DIRECTORY.name)}/${
                smsRequestPayload.projectID
              }/index.html`),
            )
              ? 'index.html'
              : undefined
          if (!_.isNil(slug)) {
            return response.sendFile(
              path.join(process.cwd(), `/${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.WALKTHROUGH_DIRECTORY.name)}/${
                smsRequestPayload.projectID
              }/${slug}`),
            )
          }
          resolve(getAPIResponse(messages.TOUR001.code, this.traceID, HttpStatus.NOT_FOUND))
        } else {
          resolve(getAPIResponse(messages.TOUR001.code, this.traceID, HttpStatus.NOT_FOUND))
        }
      })
    })
}
