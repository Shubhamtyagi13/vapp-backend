import { Credits } from '@app/credits/credits.schema'
import {
  canonicalMethods, constants, redisKeys, variables,
} from '@config'
import { PasswordResetAlert } from '@interfaces/alert.interface'
import { GenericObject } from '@interfaces/generic.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { HttpStatus, Inject, Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { AlertService } from '@services/alert.service'
import { VappLogger } from '@services/logger.service'
import AuthHandler from '@utils/auth.util'
import { createOperations, findOperations } from '@utils/crud.util'
import {
  deleteFile,
  generateRandomString,
  getAPIResponse,
  getEnvironmentVariable,
  getErrorLog,
  getSanatisedName,
  getTokenSignOptions,
  switchUserAudience,
} from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import { Request } from 'express'
import _ from 'lodash'
import { Model } from 'mongoose'
import { v4 as uuidv4 } from 'uuid'
import { AuthenticateUserDTO } from './dto/authenticate-user.dto'
import { CreateUserDTO } from './dto/create-user.dto'
import { ResetPasswordDTO } from './dto/reset-password'
import { UpdatePasswordDTO } from './dto/update-password'
import { UpdateUserDTO } from './dto/update-user.dto'
import { VerifyPasswordDTO } from './dto/verify-password'
import { User } from './user.schema'
import { crmIntegration } from './crmIntegration.schema'
import { UpdateCrmDTO } from './dto/update-crm.dto'


@Injectable()
export class UserService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(Credits.name) private creditModel: Model<Credits>,
    @InjectModel(crmIntegration.name) private crmIntegrationModel: Model<crmIntegration>,

    private logger: VappLogger,
  ) {
    this.traceID = vapp_context.traceID
  }

  findOne = (userID: string) => new Promise<ServiceResponse>((resolve) => {
    RedisHandler.getInstance().get(redisKeys.USER.value(userID), (error: Error, data: string) => {
      if (_.isNil(error) && !_.isNil(data)) {
        resolve(getAPIResponse(messages.USER032.code, this.traceID, HttpStatus.OK, JSON.parse(data) as User))
      } else {
        findOperations
          .findById(this.userModel, userID, { __v: 0, password: 0, _id: 0 })
          .then((user: User) => {
            if (!_.isNil(user)) {
              RedisHandler.getInstance().set(redisKeys.USER.value(userID), JSON.stringify(user))
              RedisHandler.getInstance().expire(redisKeys.USER.value(userID), redisKeys.USER.timeout())
              resolve(getAPIResponse(messages.USER032.code, this.traceID, HttpStatus.OK, user))
            } else {
              resolve(getAPIResponse(messages.USER009.code, this.traceID, HttpStatus.NOT_FOUND))
            }
          })
          .catch((error: Error) => {
            this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_USER, this.traceID, { userID, error }, error.message))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
      }
    })
  })

  authenticate = (user: AuthenticateUserDTO, session: GenericObject) => new Promise<ServiceResponse>((resolve) => {
    const { email, password } = user
    findOperations
      .findOne(this.userModel, { email }, { __v: 0 })
      .then((result: User) => {
        if (!_.isNil(result)) {
          if (result.activeStatus) {
            console.log(AuthHandler.getInstance().encryptionHandler().decrypt(result.password))
            if (_.eq(AuthHandler.getInstance().encryptionHandler().decrypt(result.password), password)) {
              const token = AuthHandler.getInstance()
                .tokenHandler()
                .sign(_.pick(result.toObject(), _.pull(_.keys(result.toObject()), 'password')), getTokenSignOptions(_.toString(result._id), switchUserAudience(result.userType)))
              session.user = AuthHandler.getInstance().tokenHandler().getDecodedToken(token)
              session.verified = true
              session.expTime = AuthHandler.getInstance().tokenHandler().getExpirationTime(token)
              resolve(getAPIResponse(messages.USER017.code, this.traceID, HttpStatus.OK, { token }))
            } else {
              resolve(getAPIResponse(messages.USER016.code, this.traceID, HttpStatus.UNAUTHORIZED))
            }
          } else {
            resolve(getAPIResponse(messages.USER035.code, this.traceID, HttpStatus.FORBIDDEN))
          }
        } else {
          resolve(getAPIResponse(messages.USER009.code, this.traceID, HttpStatus.NOT_FOUND))
        }
      })
      .catch((error: Error) => {
        this.logger.error(getErrorLog(canonicalMethods.AUTHENTICATE_CLIENT_USER, this.traceID, { email, password, error }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
  })

  refreshToken = (token: string) => new Promise<ServiceResponse>((resolve) => {
    const decodedToken = AuthHandler.getInstance().tokenHandler().getDecodedToken(token)
    const refresh_token = AuthHandler.getInstance()
      .tokenHandler()
      .refresh(token, { jwtid: uuidv4(), verify: { audience: decodedToken?.aud, issuer: getEnvironmentVariable(variables.JWT_ISSUER.name) } })
    if (!_.isNil(refresh_token)) {
      resolve(getAPIResponse(messages.USER037.code, this.traceID, HttpStatus.OK, { token: refresh_token }))
    } else {
      resolve(getAPIResponse(messages.JWT001.code, this.traceID, HttpStatus.BAD_REQUEST))
    }
  })

  findProfile = (userID: string) => new Promise<ServiceResponse>((resolve) => {
    const payloadObject = { userData: undefined, creditsData: undefined }
    RedisHandler.getInstance().get(redisKeys.USER.value(userID), (error: Error, data: string) => {
      if (_.isNil(error) && !_.isNil(data)) {
        payloadObject.userData = JSON.parse(data)

        RedisHandler.getInstance().get(redisKeys.USER_CREDITS.value(userID), (error: Error, data: string) => {
          if (_.isNil(error) && !_.isNil(data)) {
            payloadObject.creditsData = JSON.parse(data)
            resolve(getAPIResponse(messages.USER025.code, this.traceID, HttpStatus.OK, { payloadObject }))
          } else {
            findOperations
              .findOne(this.creditModel, { clientID: userID }, { __v: 0, password: 0, _id: 0 })
              .then((credits: Credits) => {
                if (!_.isNil(credits)) {
                  RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(userID), JSON.stringify(credits))
                  RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(userID), redisKeys.USER_CREDITS.timeout())
                  payloadObject.creditsData = credits
                }
                resolve(getAPIResponse(messages.USER025.code, this.traceID, HttpStatus.OK, { payloadObject }))
              })
              .catch((error: Error) => {
                this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_USER, this.traceID, { userID, error }, error.message))
                resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              })
          }
        })
      } else {
        findOperations
          .findById(this.userModel, userID, { __v: 0, password: 0, _id: 0 })
          .then((user: User) => {
            if (!_.isNil(user)) {
              payloadObject.userData = user
              RedisHandler.getInstance().set(redisKeys.USER.value(userID), JSON.stringify(user))
              RedisHandler.getInstance().expire(redisKeys.USER.value(userID), redisKeys.USER.timeout())
              RedisHandler.getInstance().get(redisKeys.USER_CREDITS.value(userID), (error: Error, data: string) => {
                if (_.isNil(error) && !_.isNil(data)) {
                  payloadObject.creditsData = JSON.parse(data)
                  resolve(getAPIResponse(messages.USER025.code, this.traceID, HttpStatus.OK, { payloadObject }))
                } else {
                  findOperations
                    .findOne(this.creditModel, { clientID: userID }, { __v: 0, password: 0, _id: 0 })
                    .then((credits: Credits) => {
                      if (!_.isNil(credits)) {
                        RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(userID), JSON.stringify(credits))
                        RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(userID), redisKeys.USER_CREDITS.timeout())
                        payloadObject.creditsData = credits
                      }
                      resolve(getAPIResponse(messages.USER025.code, this.traceID, HttpStatus.OK, { payloadObject }))
                    })
                    .catch((error: Error) => {
                      this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_USER, this.traceID, { userID, error }, error.message))
                      resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                    })
                }
              })
            } else {
              resolve(getAPIResponse(messages.USER009.code, this.traceID, HttpStatus.NOT_FOUND))
            }
          })
          .catch((error: Error) => {
            this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_USER, this.traceID, { userID, error }, error.message))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
      }
    })
  })

  update = (updateObject: UpdateUserDTO, userID: string) => new Promise<ServiceResponse>((resolve) => {
    findOperations
      .findById(this.userModel, userID)
      .then((result: User) => {
        if (!_.isNil(result)) {
          findOperations
            .findByIdAndUpdate(this.userModel, userID, updateObject, { new: true })
            .then((user: User) => {
              RedisHandler.getInstance().set(redisKeys.USER.value(userID), JSON.stringify(_.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))))
              RedisHandler.getInstance().expire(redisKeys.USER.value(userID), redisKeys.USER.timeout())
              resolve(
                getAPIResponse(messages.USER011.code, this.traceID, HttpStatus.OK, _.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))),
              )
            })
            .catch((error: Error) => {
              this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_USER, this.traceID, { userID, error }, error.message))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            })
        } else {
          resolve(getAPIResponse(messages.USER009.code, this.traceID, HttpStatus.NOT_FOUND))
        }
      })
      .catch((error: Error) => {
        this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_USER, this.traceID, { userID, error }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
  })

  updatePassword = (updatePasswordObject: UpdatePasswordDTO, userID: string) => new Promise<ServiceResponse>((resolve) => {
    if (!_.isEmpty(userID)) {
      const updateObject = {} as User
      updateObject.password = AuthHandler.getInstance().encryptionHandler().encrypt(updatePasswordObject.newPassword)
      findOperations
        .findById(this.userModel, userID)
        .then((result: User) => {
          if (!_.isNil(result)) {
            if (_.eq(AuthHandler.getInstance().encryptionHandler().decrypt(result.password), updatePasswordObject.oldPassword)) {
              if (_.eq(String(AuthHandler.getInstance().encryptionHandler().decrypt(result.password)), String(updatePasswordObject.newPassword))) {
                resolve(getAPIResponse(messages.USER018.code, this.traceID, HttpStatus.BAD_REQUEST))
              } else {
                findOperations
                  .findByIdAndUpdate(this.userModel, userID, updateObject)
                  .then(() => {
                    resolve(getAPIResponse(messages.USER015.code, this.traceID, HttpStatus.OK))
                  })
                  .catch((error: Error) => {
                    this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_USER_PASSWORD, this.traceID, { userID, error }, error.message))
                    resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                  })
              }
            } else {
              resolve(getAPIResponse(messages.USER021.code, this.traceID, HttpStatus.BAD_REQUEST))
            }
          } else {
            resolve(getAPIResponse(messages.USER009.code, this.traceID, HttpStatus.NOT_FOUND))
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_USER_PASSWORD, this.traceID, { userID, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    } else {
      resolve(getAPIResponse(messages.COM002.code, this.traceID, HttpStatus.FORBIDDEN))
    }
  })
  
  changePassword = (newPassword: string, userID: string) =>
  new Promise<ServiceResponse>((resolve) => {
    if (!_.isEmpty(userID)) {
      const updateObject = {} as User
      updateObject.password = AuthHandler.getInstance().encryptionHandler().encrypt(newPassword)
      findOperations
        .findById(this.userModel, userID)
        .then((result: User) => {
          if (!_.isNil(result)) {
            if (_.eq(String(AuthHandler.getInstance().encryptionHandler().decrypt(result.password)), newPassword)) {
              resolve(getAPIResponse(messages.USER018.code, this.traceID, HttpStatus.BAD_REQUEST))
            } else {
              findOperations
                .findByIdAndUpdate(this.userModel, userID, updateObject)
                .then(() => {
                  resolve(getAPIResponse(messages.USER015.code, this.traceID, HttpStatus.OK))
                })
                .catch((error: Error) => {
                  this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_USER_PASSWORD, this.traceID, { userID, error }, error.message))
                  resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                })
            }
          } else {
            resolve(getAPIResponse(messages.USER009.code, this.traceID, HttpStatus.NOT_FOUND))
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_USER_PASSWORD, this.traceID, { userID, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    } else {
      resolve(getAPIResponse(messages.COM002.code, this.traceID, HttpStatus.FORBIDDEN))
    }
  })

  resetPassword = (resetpasswordObject: ResetPasswordDTO) => new Promise<ServiceResponse>((resolve) => {
    findOperations
      .findOne(this.userModel, { email: resetpasswordObject.email })
      .then(async (result: User) => {
        if (!_.isNil(result)) {
          if (!_.isNil(result.correspondence) || !_.isNaN(result.contact)) {
            const randomCode = generateRandomString(6)
            const { firstName, middleName, lastName } = result
            const alertPayload: PasswordResetAlert = {
              reset: true,
              code: randomCode,
              client: getSanatisedName(firstName, middleName, lastName),
              year: String(new Date().getFullYear()),
            }
            if (!_.isNil(result.alerts) && result.alerts) {
              AlertService.getInstance().sendPasswordResetAlert(alertPayload, result.contact, result.email, this.traceID)
            }
            RedisHandler.getInstance().set(redisKeys.USER_RESET.value(result.email), randomCode)
            RedisHandler.getInstance().expire(redisKeys.USER_RESET.value(result.email), redisKeys.USER_RESET.timeout())
            resolve(getAPIResponse(messages.USER039.code, this.traceID, HttpStatus.OK))
          } else {
            resolve(getAPIResponse(messages.USER038.code, this.traceID, HttpStatus.FORBIDDEN))
          }
        } else {
          resolve(getAPIResponse(messages.USER009.code, this.traceID, HttpStatus.NOT_FOUND))
        }
      })
      .catch((error: Error) => {
        this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_USER_PASSWORD, this.traceID, { email: resetpasswordObject.email, error }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
  })

  verifyPassword = (resetpasswordObject: VerifyPasswordDTO) => new Promise<ServiceResponse>((resolve) => {
    RedisHandler.getInstance().get(redisKeys.USER_RESET.value(resetpasswordObject.email), async (error: Error, data: string) => {
      if (_.isNil(error) && !_.isNil(data)) {
        if (_.eq(data, resetpasswordObject.code)) {
          const newPassword = generateRandomString(10)
          const result: User = await createOperations.updateOne(this.userModel, { email: resetpasswordObject.email }, { password: AuthHandler.getInstance().encryptionHandler().encrypt(newPassword) })
          const { firstName, middleName, lastName } = result
          const alertPayload: PasswordResetAlert = {
            reset: false,
            code: newPassword,
            client: getSanatisedName(firstName, middleName, lastName),
            year: String(new Date().getFullYear()),
          }
          if (!_.isNil(result.alerts) && result.alerts) {
            AlertService.getInstance().sendPasswordResetAlert(alertPayload, result.contact, result.email, this.traceID)
          }
          resolve(getAPIResponse(messages.USER042.code, this.traceID, HttpStatus.OK, { password: newPassword }))
        } else {
          resolve(getAPIResponse(messages.USER041.code, this.traceID, HttpStatus.FORBIDDEN))
        }
      } else {
        resolve(getAPIResponse(messages.USER040.code, this.traceID, HttpStatus.FORBIDDEN))
      }
    })
  })

  updateProfileImage = (userID: string, fileName: string, filePath: string) => new Promise<ServiceResponse>((resolve) => {
    if (_.isNil(fileName)) {
      resolve(getAPIResponse(messages.USER026.code, this.traceID, HttpStatus.FORBIDDEN))
    } else {
      RedisHandler.getInstance().get(redisKeys.USER.value(userID), (error: Error, data: string) => {
        if (_.isNil(error) && !_.isNil(data)) {
          const user_object = JSON.parse(data) as User
          if (!_.isNil(user_object.profileImage)) {
            deleteFile(`${filePath}/${user_object.profileImage}`)
          }
          const updateObject = { profileImage: fileName }
          createOperations
            .updateOne(this.userModel, { _id: userID }, updateObject)
            .then((user: User) => {
              RedisHandler.getInstance().set(redisKeys.USER.value(userID), JSON.stringify(_.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))))
              RedisHandler.getInstance().expire(redisKeys.USER.value(userID), redisKeys.USER.timeout())
              resolve(
                getAPIResponse(messages.USER028.code, this.traceID, HttpStatus.OK, _.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))),
              )
            })
            .catch((error: Error) => {
              this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_USER_AVATAR, this.traceID, { userID, error }, error.message))
              deleteFile(`${filePath}/${fileName}`)
              resolve(getAPIResponse(messages.CAM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            })
        } else {
          findOperations
            .findById(this.userModel, userID, { __v: 0, password: 0, _id: 0 })
            .then((user: User) => {
              if (!_.isNil(user)) {
                RedisHandler.getInstance().set(redisKeys.USER.value(userID), JSON.stringify(user))
                RedisHandler.getInstance().expire(redisKeys.USER.value(userID), redisKeys.USER.timeout())
                if (!_.isNil(user.profileImage)) {
                  deleteFile(`${filePath}/${user.profileImage}`)
                }
                const updateObject = { profileImage: fileName }
                createOperations
                  .updateOne(this.userModel, { _id: userID }, updateObject)
                  .then((user: User) => {
                    RedisHandler.getInstance().set(redisKeys.USER.value(userID), JSON.stringify(_.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))))
                    RedisHandler.getInstance().expire(redisKeys.USER.value(userID), redisKeys.USER.timeout())
                    resolve(
                      getAPIResponse(messages.USER028.code, this.traceID, HttpStatus.OK, _.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))),
                    )
                  })
                  .catch((error: Error) => {
                    this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_USER_AVATAR, this.traceID, { userID, error }, error.message))
                    deleteFile(`${filePath}/${fileName}`)
                    resolve(getAPIResponse(messages.CAM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                  })
              } else {
                resolve(getAPIResponse(messages.USER009.code, this.traceID, HttpStatus.NOT_FOUND))
              }
            })
            .catch((error: Error) => {
              this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_USER, this.traceID, { userID, error }, error.message))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            })
        }
      })
    }
  })

  createUser = (userObject: CreateUserDTO, url: string) => new Promise<ServiceResponse>((resolve) => {
    let userType = constants.USER_TYPES.client
    const requestUrl = url.replace('/', '')
    const { smsCost } = userObject
    if (_.includes(requestUrl, 'admin')) {
      userType = constants.USER_TYPES.admin
    } else if (_.includes(requestUrl, 'client')) {
      userType = constants.USER_TYPES.client
    }
    if (
      String(userObject.email).split('@')[1].trim()
        && !String(userObject.email).split('@')[1].trim().toLowerCase().includes(getEnvironmentVariable(variables.EMAIL_DOMAIN.name))
    ) {
      resolve(getAPIResponse(messages.USER005.code, this.traceID, HttpStatus.BAD_REQUEST))
    }
    userObject.userType = userType
    userObject.password = AuthHandler.getInstance().encryptionHandler().encrypt(userObject.password)
    if (_.isNil(userObject.senderIDList) || _.isEmpty(userObject.senderIDList)) {
      userObject.senderIDList = [userObject.smsSenderID]
    } else if (!_.includes(userObject.senderIDList, userObject.smsSenderID)) {
      userObject.senderIDList.push(userObject.smsSenderID)
    }
    findOperations
      .findOne(this.userModel, { email: userObject.email.toLowerCase() })
      .then((checkExistingUser: User) => {
        if (_.isNil(checkExistingUser)) {
          createOperations
            .save(new this.userModel(userObject))
            .then((userSaveResult: User) => {
              if (!_.isNil(userSaveResult._id)) {
                createOperations
                  .save(
                    new this.creditModel({
                      clientID: userSaveResult._id,
                      clientName: getSanatisedName(userObject.firstName, userObject.middleName, userObject.lastName),
                      smsCost,
                    }),
                  )
                  .then((creditSaveResult: Credits) => {
                    if (!_.isNil(creditSaveResult._id)) {
                      resolve(getAPIResponse(messages.USER013.code, this.traceID, HttpStatus.OK))
                    } else {
                      this.logger.error(getErrorLog(canonicalMethods.CREATE_CLIENT_USER_CREDITS, this.traceID, { userObject }))
                      resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                      findOperations.findByIdAndDelete(this.userModel, userSaveResult._id, {})
                    }
                  })
                  .catch((error: Error) => {
                    this.logger.error(getErrorLog(canonicalMethods.CREATE_CLIENT_USER_CREDITS, this.traceID, { userObject, error }, error.message))
                    resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                    findOperations.findByIdAndDelete(this.userModel, userSaveResult._id, {})
                  })
              } else {
                this.logger.error(getErrorLog(canonicalMethods.CREATE_USER, this.traceID, { userObject }))
                resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                findOperations.findByIdAndDelete(this.userModel, userSaveResult._id, {})
              }
            })
            .catch((error: Error) => {
              this.logger.error(getErrorLog(canonicalMethods.CREATE_USER, this.traceID, { userObject, error }, error.message))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            })
        } else {
          resolve(getAPIResponse(messages.USER022.code, this.traceID, HttpStatus.BAD_REQUEST))
        }
      })
      .catch((error: Error) => {
        this.logger.error(getErrorLog(canonicalMethods.CREATE_USER, this.traceID, { userObject, error }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
  })

  fetchClientsAdmins = (url: string) => new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
    let userType: number
    if (_.includes(url, 'admins')) {
      userType = constants.USER_TYPES.admin
    } else if (_.includes(url, 'clients')) {
      userType = constants.USER_TYPES.client
    }
    findOperations
      .find(this.userModel, !_.isNil(userType) ? { userType } : {}, { __v: 0, password: 0 })
      .then((users: [User]) => {
        if (!_.isNil(users)) {
          resolve(getAPIResponse(messages.USER033.code, this.traceID, HttpStatus.OK, users))
        }
        resolve(getAPIResponse(messages.USER008.code, this.traceID, HttpStatus.FORBIDDEN))
      })
      .catch((error: Error) => {
        this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENTS_ADMINS, this.traceID, { url, error }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
  })

  grantAccess = (userID: string, url: string) => new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
    let grantAccess = false
    if (_.includes(url, 'deactivate')) {
      grantAccess = false
    } else if (_.includes(url, 'activate')) {
      grantAccess = true
    }
    findOperations
      .findByIdAndUpdate(this.userModel, userID, { $set: { activeStatus: grantAccess } }, { new: true })
      .then((user: User) => {
        if (!_.isNil(user)) {
          RedisHandler.getInstance().set(redisKeys.USER.value(userID), JSON.stringify(_.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))))
          RedisHandler.getInstance().expire(redisKeys.USER.value(userID), redisKeys.USER.timeout())
          resolve(
            getAPIResponse(messages.USER034.code, this.traceID, HttpStatus.OK, _.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))),
          )
        }
        resolve(getAPIResponse(messages.USER009.code, this.traceID, HttpStatus.NOT_FOUND))
      })
      .catch((error: Error) => {
        this.logger.error(getErrorLog(canonicalMethods.GRANT_USER_ACCESS, this.traceID, { userID, url, error }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
  })

  toggleAlerts = (userID: string, url: string) => new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
    let grantAccess = false
    if (_.includes(url, 'deactivate')) {
      grantAccess = false
    } else if (_.includes(url, 'activate')) {
      grantAccess = true
    }
    findOperations
      .findByIdAndUpdate(this.userModel, userID, { $set: { alerts: grantAccess } }, { new: true })
      .then((user: User) => {
        if (!_.isNil(user)) {
          RedisHandler.getInstance().set(redisKeys.USER.value(userID), JSON.stringify(_.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))))
          RedisHandler.getInstance().expire(redisKeys.USER.value(userID), redisKeys.USER.timeout())
          resolve(
            getAPIResponse(messages.USER034.code, this.traceID, HttpStatus.OK, _.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))),
          )
        }
        resolve(getAPIResponse(messages.USER009.code, this.traceID, HttpStatus.NOT_FOUND))
      })
      .catch((error: Error) => {
        this.logger.error(getErrorLog(canonicalMethods.GRANT_USER_ACCESS, this.traceID, { userID, url, error }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
  })

  toggleDomain(userID: string, url: string) {
    return new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      const useAlt = !!_.includes(url, 'enable')
      findOperations
        .findByIdAndUpdate(this.userModel, userID, { $set: { altDomain: useAlt } }, { new: true })
        .then((user: User) => {
          if (!_.isNil(user)) {
            RedisHandler.getInstance().set(redisKeys.USER.value(userID), JSON.stringify(_.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))))
            RedisHandler.getInstance().expire(redisKeys.USER.value(userID), redisKeys.USER.timeout())
            resolve(
              getAPIResponse(messages.USER047.code, this.traceID, HttpStatus.OK, _.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))),
            )
          }
          resolve(getAPIResponse(messages.USER009.code, this.traceID, HttpStatus.NOT_FOUND))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.TOGGLE_ALT_DOMAIN, this.traceID, { userID, url, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })
  }

  toggleDefaultSenderID = (user: User, senderID: string) => new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
    const userID = user._id
    if (!_.includes(user.senderIDList, senderID)) {
      resolve(getAPIResponse(messages.USER045.code, this.traceID, HttpStatus.BAD_REQUEST))
    } else {
      createOperations
        .updateOne(this.userModel, { _id: userID }, { $set: { smsSenderID: senderID } })
        .then((user: User) => {
          RedisHandler.getInstance().expire(redisKeys.USER.value(userID), redisKeys.USER.timeout())
          resolve(
            getAPIResponse(messages.USER046.code, this.traceID, HttpStatus.OK, _.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))),
          )
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.TOGGLE_DEFAULT_SENDER_ID, this.traceID, { userID, senderID, error }, error.message))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
      }
    })

    addSenderID = (userID: string, newSenderIDList: string[]) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      findOperations
        .findById(this.userModel, userID)
        .then((user: User) => {
          if (!_.isNil(user)) {
            newSenderIDList = _.filter(newSenderIDList, (senderID) => !_.includes(user.senderIDList, senderID))
            // assuming everything in user.senderIDList is in the same case as everything in newSenderIDList, else:
            // newSenderIDList = _.filter(newSenderIDList, (senderID) => !_.includes(user.senderIDList.map((id) => id.toUpperCase()), senderID.toUpperCase()))
            if (!_.isEmpty(newSenderIDList)) {
              const updatedList = [ ...user.senderIDList, ...newSenderIDList ]
              findOperations.findByIdAndUpdate(this.userModel, userID, { $set: { senderIDList: updatedList } })
                .then((user: User) => {
                  RedisHandler.getInstance().set(
                    redisKeys.USER.value(userID),
                    JSON.stringify(_.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id')))
                  )
                  RedisHandler.getInstance().expire(redisKeys.USER.value(userID), redisKeys.USER.timeout())
                  resolve(
                    getAPIResponse(messages.USER052.code, this.traceID, HttpStatus.OK, _.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id')))
                  )
                })
                .catch((error: Error) => {
                  this.logger.error(getErrorLog(canonicalMethods.ADD_SENDER_ID, this.traceID, { userID, error }, error.message))
                  resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                })
            }
          } else {
            resolve(getAPIResponse(messages.USER009.code, this.traceID, HttpStatus.NOT_FOUND))
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.ADD_SENDER_ID, this.traceID, { userID, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  logOut = (request: Request) => new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void, reject: (reason?: unknown) => void) => {
    request.session.destroy((error) => {
      if (_.isNil(error)) {
        resolve(<ServiceResponse>getAPIResponse(messages.USER043.code, this.traceID, HttpStatus.OK))
      } else {
        resolve(<ServiceResponse>getAPIResponse(messages.USER044.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR, { error }))
      }
    })
  })

  toggleProhibition = (userID: string, url: string) => new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
    let grantAccess = false
    if (_.includes(url, 'deactivate')) {
      grantAccess = false
    } else if (_.includes(url, 'activate')) {
      grantAccess = true
    }
    findOperations
      .findByIdAndUpdate(this.userModel, userID, { $set: { prohibition: grantAccess } }, { new: true })
      .then((user: User) => {
        if (!_.isNil(user)) {
          RedisHandler.getInstance().set(redisKeys.USER.value(userID), JSON.stringify(_.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))))
          RedisHandler.getInstance().expire(redisKeys.USER.value(userID), redisKeys.USER.timeout())
          resolve(
            getAPIResponse(messages.USER034.code, this.traceID, HttpStatus.OK, _.pick(user.toObject(), _.pull(_.keys(user.toObject()), 'password', '__v', '_id'))),
          )
        }
        resolve(getAPIResponse(messages.USER009.code, this.traceID, HttpStatus.NOT_FOUND))
      })
      .catch((error: Error) => {
        this.logger.error(getErrorLog(canonicalMethods.GRANT_USER_ACCESS, this.traceID, { userID, url, error }, error.message))
        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
      })
  })

  enableCrm = (userID: string, url: string) =>
  new Promise<ServiceResponse>((resolve) => {
    if (!_.isEmpty(userID)) {
      let enableCrm = _.includes(url, 'disable') ? false : true
      let updateObject = {} as User
      updateObject.enableCrm = enableCrm

      findOperations
        .findByIdAndUpdate(this.userModel, userID, updateObject, { new: true })
        .then((result: User) => {
          if (!_.isNil(result)) {
            RedisHandler.getInstance().set(
              redisKeys.USER.value(userID), JSON.stringify(result)
            )
            RedisHandler.getInstance().expire(redisKeys.USER.value(userID), redisKeys.USER.timeout())
            resolve(
              getAPIResponse(messages.USER048.code, this.traceID, HttpStatus.OK, _.pick(result.toObject(), _.pull(_.keys(result.toObject()), 'password', '__v', '_id')))
            )
          }
          resolve(getAPIResponse(messages.USER009.code, this.traceID, HttpStatus.NOT_FOUND))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.TOGGLE_CRM_INTEGRATION, this.traceID, { userID, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    } else {
      resolve(getAPIResponse(messages.COM002.code, this.traceID, HttpStatus.FORBIDDEN))
    }
  })

updateCrmValues = (updateCrmObject: UpdateCrmDTO, userID: string) =>
  new Promise<ServiceResponse>((resolve) => {
    if (!_.isEmpty(userID)) {
      const updateObject = {} as crmIntegration
      updateObject.userId = userID
      updateObject.crmName = updateCrmObject.crmName
      updateObject.apiKeys = updateCrmObject.apiKeys

      const searchQuery = {
        userId: userID,
        crmName: updateCrmObject.crmName
      }

      createOperations
        .updateOneUpsert(this.crmIntegrationModel, searchQuery, updateObject)
        .then((result: crmIntegration) => {
          resolve(getAPIResponse(messages.USER049.code, this.traceID, HttpStatus.OK, result))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.SAVE_CRM_API, this.traceID, { userID, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    } else {
      resolve(getAPIResponse(messages.COM002.code, this.traceID, HttpStatus.FORBIDDEN))
    }
  })


getCrmValues = (userID: string) =>
  new Promise<ServiceResponse>((resolve) => {
    if (!_.isEmpty(userID)) {
      const searchQuery = { userId : userID }
      console.log(searchQuery)
      findOperations
        .find(this.crmIntegrationModel, searchQuery)
        .then((result: crmIntegration) => {
          if (!_.isNil(result)) {
            console.log(result)
            resolve(getAPIResponse(messages.USER033.code, this.traceID, HttpStatus.OK, result))
          }
          resolve(getAPIResponse(messages.USER051.code, this.traceID, HttpStatus.FORBIDDEN))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.FETCH_CRM_API, this.traceID, error, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    }

  })

}
