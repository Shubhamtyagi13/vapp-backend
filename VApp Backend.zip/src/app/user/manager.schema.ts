import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ _id: false })
export class Manager extends Document {
  @Prop({ type: String, required: true, default: null })
  name: string

  @Prop({ type: String, required: true, default: null, index: true })
  email: string

  @Prop({ type: Number, required: true, index: true })
  phone: number
}

export const ManagerSchema = SchemaFactory.createForClass(Manager)
