import {
  constants, smpp_client, tables,
} from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { getObjectID } from '@utils/platform.util'
import { Document } from 'mongoose'
import { Manager, ManagerSchema } from './manager.schema'

@Schema({ collection: tables.USER.collection, autoCreate: true })
export class User extends Document {
  @Prop({ type: String, index: true, required: true })
  firstName: string

  @Prop({ type: String, default: null })
  middleName: string

  @Prop({ type: String, required: true })
  lastName: string

  @Prop({ type: String, index: true, required: true })
  email: string

  @Prop({ type: String, required: true, default: null })
  companyName: string

  @Prop({ type: String, default: null })
  profileImage: string

  @Prop({ type: Number, index: true, default: constants.USER_TYPES.client })
  userType: number

  @Prop({ type: String, index: true, required: true })
  smsSenderID: string

  @Prop({ type: [String], default: [] })
  senderIDList: [string]

  @Prop({ type: Boolean, index: true, default: true })
  isFirstTime: boolean

  @Prop({ type: String, index: true, required: true })
  password: string

  @Prop({ type: Boolean, index: true, default: false })
  activeStatus: boolean

  @Prop({ type: String, default: null })
  greeting: string

  @Prop({
    type: String, default: () => getObjectID(), auto: true, index: { unique: true },
  })
  apiKey: string

  @Prop({ type: Number, required: true, index: true })
  contact: number

  @Prop({ type: Number, default: 2, index: true })
  route: number

  @Prop({
    type: String, default: null, required: true, index: true,
  })
  correspondence: string

  @Prop({
    type: ManagerSchema, default: null, required: true, index: true,
  })
  manager: Manager

  @Prop({ type: String, default: null, index: true })
  impersonation: string

  @Prop({
    type: [String], required: false, index: true, default: [constants.FEATURES_ACCESS.CAMPAIGN.NAME],
  })
  access: Array<string>

  @Prop({ type: Boolean, default: true, index: true })
  prohibition: boolean

  @Prop({ type: Boolean, default: true, index: true })
  alerts: boolean

  @Prop({
    type: String, default: null, required: false, index: false,
  })
  primaryWhatsappToken: string

  @Prop({
    type: String, default: null, required: false, index: false,
  })
  headerID: string

  @Prop({
    type: String, default: null, required: false, index: false,
  })
  peID: string

  @Prop({ type: Number, default: 48 })
  defaultCampaignExpireyTime: number

  @Prop({ type: Boolean, default: false })
  altDomain: boolean

  @Prop({ type: Boolean, required: false, default: false })
  enableCrm: boolean
}

export const UserSchema = SchemaFactory.createForClass(User)
