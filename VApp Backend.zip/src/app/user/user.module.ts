import { Credits, CreditsSchema } from '@app/credits/credits.schema'
import { variables } from '@config'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { MulterModule } from '@nestjs/platform-express'
import { VappLogger } from '@services/logger.service'
import { getEnvironmentVariable } from '@utils/platform.util'
import { UserController } from './user.controller'
import { User, UserSchema } from './user.schema'
import { UserService } from './user.service'
import { crmIntegration, crmIntegrationSchema } from './crmIntegration.schema'

@Module({
  imports: [
    MongooseModule.forFeature([{ name: User.name, schema: UserSchema }]),
    MongooseModule.forFeature([{ name: Credits.name, schema: CreditsSchema }]),
    MongooseModule.forFeature([{ name: crmIntegration.name, schema: crmIntegrationSchema }]),
    MulterModule.register({
      dest: `./${getEnvironmentVariable(variables.UPLOAD_DIRECTORY.name)}/${getEnvironmentVariable(variables.STATIC_DIRECTORY.name)}`
    })
  ],
  controllers: [UserController],
  providers: [UserService, VappLogger]
})
export class UserModule {}
