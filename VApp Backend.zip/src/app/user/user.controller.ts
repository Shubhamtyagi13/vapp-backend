import {
  audience, contentTypes, environments, variables,
} from '@config'
import { ApiFile } from '@decorators/api-file.decorator'
import { Audience } from '@decorators/audience.decorator'
import { NoClientOverride } from '@decorators/no-client-override.decorator'
import { Token } from '@decorators/token.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { ImageInterceptor } from '@interceptors/image.interceptor'
import { GenericObject } from '@interfaces/generic.interface'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Param, Body, Controller, Get, Post, Req, Res, Session, UseGuards, UseInterceptors,
} from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import {
  ApiBearerAuth, ApiConsumes, ApiExcludeController, ApiTags,
} from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import { Model } from 'mongoose'
import { AuthenticateUserDTO } from './dto/authenticate-user.dto'
import { CreateUserDTO } from './dto/create-user.dto'
import { ResetPasswordDTO } from './dto/reset-password'
import { UpdateCrmDTO } from './dto/update-crm.dto'
import { UpdatePasswordDTO } from './dto/update-password'
import { UpdateUserDTO } from './dto/update-user.dto'
import { VerifyPasswordDTO } from './dto/verify-password'
import { User } from './user.schema'
import { UserService } from './user.service'
import { SenderIDListDTO } from './dto/senderID-list.dto'
import { ChangePasswordDTO } from './dto/change-password'

@ApiTags(UserController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('user')
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class UserController {
  constructor(@InjectModel(User.name) private userModel: Model<User>, private userService: UserService) {}

  /*
    authenticate user
  */
  @Post('authenticate')
  authenticate(@Res() response: Response, @Body() user: AuthenticateUserDTO, @Session() session: GenericObject) {
    this.userService.authenticate(user, session).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
    find only user
  */
  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Get('fetch')
  findOne(@Res() response: Response, @Req() request: Request) {
    this.userService.findOne(request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   retrieve current user profile for clients
   for admin users this route can retrieve any client
  */
  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Get('profile')
  findProfile(@Res() response: Response, @Req() request: Request) {
    this.userService.findProfile(request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   update current user object
  */
  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Post('update')
  update(@Res() response: Response, @Req() request: Request, @Body() updateObject: UpdateUserDTO) {
    this.userService.update(updateObject, request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
    update other user object
  */
    @Audience([audience.ADMIN])
    @UseGuards(AuthenticationGuard)
    @Post('update/:id')
    edit(@Res() response: Response, @Param('id') userID: string, @Body() updateObject: UpdateUserDTO) {
      this.userService.update(updateObject, userID).then((service_response: ServiceResponse) => {
        return response.status(service_response.status).send(<APIResponse>service_response)
      })
    }

      /*
    update other user's password
  */
  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post('change-password/:id')
  changePassword(@Res() response: Response, @Param('id') id: string, @Body() changePasswordObject: ChangePasswordDTO) {
    this.userService.changePassword(changePasswordObject.password, id).then((service_response: ServiceResponse) => {
      return response.status(service_response.status).send(<APIResponse>service_response)
    })
  }

  /*
   update the current user password
  */
  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Post('password')
  updatePassword(@Res() response: Response, @Req() request: Request, @Body() updatePasswordObject: UpdatePasswordDTO) {
    this.userService.updatePassword(updatePasswordObject, request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   update the current user avatar
  */
  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Post('avatar')
  @ApiConsumes(contentTypes.MULTIPART.FORM_DATA)
  @ApiFile('image')
  @UseInterceptors(ImageInterceptor())
  updateProfileImage(@Res() response: Response, @Req() request: Request) {
    this.userService.updateProfileImage(request.user._id, request.fileName, request.filePath).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   create admin or client users
  */
  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post(['client', 'admin'])
  createUser(@Res() response: Response, @Req() request: Request, @Body() userObject: CreateUserDTO) {
    this.userService.createUser(userObject, request.url).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

   /*
   deactivate or activate by ID
  */
   @Audience([audience.ADMIN])
   @UseGuards(AuthenticationGuard)
   @Get(['activate/:id', 'deactivate/:id'])
   grantAccessID(@Res() response: Response, @Req() request: Request, @Param('id') id: string) {
     this.userService.grantAccess(id, request.url).then((service_response: ServiceResponse) => {
       return response.status(service_response.status).send(<APIResponse>service_response)
     })
   }

  /*
    retrieve all admin or client users
  */
  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get(['clients', 'admins'])
  fetchClients(@Res() response: Response, @Req() request: Request) {
    this.userService.fetchClientsAdmins(request.url).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   reset password
  */
  @Post('reset')
  resetPassword(@Res() response: Response, @Req() request: Request, @Body() resetObject: ResetPasswordDTO) {
    this.userService.resetPassword(resetObject).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
  verify password
 */
  @Post('verify')
  verifyPassword(@Res() response: Response, @Req() request: Request, @Body() resetObject: VerifyPasswordDTO) {
    this.userService.verifyPassword(resetObject).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   deactivate or activate by ID
  */
  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post(['activate', 'deactivate'])
  grantAccess(@Res() response: Response, @Req() request: Request) {
    this.userService.grantAccess(request.user._id, request.url).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   refresh a user token
  */
  @Audience([audience.ADMIN, audience.CLIENT])
  @NoClientOverride()
  @Post('refresh')
  refreshToken(@Res() response: Response, @Req() request: Request, @Token() token: string) {
    this.userService.refreshToken(token).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   enable disable alerts by ID
  */
  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Get(['alerts/activate', 'alerts/deactivate'])
  toggleAlerts(@Res() response: Response, @Req() request: Request) {
    this.userService.toggleAlerts(request.user._id, request.url).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   enable/disable alt. domain use
  */
   @Audience([audience.ADMIN, audience.CLIENT])
   @UseGuards(AuthenticationGuard)
   @Get(['altdomain/enable', 'altdomain/disable'])
  toggleDomain(@Res() response: Response, @Req() request: Request) {
    this.userService.toggleDomain(request.user._id, request.url).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

   /*
   changedefaultSenderID
  */
   @Audience([audience.ADMIN, audience.CLIENT])
   @UseGuards(AuthenticationGuard)
   @Post(['senderID/:senderID'])
   toggleDefaultSenderID(@Res() response: Response, @Req() request: Request, @Param('senderID') senderID: string) {
    this.userService.toggleDefaultSenderID(request.user, senderID).then((service_response: ServiceResponse) => {
      return response.status(service_response.status).send(<APIResponse>service_response)
    })
  }

  /*
    add sender IDs
  */
    @Audience([audience.ADMIN])
    @UseGuards(AuthenticationGuard)
    @Post(['add-senderID/:id'])
    addSenderID(@Res() response: Response, @Param('id') userID: string, @Body() senderIDObject: SenderIDListDTO) {
      this.userService.addSenderID(userID, senderIDObject.senderIDList).then((service_response: ServiceResponse) => {
        return response.status(service_response.status).send(<APIResponse>service_response)
      })
    }

  /*
   enable disable prohibition by ID
  */
  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post(['prohibition/activate', 'prohibition/deactivate'])
   toggleProhibition(@Res() response: Response, @Req() request: Request) {
     this.userService.toggleProhibition(request.user._id, request.url).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
   }

  /*
   log out user
  */
  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Get('log-out')
  logOut(@Res() response: Response, @Req() request: Request) {
    this.userService.logOut(request).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  
   /*
  update the current user crm enabling
 */
  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Get(['enablecrm/enable', 'enablecrm/disable'])
  enableCrm(@Res() response: Response, @Req() request: Request) {
    this.userService.enableCrm(request.user._id, request.url).then((service_response: ServiceResponse) => {
      return response.status(service_response.status).send(<APIResponse>service_response)
    })
  }

  /*
   update the current user crm values
  */
  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Post('updatecrm')
  updateCrmValues(@Res() response: Response, @Req() request: Request, @Body() updateCRMObject: UpdateCrmDTO) {
    this.userService.updateCrmValues(updateCRMObject, request.user._id).then((service_response: ServiceResponse) => {
      return response.status(service_response.status).send(<APIResponse>service_response)
    })
  }

  /*
   get the current user crm values
  */
   @Audience([audience.ADMIN, audience.CLIENT])
   @UseGuards(AuthenticationGuard)
   @Get('getcrm')
   getCrmValues(@Res() response: Response, @Req() request: Request) {
     this.userService.getCrmValues(request.user._id).then((service_response: ServiceResponse) => {
       return response.status(service_response.status).send(<APIResponse>service_response)
     })
   }

}
