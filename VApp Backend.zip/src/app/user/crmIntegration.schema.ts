import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({collection: tables.CRM_INTEGRATION.collection, autoCreate: true})
export class crmIntegration extends Document {

  @Prop({ type: String, required: true, default: null })
  userId: string

  @Prop({ type: String, required: true, default: null })
  crmName: string

  @Prop({ type: Array, required: true, default: [] })
  apiKeys : Array<
      {
          key:string;
          value:string
      }
  >
}
export const crmIntegrationSchema = SchemaFactory.createForClass(crmIntegration)