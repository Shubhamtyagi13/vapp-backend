import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsString } from 'class-validator'

export class UpdateCrmDTO extends ClientUserIDDTO {
    @ApiProperty({ required: true })
    @IsString()
    crmName: string

    @ApiProperty({ required: true })
    apiKeys: Array<any>
}