import { smpp_client } from '@config'
import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import { Type } from 'class-transformer'
import { IsEmail, IsObject, IsOptional, IsString, ValidateNested } from 'class-validator'
import { ManagerDTO } from './manager.dto'

export class UpdateUserDTO extends ClientUserIDDTO {
  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  firstName: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  middleName: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  lastName: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  companyName: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  @IsEmail()
  correspondence: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsValidPhone()
  contact: number

  @ApiProperty({ required: false })
  @ValidateNested()
  @IsObject()
  @Type(() => ManagerDTO)
  @IsOptional()
  manager: ManagerDTO

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  smsSenderID: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  greeting: string
}
