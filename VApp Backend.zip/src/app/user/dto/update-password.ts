import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsString } from 'class-validator'

export class UpdatePasswordDTO extends ClientUserIDDTO {
  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  oldPassword: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  newPassword: string
}
