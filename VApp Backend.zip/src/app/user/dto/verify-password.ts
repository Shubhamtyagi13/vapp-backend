import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsEmail, IsString } from 'class-validator'

export class VerifyPasswordDTO {
  @ApiProperty({ required: true })
  @IsString()
  @IsEmail()
  @IsDefined()
  email: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  code: string
}
