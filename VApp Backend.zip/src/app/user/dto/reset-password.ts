import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsEmail, IsString } from 'class-validator'

export class ResetPasswordDTO {
  @ApiProperty({ required: true })
  @IsString()
  @IsEmail()
  @IsDefined()
  email: string
}
