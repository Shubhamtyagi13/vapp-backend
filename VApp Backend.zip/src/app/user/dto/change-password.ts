import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsString } from 'class-validator'

export class ChangePasswordDTO {
  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  password: string
}
