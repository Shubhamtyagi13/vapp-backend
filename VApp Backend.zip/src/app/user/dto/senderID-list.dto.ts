import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsArray } from 'class-validator'

export class SenderIDListDTO {
  @ApiProperty({ required: true })
  @IsArray()
  @IsDefined()
  senderIDList: string[]
}
