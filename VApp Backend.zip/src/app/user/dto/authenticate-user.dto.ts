import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsString } from 'class-validator'

export class AuthenticateUserDTO {
  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly email: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly password: string
}
