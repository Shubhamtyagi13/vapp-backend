import { ClientUserIDDTO } from '@dto/client-id.dto'
import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import { IsDefined, IsEmail, IsNotEmpty, IsString } from 'class-validator'

export class ManagerDTO extends ClientUserIDDTO {
  @ApiProperty()
  @IsDefined()
  @IsNotEmpty()
  @IsEmail()
  email: string

  @ApiProperty()
  @IsDefined()
  @IsNotEmpty()
  @IsString()
  name: string

  @ApiProperty()
  @IsDefined()
  @IsNotEmpty()
  @IsValidPhone()
  phone: number
}
