import { smpp_client } from '@config'
import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import { Type } from 'class-transformer'
import { IsAlpha, IsBoolean, IsDecimal, IsDefined, IsEmail, IsNumber, IsOptional, IsString, Length, ValidateNested, IsArray } from 'class-validator'
import { ManagerDTO } from './manager.dto'

export class CreateUserDTO {
  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  firstName: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  middleName: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  lastName: string

  @ApiProperty({ required: true })
  @IsEmail()
  @IsDefined()
  email: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  companyName: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  profileImage: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsNumber()
  userType: number

  @ApiProperty({ required: true })
  @IsString()
  @Length(6, 6)
  @IsAlpha()
  @IsDefined()
  smsSenderID: string

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  isFirstTime: boolean

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  password: string

  @ApiProperty()
  @IsString()
  @IsEmail()
  correspondence: string

  @ApiProperty()
  @IsDefined()
  @IsValidPhone()
  contact: number

  @ApiProperty()
  @ValidateNested({ each: true })
  @Type(() => ManagerDTO)
  @IsDefined()
  manager: ManagerDTO

  @ApiProperty({ required: false })
  @IsOptional()
  @IsBoolean()
  activeStatus: boolean

  @ApiProperty({ required: false })
  @IsOptional()
  @IsString()
  greeting: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsDecimal()
  smsCost: number

  @ApiProperty({})
  @IsOptional()
  @IsArray()
  @Type(()=> String)
  senderIDList: [string]

  @ApiProperty({})
  @IsDefined()
  @IsNumber()
  peID: number
}
