import { canonicalMethods, constants, dynamic_config, variables } from '@config'
import { ServiceResponse } from '@interfaces/response.interface'
import { SystemInfo } from '@interfaces/system.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { HttpStatus, Inject, Injectable } from '@nestjs/common'
import { VappLogger } from '@services/logger.service'
import { FireBaseHandler } from '@utils/firebase.util'
import { getAPIResponse, getEnvironmentVariable, getErrorLog } from '@utils/platform.util'
import _ from 'lodash'

@Injectable()
export class SystemService {
  private traceID: string

  constructor(@Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext, private logger: VappLogger) {
    this.traceID = this.vapp_context.traceID
  }

  getSystemInfo = () => new Promise<any>((resolve: (value?: any | PromiseLike<any>) => void, reject: (reason?: unknown) => void) => {
      const appVersion = getEnvironmentVariable(variables.APPLICATION_VERSION.name)
      const infoObject: SystemInfo = <SystemInfo>{
        appVersion
      }
      resolve(<ServiceResponse>getAPIResponse(messages.SYS001.code, this.traceID, HttpStatus.OK, infoObject))
    })

  getMaintenance = () =>
    new Promise<ServiceResponse>((resolve) => {
      FireBaseHandler.getInstance()
        .database()
        .ref(dynamic_config.DYNAMIC_CONFIG)
        .child(variables.MAINTENANCE_MODE.name)
        .once('value', (snapshot) => {
          resolve(getAPIResponse(messages.SYS004.code, this.traceID, HttpStatus.OK, { status: snapshot.val() }))
        })
    })

  toggleMaintenance = (userID: string, username: string, password: string, url: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      let grantAccess = false
      if (_.includes(url, 'deactivate')) {
        grantAccess = false
      } else if (_.includes(url, 'activate')) {
        grantAccess = true
      }
      if (
        _.eq(getEnvironmentVariable(variables.SYSTEM_USERNAME.name), String(username)) &&
        _.eq(getEnvironmentVariable(variables.SYSTEM_PASSWORD.name), String(password))
      ) {
        FireBaseHandler.getInstance()
          .database()
          .ref(dynamic_config.DYNAMIC_CONFIG)
          .child(variables.MAINTENANCE_MODE.name)
          .set(grantAccess)
          .then(() => {
            resolve(getAPIResponse(messages.SYS003.code, this.traceID, HttpStatus.OK, { status: grantAccess }))
          })
          .catch((error: Error) => {
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            this.logger.error(getErrorLog(canonicalMethods.TOGGLE_MAINTENANCE, this.traceID, { userID, username, password, url, error }, error.message))
          })
      } else {
        resolve(getAPIResponse(messages.SYS002.code, this.traceID, HttpStatus.UNAUTHORIZED, {}))
      }
    })
}
