import { BasicAuthenticationMiddleware } from '@middlewares/basic.auth.middleware'
import { MiddlewareConsumer, Module, NestModule } from '@nestjs/common'
import { BullInterfaceService } from '@services/bull-ui.service'
import { VappLogger } from '@services/logger.service'
import { SystemController } from './system.controller'
import { SystemService } from './system.service'

@Module({
  controllers: [SystemController],
  providers: [SystemService, VappLogger]
})
export class SystemModule implements NestModule {
  configure(consumer: MiddlewareConsumer): void {
    consumer.apply(BasicAuthenticationMiddleware()).forRoutes('/system/jobs').apply(BullInterfaceService.getInstance().getAdapter().getRouter()).forRoutes('/system/jobs')
  }
}
