import { audience, environments, variables } from '@config'
import { Audience } from '@decorators/audience.decorator'
import { SystemAuthDTO } from '@dto/system-auth.dto'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Body, Controller, Get, Post, Req, Res, UseGuards,
} from '@nestjs/common'
import { ApiBearerAuth, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import { SystemService } from './system.service'

@ApiTags(SystemController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('system')
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class SystemController {
  constructor(private readonly systemService: SystemService) {}

  @Get('info')
  info(@Res() response: Response) {
    this.systemService.getSystemInfo().then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   maintenace mode
  */
  @Audience([audience.ADMIN, audience.CLIENT])
  @UseGuards(AuthenticationGuard)
  @Post(['maintenance/activate', 'maintenance/deactivate'])
  toggleAlerts(@Res() response: Response, @Req() request: Request, @Body() payload: SystemAuthDTO) {
    this.systemService.toggleMaintenance(request.user._id, payload.username, payload.password, request.url).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Get(['maintenance'])
  alertState(@Res() response: Response, @Req() request: Request) {
    this.systemService.getMaintenance().then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }
}
