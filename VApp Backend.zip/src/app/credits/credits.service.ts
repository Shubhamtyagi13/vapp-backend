import { User } from '@app/user/user.schema'
import { canonicalMethods, constants, redisKeys } from '@config'
import { CreditsApprovedAlert } from '@interfaces/alert.interface'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { HttpStatus, Inject } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { AlertService } from '@services/alert.service'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import {
  dateFromObjectId, getAPIResponse, getDateTimeString, getErrorLog, getSanatisedName,
} from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import _ from 'lodash'
import { Model } from 'mongoose'
import { Credits, CreditsRequest } from './credits.schema'

export class CreditsService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    @InjectModel(Credits.name) private creditsModel: Model<Credits>,
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(CreditsRequest.name) private creditsRequestModel: Model<CreditsRequest>,
    private logger: VappLogger,
  ) {
    this.traceID = vapp_context.traceID
  }

  findSpecific = (userID: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      if (!_.isEmpty(userID)) {
        RedisHandler.getInstance().get(redisKeys.USER_CREDITS.value(userID), (error: Error, data: string) => {
          if (_.isNil(error) && !_.isNil(data)) {
            resolve(getAPIResponse(messages.CRE003.code, this.traceID, HttpStatus.OK, JSON.parse(data) as Credits))
          }
          findOperations
            .findOne(this.creditsModel, { clientID: userID }, { __v: 0 })
            .then((credits: Credits) => {
              if (!_.isNil(credits)) {
                RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(userID), JSON.stringify(credits))
                RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(userID), redisKeys.USER_CREDITS.timeout())
                resolve(getAPIResponse(messages.CRE003.code, this.traceID, HttpStatus.OK, credits))
              }
              resolve(getAPIResponse(messages.CRE001.code, this.traceID, HttpStatus.FORBIDDEN))
            })
            .catch((error: Error) => {
              this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_CREDITS, this.traceID, { userID, error }, error.message))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            })
        })
      } else {
        resolve(getAPIResponse(messages.COM002.code, this.traceID, HttpStatus.FORBIDDEN))
      }
    })

  requestCredits = (firstName: string, middleName: string, lastName: string, credits: number, clientID: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      const clientName = getSanatisedName(firstName, middleName, lastName)
      const newCreditRequest = new this.creditsRequestModel({
        credits: Number(credits),
        clientID,
        clientName,
      } as CreditsRequest)
      createOperations
        .save(newCreditRequest)
        .then((creditRequestResult: CreditsRequest) => {
          if (!_.isNil(creditRequestResult)) {
            findOperations
              .find(this.creditsRequestModel, { clientID }, { __v: 0 })
              .then((creditRequests: CreditsRequest[]) => {
                if (!_.isNil(creditRequests)) {
                  RedisHandler.getInstance().set(redisKeys.USER_CREDITS_REQUESTS.value(clientID), JSON.stringify(creditRequests))
                  RedisHandler.getInstance().expire(redisKeys.USER_CREDITS_REQUESTS.value(clientID), redisKeys.USER_CREDITS_REQUESTS.timeout())
                  resolve(getAPIResponse(messages.CRE012.code, this.traceID, HttpStatus.OK, creditRequestResult))
                }
                resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.FORBIDDEN))
              })
              .catch((error: Error) => {
                this.logger.error(getErrorLog(canonicalMethods.REQUEST_CLIENT_CREDITS, this.traceID, { clientID, error }, error.message))
                resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              })
          } else {
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.REQUEST_CLIENT_CREDITS, this.traceID, { clientID, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  approveCredits = (firstName: string, middleName: string, lastName: string, transactionID: string, adminID: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      // aprrove credits for a client
      const adminName = getSanatisedName(firstName, middleName, lastName)
      findOperations
        .findById(this.creditsRequestModel, transactionID)
        .then((creditRequestResult: CreditsRequest) => {
          if (!_.isNil(creditRequestResult)) {
            if (!creditRequestResult.approved) {
              createOperations
                .updateOne(this.creditsRequestModel, { _id: transactionID }, { $set: { adminName, adminID, approved: true } })
                .then((creditApproveResult: CreditsRequest) => {
                  if (!_.isNil(creditApproveResult)) {
                    createOperations
                      .updateOne(this.creditsModel, { clientID: creditApproveResult.clientID }, { $inc: { credits: creditApproveResult.credits } })
                      .then((creditUpdateResult: Credits) => {
                        if (!_.isNil(creditUpdateResult)) {
                          RedisHandler.getInstance().set(redisKeys.USER_CREDITS.value(creditApproveResult.clientID), JSON.stringify(creditUpdateResult))
                          RedisHandler.getInstance().expire(redisKeys.USER_CREDITS.value(creditApproveResult.clientID), redisKeys.USER_CREDITS.timeout())
                          findOperations
                            .find(this.creditsRequestModel, { clientID: creditApproveResult.clientID }, { __v: 0 })
                            .then(async (creditRequests: CreditsRequest[]) => {
                              if (!_.isNil(creditRequests)) {
                                RedisHandler.getInstance().set(redisKeys.USER_CREDITS_REQUESTS.value(creditApproveResult.clientID), JSON.stringify(creditRequests))
                                RedisHandler.getInstance().expire(redisKeys.USER_CREDITS_REQUESTS.value(creditApproveResult.clientID), redisKeys.USER_CREDITS_REQUESTS.timeout())

                                const result: User = await findOperations.findById(this.userModel, creditApproveResult.clientID)
                                const dateTime = getDateTimeString(dateFromObjectId(creditApproveResult.id))
                                const { firstName, middleName, lastName } = result
                                const alertPayload: CreditsApprovedAlert = {
                                  date: dateTime.date,
                                  time: dateTime.time,
                                  credits: String(creditApproveResult.credits),
                                  client: getSanatisedName(firstName, middleName, lastName),
                                  year: String(new Date().getFullYear()),
                                }
                                if (!_.isNil(result.alerts) && result.alerts) {
                                  AlertService.getInstance().sendCreditsApprovedAlert(alertPayload, result.contact, result.email, this.traceID)
                                }
                                resolve(getAPIResponse(messages.CRE013.code, this.traceID, HttpStatus.OK, creditRequestResult))
                              }
                              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                            })
                            .catch((error: Error) => {
                              this.logger.error(getErrorLog(canonicalMethods.APPROVE_CLIENT_CREDITS, this.traceID, { adminID, transactionID, error }, error.message))
                              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                            })
                        } else {
                          this.logger.error(getErrorLog(canonicalMethods.FIND_CLIENT_CREDITS, this.traceID, { adminID, transactionID }, messages.COM001.code))

                          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                        }
                      })
                      .catch((error: Error) => {
                        this.logger.error(getErrorLog(canonicalMethods.APPROVE_CLIENT_CREDITS, this.traceID, { adminID, transactionID, error }, error.message))
                        resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                      })
                  } else {
                    resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                  }
                })
                .catch((error: Error) => {
                  this.logger.error(getErrorLog(canonicalMethods.APPROVE_CLIENT_CREDITS, this.traceID, { adminID, transactionID, error }, error.message))
                  resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                })
            } else {
              resolve(getAPIResponse(messages.CRE016.code, this.traceID, HttpStatus.BAD_REQUEST))
            }
          } else {
            resolve(getAPIResponse(messages.CRE015.code, this.traceID, HttpStatus.NOT_FOUND))
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.APPROVE_CLIENT_CREDITS, this.traceID, { adminID, transactionID, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  getTransactions = (clientID: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      findOperations
        .findLean(this.creditsRequestModel, { clientID }, {}, { _id: -1 })
        .then((transactions: [CreditsRequest]) => {
          if (!_.isNil(transactions)) {
            resolve(getAPIResponse(messages.CRE017.code, this.traceID, HttpStatus.OK, { transactions }))
          } else {
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.FETCH_CLIENT_TRANSACTIONS, this.traceID, { clientID, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  getTransactionsAll = () =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      findOperations
        .findLean(this.creditsRequestModel, {}, {}, { _id: -1 })
        .then((transactions: [CreditsRequest]) => {
          if (!_.isNil(transactions)) {
            resolve(getAPIResponse(messages.CRE017.code, this.traceID, HttpStatus.OK, { transactions }))
          } else {
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.FETCH_CLIENT_TRANSACTIONS_UNAPPROVED, this.traceID, { error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })
}
