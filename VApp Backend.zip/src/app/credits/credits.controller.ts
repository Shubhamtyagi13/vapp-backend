import { audience, environments, variables } from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { APIResponse, ServiceResponse } from '@interfaces/response.interface'
import {
  Controller, Get, Param, Req, Res, UseGuards,
} from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { ApiBearerAuth, ApiExcludeController, ApiTags } from '@nestjs/swagger'
import { ParseIntPipe } from '@pipes/parse-int.pipe'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import { Model } from 'mongoose'
import { Credits, CreditsRequest } from './credits.schema'
import { CreditsService } from './credits.service'

/* Credits Controller is used for finding credits for some specific user and to create a new credit request by the user. */
@ApiTags(CreditsController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('credits')
@ApiExcludeController(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
export class CreditsController {
  constructor(
    @InjectModel(Credits.name) private creditsModel: Model<Credits>,
    private creditsService: CreditsService,
    @InjectModel(CreditsRequest.name) private creditsRequestModel: Model<CreditsRequest>,
  ) {}

  /*
  find credits for specific client
  */
  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get('specific')
  findSpecific(@Res() response: Response, @Req() request: Request) {
    this.creditsService.findSpecific(request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*  
    find credits for specific client by id
  */
    @Audience([audience.ADMIN])
    @UseGuards(AuthenticationGuard)
    @Get('specific/:id')
    findSpecificId(@Res() response: Response, @Param('id') id: string) {
      this.creditsService.findSpecific(id).then((service_response: ServiceResponse) => {
        return response.status(service_response.status).send(<APIResponse>service_response)
      })
    }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get('request/:credits')
  requestCredits(@Param('credits', ParseIntPipe()) credits: number, @Req() request: Request, @Res() response: Response) {
    this.creditsService
      .requestCredits(request.user.firstName, request.user.middleName, request.user.lastName, credits, request.user._id)
      .then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get('approve/:transactionID')
  approveCredits(@Param('transactionID') transactionID: string, @Req() request: Request, @Res() response: Response) {
    this.creditsService
      .approveCredits(request.user.firstName, request.user.middleName, request.user.lastName, transactionID, request.user._id)
      .then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.CLIENT, audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get('transactions')
  getTransactions(@Req() request: Request, @Res() response: Response) {
    this.creditsService.getTransactions(request.user._id).then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get('transactions/all')
  getTransactionsAll(@Req() request: Request, @Res() response: Response) {
    this.creditsService.getTransactionsAll().then((service_response: ServiceResponse) => response.status(service_response.status).send(<APIResponse>service_response))
  }
}
