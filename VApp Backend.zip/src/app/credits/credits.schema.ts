import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.CREDITS.collection, autoCreate: true })
export class Credits extends Document {
  @Prop({ type: Number, index: true, default: 0 })
  credits: number

  @Prop({ type: Number, index: true, default: 0 })
  frozenCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsSentCount: number

  @Prop({ type: Number, index: true, default: 0.13 })
  smsCost: number

  @Prop({ type: Number, index: true, default: 0 })
  smsFailedCount: number

  @Prop({ type: Number, index: true, default: 0 })
  smsDeliveredCount: number

  @Prop({ type: Number, index: true, default: 0.13 })
  whatsappCost: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappSentCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappFailedCount: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappDeliveredCount: number

  @Prop({ type: String, index: true, required: true })
  clientID: string

  @Prop({ type: Number, index: true, default: 0 })
  smsCredits: number

  @Prop({ type: Number, index: true, default: 0 })
  whatsappCredits: number

  @Prop({ type: String, index: true, required: true })
  clientName: string
}

@Schema({ collection: tables.CREDIT_REQUESTS.collection, autoCreate: true, timestamps: true })
export class CreditsRequest extends Document {
  @Prop({ type: Number, index: true, required: true })
  credits: number

  @Prop({ type: String, index: true, required: true })
  clientID: string

  @Prop({ type: Boolean, index: true, default: false })
  approved: boolean

  @Prop({ type: String, index: true, default: null })
  adminID: string

  @Prop({ type: String, default: null })
  adminName: string

  @Prop({ type: String, required: true, default: null })
  clientName: string
}

export const CreditsSchema = SchemaFactory.createForClass(Credits)
export const CreditsRequestSchema = SchemaFactory.createForClass(CreditsRequest)
