import { User, UserSchema } from '@app/user/user.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { CreditsController } from './credits.controller'
import { Credits, CreditsRequest, CreditsRequestSchema, CreditsSchema } from './credits.schema'
import { CreditsService } from './credits.service'

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Credits.name, schema: CreditsSchema },
      { name: CreditsRequest.name, schema: CreditsRequestSchema }
    ])
  ],
  controllers: [CreditsController],
  providers: [CreditsService, VappLogger],
  exports: [MongooseModule]
})
export class CreditsModule {}
