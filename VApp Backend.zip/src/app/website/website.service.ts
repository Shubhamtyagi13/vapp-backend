import { canonicalMethods, constants, cronJobs, redisKeys, virtuality_config } from '@config'
import { ServiceResponse } from '@interfaces/response.interface'
import { VappContext } from '@interfaces/trace.interface'
import { messages } from '@messages'
import { MailerService } from '@nestjs-modules/mailer'
import { HttpStatus, Inject, Injectable } from '@nestjs/common'
import { InjectModel } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { createOperations, findOperations } from '@utils/crud.util'
import { epochTimeFromDate, getAPIResponse, getErrorLog } from '@utils/platform.util'
import { RedisHandler } from '@utils/redis.util'
import _ from 'lodash'
import { Model } from 'mongoose'
import { FireBaseHandler } from '@utils/firebase.util'
import { InjectQueue } from '@nestjs/bull'
import { Queue } from 'bull'
import { storeUserMetadata } from '@app/contact/cron/helper/common.helper'
import { User } from '@app/user/user.schema'
import { CreateClientDTO } from './dto/create-client.dto'
import { CreateFeedbackDTO } from './dto/create-feedback.dto'
import { CreateNoticeDTO } from './dto/create-notice.dto'
import { CreateTestimonialDTO } from './dto/create-testimonial.dto'
import { SendEmailDTO } from './dto/send-email.dto'
import { Client, Feedback, Notice, Testimonial } from './website.schema'
import { CreateMetadataDTO } from './dto/create-metadata.dto'
import { UserMetadata } from './user-metadata.schema'
import { FetchUserMetadataDTO } from './dto/fetch-metadata.dto'

@Injectable()
export class WebsiteService {
  private traceID: string

  constructor(
    @Inject(constants.PROVIDERS.VAPP_CONTEXT) private vapp_context: VappContext,
    @InjectModel(User.name) private userModel: Model<User>,
    @InjectModel(Client.name) private clientModel: Model<Client>,
    @InjectModel(Testimonial.name) private testimonialModel: Model<Testimonial>,
    @InjectModel(Notice.name) private noticeModel: Model<Notice>,
    @InjectModel(Feedback.name) private feedbackModel: Model<Feedback>,
    @InjectModel(UserMetadata.name) private userMetadataModel: Model<UserMetadata>,
    @InjectQueue(cronJobs.UPLOAD_CLIENT_CONTACTS.name) private contactsUploadQueue: Queue,
    private logger: VappLogger,
    private readonly mailerService: MailerService
  ) {
    this.traceID = vapp_context.traceID
  }

  fetchWebsiteClients = (active: string) =>
    new Promise<ServiceResponse>((resolve) => {
      const fetchActive: boolean = _.includes(active, 'active')

      RedisHandler.getInstance().get(redisKeys.WEBSITE_CLIENTS.value(), (error: Error, data: string) => {
        if (_.isNil(error) && !_.isNil(data)) {
          const websiteClients: Client[] = JSON.parse(data) as Client[]
          if (websiteClients.length > 0) {
            return resolve(getAPIResponse(messages.WEB001.code, this.traceID, HttpStatus.OK, fetchActive ? websiteClients.filter((client) => client.active) : websiteClients))
          }
          return resolve(getAPIResponse(messages.WEB002.code, this.traceID, HttpStatus.OK, []))
        }
        return findOperations
          .find(this.clientModel, {}, { __v: 0 })
          .then((websiteClients: Client[]) => {
            if (!_.isNil(websiteClients)) {
              RedisHandler.getInstance().set(redisKeys.WEBSITE_CLIENTS.value(), JSON.stringify(websiteClients))
              RedisHandler.getInstance().expire(redisKeys.WEBSITE_CLIENTS.value(), redisKeys.WEBSITE_CLIENTS.timeout())
              if (websiteClients.length > 0) {
                resolve(getAPIResponse(messages.WEB001.code, this.traceID, HttpStatus.OK, fetchActive ? websiteClients.filter((client) => client.active) : websiteClients))
              }
              resolve(getAPIResponse(messages.WEB002.code, this.traceID, HttpStatus.OK, []))
            }
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
          .catch((error: Error) => {
            this.logger.error(getErrorLog(canonicalMethods.FIND_WEBSITE_CLIENTS, this.traceID, { error }, error.message))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
      })
    })

  fetchWebsiteTestimonials = (active: string) =>
    new Promise<ServiceResponse>((resolve) => {
      const fetchActive: boolean = _.includes(active, 'active')

      RedisHandler.getInstance().get(redisKeys.WEBSITE_TESTIMONIALS.value(), (error: Error, data: string) => {
        if (_.isNil(error) && !_.isNil(data)) {
          const websiteTestimonials: Testimonial[] = JSON.parse(data) as Testimonial[]
          if (websiteTestimonials.length > 0) {
            resolve(getAPIResponse(messages.WEB003.code, this.traceID, HttpStatus.OK, fetchActive ? websiteTestimonials.filter((testimonials) => testimonials.active) : websiteTestimonials))
          }
          resolve(getAPIResponse(messages.WEB004.code, this.traceID, HttpStatus.OK, []))
        }

        findOperations
          .find(this.testimonialModel, {}, { __v: 0 })
          .then((websiteTestimonials: Testimonial[]) => {
            if (!_.isNil(websiteTestimonials)) {
              RedisHandler.getInstance().set(redisKeys.WEBSITE_TESTIMONIALS.value(), JSON.stringify(websiteTestimonials))
              RedisHandler.getInstance().expire(redisKeys.WEBSITE_TESTIMONIALS.value(), redisKeys.WEBSITE_TESTIMONIALS.timeout())
              if (websiteTestimonials.length > 0) {
                resolve(getAPIResponse(messages.WEB003.code, this.traceID, HttpStatus.OK, fetchActive ? websiteTestimonials.filter((testimonials) => testimonials.active) : websiteTestimonials))
              }
              resolve(getAPIResponse(messages.WEB004.code, this.traceID, HttpStatus.OK, []))
            }
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
          .catch((error: Error) => {
            this.logger.error(getErrorLog(canonicalMethods.FIND_WEBSITE_TESTIMONIALS, this.traceID, { error }, error.message))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
      })
    })

  createWebsiteTestimonial = (testimonial: CreateTestimonialDTO, fileName: string) =>
    new Promise<ServiceResponse>((resolve) => {
      if (_.isNil(fileName)) {
        resolve(getAPIResponse(messages.WEB010.code, this.traceID, HttpStatus.FORBIDDEN))
      } else {
        createOperations
          .save(new this.testimonialModel({ ...testimonial, image: fileName }))
          .then((testimonialSaveResult: Testimonial) => {
            if (!_.isNil(testimonialSaveResult._id)) {
              findOperations
                .find(this.testimonialModel, {}, { __v: 0 })
                .then((websiteTestimonials: Testimonial[]) => {
                  if (!_.isNil(websiteTestimonials)) {
                    RedisHandler.getInstance().set(redisKeys.WEBSITE_TESTIMONIALS.value(), JSON.stringify(websiteTestimonials))
                    RedisHandler.getInstance().expire(redisKeys.WEBSITE_TESTIMONIALS.value(), redisKeys.WEBSITE_TESTIMONIALS.timeout())
                    resolve(getAPIResponse(messages.WEB009.code, this.traceID, HttpStatus.OK))
                  }
                  resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                })
                .catch((error: Error) => {
                  this.logger.error(getErrorLog(canonicalMethods.CREATE_TESTIMONIAL, this.traceID, { testimonial, error }, error.message))
                  resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                })
            } else {
              this.logger.error(getErrorLog(canonicalMethods.CREATE_TESTIMONIAL, this.traceID, { testimonial }))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              findOperations.findByIdAndDelete(this.testimonialModel, testimonialSaveResult._id, {})
            }
          })
          .catch((error: Error) => {
            this.logger.error(getErrorLog(canonicalMethods.CREATE_TESTIMONIAL, this.traceID, { error, testimonial }, error.message))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
      }
    })

  createWebsiteNotice = (notice: CreateNoticeDTO) =>
    new Promise<ServiceResponse>((resolve) => {
      createOperations
        .save(new this.noticeModel(notice))
        .then((noticeSaveResult: Notice) => {
          if (!_.isNil(noticeSaveResult._id)) {
            resolve(getAPIResponse(messages.WEB017.code, this.traceID, HttpStatus.OK))
          } else {
            this.logger.error(getErrorLog(canonicalMethods.CREATE_NOTICE, this.traceID, { notice }))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            findOperations.findByIdAndDelete(this.testimonialModel, noticeSaveResult._id, {})
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.CREATE_NOTICE, this.traceID, { error, notice }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  createUserMetadata = (payload: CreateMetadataDTO) =>
    new Promise<ServiceResponse>((resolve) => {
      storeUserMetadata(payload.data, this.traceID)
        .then(() => {
          payload.data = []
          this.contactsUploadQueue
            .add({ payload, traceID: this.traceID, instance: CreateMetadataDTO.name })
            .catch((error: Error) => {
              this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_CONTACTS, this.traceID, { payload }, error.message))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            })
            .then(() => {
              resolve(getAPIResponse(messages.WEB026.code, this.traceID, HttpStatus.OK))
            })
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.UPDATE_CLIENT_CONTACTS, this.traceID, { payload }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  fetchUserMetadata = (payload: FetchUserMetadataDTO) =>
    new Promise<ServiceResponse>((resolve) => {
      RedisHandler.getInstance().get(redisKeys.USER_API_KEY.value(payload.apiKey), async (error: Error, data: string) => {
        let user: User
        if (_.isNil(data)) {
          user = await findOperations.findOne(this.userModel, { apiKey: payload.apiKey })
          if (!_.isNil(user)) {
            RedisHandler.getInstance().set(redisKeys.USER_API_KEY.value(payload.apiKey), JSON.stringify(user))
            RedisHandler.getInstance().expire(redisKeys.USER_API_KEY.value(payload.apiKey), redisKeys.USER_API_KEY.timeout())
          } else {
            return resolve(getAPIResponse(messages.WEB028.code, this.traceID, HttpStatus.FORBIDDEN))
          }
        } else {
          user = JSON.parse(data)
        }
         RedisHandler.getInstance().get(redisKeys.USER_METADATA.value(`${payload.phone}`), (error: Error, data: string) => {
           if (_.isNil(error) && !_.isNil(data)) {
             return resolve(getAPIResponse(messages.WEB027.code, this.traceID, HttpStatus.OK, { name: data }))
           }
           return findOperations
             .findOneLean(this.userMetadataModel, { phone: payload.phone }, { __v: 0 })
             .then((userMetadata: UserMetadata) => {
               RedisHandler.getInstance().set(redisKeys.USER_METADATA.value(`${payload.phone}`), _.isNil(userMetadata) ? '' : userMetadata.name)
               RedisHandler.getInstance().expire(redisKeys.USER_METADATA.value(`${payload.phone}`), redisKeys.USER_METADATA.timeout())
               return resolve(getAPIResponse(messages.WEB027.code, this.traceID, HttpStatus.OK, { name: _.isNil(userMetadata) ? '' : userMetadata.name }))
             })
             .catch((error: Error) => {
               this.logger.error(getErrorLog(canonicalMethods.FIND_USER_METADATA, this.traceID, { error }, error.message))
               resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
             })
         })
      })
    })

  createWebsiteClient = (client: CreateClientDTO, fileName: string) =>
    new Promise<ServiceResponse>((resolve) => {
      if (_.isNil(fileName)) {
        resolve(getAPIResponse(messages.WEB010.code, this.traceID, HttpStatus.FORBIDDEN))
      } else {
        createOperations
          .save(new this.clientModel({ ...client, image: fileName }))
          .then((clientSaveResult: Client) => {
            if (!_.isNil(clientSaveResult._id)) {
              findOperations
                .find(this.clientModel, {}, { __v: 0 })
                .then((websiteClients: Client[]) => {
                  if (!_.isNil(websiteClients)) {
                    RedisHandler.getInstance().set(redisKeys.WEBSITE_CLIENTS.value(), JSON.stringify(websiteClients))
                    RedisHandler.getInstance().expire(redisKeys.WEBSITE_CLIENTS.value(), redisKeys.WEBSITE_CLIENTS.timeout())
                    resolve(getAPIResponse(messages.WEB012.code, this.traceID, HttpStatus.OK))
                  }
                  resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                })
                .catch((error: Error) => {
                  this.logger.error(getErrorLog(canonicalMethods.CREATE_WEBSITE_CLIENT, this.traceID, { client, error }, error.message))
                  resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
                })
            } else {
              this.logger.error(getErrorLog(canonicalMethods.CREATE_WEBSITE_CLIENT, this.traceID, { client }))
              resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              findOperations.findByIdAndDelete(this.testimonialModel, clientSaveResult._id, {})
            }
          })
          .catch((error: Error) => {
            this.logger.error(getErrorLog(canonicalMethods.CREATE_WEBSITE_CLIENT, this.traceID, { error, client }, error.message))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
          })
      }
    })

  toggleCLient = (id: string, url: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      let toggleActive = false
      if (_.includes(url, 'deactivate')) {
        toggleActive = false
      } else if (_.includes(url, 'activate')) {
        toggleActive = true
      }
      findOperations
        .findByIdAndUpdate(this.clientModel, id, { $set: { active: toggleActive } }, { new: true })
        .then((client: Client) => {
          if (!_.isNil(client)) {
            findOperations
              .find(this.clientModel, {}, { __v: 0 })
              .then((websiteClients: Client[]) => {
                if (!_.isNil(websiteClients)) {
                  RedisHandler.getInstance().set(redisKeys.WEBSITE_CLIENTS.value(), JSON.stringify(websiteClients))
                  RedisHandler.getInstance().expire(redisKeys.WEBSITE_CLIENTS.value(), redisKeys.WEBSITE_CLIENTS.timeout())
                  resolve(getAPIResponse(messages.WEB013.code, this.traceID, HttpStatus.OK))
                }
                resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              })
              .catch((error: Error) => {
                this.logger.error(getErrorLog(canonicalMethods.TOGGLE_WEBSITE_CLIENT, this.traceID, { client, error }, error.message))
                resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              })
          } else {
            resolve(getAPIResponse(messages.WEB015.code, this.traceID, HttpStatus.NOT_FOUND))
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.TOGGLE_WEBSITE_CLIENT, this.traceID, { id, url, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  toggleTestimonial = (id: string, url: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      let toggleActive = false
      if (_.includes(url, 'deactivate')) {
        toggleActive = false
      } else if (_.includes(url, 'activate')) {
        toggleActive = true
      }
      findOperations
        .findByIdAndUpdate(this.testimonialModel, id, { $set: { active: toggleActive } }, { new: true })
        .then((testimonial: Testimonial) => {
          if (!_.isNil(testimonial)) {
            findOperations
              .find(this.testimonialModel, {}, { __v: 0 })
              .then((testimonials: Testimonial[]) => {
                if (!_.isNil(testimonials)) {
                  RedisHandler.getInstance().set(redisKeys.WEBSITE_TESTIMONIALS.value(), JSON.stringify(testimonials))
                  RedisHandler.getInstance().expire(redisKeys.WEBSITE_TESTIMONIALS.value(), redisKeys.WEBSITE_TESTIMONIALS.timeout())
                  resolve(getAPIResponse(messages.WEB014.code, this.traceID, HttpStatus.OK))
                }
                resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              })
              .catch((error: Error) => {
                this.logger.error(getErrorLog(canonicalMethods.TOGGLE_TESTIMONIAL, this.traceID, { testimonial, error }, error.message))
                resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
              })
          } else {
            resolve(getAPIResponse(messages.WEB016.code, this.traceID, HttpStatus.NOT_FOUND))
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.TOGGLE_TESTIMONIAL, this.traceID, { id, url, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  toggleNotice = (id: string, url: string) =>
    new Promise<ServiceResponse>((resolve: (value?: ServiceResponse | PromiseLike<ServiceResponse>) => void) => {
      let toggleActive = false
      if (_.includes(url, 'deactivate')) {
        toggleActive = false
      } else if (_.includes(url, 'activate')) {
        toggleActive = true
      }
      findOperations
        .findByIdAndUpdate(this.noticeModel, id, { $set: { active: toggleActive } }, { new: true })
        .then((notice: Notice) => {
          if (!_.isNil(notice)) {
            resolve(getAPIResponse(messages.WEB018.code, this.traceID, HttpStatus.OK))
          } else {
            resolve(getAPIResponse(messages.WEB019.code, this.traceID, HttpStatus.NOT_FOUND))
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.TOGGLE_NOTICE, this.traceID, { id, url, error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  fetchWebsiteNotices = (active: string) =>
    new Promise<ServiceResponse>((resolve) => {
      const fetchActive: boolean = _.includes(active, 'active')
      const currentTimestamp = epochTimeFromDate(new Date())
      findOperations
        .find(this.noticeModel, fetchActive ? { active: true, created: { $lte: currentTimestamp }, expires: { $gt: currentTimestamp } } : {}, { _id: 0, __v: 0 })
        .then((websiteNotices: Notice[]) => {
          if (!_.isNil(websiteNotices)) {
            resolve(getAPIResponse(messages.WEB020.code, this.traceID, HttpStatus.OK, websiteNotices))
          }
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.FIND_WEBSITE_NOTICES, this.traceID, { error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  createWebsiteFeedback = (feedback: CreateFeedbackDTO) =>
    new Promise<ServiceResponse>((resolve) => {
      createOperations
        .save(new this.feedbackModel(feedback))
        .then((feedbackSaveResult: Feedback) => {
          if (!_.isNil(feedbackSaveResult._id)) {
            resolve(getAPIResponse(messages.WEB021.code, this.traceID, HttpStatus.OK))
          } else {
            this.logger.error(getErrorLog(canonicalMethods.CREATE_WEBSITE_FEEDBACKS, this.traceID, { feedback }))
            resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
            findOperations.findByIdAndDelete(this.testimonialModel, feedbackSaveResult._id, {})
          }
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.CREATE_WEBSITE_FEEDBACKS, this.traceID, { error, feedback }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  sendEmail = (payload: SendEmailDTO) =>
    new Promise<ServiceResponse>((resolve) => {
      const text = `Name: ${payload.name}, Email: ${payload.email}, Phone: ${payload.phone}, Subject: ${payload.subject}, Message: ${payload.message}`
      const html = `Name: ${payload.name}, <br /> Email: ${payload.email}, <br /> Phone: ${payload.phone}, <br /> Subject: ${payload.subject}, <br /> Message: ${payload.message}`
      this.mailerService
        .sendMail({
          to: 'tusharsadana@gmail.com', // list of receivers
          from: 'query@virtualityinnoventure.com', // sender address
          subject: "There's a Query on Virtuality Innoventure", // Subject line
          text, // plaintext body
          html // HTML body content
        })
        .then((res) => {
          resolve(getAPIResponse(messages.WEB023.code, this.traceID, HttpStatus.OK))
        })
        .catch((err) => {
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  getVirtualityDetails = () =>
    new Promise<ServiceResponse>((resolve) => {
      FireBaseHandler.getInstance()
        .database()
        .ref(virtuality_config.VIRTUALITY_WEBSITE)
        .once('value', (snapshot) => {
          //
          resolve(getAPIResponse(messages.WEB024.code, this.traceID, HttpStatus.OK, snapshot.val()))
        })
        .catch((err) => {
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  fetchWebsiteFeedback = () =>
    new Promise<ServiceResponse>((resolve) => {
      findOperations
        .find(this.feedbackModel, {})
        .then((feedbacks: Feedback[]) => {
          resolve(getAPIResponse(messages.WEB022.code, this.traceID, HttpStatus.OK, feedbacks))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.CREATE_WEBSITE_FEEDBACKS, this.traceID, { error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })

  setFeedbackViewed = (id: string) =>
    new Promise<ServiceResponse>((resolve) => {
      findOperations
        .findByIdAndUpdate(this.feedbackModel, id, { $set: { viewed: true } })
        .then((feedback: Feedback) => {
          resolve(getAPIResponse(messages.WEB025.code, this.traceID, HttpStatus.OK, feedback))
        })
        .catch((error: Error) => {
          this.logger.error(getErrorLog(canonicalMethods.SET_FEEDBACK_VIEWED, this.traceID, { error }, error.message))
          resolve(getAPIResponse(messages.COM001.code, this.traceID, HttpStatus.INTERNAL_SERVER_ERROR))
        })
    })
}
