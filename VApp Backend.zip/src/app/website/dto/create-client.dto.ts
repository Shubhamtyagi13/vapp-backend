import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsOptional, IsString } from 'class-validator'

export class CreateClientDTO {
  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly name: string

  @ApiProperty({ required: false })
  @IsString()
  @IsOptional()
  readonly link: string

  @ApiProperty({ type: 'file' })
  @IsOptional()
  image: any
}
