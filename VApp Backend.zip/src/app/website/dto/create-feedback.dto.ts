import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import { IsDefined, IsEmail, IsString } from 'class-validator'

export class CreateFeedbackDTO {
  @ApiProperty({ required: true })
  @IsEmail()
  @IsDefined()
  readonly email: string

  @ApiProperty({ required: true })
  @IsValidPhone()
  @IsDefined()
  readonly phone: number

  @ApiProperty({ required: true })
  @IsDefined()
  readonly name: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly message: string

  @ApiProperty({ required: true })
  @IsDefined()
  @IsString()
  readonly product: string
}
