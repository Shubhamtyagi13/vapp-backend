import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsOptional, IsString, IsUrl } from 'class-validator'

export class CreateTestimonialDTO {
  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly clientName: string

  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly text: string

  @ApiProperty({ required: false })
  @IsUrl({ protocols: ['http', 'https'], require_protocol: true, require_host: true })
  @IsOptional()
  readonly link: string

  @ApiProperty({ type: 'file' })
  @IsOptional()
  image: any
}
