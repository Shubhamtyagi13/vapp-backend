import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsOptional, IsString } from 'class-validator'

export class SendEmailDTO {
  readonly name: string

  readonly phone: string

  readonly email: string

  readonly subject: string

  readonly message: string
}
