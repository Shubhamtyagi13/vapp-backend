import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import { IsDefined, IsMongoId, IsString } from 'class-validator'

export class FetchUserMetadataDTO {
  @ApiProperty({ required: true, description: 'API key of your VAPP Account' })
  @IsString()
  @IsDefined()
  @IsMongoId()
  apiKey: string

  @ApiProperty({ required: true, description: '10 digits phone number for which metadata needs to be fetched', example: 1234567890 })
  @IsDefined()
  @IsValidPhone()
  readonly phone: number
}
