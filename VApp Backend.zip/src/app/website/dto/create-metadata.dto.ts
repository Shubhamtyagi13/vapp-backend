import { ApiProperty } from '@nestjs/swagger'
import { IsValidPhone } from '@transformers/phone.transformer'
import { Type } from 'class-transformer'
import { ArrayMinSize, IsArray, IsDefined, IsNotEmpty, IsString, ValidateNested } from 'class-validator'

export class UserMetadataDTO {
  @ApiProperty({ required: true })
  @IsDefined()
  @IsValidPhone()
  readonly phone: number

  @ApiProperty({ required: true })
  @IsString()
  @IsNotEmpty()
  readonly name: string
}
export class CreateMetadataDTO {
  @ApiProperty({ required: true })
  @IsArray()
  @ValidateNested({ each: true })
  @ArrayMinSize(1)
  @Type(() => UserMetadataDTO)
  data: Array<UserMetadataDTO>
}
