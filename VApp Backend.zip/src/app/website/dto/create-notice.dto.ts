import { ApiProperty } from '@nestjs/swagger'
import { IsDefined, IsNumber, IsOptional, IsString } from 'class-validator'

export class CreateNoticeDTO {
  @ApiProperty({ required: true })
  @IsString()
  @IsDefined()
  readonly message: string

  @ApiProperty({ required: false })
  @IsNumber()
  @IsOptional()
  readonly created: number

  @ApiProperty({ required: true })
  @IsNumber()
  @IsDefined()
  readonly expires: number

  @ApiProperty({ required: true })
  @IsString()
  @IsOptional()
  readonly link: string
}
