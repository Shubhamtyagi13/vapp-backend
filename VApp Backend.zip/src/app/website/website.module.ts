import { UploadClientContactsQueueModule } from '@app/contact/cron/queue.module'
import { User, UserSchema } from '@app/user/user.schema'
import { Module } from '@nestjs/common'
import { MongooseModule } from '@nestjs/mongoose'
import { VappLogger } from '@services/logger.service'
import { UserMetadata, UserMetadataSchema } from './user-metadata.schema'
import { WebsiteController } from './website.controller'
import { Client, ClientSchema, Feedback, FeedbackSchema, Notice, NoticeSchema, Testimonial, TestimonialSchema } from './website.schema'
import { WebsiteService } from './website.service'

@Module({
  imports: [
    UploadClientContactsQueueModule,
    MongooseModule.forFeature([
      { name: User.name, schema: UserSchema },
      { name: Testimonial.name, schema: TestimonialSchema },
      { name: Client.name, schema: ClientSchema },
      { name: Notice.name, schema: NoticeSchema },
      { name: Feedback.name, schema: FeedbackSchema },
      { name: UserMetadata.name, schema: UserMetadataSchema }
    ])
  ],
  controllers: [WebsiteController],
  providers: [WebsiteService, VappLogger]
})
export class WebsiteModule {}
