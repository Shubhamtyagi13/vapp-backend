import {
  audience, contentTypes, environments, image_intercept, variables,
} from '@config'
import { Audience } from '@decorators/audience.decorator'
import { AuthenticationGuard } from '@guards/authentication.guard'
import { ImageInterceptor } from '@interceptors/image.interceptor'
import { APIResponse } from '@interfaces/response.interface'
import {
  Body, Controller, Get, Param, Post, Req, Res, UseGuards, UseInterceptors,
} from '@nestjs/common'
import {
  ApiBearerAuth, ApiConsumes, ApiExcludeController, ApiExcludeEndpoint, ApiTags,
} from '@nestjs/swagger'
import { getEnvironmentVariable } from '@utils/platform.util'
import { Request, Response } from 'express'
import _ from 'lodash'
import { CreateClientDTO } from './dto/create-client.dto'
import { CreateFeedbackDTO } from './dto/create-feedback.dto'
import { CreateMetadataDTO } from './dto/create-metadata.dto'
import { CreateNoticeDTO } from './dto/create-notice.dto'
import { CreateTestimonialDTO } from './dto/create-testimonial.dto'
import { FetchUserMetadataDTO } from './dto/fetch-metadata.dto'
import { SendEmailDTO } from './dto/send-email.dto'
import { WebsiteService } from './website.service'

@ApiTags(WebsiteController.name)
@ApiBearerAuth('Authorization Bearer Token')
@Controller('website')
export class WebsiteController {
  constructor(private websiteService: WebsiteService) {}

  /*
   fetch all website clients
  */
  @Get(['client/all', 'client/active'])
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  fetchClients(@Res() response: Response<APIResponse>, @Req() request: Request) {
    this.websiteService.fetchWebsiteClients(request.url.replace('/', '')).then((service_response) => response.status(service_response.status).send(service_response))
  }

  /*
   fetch all website testimonials
  */
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  @Get(['testimonial/all', 'testimonial/active'])
  fetchTestimonials(@Res() response: Response<APIResponse>, @Req() request: Request) {
    this.websiteService.fetchWebsiteTestimonials(request.url.replace('/', '')).then((service_response) => response.status(service_response.status).send(service_response))
  }

  /*
   create new website testimonial
  */
  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @ApiConsumes(contentTypes.MULTIPART.FORM_DATA)
  @UseInterceptors(ImageInterceptor(image_intercept.TESTIMONIAL))
  @Post('testimonial')
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  uploadTestimonial(@Res() response: Response<APIResponse>, @Req() request: Request, @Body() testimonial: CreateTestimonialDTO) {
    this.websiteService.createWebsiteTestimonial(testimonial, request.fileName).then((service_response) => response.status(service_response.status).send(service_response))
  }

  /*
   create new website client
  */
  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @ApiConsumes(contentTypes.MULTIPART.FORM_DATA)
  @UseInterceptors(ImageInterceptor(image_intercept.CLIENT))
  @Post('client')
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  uploadClient(@Res() response: Response<APIResponse>, @Req() request: Request, @Body() client: CreateClientDTO) {
    this.websiteService.createWebsiteClient(client, request.fileName).then((service_response) => response.status(service_response.status).send(service_response))
  }

  /*
   deactivate or activate client by ID
  */
  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get(['client/activate/:id', 'client/deactivate/:id'])
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  toggleClient(@Res() response: Response, @Req() request: Request, @Param('id') id: string) {
    this.websiteService.toggleCLient(id, request.url).then((service_response) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   deactivate or activate testimonial by ID
  */
  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get(['testimonial/activate/:id', 'testimonial/deactivate/:id'])
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  toggleTestimonial(@Res() response: Response, @Req() request: Request, @Param('id') id: string) {
    this.websiteService.toggleTestimonial(id, request.url).then((service_response) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   create new website notice
  */
  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Post('notice')
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  createNotice(@Res() response: Response<APIResponse>, @Req() request: Request, @Body() notice: CreateNoticeDTO) {
    this.websiteService.createWebsiteNotice(notice).then((service_response) => response.status(service_response.status).send(service_response))
  }

  /*
   upload user metadata
  */
  @Audience([audience.ADMIN])
  @Post('metadata')
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  uploadUserMetadata(@Body() payload: CreateMetadataDTO, @Res() response: Response<APIResponse>, @Req() request: Request) {
    this.websiteService.createUserMetadata(payload).then((service_response) => response.status(service_response.status).send(service_response))
  }

  /*
   upload user metadata
  */
  @Post('fetch-metadata')
  fetchUserMetadata(@Body() payload: FetchUserMetadataDTO, @Res() response: Response<APIResponse>, @Req() request: Request) {
    this.websiteService.fetchUserMetadata(payload).then((service_response) => response.status(service_response.status).send(service_response))
  }

  /*
   deactivate or activate notice by ID
  */
  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get(['notice/activate/:id', 'notice/deactivate/:id'])
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  toggleNotice(@Res() response: Response, @Req() request: Request, @Param('id') id: string) {
    this.websiteService.toggleNotice(id, request.url).then((service_response) => response.status(service_response.status).send(<APIResponse>service_response))
  }

  /*
   fetch all website testimonials
  */
  @Get(['notice/all', 'notice/active'])
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  fetchNotices(@Res() response: Response<APIResponse>, @Req() request: Request) {
    this.websiteService.fetchWebsiteNotices(request.url.replace('/', '')).then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Get(['virtuality'])
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  virtuality(@Res() response: Response<APIResponse>, @Req() request: Request) {
    this.websiteService.getVirtualityDetails().then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Post('/feedback')
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  createFeedback(@Res() response: Response<APIResponse>, @Body() feedback: CreateFeedbackDTO) {
    this.websiteService.createWebsiteFeedback(feedback).then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Post('/email')
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  sendEmail(@Res() response: Response<APIResponse>, @Body() feedback: SendEmailDTO) {
    this.websiteService.sendEmail(feedback).then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get('/feedback')
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  fetchFeedback(@Res() response: Response<APIResponse>) {
    this.websiteService.fetchWebsiteFeedback().then((service_response) => response.status(service_response.status).send(service_response))
  }

  @Audience([audience.ADMIN])
  @UseGuards(AuthenticationGuard)
  @Get('/feedback/viewed/:id')
  @ApiExcludeEndpoint(_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.production))
  setFeedbackViewed(@Res() response: Response<APIResponse>, @Param('id') id: string) {
    this.websiteService.setFeedbackViewed(id).then((service_response) => response.status(service_response.status).send(service_response))
  }
}
