import { tables } from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.TESTIMONIAL.collection, autoCreate: true })
export class Testimonial extends Document {
  @Prop({ type: String, required: true })
  clientName: string

  @Prop({ type: String, index: true, required: true })
  text: string

  @Prop({ type: String, default: null })
  image: string

  @Prop({ type: Boolean, default: true, index: true })
  active: boolean

  @Prop({ type: String, default: null })
  link: string
}

@Schema({ collection: tables.CLIENTS.collection, autoCreate: true })
export class Client extends Document {
  @Prop({ type: String, required: true })
  name: string

  @Prop({ type: String, default: null })
  image: string

  @Prop({ type: Boolean, default: true, index: true })
  active: boolean

  @Prop({ type: String, default: null })
  link: string
}

@Schema({ collection: tables.NOTICES.collection, autoCreate: true })
export class Notice extends Document {
  @Prop({ type: String, required: true })
  message: string

  @Prop({ type: Boolean, default: true, index: true })
  active: boolean

  @Prop({ type: Number, default: Math.floor(new Date().getTime() / 1000), index: true })
  created: number

  @Prop({ type: Number, required: true, index: true })
  expires: number

  @Prop({ type: String, default: null })
  link: string
}

@Schema({ collection: tables.FEEDBACK.collection, autoCreate: true })
export class Feedback extends Document {
  @Prop({ type: String, required: true })
  email: string

  @Prop({type:Number,required:true})
  phone:number

  @Prop({type:String,required:true})
  name:string

  @Prop({ type: String, required: true })
  message: string

  @Prop({ type: String, required: true })
  product: string

  @Prop({type:Boolean, required:false, default: false})
  viewed : boolean
}

export const ClientSchema = SchemaFactory.createForClass(Client)

export const TestimonialSchema = SchemaFactory.createForClass(Testimonial)

export const NoticeSchema = SchemaFactory.createForClass(Notice)

export const FeedbackSchema = SchemaFactory.createForClass(Feedback)
