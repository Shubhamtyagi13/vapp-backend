import { tables,
} from '@config'
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose'
import { Document } from 'mongoose'

@Schema({ collection: tables.USER_METADATA.collection, autoCreate: true })
export class UserMetadata extends Document {
  @Prop({ type: Number, index: true, required: true, unique: true })
  phone: number

  @Prop({ type: String, index: true, required: true })
  name: string
}

export const UserMetadataSchema = SchemaFactory.createForClass(UserMetadata)
