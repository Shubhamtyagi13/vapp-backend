import dotenv from 'dotenv'

dotenv.config()
import { cronJobs, environments, variables } from '@config'
import { CoreCronModule } from '@core/core.cron.module'
import { consortium } from '@messages'
import { NestFactory } from '@nestjs/core'
import { NestExpressApplication } from '@nestjs/platform-express'
import { VappLogger } from '@services/logger.service'
import { ConfigHandler } from '@utils/config.util'
import { getAllowedOrigin, getArgs, getEnvironmentVariable } from '@utils/platform.util'
import { json, urlencoded } from 'body-parser'
import cookieParser from 'cookie-parser'
import _ from 'lodash'
import fs from 'fs'
import { SocketAapter } from '@utils/socket.util'
import { GenericObject } from '@interfaces/generic.interface'

const cronPortSwitcher = () => {
  const cron_processor = (getArgs() as GenericObject).cron
  const options = [
    cronJobs.UPLOAD_DELIVERY_REPORT.name,
    cronJobs.CREATE_CAMPAIGN_REPORT.name,
    cronJobs.CREATE_REPORT.name,
    cronJobs.ENGAGEMENT_TRACKING.name,
    cronJobs.CREATE_SMS_CAMPAIGN.name,
    cronJobs.CREATE_WHATSAPP_CAMPAIGN.name,
    cronJobs.CREATE_DRIP_SMS_CAMPAIGN.name,
    cronJobs.CREATE_DRIP_WHATSAPP_CAMPAIGN.name,
    cronJobs.UPLOAD_CLIENT_CONTACTS.name,
    cronJobs.IVR_WEBHOOK.name,
    cronJobs.IVR_WEBHOOK_FINALIZE.name,
    cronJobs.UPLOAD_DELIVERY_REPORT.name,
    cronJobs.PROCESS_INTEGRATIONS.name,
    cronJobs.CREATE_RBM_CAMPAIGN.name
  ]
  return 4000 + options.indexOf(cron_processor)
}

const bootstrap = () => {
  const logger = new VappLogger()
  return new Promise<boolean>((resolve: (value?: boolean | PromiseLike<boolean>) => void, reject: (reason?: unknown) => void) => {
    const port = cronPortSwitcher()
    const address: string = getEnvironmentVariable(variables.ADDRESS.name)
    const httpsOptions = {}
    if (!_.eq(getEnvironmentVariable(variables.VAPP_ENV.name), environments.local)) {
      // httpsOptions = _.assign(httpsOptions, {
      //   key: fs.readFileSync(getEnvironmentVariable(variables.SERVER_PRIVATE_KEY.name)),
      //   cert: fs.readFileSync(getEnvironmentVariable(variables.SERVER_FULLCHAIN_KEY.name)),
      // })
    }
    NestFactory.create<NestExpressApplication>(CoreCronModule)
      .then((app: NestExpressApplication) => {
        ConfigHandler.getInstance()
        app.set('trust proxy', 1)
        app.use(cookieParser())
        app.disable('x-powered-by')
        app.enableCors({
          origin: getAllowedOrigin(),
          credentials: true
        })
        app.use(json({ limit: '1gb', strict: true }))
        app.use(urlencoded({ limit: '1gb', extended: true }))
        app.setGlobalPrefix(getEnvironmentVariable(variables.API_PREFIX.name))
        app.useLogger(logger)
        app.useWebSocketAdapter(new SocketAapter(app))
        app.listen(port, address).then(() => {
          app
            .getUrl()
            .then((url: string) => {
              logger.log(`${consortium.initialised(url, port)}`)
              resolve(true)
            })
            .catch((error: Error) => {
              logger.error(error.message)
              reject()
              process.exit(0)
            })
        })
      })
      .catch((error: Error) => {
        logger.error(error.message)
        reject()
        process.exit(0)
      })
  })
}

bootstrap()
